/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

/**
  * @author bsp, created on 2004-06-26
  */
public class JTDS_SQLServer extends SQLServer {

    // url: jdbc:jtds:sqlserver://localhost:2914

    public String getDriverClass() {
        return "net.sourceforge.jtds.jdbc.Driver";
    }

    public boolean isSystemTable(String tableName) {
        tableName = tableName.toUpperCase();
        if (tableName.equals("DTPROPERTIES")) { return true; }
        return super.isSystemTable(tableName);
    }
}

