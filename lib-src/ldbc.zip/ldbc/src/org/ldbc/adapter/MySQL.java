/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import java.sql.*;
import java.io.*;
import java.util.*;

/**
 *
 * Currently, only 'MySQL Max 4.0.2' is supported
 *
 * Link for docs:
 * http://www.mysql.com/doc/en/index.html
 *
 * Known issues:
 *
 * MySQL doesn't support EXISTS and IN(SELECT...)
 * SELECT * FROM TEST WHERE ID IN(SELECT ID FROM TEST)
 * SELECT * FROM TEST T1 WHERE EXISTS(SELECT * FROM TEST T2 WHERE T1.ID=T2.ID)
 *
 * DatabaseMetaData stores tables in lowercase, 
 * but columns in mixed case. Not sure what the rule is.
 * storesLowerCaseIdentifiers=false
 * storesLowerCaseQuotedIdentifiers=false
 * storesMixedCaseIdentifiers=true
 * storesMixedCaseQuotedIdentifiers=false
 * storesUpperCaseIdentifiers=false
 * storesUpperCaseQuotedIdentifiers=false
 * create table MiXeD2(UPPER INT,lower int,MiXed1 int, mIxEd2 int)
 * getTables: mixed
 * getColumns: mixed ; UPPER ; lower ; MiXed1 ; mIxEd2
 * (bug logged 2002-07-15)
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getPrimaryKeys
 * Column PK_NAME returns the colum, not the name of the index itself.
 * For example, a table CREATE TABLE(ID INT PRIMARY KEY,NAME VARCHAR(255)),
 * the row returned is:
 * TABLE_NAME: TEST; COLUMN_NAME: ID; PK_NAME: ID
 * expected result:   
 * TABLE_NAME: TEST; COLUMN_NAME: ID; PK_NAME: PRIMARY
 * (workaround: use 'PRIMARY' as the index name for MySQL)
 * (bug logged 2002-07-15)
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getPrimaryKeys:
 * The result is not sorted by column name. According to the specs, if must
 * be sorted by column name.
 * (workaround implemented in the JDBC driver)
 *
 * Doesn't automatically detect if a columns is supposed to be NOT NULL, as in:
 * CREATE TABLE TEST(ID INT, PRIMARY KEY(ID))
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getTables is not sorted by TABLE_SCHEM, TABLE_NAME
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getColumns is not sorted by TABLE_SCHEM, TABLE_NAME, ORDINARY_POSITION 
 * (workaround implemented in the JDBC driver)
 *
 * Statement.executeQuery allows CREATE TABLE, should throw an Exception
 * (workaround implemented in the JDBC driver)
 *
 * Positive signs with space between sign and value are not supported:
 * SELECT + 1 FROM TEST fails 
 * SELECT +1 FROM TEST works
 * SELECT - 1 FROM TEST works
 * (workaround implemented in the JDBC driver)
 *
 * MySQL supports a non-standard escape syntax for text data (using \):
 * SELECT '\%' FROM TEST results in '%' instead of '\%'
 * (workaround implemented in the JDBC driver)
 *
 * MySQL currently truncates empty spaces at the end of a VARCHAR, so that
 * SELECT ' HI ' FROM TEST results in ' HI' instead of ' HI '
 *
 * ResultSet.getInt() throws an exception if the data type is DECIMAL,
 * according to the specs a conversion should be made.
 *
 * ResultSet.getString() on a DECIMAL data type should return the value formatted
 * for example for DECIMAL(10,2) the returned value should be 0.00 and not 0
 *
 * ResultSetMetaData precision and scale are not returned correctly - for always 1 too much.
 * CREATE TABLE TEST(X DECIMAL(10,2)) ... SELECT * FROM TEST will return precision 11, scale 3.
 * for VARCHAR, the precision is always 0.
 *
 * CAST(column AS INTEGER) is not supported.
 * CAST(column AS SIGNED) must be used instead. 
 * This is non-standard.
 * (workaround implemented in the JDBC driver)
 * 
 * CAST(column AS VARCHAR(255)) is not supported.
 * CAST(column AS BINARY) must be used instead.
 * This is non-standard.
 * (workaround implemented in the JDBC driver)
 *
 * String concatenation using || doesn't work as expected: it's a logical OR. 
 * That's like in C / C++ / Java, but not ANSI SQL.
 *
 * MySQL doesn't return the data type 'DATE' for constant, it always returns VARCHAR or INT.
 *  
 * If autocommit is true and commit is called, the following exception is thrown:
 * 'Can't call commit when autocommit=true'
 * All other databases don't throw this exception.
 *
 * To support transaction, currently all tables are created as INNODB tables. 
 *
 * Should throw a exception if PreparedStatement.setObject(1,null) is called.
 * See also JDBC API Tutorial and Reference, Second Edition,
 * page 544, 24.1.5 Sending JDBC NULL as an IN parameter 
 *
 * Statement / PreparedStatement.getMoreResults
 * Implementation is wrong somehow.
 * After this call: stat.executeQuery("SELECT * FROM TEST")
 * the following method returns true: stat.getMoreResults() 
 * and rs.next() throws a NullPointerException
 *
 * LIKE ... ESCAPE is not supported. Escape is ANSI standard.
 *
 * ResultSet.getRow() doesn't return the correct value.
 *
 * ResultSet.setFetchSize(100) after Statement.setMaxRows(50) should throw
 * an exception, but doesn't.
 *
 * Statement / PreparedStatement setMaxFieldSize is ignored.
 *
 * Statement / PreparedStatement getMaxFieldSize returns 1048576 instead of 0.
 *
 * PreparedStatement.getMetaData() throws an exception:
 * com.mysql.jdbc.NotImplemented: Feature not implemented
 * It should return null because the driver cannot return a ResultSetMetaData object
 * (see JDBC API Tutorial an Reference, Second Edition, page 552, 
 * PreparedStatement.getMetaData())
 *
 * PreparedStatement.setDate, Time, Timestamp and ResultSet.getDate, Time, Timestamp with calendar
 * are not implemented correctly
 *
 * Batch update bug:
 * The driver seems to supports continued updates, but the buggy update
 * should have an update count of -3.
 *
 * ResultSet.getCharacterStream is not implemented
 * com.mysql.jdbc.NotImplemented: Feature not implemented
 *     at com.mysql.jdbc.ResultSet.getCharacterStream(ResultSet.java:852)
 *
 * When using LONGTEXT as a column type, and using
 * DatabaseMetaData.getColumns, then calling getInt("COLUMN_SIZE"),
 * the following exception is thrown:
 * java.sql.SQLException: Invalid value for getInt() - '2147483657'
 * probably 2147483657 is the wrong value, because Integer.MAX_VALUE is
 * 2147483647 (47, not 57).
 *
 * Calling PreparedStatement.setBytes on a LONGBLOB with
 * 500'000 bytes fails with the exception:
 * com.mysql.jdbc.PacketTooBigException: Packet for query is too large 
 * (1'266'398 > 1'048'576)
 * All other databases work fine with this size.
 * But two blobs with 400'000 bytes each works fine.
 *
 * Foreign keys need an explicit index on the child column, for example:
 * CREATE TABLE parent(id INT NOT NULL, PRIMARY KEY (id)) TYPE=INNODB;
 * CREATE TABLE child(id INT, parent_id INT, INDEX par_ind (parent_id),
 *    FOREIGN KEY (parent_id) REFERENCES parent(id) ON DELETE SET NULL
 * ) TYPE=INNODB;
 * All other databases do not require this. They probably just go ahead and
 * create the index themselves, if one is required.
 *
 *
 * DatabaseMetaData.getExportedKeys and getCrossReference don't work. 
 * They always returns 0 rows.
 *
 * DatabaseMetaData.getImportedKeys, getExportedKeys and getCrossReference
 * return the wrong data type for many columns.
 *
 * MySQL doesn't understand quoted names in CREATE TABLE (and probably other) statements.
 * 
 * MySQL does not support user defined constraint names: 
 * CREATE TABLE XREF_COMPLEX_B(A INT NULL,B INT NOT NULL, C INT NULL, PRIMARY KEY(C,B))
 * CREATE TABLE XREF_COMPLEX_A(A INT NULL,B INT NOT NULL, C INT NULL, PRIMARY KEY(A,C), 
 *             CONSTRAINT XYZ FOREIGN KEY(A,B) REFERENCES XREF_COMPLEX_B(C,B))
 * Afterwards, the constraint name (retrieved using DatabaseMetaData.getImportedKeys)
 * is not XYZ but some number, for example 0_1073.
 * 
 * X and Y are keywords!
 * 
 */
public class MySQL extends Base implements Adapter {
    // url: jdbc:mysql://[hostname][:port]/[dbname][?param1=value1][&param2=value2].....
    // url: jdbc:mysql://localhost/test
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        //return "org.gjt.mm.mysql.Driver";
        return "com.mysql.jdbc.Driver";
    }
    public String getStringConstant(String s) {
        char[] ch=s.toCharArray();
        StringBuffer buff=new StringBuffer();
        buff.append("'");
        for(int i=1;i<ch.length-1;i++) {
            char c=ch[i];
            if(c=='\\') {
                buff.append(c);
            }
            buff.append(c);
        }
        buff.append("'");
        return buff.toString();
    }
    public void convertDataType(DataType type) throws SQLException {
        int precision=type.getPrecision();
        int scale=type.getScale();
        switch(type.getDataType()) {
        case Types.LONGVARBINARY:
        case Types.BINARY:
        case Types.VARBINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
        case Types.SMALLINT:
        case Types.BIGINT:
            type.update(Types.INTEGER,0,0);
            break;
        case Types.DOUBLE:
            type.update(Types.DECIMAL,precision,scale);
            break;
        case Types.CHAR:
            type.update(Types.VARCHAR,precision,scale);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    public String getBinaryConstant(String s) {
        if(s.length()==0) {
            return "''";
        }
        return "0x"+s;
    }
    public String getCast(String value,DataType type) throws SQLException {
        String s="";
        switch(type.getDataType()) {
        case Types.INTEGER:
            // special case: VARCHAR is converted to number automatically
            return "(("+value+")+0)";
        case Types.VARCHAR:
            // special case: VARCHAR is converted to number automatically
            return "CONCAT("+value+")";
        case Types.TIMESTAMP:
            s="DATETIME";
            break;
        case Types.DECIMAL:
            // special case: VARCHAR is converted to number automatically
            return "("+value+"+0.0)";
        }
        return "CAST("+value+" AS "+s+")";
    }
    public String getStringConcatenation(String a,String b) {
        return "CONCAT("+a+","+b+")";
    }
    public String getCreateTable(String tableName, String columns, String option) {
        return "CREATE TABLE "+quote(tableName)+"("+columns+") TYPE=InnoDB";
    }
    public void init() throws SQLException {
        Connection conn=nativeConn;
        Statement stat=conn.createStatement();
        ResultSet rs=stat.executeQuery("show variables like \"have_innodb\"");
        if(!rs.next() || !rs.getString("Value").equals("YES")) {
            throw Factory.getGeneralException("This database does not support InnoDB.");
        }
        rs.close();
        stat.close();
    }
    public Reader getCharacterStream(ResultSet rs,int columnIndex) throws SQLException {
        String s=rs.getString(columnIndex);
        if(s==null) {
            return null;
        }
        return new StringReader(s);
    }
    public boolean needExplicitIndexOnForeignKey() {
        return true;
    }
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName)+" ON "+quote(tableName);
    }
    public String quote(String identifier) {
        return identifier.toUpperCase();
    }

    public boolean isPrimaryKey(String indexname, String pkname) {
        if(indexname.equals(pkname)) {
            return true;
        } else if(indexname.equals("PRIMARY")) {
            return true;
        }
        return false;
    }
    
    public String getForeignKeyName(String table, String originalName) throws SQLException {
        if(originalName==null) {
            // no chance
            return originalName;
        }
        Hashtable numbers = new Hashtable();
        Hashtable names = new Hashtable();
        mapForeignKeys(table, numbers, names);
        String name = (String)numbers.get(originalName);
        if(name == null) {
            throw Factory.getGeneralException("Could not map foreign key: table="+table+" original="+originalName);
        }
        return name;
    }

    private void mapForeignKeys(String table, Hashtable numbers, Hashtable names) throws SQLException {
        ResultSet rs = nativeConn.getMetaData().getImportedKeys(null, null, table);
        int id = 1; 
        while(rs.next()) {
            String number=rs.getString(12);
            if(number!=null && numbers.get(number) == null) {
                String name = "FK_"+id;
                id++;
                numbers.put(number, name);
                names.put(name, number);
            }
        }
    }
    
    public String getDropForeignKeyStatement(String tableName, String fkName) throws SQLException {
        Hashtable numbers = new Hashtable();
        Hashtable names = new Hashtable();
        mapForeignKeys(tableName, numbers, names);
        String number = (String)numbers.get(fkName);
        if(number == null) {
            throw Factory.getGeneralException("Could not map foreign key: table="+tableName+" name="+fkName);
        }
        return "ALTER TABLE "+quote(tableName)+" DROP FOREIGN KEY "+quote(number);
    }

    public String getSelect(boolean distinct, String top, String rest) throws SQLException {
        String select="SELECT ";
        if(distinct) {
            select+="DISTINCT ";
        }
        select+=rest;
        if(top!=null) {
            select += " LIMIT "+top;
        }
        return select;     
    }
    
    protected void autoIncLoadColumns() throws SQLException {
        autoIncColumns = new Hashtable();
        DatabaseMetaData meta = nativeConn.getMetaData();
        ResultSet rs = meta.getColumns(null, null, null, null);
        while(rs.next()) {
            String remarks = rs.getString("REMARKS");
            if(remarks!=null && remarks.equalsIgnoreCase("auto_increment")) {
                String tableName = rs.getString("TABLE_NAME").toUpperCase();
                String columnName = rs.getString("COLUMN_NAME").toUpperCase();
                // we don't know the column names yet
                Table table = new Table(tableName, null, columnName);
                autoIncColumns.put(tableName, table);
            }
        }
        rs.close();
        // get the column names
        for (Enumeration t = autoIncColumns.keys(); t.hasMoreElements();) {
            String tableName = (String) t.nextElement();
            Table table = (Table) autoIncColumns.get(tableName);
            rs = meta.getColumns(null, null, tableName, null);
            Vector v = new Vector();
            while (rs.next()) {
                v.addElement(rs.getString("COLUMN_NAME").toUpperCase());
            }
            rs.close();
            String[] cols = new String[v.size()];
            v.copyInto(cols);
            table.setColumns(cols);
        }
    }

    public void autoIncAddColumn(String tableName, String[] cols,
            String columnName) throws SQLException {
        if (autoIncColumns == null) {
            autoIncLoadColumns();
        }
        Table table = new Table(tableName, cols, columnName);
        autoIncColumns.put(tableName, table);
    }
    
    public void autoIncPreInsert(PreparedStatement nativePrep, boolean autoValue, Command command)
            throws SQLException {
        if(autoValue) {
            nativePrep.setNull(1, Types.INTEGER);
        }
    }
    
    public void autoIncPostInsert(PreparedStatement nativePrep,Command command) throws SQLException {
        // nothing to do
    }
    
    public int autoIncGetLastId() throws SQLException {
        Statement stat = nativeConn.createStatement(); 
        ResultSet rs = stat.executeQuery("SELECT @@IDENTITY as lastid");
        rs.next();
        int lastId = rs.getInt(1);
        rs.close();
        stat.close();
        return lastId;
    }

    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.CLOB:
            return "MEDIUMTEXT";
        case Types.BLOB:
            return "MEDIUMBLOB";
        }
        String sql = getDefaultDataTypeString(type);
        if(autoIncrement) {
            sql += " AUTO_INCREMENT";
        }
        return sql;
    }
}
