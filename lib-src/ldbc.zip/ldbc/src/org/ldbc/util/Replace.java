package org.ldbc.util;

import java.util.*;
import java.io.*;

public class Replace {
    /**
     * Uses apache - jakarta regexp package
     * see also: http://jakarta.apache.org/regexp/apidocs/
     */
     
    public static void main(String a[]) {
        Replace app=new Replace();
        app.mRecurse=false;
        app.mExtension=".html";
        app.mFile=null;
        String directory=".";
        for(int i=0;i<a.length;i++) {
            String s=a[i];
            if(s.equals("-?")) {
                System.out.println("Options: ");
                System.out.println("-r+            recurse subdirectories");
                System.out.println("-t <t1> <t2>   replace text with text2");
                System.out.println("-e <extension> process only this files");
                System.out.println("               default: .html");
                System.out.println("-d <dir>       directory to process");
                System.out.println("               default: .");
                System.out.println("-l <file>      use properties file");
                return;
            } else if(s.equals("-r+")) {
                app.mRecurse=true;
            } else if(s.equals("-t")) {
                app.mText1=a[++i];
                app.mText2=a[++i];
            } else if(s.equals("-d")) {
                directory=a[++i];
            } else if(s.equals("-e")) {
                app.mExtension=a[++i];
            } else if(s.equals("-l")) {
                app.mFile=a[++i];
            }
        }
        try {
            app.prepare();
            app.processDir(directory,0);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    boolean mRecurse;
    String mExtension;
    String mText1;
    String mText2;
    String[] mOriginal;
    String[] mReplace;
    String mFile;
    
    RE mRE = new RE();
    REDebugCompiler mCompiler = new REDebugCompiler();
    REProgram[] mPattern;
    
    
    void processDir(String path,int level) throws Exception {
        File f = new File(path);
        if (f.isFile()) {
            if(path.toLowerCase().endsWith(mExtension.toLowerCase())) {
                processFile(path);
            }
        } else if (f.isDirectory() && (mRecurse || level==0)) {
            String list[] = f.list();
            for (int i = 0; i < list.length; i++) {
                processDir(path+File.separatorChar+list[i],level+1);
            }
        }
    }
    void prepare() throws Exception {
        Vector t1=new Vector();
        Vector t2=new Vector();
        if(mFile!=null) {
            LineNumberReader r=new LineNumberReader(new FileReader(mFile));
            while(true) {
                String s=null;
                do {
                    s=r.readLine();
                    if(s==null) {
                        break;
                    }
                } while(s.equals(""));
                if(s==null) {
                    break;
                }
                t1.addElement(s.trim());
                s=r.readLine();
                t2.addElement(s.trim());
            }
            r.close();
        }
        if(mText1!=null) {
            t1.addElement(mText1);
            t2.addElement(mText2);
        }
        
        //mPattern=new Pattern[t1.size()];
        mPattern=new REProgram[t1.size()];
        
        mOriginal=new String[t1.size()];
        t1.copyInto(mOriginal);
        
        mReplace=new String[t2.size()];
        t2.copyInto(mReplace);
        for(int i=0;i<t1.size();i++) {
            String pattern=(String)t1.elementAt(i);
            
            //mPattern[i]=Pattern.compile(pattern);
            mPattern[i]=mCompiler.compile(pattern);
            
            System.out.println("replace "+pattern+" with "+mReplace[i]);
        }
    }
    void processFile(String name) throws Exception {
        File f=new File(name);
        File fnew = new File(name + ".new");
        int len=(int)f.length();
        FileReader read=new FileReader(f);
        char[] buffer=new char[len];
        int left=len;
        while(left>0) {
            left-=read.read(buffer,left-len,left);
        }
        read.close();
        String s=new String(buffer);
        System.out.println("process "+name);
        for(int i=0;i<mPattern.length;i++) {
            
            //Pattern p=mPattern[i];
            REProgram p=mPattern[i];
            
            //Matcher m=p.matcher(s);
            mRE.setProgram(p);
            
            //s=m.replaceAll(mReplace[i]);
            s=mRE.subst(s,mReplace[i]);
            /*
            String replace=mReplace[i];
            int index=replace.indexOf('*');
            if(index==-1) {
                 s=mRE.subst(s,mReplace[i]);
            } else {
                String original=mOriginal[i];
                while(true) {
                    boolean match;
                    match=mRE.match(s);
                    if(!match) {
                        break;
                    }
//System.out.println("match!");
                    String sub=mRE.getParen(1);
//System.out.println("sub="+sub);
                    String repl_now=replace.substring(0,index)+sub+replace.substring(index+1);
//System.out.println("repl_now="+repl_now);
                    int startWholeExpr=mRE.getParenStart(0);   // startWholeExpr will be index 1
                    int endWholeExpr=mRE.getParenEnd(0);       // endWholeExpr will be index 6
                    
                    s=s.substring(0,startWholeExpr)+repl_now+s.substring(endWholeExpr);
//System.out.println("s="+s);
                }
            }
            */
        }
        FileWriter write=new FileWriter(fnew);
        write.write(s);
        write.flush();
        write.close();
        File fbak = new File(name + ".bak");
        fbak.delete();
        f.renameTo(fbak);
        File fcopy = new File(name);
        fnew.renameTo(fcopy);
        fbak.delete();
    }
}

