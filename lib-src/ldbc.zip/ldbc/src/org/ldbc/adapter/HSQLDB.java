/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;

import java.sql.*;

/**
 * Known issues
 *
 * getIndexInfo returns ORDINAL_POSITON not ORDINAL_POSITION
 * (logged a bug 2002-07-11)
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getColumns
 * IS_NULLABLE is true for primay key columns, should be false
 * (at least all other tested databases return false) 
 * (logged a bug 2002-07-15; Primary key should not allow null values)
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getTables (probably also getColumns):
 * Wildcards are not pocessed correctly, search for table T\\_2 doesnt return table T_2
 * (workaround implemented in the JDBC driver)
 * 
 * DatabaseMetaData.getImportedKeys orders the result by 
 * PKTABLE_CAT, PKTABLE_SCHEM, PKTABLE_NAME, KEY_SEQ.
 * But that's actually wrong, in the following example: two references to the same table,
 * each reference contains two columns: (A,B), (C,D). In this case the list is ordered like this:
 * (1,A)(1,C)(2,B)(2,D) instead of (1,A)(2,B)(1,C)(2,D)
 *
 * ResultSet.getInt() throws an exception if the data type is DECIMAL,
 * according to the specs a conversion should be made.  
 *
 * ResultSet.getString() on a DECIMAL data type should return the value formatted
 * for example for DECIMAL(10,2) the returned value should be 0.00 and not 0
 *
 * ResultSetMetaData precision and scale are not returned - always 0.
 *
 * Time format error: the following statement should work, but throws an exception: 
 * CREATE TABLE Test ( ID INT , Current DATETIME )
 * insert into test values(1,'2002-01-01 0:0:0.0') 
 * This works:
 * insert into test values(1,'2002-01-01 00:00:00.0')
 *
 * CAST bug
 * The following statement should work:
 * SELECT CAST(I AS VARCHAR(255)) FROM DATA ORDER BY ID
 * The problems seems to be the (255)
 * (workaround implemented in the JDBC driver)
 * 
 * LENGTH on NULL bug
 * LENGTH(NULL) should return null, but returns 0
 *
 * ABS(4) returns data type DECIMAL, should return data type INTEGER
 *
 * Should throw a exception if PreparedStatement.setObject(1,null) is called.
 * See also JDBC API Tutorial and Reference, Second Edition,
 * page 544, 24.1.5 Sending JDBC NULL as an IN parameter 
 *
 * PreparedStatement.setBoolean doesn't work if the parameter
 * is a INTEGER value. Works with other databases (true=1, false=0)
 *
 * PreparedStatement.setLong doesn't work if the parameter
 * is a DECIMAL (for example, DECIMAL(30,0)) value, 
 * for example Long.MAX_VALUE or Long.MIN_VALUE
 *
 * Statement / PreparedStatement.getMoreResults
 * is supposed to close the current resultset according to the specs.
 * This is not done.
 *
 * The default search string escape character is not used,
 * only if ESCAPE '\' is added. Same as SQLServer.
 *
 * ResultSet.setFetchSize(-1) is allowed. The standard says it should
 * throw an exception.
 *
 * ResultSet.setFetchSize(100) after Statement.setMaxRows(50) should throw
 * an exception, but doesn't.
 *
 * Statement / PreparedStatement setMaxFieldSize is ignored.
 *
 * PreparedStatement.getMetaData() throws an exception:
 * java.sql.SQLException: This function is not supported
 * It should return null because the driver cannot return a ResultSetMetaData object
 * (see JDBC API Tutorial an Reference, Second Edition, page 552, 
 * PreparedStatement.getMetaData())
 *
 * The database should support at least Connection.TRANSACTION_READ_COMMITTED.
 * Currently, only TRANSACTION_READ_UNCOMMITTED is supported.
 *
 * Statement.setQueryTimeout(-1) should throw an exception.
 *
 * Statement.getQueryTimeout doesn't return the value set before.
 *
 * PreparedStatement.setDate, Time, Timestamp and ResultSet.getDate, Time, Timestamp with calendar
 * are not supported
 *
 * Batch updates are not supported.
 *
 * ResultSet.getBlob is not supported.
 *
 * PreparedStatement.setBinaryStream(2,null,0);
 * throws a NullPointerException
 *
 * When autocommit is on, executing a query on a statement is
 * supposed to close the old resultset. This is not implemented. 
 * 
 * This doesn't work:
 * CREATE TABLE TEST(ID INT PRIMARY KEY DEFAULT -1, OBJNAME BLOB DEFAULT NULL)
 */
public class HSQLDB extends Base implements Adapter {
    
    // url: jdbc:hsqldb:sample
    public String getName() {
        return getClass().getName();
    }
    
    public String getDriverClass() {
        return "org.hsqldb.jdbcDriver";
    }
    
    protected String getExceptionMap() {
    	return "23000="+Messages.INSERT_NULL+
		" S0021="+Messages.COLUMN_ALREADY_EXISTS;
	}
    
    public String getBinaryConstant(String s) {
        return "'"+s+"'";
    }

    public String getCreateTable(String tableName, String columns, String option) {
        String sql = "CREATE ";
        if(option!=null && option.toUpperCase().equals("'CACHED'")) {
            sql += "CACHED ";
        }
        sql += "TABLE " + quote(tableName) + "(" + columns + ")";
        return sql;
    }
    
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.CLOB:
            return "LONGVARCHAR";
        case Types.BLOB:
            return "BINARY";
        }
        return getDefaultDataTypeString(type);
    }
    
    public void convertDataType(DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.BINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
         case Types.BIGINT:
         case Types.NUMERIC:
            type.update(Types.INTEGER,0,0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    
    public String getCast(String value,DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.VARCHAR:
            return "CAST("+value+" AS VARCHAR)";
        default:
            return super.getCast(value,type);
        }
    }
    
    public String getDefaultLikeEscape() {
        // escape '\'
        return "ESCAPE '\\'";
    }
    
    public void setTransactionIsolation(int level) {
        // only Connection.TRANSACTION_READ_UNCOMMITTED is supported
    }
    
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }
    
    public boolean isSystemIndex(String tablename, String indexname) {
        if(indexname.toUpperCase().startsWith("SYS_IDX_")) {
            return true;
        }
        return false;
    }
    
}
