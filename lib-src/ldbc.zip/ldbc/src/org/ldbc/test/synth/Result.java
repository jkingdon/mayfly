package org.ldbc.test.synth;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.*;
import java.util.*;

class Result implements Comparable {
    final static int SUCCESS=0, BOOLEAN=1, INT=2, EXCEPTION=3, RESULTSET=4;
    private int type;
    private boolean bool;
    private int intValue;
    private SQLException exception;
    private ArrayList rows;
    private ArrayList header;
    
    Result() {
        type = SUCCESS;
    }
    
    Result(SQLException e) {
        type = EXCEPTION;
        exception = e;
    }
    
    Result(boolean b) {
        type = BOOLEAN;
        this.bool = b; 
    }
    
    Result(int i) {
        type = INT;
        this.intValue = i;
    }
    
    Result(ResultSet rs) {
        type = RESULTSET;
        try {
            rows = new ArrayList();
            header = new ArrayList();
            ResultSetMetaData meta = rs.getMetaData();
            int len = meta.getColumnCount();
            for(int i=0; i<len; i++) {
                Column column = new Column(meta, i+1);
            }
            while(rs.next()) {
                Row row = new Row(rs, len);
                rows.add(row);
            }
            Collections.sort(rows);
        } catch(SQLException e) {
            type = EXCEPTION;
            exception = e;
        }
    }

	public String toString() {
        switch(type) {
        case SUCCESS:
            return "success";
        case BOOLEAN:
            return "boolean: " + this.bool;
        case INT:
            return "int: " + this.intValue;
        case EXCEPTION: {
        	StringWriter w = new StringWriter();
        	exception.printStackTrace(new PrintWriter(w));
            return "exception: "+exception.getSQLState()+"\n"+w.toString();
        }
        case RESULTSET:
            String result = "ResultSet {\n  ";
            for(int i=0; i<header.size(); i++) {
                Column column = (Column)header.get(i);
                result += column.toString() + "; ";
            }
            result += "} = {\n";
            for(int i=0; i<rows.size(); i++) {
                Row row = (Row)rows.get(i);
                result += "  { " + row.toString() + "};\n";
            }
            return result + "}";
        default:
            throw new Error("internal");
        }
    }
    
    public int compareTo(Object o) {
    	Result r = (Result)o;
        switch(type) {
        case EXCEPTION:
        	return exception.getSQLState().compareTo(r.exception.getSQLState());
        case BOOLEAN:
        case INT:
        case SUCCESS:
        case RESULTSET:
        	return toString().compareTo(r.toString());
        default:
            throw new Error("internal");
        }
    }

}
