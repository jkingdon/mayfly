package org.ldbc.test;
import java.sql.*;

public class TestFunctions extends TestBase {
    public static void main(String[] argv) {
        new TestFunctions().test(argv);
    }
    Statement stat;
    void test(Connection conn) throws SQLException {
        stat=conn.createStatement();
        test("CREATE TABLE TEST(ID INT PRIMARY KEY,I INT,V VARCHAR(255),D DATETIME,XD DECIMAL(10,2))");
        test("INSERT INTO TEST VALUES(0,null,null,null,null)");
        test("INSERT INTO TEST VALUES(1,0,'Hello',DATE '1900-1-2',0.0)");
        test("INSERT INTO TEST VALUES(2,2,'World',TIMESTAMP '2001-2-3 4:5:6',10.35)");
        test("INSERT INTO TEST VALUES(3,-3,'Hi',TIMESTAMP '2999-8-7 6:5:4',12345.67)");
        ResultSet rs;
        rs=stat.executeQuery("SELECT I FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"0","2","-3"});
        rs=stat.executeQuery("SELECT CAST(I AS INT) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"0","2","-3"});
        rs=stat.executeQuery("SELECT CAST(I AS VARCHAR(255)) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"0","2","-3"});
        rs=stat.executeQuery("SELECT LENGTH(V) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"5","5","2"});
        /*
        // hsqldb
        rs=mStat.executeQuery("SELECT ABS(I) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"0","2","3"});
        */
        rs=stat.executeQuery("SELECT MOD(10,3) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{"1","1","1","1"});
        
        /*
        // pointbase
        rs=mStat.executeQuery("SELECT SIGN(I) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"0","1","-1"});
        */
        /*
        // pointbase
        rs=mStat.executeQuery("SELECT ASCII(V) FROM TEST ORDER BY ID");
        testDataType(rs,Types.INTEGER);
        testValues(rs,new String[]{null,"72","87","72"});
        */
        /*
        // pointbase
        rs=mStat.executeQuery("SELECT CHAR(48) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{"0","0","0","0"});
        */
        
        rs=stat.executeQuery("SELECT CONCAT(V,V) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"HelloHello","WorldWorld","HiHi"});

        rs=stat.executeQuery("SELECT LOWER(V) FROM TEST ORDER BY ID");
        /*
        // postgre returns CLOB
        testDataType(rs,Types.VARCHAR);
        */
        testValues(rs,new String[]{null,"hello","world","hi"});
        
        /*
        // hsqldb
        rs=mStat.executeQuery("SELECT LEFT(V,2) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"He","Wo","Hi"});
        
        rs=mStat.executeQuery("SELECT RIGHT(V,1) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"o","d","i"});
        */
        // pointbase
        /*
        rs=mStat.executeQuery("SELECT SUBSTRING(V,2,2) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"el","or","i"});
        
        rs=mStat.executeQuery("SELECT SUBSTRING(V,2) FROM TEST ORDER BY ID");
        testDataType(rs,Types.VARCHAR);
        testValues(rs,new String[]{null,"ello","orld","i"});
        */
        rs=stat.executeQuery("SELECT UPPER(V) FROM TEST ORDER BY ID");
        /*
        // postgre returns CLOB
        testDataType(rs,Types.VARCHAR);
        */
        testValues(rs,new String[]{null,"HELLO","WORLD","HI"});

        rs=stat.executeQuery("SELECT NOW() FROM TEST ORDER BY ID");
        
        /*
        rs=mStat.executeQuery("SELECT YEAR(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT MONTH(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT DAYOFMONTH(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT DAYOFWEEK(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT DAYOFYEAR(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT HOUR(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT MINUTE(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        rs=mStat.executeQuery("SELECT SECOND(NOW()) FROM TEST ORDER BY ID");
        testDataType(rs,Types.TIMESTAMP);
        */
        
    }
    void testDataType(ResultSet rs,int datatype) throws SQLException {
        testResultSetMeta(rs,1,null,new int[]{datatype},null,null);
    }
    void testValues(ResultSet rs,String[] data) throws SQLException {
        int i=0;
        while(rs.next()) {
            String s=rs.getString(1);
            if(s==null ? (data[i]!=null) : (!s.equals(data[i]))) {
                error("s= "+s+" should be: "+data[i]);
            }
            i++;
        }
        if(i!=data.length) {
            error("rows: "+i+" should be: "+data.length);
        }
    }
    void test(String sql) throws SQLException {
        trace(sql);
        stat.execute(sql);
    }
}
