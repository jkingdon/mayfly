/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import org.ldbc.jdbc.*;
import java.sql.*;
import java.util.*;

/**
 * Kown issues:
 *
 * DatabaseMetaData.getColumns
 * column IS_NULLABLE returns "NO " (single space) instead of "NO" if the
 * column is not nullable.
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getTables is not sorted by table name
 * (workaround implemented in the JDBC driver)
 *
 * Does not support the operator || to concatenate strings.
 * (workaround implemented in the JDBC driver)
 *
 * Does not support the TIME data type.
 *
 * Limitation for DATETIME is 3.33 milliseconds instead of 1 millisecond.
 *
 * Datetime data type: the earliest year supported is 1753. 
 * This statement fails:
 * INSERT INTO TEST VALUES (3,{ts '1000-01-01 00:00:00.0'})
 *
 * The function LENGTH is not supported, because it is called LEN instead.
 *
 * If the url does not contain ';SelectMethod=cursor' then
 * setAutoCommit(false) throws this exception:
 * [java] java.sql.SQLException: [Microsoft][SQLServer 2000 Driver for JDBC]
 * Can't start manual transaction mode because there are cloned connections.
 *
 * PreparedStatement.setByte(1,(byte)-20) on a INTEGER column converts
 * the value to 236 (2s complement, 256-20=236). 
 *
 * The SQL Server 2000 / Microsoft JDBC driver combination 
 * by default doesn't support the quoted names functionality - 
 * it simply ignores the quotes. 
 * Quoted name functionality is part of SQL-92 standard and 
 * required for JDBC compliance.
 * 
 * The default search string escape character is not used,
 * only if ESCAPE '\' is added. Same as HSQLDB.
 *
 * Statement / PreparedStatement setMaxFieldSize is ignored.
 *
 * ResultSet.getBytes can not be called multiple times for the same column.
 *
 * ResultSet.getBlob fails for this table:
 * CREATE TABLE TEST(ID INTEGER NOT NULL,VALUE IMAGE,PRIMARY KEY(ID))
 * INSERT INTO TEST VALUES (1,0x01010101)
 * SELECT *  FROM TEST ORDER BY ID
 * The exception is:
 * java.sql.SQLException: [Microsoft][SQLServer 2000 Driver for JDBC]
 * Unsupported data conversion.
 * ResultSet.getBytes however works.
 *
 * PreparedStatement.setNull(2,Types.CLOB) works but after this
 * PreparedStatement.executeUpdate throws an exception:
 * java.lang.NullPointerException
 * at com.microsoft.jdbc.sqlserver.tds.TDSRPCParameter.initializeUserParam(Unknown Source)
 * ...
 *
 * ALTER TABLE ... RENAME is not supported; instead of that, sp_rename must be used.
 * 
 * ALTER TABLE ... ADD COLUMN ... has a strange syntax: COLUMN is not necessary (and not allowed)
 *
 * From the docs:
 * At any time, only one table in a session can have the IDENTITY_INSERT property set to ON. 
 *
 */
public class SQLServer extends Base implements Adapter {
    
    // url: jdbc:microsoft:sqlserver://localhost:2914
    private String autoIncTableWithExplicitValue;
    
    public String getName() {
        return getClass().getName();
    }
    
    public String getDriverClass() {
        return "com.microsoft.jdbc.sqlserver.SQLServerDriver";
    }
    
    public void init() throws SQLException {
        Connection conn=nativeConn;
        boolean auto=conn.getAutoCommit();
        try {
            conn.setAutoCommit(false);
            // test if two open statements at the same time is allowed
            Statement s1=conn.createStatement();
            Statement s2=conn.createStatement();
            s1.close();
            s2.close();
        } catch(SQLException e) {
            throw Factory.getGeneralException("Make sure the url contains ';SelectMethod=cursor'");
        }
        conn.setAutoCommit(auto);
    }
    
    public String getStringConcatenation(String a,String b) {
        return a+" + "+b;
    }
    
    public void convertDataType(DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.LONGVARBINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.CLOB:
            return "TEXT";
        case Types.BLOB:
            return "IMAGE";
        }
        String sql = getDefaultDataTypeString(type);
        if(autoIncrement) {
            sql += " IDENTITY";
        }
        return sql;
    }
    
    public String getBinaryConstant(String s) {
        return "0x"+s;
    }
    
    public String getLength(String value) throws SQLException {
        return "LEN("+value+")";
    }

    public String getMod(String v1,String v2) throws SQLException {
        return "(("+v1+")%("+v2+"))";
    }
    
    public String getNow() throws SQLException {
        return "GETDATE()";
    }
    
    public String getDefaultLikeEscape() {
        // escape '\'
        return "ESCAPE '\\'";
    }
    
    public void setNull(jdbcPreparedStatement prep,int parameterIndex, int sqlType) throws SQLException {
        if(sqlType==Types.CLOB) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.VARCHAR);
        } else if(sqlType==Types.BLOB){
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.BINARY);
        } else {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),sqlType);
        }
    }
    
    public String getRenameStatement(String tableName, String newName) throws SQLException {
        return "EXEC sp_rename '"+tableName+"', '"+newName+"', 'OBJECT'";
    }

    public String getAddColumnStatement(String tableName, String columnDef) throws SQLException {
        return "ALTER TABLE "+quote(tableName)+" ADD "+columnDef;
    }
    
    protected void autoIncLoadColumns() throws SQLException {
        autoIncColumns = new Hashtable();
        DatabaseMetaData meta = nativeConn.getMetaData();
        // TODO: could improve performance if systables are not read
        ResultSet rs = meta.getColumns(null, null, null, null);
        while(rs.next()) {
            String typename = rs.getString("TYPE_NAME");
            if(typename!=null && typename.toLowerCase().endsWith(" identity")) {
                String tableName = rs.getString("TABLE_NAME");
                String columnName = rs.getString("COLUMN_NAME");
                // we don't know the column names yet
                Table table = new Table(tableName, null, columnName);
                autoIncColumns.put(tableName, table);
            }
        }
        rs.close();
        // get the column names
        for (Enumeration t = autoIncColumns.keys(); t.hasMoreElements();) {
            String tableName = (String) t.nextElement();
            Table table = (Table) autoIncColumns.get(tableName);
            rs = meta.getColumns(null, null, tableName, null);
            Vector v = new Vector();
            while (rs.next()) {
                v.addElement(rs.getString("COLUMN_NAME"));
            }
            rs.close();
            String[] cols = new String[v.size()];
            v.copyInto(cols);
            table.setColumns(cols);
        }
    }

    public boolean autoIncNeedGeneratedValue() {
        // no need to add the identity column to the column list 
        return false;
    }

    public void autoIncAddColumn(String tableName, String[] cols,
            String columnName) throws SQLException {
        if (autoIncColumns == null) {
            autoIncLoadColumns();
        }
        Table table = new Table(tableName, cols, columnName);
        autoIncColumns.put(tableName, table);
    }
    
    public void autoIncPreInsert(PreparedStatement nativePrep, boolean autoValue, Command command)
            throws SQLException {
        if(!autoValue) {
            Statement stat = nativeConn.createStatement();
            String tableName = command.getTableName();
            if(autoIncTableWithExplicitValue!=null) {
                // need to switch it off even if it was on for this table 
                // because the table could have been dropped and re-created
                stat.executeUpdate("SET IDENTITY_INSERT "+autoIncTableWithExplicitValue+" OFF");
            }
            autoIncTableWithExplicitValue = tableName;
            stat.executeUpdate("SET IDENTITY_INSERT "+tableName+" ON");
            stat.close();
        }
    }
    
    public void autoIncPostInsert(PreparedStatement nativePrep,Command command) throws SQLException {
        // nothing to do
    }
    
    public int autoIncGetLastId() throws SQLException {
        Statement stat = nativeConn.createStatement(); 
        ResultSet rs = stat.executeQuery("SELECT @@IDENTITY as lastid");
        rs.next();
        int lastId = rs.getInt(1);
        rs.close();
        stat.close();
        return lastId;
    }

}

