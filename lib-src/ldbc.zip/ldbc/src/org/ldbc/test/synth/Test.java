package org.ldbc.test.synth;

import java.util.*;

public class Test {

    private boolean trace = false;
    private Database database;
    private ArrayList databases;

    public static void main(String[] argv) {
        try {
            Test app = new Test();
            app.test(argv);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    private void printUsage() {
        print("Usage: java " + getClass().getName());
        print("options:");
        print("-trace  print trace messages");
        print("-?      display this message");
    }

    private void print(String s) {
        System.out.println(s);
    }

    private void trace(String s) {
        if (trace) {
            print(s);
        }
    }

    private void test(String[] argv) throws Exception {
        for (int i = 0; i < argv.length; i++) {
            String s = argv[i];
            if (s.equals("-trace")) {
                trace = true;
            } else if (s.equals("-?")) {
                printUsage();
            }
        }
        databases = new ArrayList();
        
        /*
        databases.add(new Database(
        		"org.hsqldb.jdbcDriver", 
				"jdbc:hsqldb:test1", 
				"sa", 
				""
		));
        databases.add(new Database(
        		"com.pointbase.jdbc.jdbcDriver", 
				"jdbc:pointbase:embedded:sample,create=true", 
				"PBPUBLIC", 
				"PBPUBLIC"
		));
		*/
        databases.add(new Database(
        		"org.ldbc.jdbc.jdbcDriver", 
				"jdbc:ldbc:hsqldb:test1", 
				"sa", 
				""
		));
        databases.add(new Database(
        		"org.ldbc.jdbc.jdbcDriver", 
				"jdbc:ldbc:pointbase:embedded:sample,create=true", 
				"PBPUBLIC", 
				"PBPUBLIC"
		));

        test();
    }

    private void test() throws Exception {
    	Generator gen = Generator.getInstance();
    	/*
    	for(int i=0; i<1000; i++) {
    		System.out.println(Value.randomDecimal(10, 2));
    	}
    	*/
    	Database db = (Database) databases.get(0);
        process(db.getConnect());
        process(db.getReset());
        ArrayList tables = new ArrayList();
        for(int i=0; i<2; i++) {
        	Table table = Table.getRandomTable();
        	process(db.getCreateTable(table));
        	tables.add(table);
        	Index index = table.getRandomIndex();
        	process(db.getCreateIndex(index));
        }
        for(int i=0; i<10; i++) {
        	Table table = (Table) tables.get(gen.getInt(tables.size()));
        	Command command = db.getRandomInsert(table);
        	process(command);
        }
        for(int i=0; i<100; i++) {
        	Table table = (Table) tables.get(gen.getInt(tables.size()));
        	Command command = db.getRandomSelect(table);
        	process(command);
        }
        for(int i=0; i<100; i++) {
        	Table table = (Table) tables.get(gen.getInt(tables.size()));
        	Command command = db.getRandomSelectJoin(table);
        	process(command);
        }
        for(int i=0; i<5; i++) {
        	Table table = (Table) tables.get(gen.getInt(tables.size()));
        	Command command = db.getRandomUpdate(table);
        	process(command);
        }
        for(int i=0; i<5; i++) {
        	Table table = (Table) tables.get(gen.getInt(tables.size()));
        	Command command = db.getRandomDelete(table);
        	process(command);
        }
        for(int i=0; i<2; i++) {
        	Table table = (Table) tables.get(i);
        	process(db.getDropTable(table));
        }
        process(db.getDisconnect());
    }
    
    private void process(Command command) throws Exception {
        ArrayList results = new ArrayList();
        for(int i=0; i<databases.size(); i++) {
            Database db = (Database)databases.get(i);
            Result result = command.run(db);
            results.add(result);
        }
        compareResults(results);
    }
    
    private void compareResults(ArrayList results) {
    	Result original = (Result)results.get(0);
    	for(int i=1; i<results.size(); i++) {
    		Result copy = (Result)results.get(i);
    		if(original.compareTo(copy) != 0) {
    			throw new Error("Results don't match:\n"+original+"\n"+copy);
    		}
    	}
    }

}
