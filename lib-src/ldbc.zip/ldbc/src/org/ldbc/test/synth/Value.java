package org.ldbc.test.synth;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;

public class Value {
	int type;
	Object data;
	
	private Value(int type, Object data) {
		this.type = type;
		this.data = data;
	}
	
	String getSQL() {
		if(data == null) {
			return "NULL";
		}
		switch(type) {
        case Types.DECIMAL:
        case Types.NUMERIC:
        case Types.BIGINT:
        	return data.toString();
        case Types.BLOB:
        	return getBlobSQL();
        case Types.CLOB:
        case Types.VARCHAR:
        case Types.CHAR:
        	return "'" + data.toString() + "'";
        case Types.DATE:
        case Types.TIMESTAMP:
        	return getDateSQL((Date)data);
        case Types.INTEGER:
            return ((Integer)data).toString();
        default:
        	throw new Error("type="+type);
		}
	}
	
	private static Date randomDate() {
		Generator gen = Generator.getInstance();
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, 2004);
		cal.set(Calendar.MONTH, 11 -1);
		cal.set(Calendar.DAY_OF_MONTH, 10);
		cal.set(Calendar.HOUR_OF_DAY, 9);
		cal.set(Calendar.MINUTE, 8);
		cal.set(Calendar.SECOND, 7);
		Date d = cal.getTime();
		return d;
	}

	private static String getDateSQL(Date date) {
		StringBuffer buff = new StringBuffer("TIMESTAMP '");
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		buff.append(cal.get(Calendar.YEAR));
		buff.append('-');
		buff.append(cal.get(Calendar.MONTH)+1);
		buff.append('-');
		buff.append(cal.get(Calendar.DAY_OF_MONTH));
		buff.append(' ');
		buff.append(cal.get(Calendar.HOUR_OF_DAY));
		buff.append(':');
		buff.append(cal.get(Calendar.MINUTE));
		buff.append(':');
		buff.append(cal.get(Calendar.SECOND));
		buff.append("'");
		return buff.toString();
	}
	
	private String getBlobSQL() {
		byte[] bytes = (byte[]) data;
		StringBuffer buff = new StringBuffer("X'");
		for(int i=0; i<bytes.length; i++) {
			int c = ((int) bytes[i]) & 0xff;
			buff.append(Integer.toHexString(c >> 4 & 0xf));
			buff.append(Integer.toHexString(c & 0xf));

		}
		buff.append("'");
		return buff.toString();
	}

	public static Value read(ResultSet rs, int index) throws SQLException {
		ResultSetMetaData meta = rs.getMetaData();
		Object data;
		int type = meta.getColumnType(index);
		switch(type) {
		case Types.DECIMAL:
        case Types.BIGINT:
        case Types.NUMERIC:
        	data = rs.getBigDecimal(index);
			break;
        case Types.BLOB:
        	data = rs.getBytes(index);
    		break;
        case Types.CLOB:
        case Types.BINARY:
        case Types.VARCHAR:
        case Types.CHAR:
        	data = rs.getString(index);
    		break;
        case Types.DATE:
        case Types.TIMESTAMP:
        	data = rs.getDate(index);
    		break;
        case Types.INTEGER:
            data = new Integer(rs.getInt(index));
        	break;
        case Types.NULL:
        	data = null;
        	break;
        default:
        	throw new Error("type="+type);
		}
		if(rs.wasNull()) {
			data = null;
		}
		return new Value(type, data);
	}

	public static Value getRandom(int type, int precision, int scale, boolean mayBeNull) {
		Generator gen = Generator.getInstance();
		Object data;
		if(mayBeNull && gen.getBoolean(20)) {
			return new Value(type, null);
		}
    	switch(type) {
        case Types.DECIMAL:
        	data = randomDecimal(precision, scale);
        	break;
        case Types.BLOB:
        	data = randomBlob(precision);
        	break;
        case Types.CLOB:
        case Types.VARCHAR:
        	data = gen.randomString(gen.getInt(precision));
        	break;
        case Types.DATE:
        	data = randomDate();
        	break;
        case Types.INTEGER:
        	// int: -5 .. 15
        	data = new Integer(gen.getLog(20) - 5);
        	break;
        default:
        	throw new Error("type="+type);
        }
    	return new Value(type, data);
	}
	
	private static byte[] randomBlob(int max) {
		Generator gen = Generator.getInstance();
		int len = gen.getLog(max);
		byte[] data = new byte[len];
		gen.getBytes(data);
		return data;
	}
	
	public static BigDecimal randomDecimal(int precision, int scale) {
		Generator gen = Generator.getInstance();
		int len = gen.getLog(precision-scale)+scale;
		if(len==0) {
			len++;
		}
		StringBuffer buff = new StringBuffer();
    	for(int i=0; i<len; i++) {
			buff.append((char) ('0' + gen.getInt(10)));
		}
		// System.out.println(len+" "+scale+" "+(len-scale)+" "+buff.toString());
		buff.insert(len - scale, '.');
		if(gen.getBoolean(20)) {
    		buff.insert(0, '-');
    	}
		// System.out.println(">"+buff.toString());
		
		return new BigDecimal(buff.toString());
	}
	
    public int compareTo(Object o) {
    	Value v = (Value)o;
    	if(type != v.type) {
    		throw new Error("compare "+type+" "+v.type+" "+data+" "+v.data);
    	}
		if(data==null) {
            return (v.data==null) ? 0 : -1; 
        } else if(v.data==null) {
            return 1;
        }
		switch(type) {
        case Types.DECIMAL:
        	return ((BigDecimal)data).compareTo((BigDecimal)v.data);
        case Types.BLOB:
        	return compareBytes((byte[])data, (byte[])v.data);
        case Types.CLOB:
        case Types.VARCHAR:
        	return data.toString().compareTo(v.data.toString());
        case Types.DATE:
        	return ((Date)data).compareTo((Date)v.data);
        case Types.INTEGER:
            return ((Integer)data).compareTo((Integer)v.data);
        default:
        	throw new Error("type="+type);
		}
	}
    
    static int compareBytes(byte[] a, byte[] b) {
    	int al = a.length, bl = b.length;
    	int len = Math.min(al, bl);
    	for(int i=0; i<len; i++) {
    		int x = ((int)a[i]) & 0xff;
    		int y = ((int)b[i]) & 0xff;
    		if(x==y) {
    			continue;
    		}
    		return x>y ? 1 : -1;
    	}
    	return al==bl ? 0 : al > bl ? 1 : -1; 
    }
	
	public String toString() {
		// throw new Error("hey!");
		return getSQL();
	}

}
