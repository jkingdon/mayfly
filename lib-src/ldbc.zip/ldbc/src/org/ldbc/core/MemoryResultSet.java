/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.sql.*;
import java.net.*;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Vector;

/** 
 * Represents a result set - in memory.
 * This class doesn't check if the resultset was closed or invalid.
 */
public class MemoryResultSet implements ResultSet, ResultSetMetaData {
    int columnCount;
    int rowCount;
    String[] labels;
    int[] dataTypes;
    Object[][] data;
    int current;
    boolean wasNull;
    
    /**
     * Moves the cursor to the next row of the resultset
     *
     * @return true if successfull, false if there are no more rows
     */
    public boolean next() throws SQLException {
        if(current>=rowCount) {
            throw Factory.getClosedException();
        }
        current++;
        return current<rowCount;
    }
    /**
     * Gets the meta data of this resultset
     *
     * @return the meta data 
     */
    public ResultSetMetaData getMetaData() throws SQLException {
        return this;
    }
    /**
     * Returns the value of the specified column as a String.
     *
     * @param columnName - the name ofthe column
     * @return the value 
     */
    public String getString(String columnName) throws SQLException {
        int columnIndex=findColumn(columnName);
        return getString(columnIndex);
    }
    /**
     * Returns the value of the specified column as a String.
     *
     * @param columnIndex the index (1,2,...)
     * @return the value 
     */
    public String getString(int columnIndex) throws SQLException {
        checkColumnIndex(columnIndex);
        checkCurrentRow();
        Object d=data[current][columnIndex-1];
        if(d==null) {
            wasNull=true;
            return null;
        }
        wasNull=false;
        return d.toString();
    }
    /**
     * Was the last column accessed a null value?
     * @return true if the last column accessed was a null value 
     */
    public boolean wasNull() throws SQLException {
        return wasNull;
    }
    /**
     * Returns the column index for a given column label.
     * A case-insensitive search is made.
     *
     * @param columnName - the name ofthe column
     * @return the column index
     * @throws SQLException if the row is not found
     */
    public int findColumn(String columnName) throws SQLException {
        columnName=columnName.toUpperCase();
        for(int i=0;i<columnCount;i++) {
            if(columnName.equals(labels[i])) {
                return i+1;
            }
        }
        throw Factory.getSQLException(Messages.COLUMN_NOT_FOUND,columnName);
    }
    /**
     * Returns the value of the specified column as a int.
     *
     * @param columnIndex the index (1,2,...)
     * @return the value 
     */
    public int getInt(int columnIndex) throws SQLException {
        checkColumnIndex(columnIndex);
        checkCurrentRow();
        Object d=data[current][columnIndex-1];
        if(d==null) {
            wasNull=true;
            return 0;
        }
        wasNull=false;
        int datatype=dataTypes[columnIndex-1];
        switch(datatype) {
        case Types.INTEGER:
            return ((Integer)d).intValue();
        case Types.BIT:
            return ((Boolean)d).booleanValue() ? 1 : 0;
        } 
        return Integer.parseInt(d.toString());
    }
    /**
     * Returns the value of the specified column as a int.
     *
     * @param columnName - the name ofthe column
     * @return the value 
     */
    public int getInt(String columnName) throws SQLException {
        int columnIndex=findColumn(columnName);
        return getInt(columnIndex);
    }
    /**
     * Closes the resultset.
     */
    public void close() throws SQLException {
    }
    /**
     * Returns the data type of a column.
     *
     * @param colum the column index (1,2,...)
     * @return the data type 
     */
	public int getColumnType(int column) throws SQLException {
        checkColumnIndex(column);
        return dataTypes[column-1];
    }
    /**
     * Returns the data type name of a column.
     *
     * @param colum the column index (1,2,...)
     * @return the data type 
     */
	public String getColumnTypeName(int column) throws SQLException {
        int type=getColumnType(column);
        return DataType.getDataTypeString(type);
    }
    /**
     * Returns the number of columns
     *
     * @return the number of columns 
     */
	public int getColumnCount() throws SQLException {
        return columnCount;
    }
    /**
     * Returns the column label
     *
     * @return the column label 
     */
	public String getColumnLabel(int column) throws SQLException {
        checkColumnIndex(column);
        return labels[column-1];
    }
    /**
     * Returns the column name
     *
     * @return the column name 
     */
	public String getColumnName(int column) throws SQLException {
        checkColumnIndex(column);
        return labels[column-1];
    }
    /**
     * Returns the default precision for this database type.
     *
     * @return the default value
     */
	public int getPrecision(int column) throws SQLException {
        checkColumnIndex(column);
        return DataType.getDefaultPrecision(dataTypes[column-1]);
    }
    /**
     * Returns the default scale for this database type.
     *
     * @return the default value
     */
	public int getScale(int column) throws SQLException {
        checkColumnIndex(column);
        return DataType.getDefaultScale(dataTypes[column-1]);
    }
    /**
     * Returns the value of the specified column as a boolean.
     *
     * @return the value 
     */
    public boolean getBoolean(int columnIndex) throws SQLException {
        return getInt(columnIndex)!=0 ? true : false;
    }
    /**
     * Returns the value of the specified column as a boolean.
     *
     * @return the value 
     */
    public boolean getBoolean(String columnName) throws SQLException {
        return getInt(columnName)!=0 ? true : false;
    }
    /**
     * Returns the value of the specified column as a byte.
     *
     * @return the value 
     */
    public byte getByte(int columnIndex) throws SQLException {
        return (byte)getInt(columnIndex);
    }
    /**
     * Returns the value of the specified column as a byte.
     *
     * @return the value 
     */
    public byte getByte(String columnName) throws SQLException {
        return (byte)getInt(columnName);
    }
    /**
     * Returns the value of the specified column as a short.
     *
     * @return the value 
     */
    public short getShort(int columnIndex) throws SQLException {
        return (short)getInt(columnIndex);
    }
    /**
     * Returns the value of the specified column as a short.
     *
     * @return the value 
     */
    public short getShort(String columnName) throws SQLException {
        return (short)getInt(columnName);
    }
    /**
     * Returns the value of the specified column as a long.
     *
     * @return the value 
     */
    public long getLong(int columnIndex) throws SQLException {
        return getInt(columnIndex);
    }
    /**
     * Returns the value of the specified column as a long.
     *
     * @return the value 
     */
    public long getLong(String columnName) throws SQLException {
        return getInt(columnName);
    }
    /**
     * Returns the value of the specified column as a float.
     *
     * @return the value 
     */
    public float getFloat(int columnIndex) throws SQLException {
        return getInt(columnIndex);
    }
    /**
     * Returns the value of the specified column as a float.
     *
     * @return the value 
     */
    public float getFloat(String columnName) throws SQLException {
        return getInt(columnName);
    }
    /**
     * Returns the value of the specified column as a double.
     *
     * @return the value 
     */
    public double getDouble(int columnIndex) throws SQLException {
        return getInt(columnIndex);
    }
    /**
     * Returns the value of the specified column as a double.
     *
     * @return the value 
     */
    public double getDouble(String columnName) throws SQLException {
        return getInt(columnName);
    }
    /**
     * Returns the value of the specified column as a BigDecimal.
     *
     * @return the value 
     */
    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        int i=getInt(columnIndex);
        if(wasNull()) {
            return null;
        }
        return new BigDecimal(""+i);
    }
    /**
     * Returns the value of the specified column as a BigDecimal.
     *
     * @return the value 
     */
    public BigDecimal getBigDecimal(String columnName) throws SQLException {
        int i=getInt(columnName);
        if(wasNull()) {
            return null;
        }
        return new BigDecimal(""+i);
    }
    
    
// =============================================================    
    
    /**
     * @deprecated
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte[] getBytes(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getAsciiStream(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getUnicodeStream(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getBinaryStream(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte[] getBytes(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getAsciiStream(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getUnicodeStream(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getBinaryStream(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public SQLWarning getWarnings() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void clearWarnings() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public String getCursorName() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.Reader getCharacterStream(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.Reader getCharacterStream(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean isBeforeFirst() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean isAfterLast() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean isFirst() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean isLast() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void beforeFirst() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void afterLast() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean first() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean last() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean absolute( int row ) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean relative( int rows ) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean previous() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setFetchDirection(int direction) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getFetchDirection() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setFetchSize(int rows) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getFetchSize() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getType() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getConcurrency() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean rowUpdated() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean rowInserted() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean rowDeleted() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateNull(int columnIndex) throws SQLException {  
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateByte(int columnIndex, byte x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateShort(int columnIndex, short x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateInt(int columnIndex, int x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateLong(int columnIndex, long x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateFloat(int columnIndex, float x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateDouble(int columnIndex, double x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateString(int columnIndex, String x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBytes(int columnIndex, byte x[]) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateDate(int columnIndex, java.sql.Date x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateTime(int columnIndex, java.sql.Time x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateTimestamp(int columnIndex, java.sql.Timestamp x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateAsciiStream(int columnIndex, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBinaryStream(int columnIndex, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateCharacterStream(int columnIndex, java.io.Reader x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateObject(int columnIndex, Object x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateNull(String columnName) throws SQLException {  
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBoolean(String columnName, boolean x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateByte(String columnName, byte x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateShort(String columnName, short x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateInt(String columnName, int x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateLong(String columnName, long x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateFloat(String columnName, float x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateDouble(String columnName, double x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateString(String columnName, String x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBytes(String columnName, byte x[]) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateDate(String columnName, java.sql.Date x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateTime(String columnName, java.sql.Time x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateTimestamp(String columnName, java.sql.Timestamp x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateAsciiStream(String columnName, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateBinaryStream(String columnName, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateCharacterStream(String columnName, java.io.Reader reader, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateObject(String columnName, Object x, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateObject(String columnName, Object x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void insertRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void updateRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void deleteRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void refreshRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void cancelRowUpdates() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void moveToInsertRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void moveToCurrentRow() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Statement getStatement() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(int i, java.util.Map map) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef(int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob(int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob(int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray(int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(String colName, java.util.Map map) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef(String colName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob(String colName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob(String colName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray(String colName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(int columnIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(String columnName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(int columnIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(String columnName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isAutoIncrement(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isCaseSensitive(int column) throws SQLException {	
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isSearchable(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isCurrency(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public int isNullable(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isSigned(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public int getColumnDisplaySize(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public String getSchemaName(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public String getTableName(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public String getCatalogName(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isReadOnly(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isWritable(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
	public boolean isDefinitelyWritable(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public String getColumnClassName(int column) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
    
    
    public URL getURL(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public URL getURL(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateRef(int columnIndex, Ref x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateRef(String columnName,  Ref x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateBlob(int columnIndex, Blob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateBlob(String columnName, Blob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateClob(int columnIndex, Clob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateClob(String columnName, Clob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateArray(int columnIndex, Array x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void updateArray(String columnName, Array x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

// =============================================================    


    /**
     * Create a new MemoryResultSet from a resultset
     *
     * @param rs the original resultset (may be null)
     * @param columncount the number of columns (other columns are ignored)
     * @param datatypes the sql datatypes (java.sql.Types)
     */
    public MemoryResultSet(ResultSet rs,
    String labels[],int[] dataTypes) throws SQLException {
        int columncount=labels.length;
        if(dataTypes.length!=columncount) {
            throw new Error("Internal error");
        }
        columnCount=columncount;
        this.dataTypes=dataTypes;
        this.labels=labels;
        Vector rows=new Vector();
        if(rs!=null) {
            while(rs.next()) {
                Object[] row=new Object[columncount];
                for(int i=0;i<columncount;i++) {
                    row[i]=getObject(rs,i,dataTypes[i]);
                }
                rows.addElement(row);
            }
            // close is required for DB2
            rs.close();
            rowCount=rows.size();
        }
        data=new Object[rowCount][];
        rows.copyInto(data);
        current=-1;
    }
    /**
     * Reads an object from a ResultSet
     * @param rs - the original resultset
     * @param column - the column index (0,1,...)
     * @param datatype - the SQL data type
     */
    private static Object getObject(ResultSet rs,int column,int datatype) throws SQLException {
        switch(datatype) {
        case Types.INTEGER:
            int dataInt=rs.getInt(column+1);
            if(rs.wasNull()) {
                return null;
            }
            return new Integer(dataInt);
        case Types.VARCHAR:
        case Types.CHAR:
            return rs.getString(column+1);
        case Types.SMALLINT:
            short dataShort=rs.getShort(column+1);
            if(rs.wasNull()) {
                return null;
            }
            return new Short(dataShort);
        case Types.BIT:
            boolean bit=rs.getBoolean(column+1);
            if(rs.wasNull()) {
                return null;
            }
            return new Boolean(bit);
        default:
            throw Factory.getGeneralException("datatype:"+datatype);
        }
    }
    /**
     * Check if currently on a valid row
     * @throws SQLException if not ok
     */
    void checkCurrentRow() throws SQLException {
        if(current<0 || current>=rowCount) {
            throw Factory.getInvalidValueException("current:"+current+" rowcount:"+rowCount);
        }
    }
    /**
     * Check if the column index is ok
     * @param columnIndex (1,2,...)
     * @throws SQLException if not ok
     */
    void checkColumnIndex(int columnIndex) throws SQLException {
        if(columnIndex<1 || columnIndex>columnCount) {
            throw Factory.getInvalidValueException("columnIndex:"+columnIndex+" min:1 max:"+columnCount);
        }
    }
    /**
     * Sets a specific column in a row to a value
     * @param row row number (0,1,...)
     * @param columnIndex (1,2,...)
     * @param x the value
     */
    public void setInt(int row,int columnIndex,int x) {
        columnIndex--;
        data[row][columnIndex]=new Integer(x);
    }
    
    /**
     * Sets a specific column in a row to a value
     * @param row row number (0,1,...)
     * @param columnIndex (1,2,...)
     * @param x the value
     */
    public void setShort(int row,int columnIndex,short x) {
        columnIndex--;
        data[row][columnIndex]=new Short(x);
    }
    
    
    /**
     * Sets a specific column in a row to a value
     * @param row row number (0,1,...)
     * @param columnIndex (1,2,...)
     * @param x the value
     */
    public void setString(int row,int columnIndex,String x) {
        columnIndex--;
        data[row][columnIndex]=x;
    }
    /**
     * Adds one row at the end
     * @param data[]
     */
    public void appendRow(Object[] data) {
        Object[][] newdata=new Object[rowCount+1][];
        System.arraycopy(this.data,0,newdata,0,rowCount);
        newdata[rowCount]=data;
        rowCount++;
        this.data=newdata;
        reset();
    }
    /**
     * Delete a specific row and reset the cursor
     * @param row row number (0,1,...)
     */
    public void deleteRow(int row) {
        rowCount--;
        Object[][] newdata=new Object[rowCount][];
        if(row>0) {
            System.arraycopy(data,0,newdata,0,row);
        }
        if(rowCount-row>0) {
            System.arraycopy(data,row+1,newdata,row,rowCount-row);
        }
        data=newdata;
        reset();
    }
    /**
     * Resets the resultset to the row before the first row
     */
    public void reset() {
        current=-1;
    }
    /**
     * Sets a specific column in a row to 'null'
     * @param row row number (0,1,...)
     * @param columnIndex (1,2,...)
     */
    public void setNull(int row,int columnIndex) {
        columnIndex--;
        data[row][columnIndex]=null;
    }
    /**
     * Converts the data in a specific column to uppercase
     * @param columnIndex (1,2,...)
     */
    public void convertAllToUpperCase(int columnIndex) {
        columnIndex--;
        for(int i=0;i<rowCount;i++) {
            Object[] row=data[i];
            Object s=row[columnIndex];
            if(s!=null) {
                row[columnIndex]=s.toString().toUpperCase();
            }
        }
    }
    /**
     * Sets the data in a specific column
     * @param columnIndex (1,2,...)
     * @param text the new value
     */
    public void setAllString(int columnIndex,String text) {
        columnIndex--;
        for(int i=0;i<rowCount;i++) {
            Object[] row=data[i];
            row[columnIndex]=text;
        }
    }
    /**
     * Sets the data in a specific column
     * @param columnIndex (1,2,...)
     * @param text the new value
     */
    public void setAllInt(int columnIndex,int value) {
        columnIndex--;
        Integer v=new Integer(value);
        for(int i=0;i<rowCount;i++) {
            Object[] row=data[i];
            row[columnIndex]=v;
        }
    }
    /**
     * Sets a specific column to 'null'
     * @param columnIndex (1,2,...)
     */
    public void setAllNull(int columnIndex) {
        columnIndex--;
        for(int i=0;i<rowCount;i++) {
            data[i][columnIndex]=null;
        }
    }
    /**
     * Sets a specific column in a row to a value
     * @param row row number (0,1,...)
     * @param columnIndex (1,2,...)
     * @param x the value
     */
    public void setAllShort(int columnIndex,short x) {
        columnIndex--;
        Object o=new Short(x);
        for(int i=0;i<rowCount;i++) {
            data[i][columnIndex]=o;
        }
    }
    /**
     * Sort the resultset by one or more columns.
     * Only VARCHAR, BIT, INTEGER and SMALLINT columns are supported.
     * Null values are not supported.
     * @param index array of column index. each index is (1,2,...)
     */
    public void sort(int[] index) throws SQLException {
        int cols=index.length;
        for(int i=1,j; i<rowCount; i++) {
            Object[] row=data[i];
            for(j=i-1; j>=0 && bigger(data[j],row,cols,index); j--) {
                data[j+1]=data[j];
            }
            data[j+1]=row;
        }
    }
    /**
     * Check if a row is bigger.
     * Only VARCHAR, BIT, INTEGER and SMALLINT columns are supported.
     * Null values are sorted low.
     * @param index array of column index. each index is (1,2,...)
     */
    public boolean bigger(Object[] a,Object[] b,int len,int[] index) throws SQLException {
        for(int i=0;i<len;i++) {
            int idx=index[i]-1;
            Object o1=a[idx];
            Object o2=b[idx];
            if(o1==null) {
                if(o2==null) {
                    continue;
                }
                // null is smaller than any other value
                return false;
            } else if(o2==null) {
                // any other value is bigger than null
                return true;
            }
            int datatype=dataTypes[idx];
            switch(datatype) {
            case Types.VARCHAR:
                int compare=((String)o1).compareTo((String)o2);
                if(compare!=0) {
                    return compare>0;
                }
                break;
            case Types.INTEGER:
                int i1=((Integer)o1).intValue();
                int i2=((Integer)o2).intValue();
                if(i1!=i2) {
                    return i1>i2;
                }
                break;
            case Types.SMALLINT:
                short s1=((Short)o1).shortValue();
                short s2=((Short)o2).shortValue();
                if(s1!=s2) {
                    return s1>s2;
                }
                break;
            case Types.BIT:
                boolean b1=((Boolean)o1).booleanValue();
                boolean b2=((Boolean)o2).booleanValue();
                if(b1!=b2) {
                    return b1==true && b2==false;
                }
                break;
            default:
                throw Factory.getGeneralException("datatype:"+datatype);
            }
        }
        return false;
    }
    
}

