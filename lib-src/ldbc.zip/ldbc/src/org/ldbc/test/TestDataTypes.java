package org.ldbc.test;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class TestDataTypes extends TestBase {
    public static void main(String[] argv) {
        new TestDataTypes().test(argv);
    }
    Statement stat;
    void test(Connection conn) throws SQLException {
        stat=conn.createStatement();
        PreparedStatement prep;
        ResultSet rs;
        stat=conn.createStatement();
        // test date
        test("CREATE TABLE TEST(ID INT PRIMARY KEY,D DATETIME,N DECIMAL(10,2))");
        prep=conn.prepareStatement("INSERT INTO TEST VALUES(?,?,?)");
        Calendar local=Calendar.getInstance();
        Calendar gmt=Calendar.getInstance(TimeZone.getTimeZone("GMT+00:00"));
        Calendar plusone=Calendar.getInstance(TimeZone.getTimeZone("GMT+01:00"));
        Timestamp t0=java.sql.Timestamp.valueOf("2000-01-01 0:0:0.0");
        Timestamp t1=java.sql.Timestamp.valueOf("2000-01-01 1:0:0.0");
        BigDecimal n0=new BigDecimal("-1.23");
        BigDecimal n1=new BigDecimal("31.41");
        trace("set 0");
        prep.setInt(1,0);
        prep.setTimestamp(2,t0);
        prep.setBigDecimal(3,n0);
        prep.execute();
        trace("set 1");
        prep.setInt(1,1);
        prep.setTimestamp(2,t0,local);
        prep.setBigDecimal(3,n1);
        prep.execute();        
        trace("set 2");
        prep.setInt(1,2);
        prep.setTimestamp(2,t0,gmt);
        prep.setBigDecimal(3,n0);
        prep.execute();
        trace("set 3");        
        prep.setInt(1,3);
        prep.setTimestamp(2,t0,plusone);
        prep.setBigDecimal(3,n0);
        prep.execute();
        trace("get 0");
        rs=queryInit("ID=0");
        check(rs.getTimestamp(1).equals(t0));
        trace("dec="+rs.getBigDecimal(2));
        check(rs.getBigDecimal(2).equals(n0));
        BigDecimal bd = rs.getBigDecimal(3);
        check(bd.equals(new BigDecimal("3.1415")));
        trace("get 1");
        rs=queryInit("ID=1");
        check(rs.getTimestamp(1,local).equals(t0));
        check(rs.getBigDecimal(2).equals(n1));
        trace("get 2");
        rs=queryInit("ID=2");
        check(rs.getTimestamp(1,gmt).equals(t0));
        trace("get 3");
        rs=queryInit("ID=3");
        check(rs.getTimestamp(1,plusone).equals(t0));
        // read the time that was stored in GMT+1 and now read in GMT
        // the result must be GMT+1
        trace("get 3 in gmt");
        rs=queryInit("ID=3");
        check(rs.getTimestamp(1,gmt).equals(t1));
    }
    
    ResultSet queryInit(String where) throws SQLException {
        trace(where);
        ResultSet rs=stat.executeQuery("SELECT D, N, 3.1415 FROM TEST WHERE "+where);
        if(!rs.next()) {
            error("No data");
        }
        return rs;
    }
    
    void test(String sql) throws SQLException {
        trace(sql);
        stat.execute(sql);
    }
}
