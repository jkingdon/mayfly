/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;
import java.net.*;
import java.io.*;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Map;

/**
 * Callable Statement.
 *
 */
public class jdbcCallableStatement extends jdbcPreparedStatement implements CallableStatement {
    
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean wasNull() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public String getString(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean getBoolean(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte getByte(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public short getShort(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getInt(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public long getLong(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public float getFloat(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public double getDouble(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * @deprecated
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte[] getBytes(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object  getObject (int i, java.util.Map map) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef (int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob (int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob (int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray (int i) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Date getDate(int parameterIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Time getTime(int parameterIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.sql.Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter (int paramIndex, int sqlType, String typeName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public URL getURL(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Time getTime(String parameterName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Date getDate(String parameterName, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(String parameterName, Map map) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Timestamp getTimestamp(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Time getTime(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Date getDate(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte[] getBytes(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public double getDouble(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public float getFloat(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public long getLong(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getInt(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public short getShort(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public byte getByte(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean getBoolean(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public String getString(String parameterName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setNull(String parameterName, int sqlType, String typeName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setTime(String parameterName, Time x, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setObject(String parameterName, Object x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setTime(String parameterName, Time x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setDate(String parameterName, Date x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setBytes(String parameterName, byte[] x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setString(String parameterName, String x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setDouble(String parameterName, double x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setFloat(String parameterName, float x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setLong(String parameterName, long x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setInt(String parameterName, int x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setShort(String parameterName, short x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setByte(String parameterName, byte x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setBoolean(String parameterName, boolean x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setNull(String parameterName, int sqlType) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setURL(String parameterName, URL val) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public URL getURL(int parameterIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void registerOutParameter(String parameterName, int sqlType) throws SQLException {
        throw Factory.getUnsupportedException(); 
    } 
    
// =============================================================    
    
    jdbcCallableStatement(Adapter adapter,jdbcConnection conn,String sql) throws SQLException {
        super(adapter,conn,sql);
    }
}

