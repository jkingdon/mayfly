/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.sql.*;
import org.ldbc.jdbc.*;

public class Command {
    
    public final static int 
        COMMIT=0,ROLLBACK=1,AUTOCOMMIT_TRUE=2,AUTOCOMMIT_FALSE=3,
        SELECT=4,INSERT=5,UPDATE=6,DELETE=7,CREATE_TABLE=8,DROP_TABLE=9,
        CREATE_INDEX=10,DROP_INDEX=11,GET_AUTOINCREMENT_KEY=12,
        ALTER_TABLE_DROP_CONSTRAINT=13,ALTER_TABLE_RENAME=14, ALTER_TABLE_ADD_COLUMN=15;
    private final static String[] COMMAND={
        "COMMIT","ROLLBACK","AUTOCOMMIT_TRUE","AUTOCOMMIT_FALSE",
        "SELECT","INSERT","UPDATE","DELETE","CREATE TABLE","DROP TABLE",
        "CREATE INDEX","DROP INDEX","LAST AUTOINCREMENT",
        "ALTER TABLE DROP CONSTRAINT","ALTER TABLE RENAME","ALTER TABLE ADD COLUMN"
        };

    private Adapter adapter;
    private int type;
    private String originalSQL;
    private String vendorSQL;
    private int parameterIndexOffset;
    private String tableName;
    private boolean ifExists;  // for 'drop table if exists'
    private boolean ifNotExists; // for 'create table if not exists'
    private int limit=-1;
    private boolean autoIncInsertAutoValue;
    private boolean autoIncInsert;
    private boolean autoIncCreate;
    private String autoIncCol;
    private String[] autoIncOtherCols;
	
    public Result executePseudo(jdbcConnection conn) throws SQLException {
        switch(type) {
        case Command.COMMIT:
            conn.commit();
            return new Result(0);
        case Command.ROLLBACK:
            conn.rollback();
            return new Result(0);
        case Command.AUTOCOMMIT_TRUE:
            conn.setAutoCommit(true);
            return new Result(0);
        case Command.AUTOCOMMIT_FALSE:
            conn.setAutoCommit(false);
            return new Result(0);
        case Command.GET_AUTOINCREMENT_KEY:
            MemoryResultSet rs = new MemoryResultSet(null,
                new String[]{"LAST"},
                new int[]{Types.INTEGER}
            );
            rs.appendRow(new Object[]{new Integer(adapter.autoIncGetLastId())});
            jdbcResultSet result=new jdbcResultSet(conn,rs);
            return new Result(result);
        }
        throw Factory.getSQLException(Messages.SYNTAX_ERROR,originalSQL+" (EXECUTE UPDATE)");
    }
    
    public void setAutoIncCreate(String autoIncCol, String[] otherCols) {
        this.autoIncCreate = true;
        this.autoIncCol = autoIncCol;
        this.autoIncOtherCols = otherCols;
    }
    
    public void preExecuteInsertCreate(PreparedStatement nativePrep) throws SQLException {
        if(autoIncInsert) {   
            adapter.autoIncPreInsert(nativePrep, autoIncInsertAutoValue, this);
        }
    }
    
    public void postExecuteInsertCreate(PreparedStatement nativePrep) throws SQLException {
        if(autoIncInsertAutoValue) {        
            adapter.autoIncPostInsert(nativePrep, this);
        } else if(autoIncCreate) {
            adapter.autoIncAddColumn(tableName, autoIncOtherCols, autoIncCol);
        }
    }

    public boolean needToExecute(jdbcConnection conn) throws SQLException {
        switch(type) {
        case COMMIT:
        case ROLLBACK:
        case AUTOCOMMIT_TRUE:
        case AUTOCOMMIT_FALSE:
        case SELECT:
        case INSERT:
        case UPDATE:
        case DELETE:
        case CREATE_INDEX:
        case DROP_INDEX:
        case ALTER_TABLE_DROP_CONSTRAINT:
        case ALTER_TABLE_RENAME:
        case ALTER_TABLE_ADD_COLUMN:
            return true;
        case CREATE_TABLE:
            if(ifNotExists && doesTableExist(conn, tableName)) {
                return false;
            }
            return true;
        case DROP_TABLE:
            if(ifExists && !doesTableExist(conn, tableName)) {
                return false;
            }
            return true;
        }
        return true;
    }
    
    private boolean doesTableExist(jdbcConnection conn, String table) throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        ResultSet rs = meta.getTables(null, null, table, null);
        boolean exists = rs.next();
        rs.close();
        return exists;
    }
    
    public void setType(int type) {
        this.type=type;
        // make sure executing it fails
        // because it's not supposed to be executed
        vendorSQL="- "+COMMAND[type]+" -";
    }
    
    public Command(Adapter adapter) {
		this.adapter=adapter;     
    }
    
	public void setOriginalSQL(String sql) {
		originalSQL=sql;
	}
    
	public void setVendorSQL(String sql) {
		vendorSQL=sql;
	}
    
	public int translateParameterIndex(int parameterIndex) {
		return parameterIndexOffset+parameterIndex;
	}
    
    public void setParameterIndexOffset(int offset) {
        parameterIndexOffset=offset;
    }
    
    public String getVendorSQL() {
		return vendorSQL;
    }
    
    public void checkQuery() throws SQLException {
        if(!isSelect()) {
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,originalSQL+" (EXECUTE QUERY)");
        }
    }
    
    public void checkHasUpdateCount() throws SQLException {
        if(isSelect()) {
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,originalSQL+" (EXECUTE UPDATE)");
        }
    }
    
    public boolean isCreateOrDrop() {
        switch(type) {
        case CREATE_INDEX:
        case CREATE_TABLE:
        case DROP_INDEX:
        case DROP_TABLE:
        case ALTER_TABLE_DROP_CONSTRAINT:
        case ALTER_TABLE_RENAME:
        case ALTER_TABLE_ADD_COLUMN:
            return true;
        }
        return false;
    }
    
    public boolean hasUpdateCount() {
        switch(type) {
        case SELECT:
        case GET_AUTOINCREMENT_KEY:
            return false;
        }
        return true;
    }
    
    public boolean isPseudo() {
        switch(type) {
        case COMMIT:
        case ROLLBACK:
        case AUTOCOMMIT_FALSE:
        case AUTOCOMMIT_TRUE:
        case GET_AUTOINCREMENT_KEY:
            return true;
        }
        return false;
    }
    
	public boolean isSelect() {
        switch(type) {
        case SELECT:
        case GET_AUTOINCREMENT_KEY:
            return true;
        }
        return false;
	}
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public String getTableName() {
        return tableName;
    }

    public void setIfExists(boolean ifExists) {
        this.ifExists = ifExists;
    }

    public void setIfNotExists(boolean ifNotExists) {
        this.ifNotExists = ifNotExists;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public boolean isInLimit(int row) {
        if(limit==-1) {
            return true;
        }
        return row <= limit;
    }

    public void setAutoIncInsertAutoValue(boolean b) {
        autoIncInsertAutoValue = b;
    }
    
    public void setAutoIncInsert(boolean b) {
        autoIncInsert = b;
    }

    public boolean isAutoIncInsert() {
        return autoIncInsertAutoValue;
    }

}

