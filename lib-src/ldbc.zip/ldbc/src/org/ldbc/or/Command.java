/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */
package org.ldbc.or;

import java.sql.PreparedStatement;
import java.sql.Types;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Connection;
import java.util.*;
import java.math.*;

/**
 * A query object is used to parameterize a query.
 */
public class Command {
    
    // TODO: instead of constructor with Database, use setDatabase method
    // and call it after initializing. like this, the class can initialize everything
    // it needs to

    private Database db;
    private Table table;
    private String sql;
    private ArrayList params = new ArrayList();
    private ArrayList types = new ArrayList();
    
    public final static int INTEGER = Types.INTEGER;
    public final static int VARCHAR = Types.VARCHAR;
    public final static int DECIMAL = Types.DECIMAL;
    public final static int DOUBLE = Types.DOUBLE;
    public final static int TIMESTAMP = Types.TIMESTAMP;
    public final static int BLOB = Types.BLOB;

    Command(Table table, String sql) {
        this.table = table;
        this.sql = sql;
    }

    Command(Database db, String sql) {
        this.db = db;
        this.sql = sql;
    }

    /**
     * Clears all parameters that are set so far.
     */
    public void clearParameters() {
        params = new ArrayList();
        types = new ArrayList();
    }

    /**
     * Sets the next parameter to an integer value.
     * 
     * @param i the value
     * @return this object
     */
    public Command setInt(int i) {
        params.add(new Integer(i));
        types.add(new Integer(INTEGER));
        return this;
    }

    /**
     * Sets the next parameter to a string value.
     * 
     * @param s the value (may be null)
     * @return this object
     */
    public Command setString(String s) {
        params.add(s);
        types.add(new Integer(VARCHAR));
        return this;
    }

    /**
     * Sets the next parameter to a BigDecimal value.
     * 
     * @param b the value (may be null)
     * @return this object
     */
    public Command setBigDecimal(BigDecimal b) {
        params.add(b);
        types.add(new Integer(DECIMAL));
        return this;
    }

    /**
     * Sets the next parameter to a double value.
     * 
     * @param d the value
     * @return this object
     */
    public Command setDouble(double d) {
        params.add(new Double(d));
        types.add(new Integer(DOUBLE));
        return this;
    }

    /**
     * Sets the next parameter to an object. This may be an 
     * Integer, a String, a BigDecimal, a Double, a Date or a byte array.
     * The type may be: INTEGER, VARCHAR, DECIMAL, DOUBLE, TIMESTAMP or BLOB. 
     * 
     * @param o the value (may be null)
     * @param type the data type (from java.sql.Types)
     * @return this object
     */
    public Command setObject(Object o, int type) {
        Class expected = null; 
        switch(type) {
        case INTEGER:
            expected = Integer.class;
            break;            
        case VARCHAR:
            expected = String.class;
            break;            
        case DECIMAL:
            expected = BigDecimal.class;
            break;            
        case DOUBLE:
            expected = BigDecimal.class;
            break;            
        case TIMESTAMP:
            expected = BigDecimal.class;
            break;            
        case BLOB:
            expected = BigDecimal.class;
            break;            
        }
        DatabaseException.check(expected != null, "Unsupported data type: "+type);
        DatabaseException.check(o==null || (expected.isAssignableFrom(o.getClass())), "Incompatible data type: "+o.getClass().getName()+" expected type: "+expected);
        params.add(o);
        types.add(new Integer(type));
        return this;
    }

    /**
     * Sets the next parameter to a Date value.
     * 
     * @param d the value (may be null)
     * @return this object
     */
    public Command setDate(Date d) {
        if(d == null) {
            params.add(null);
        } else if(d instanceof java.sql.Timestamp) {
            params.add(d);
        } else {
            params.add(new java.sql.Timestamp(d.getTime()));
        }
        types.add(new Integer(TIMESTAMP));
        return this;
    }

    /**
     * Sets the next parameter to a byte array value.
     * 
     * @param blob the value (may be null)
     * @return this object
     */
    public Command setBytes(byte[] blob) {
        params.add(blob);
        types.add(new Integer(BLOB));
        return this;
    }
    
    /**
     * Runs a DELETE, UPDATE or INSERT statement. The update count of the
     * statement is returned. This method throws an exception for SELECT statements.
     * 
     * @return the update count
     */
    public int run() {
        DatabaseException.check(db!=null && table==null, "No update count");
        try {
            Connection conn = db.getConnection();
            PreparedStatement prep = conn.prepareStatement(sql);
            bind(prep);
            int count = prep.executeUpdate();
            return count;
        } catch (Throwable e) {
            throw new DatabaseException("Error executing command "
                    + sql, e);
        }
    }
    
    /**
     * Loads an object from the database. If there is more than
     * one row that passes the condition, an exception is throws. To load
     * multiple objects, use the method loadArrayList. If no row is not found, null
     * is returned.
     * <p>
     * If the command was created with a class, the object returned will be of that type.
     * Otherwise, an object array is returned.
     * 
     * @return the object or null if no object was found
     */
    public Object load() {
        ArrayList list = loadArrayList();
        int size = list.size();
        if (size == 0) {
            return null;
        }
        DatabaseException.check(size == 1,
                "Expected one object but found " + size);
        return list.get(0);
    }
    
    /**
     * Loads a list of objects from the database. This method returns a collection
     * of size 0 if no rows are found.
     * <p>
     * If the command was created with a class, the each element in the array list will be of that type.
     * Otherwise, each element in the array list will be an object array.
     * <p>
     * @return the array (a empty array list if no objects where found)
     */
    public ArrayList loadArrayList() {
        ArrayList list;
        if(table==null) {
            try {
                list = new ArrayList();
                Connection conn = db.getConnection();
                PreparedStatement prep = conn.prepareStatement(sql);
                bind(prep);
                ResultSet rs = prep.executeQuery();
                if(rs.next()) {
                    ResultSetMetaData meta = rs.getMetaData();
                    int len = meta.getColumnCount();
                    do {
                        Object[] obj = new Object[len];
                        for (int i = 0; i < len; i++) {
                            obj[i] = rs.getObject(i+1);
                        }
                        list.add(obj);
                    } while (rs.next());
                }
                return list; 
            } catch (Throwable e) {
                throw new DatabaseException("Error executing command "
                        + sql, e);
            }
        }
        list = table.loadArrayList(this);
        return list;
    }
    
    String getSQL() {
        return sql;
    }

    void bind(PreparedStatement prep) {
        try {
            for (int i = 0; i < params.size(); i++) {
                // type is java.sql.Types
                int type = ((Integer) types.get(i)).intValue();
                Object obj = params.get(i);
                prep.setObject(i + 1, obj, type);
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error binding statement " + prep, e);
        }
    }
}
