/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import org.ldbc.jdbc.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public class Base implements Adapter {

    /**
     * The wrapped connection object
     */
    protected jdbcConnection ldbcConn;

    /**
     * The internal (native) connection object
     */
    protected Connection nativeConn;

    protected Hashtable autoIncColumns;
    private int autoIncLastIdTry;
    private int autoIncLastId;
    private final static String AUTOINC_TABLE = "LDBC_SYS_AUTOINCREMENT";
    private HashMap exceptionMap = new HashMap();
    
    protected String getExceptionMap() {
    	return "";
	}

    public void setConnection(jdbcConnection externalConn, Connection conn)
            throws SQLException {
        ldbcConn = externalConn;
        nativeConn = conn;
        init();
        String map = getExceptionMap();
		StringTokenizer st = new StringTokenizer(map, "= ");
		while (st.hasMoreTokens()) {
	         String source = st.nextToken();
	         String target = st.nextToken();
	         exceptionMap.put(source,target);
		}
    }

    public void init() throws SQLException {
    }

    public String getName() {
        return getClass().getName();
    }

    public String getDriverClass() {
        return "";
    }

    public String getDefaultSchema() throws SQLException {
        return null;
    }

    public void convertDataType(DataType type) throws SQLException {
        type.update(type.getDataType(), type.getPrecision(), type.getScale());
    }

    public String getStringConcatenation(String a, String b) {
        return a + " || " + b;
    }

    public String getStringConstant(String s) {
        return s;
    }

    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        return getDefaultDataTypeString(type);
    }

    public static String getDefaultDataTypeString(DataType type)
            throws SQLException {
        int datatype = type.getDataType();
        String name = DataType.getDataTypeString(datatype);
        switch (datatype) {
        case Types.INTEGER:
        case Types.TIMESTAMP:
        case Types.BLOB:
        case Types.CLOB:
            return name;
        case Types.VARCHAR:
            return name + "(" + type.getPrecision() + ")";
        case Types.DECIMAL:
            return name + "(" + type.getPrecision() + "," + type.getScale()
                    + ")";
        default:
            throw Factory.getGeneralException("datatype:" + datatype);
        }
    }

    public String getDateConstant(String s) {
        // some datebases (HSQLDB) have problems with formats like 2002-01-01
        // 0:0:0.0
        s = java.sql.Date.valueOf(s).toString();
        return "{ts '" + s + " 00:00:00.0'}";
    }

    public String getTimestampConstant(String s) {
        // some datebases (HSQLDB) have problems with formats like 2002-01-01
        // 0:0:0.0
        s = java.sql.Timestamp.valueOf(s).toString();
        return "{ts '" + s + "'}";
    }

    public String getBinaryConstant(String s) {
        return "X'" + s + "'";
    }

    public String getCast(String value, DataType type) throws SQLException {
        String s = getDataTypeString(type, false);
        return "CAST(" + value + " AS " + s + ")";
    }

    public String getLength(String value) throws SQLException {
        return "LENGTH(" + value + ")";
    }

    public String getMod(String v1, String v2) throws SQLException {
        return "MOD(" + v1 + "," + v2 + ")";
    }

    public String getNow() throws SQLException {
        return "NOW()";
    }

    public String getCreateTable(String tableName, String columns, String option) {
        return "CREATE TABLE " + quote(tableName) + "(" + columns + ")";
    }

    public SQLException convertThrowable(Throwable e) {
        if (e instanceof SQLException) {
            return convertSQLException((SQLException) e);
        }
        return Factory.getSQLException(Messages.GENERAL_ERROR, e.toString(), e);
    }

    public String getDefaultLikeEscape() {
        return "";
    }

    public boolean supportsAnsiJoinSyntax() {
        return true;
    }

    public void setTransactionIsolation(int level) throws SQLException {
        nativeConn.setTransactionIsolation(level);
    }

    public void cancel(Statement stat) throws SQLException {
        stat.cancel();
    }

    public byte[] getBytes(ResultSet rs, int columnIndex) throws SQLException {
        return rs.getBytes(columnIndex);
    }

    public Reader getCharacterStream(ResultSet rs, int columnIndex)
            throws SQLException {
        return rs.getCharacterStream(columnIndex);
    }

    public String getClobString(ResultSet rs, int columnIndex)
            throws SQLException {
        return rs.getString(columnIndex);
    }

    public void setString(jdbcPreparedStatement prep, int parameterIndex,
            String x) throws SQLException {
        prep.getVendorObject().setString(
                prep.translateParameterIndex(parameterIndex), x);
    }

    public void setCharacterStream(jdbcPreparedStatement prep,
            int parameterIndex, Reader x, int length) throws SQLException {
        prep.getVendorObject().setCharacterStream(
                prep.translateParameterIndex(parameterIndex), x, length);
    }

    public void setAsciiStream(jdbcPreparedStatement prep, int parameterIndex,
            InputStream x, int length) throws SQLException {
        prep.getVendorObject().setAsciiStream(
                prep.translateParameterIndex(parameterIndex), x, length);
    }

    public void setNull(jdbcPreparedStatement prep, int parameterIndex,
            int sqlType) throws SQLException {
        prep.getVendorObject().setNull(
                prep.translateParameterIndex(parameterIndex), sqlType);
    }

    public void setBytes(jdbcPreparedStatement prep, int parameterIndex,
            byte[] x) throws SQLException {
        prep.getVendorObject().setBytes(
                prep.translateParameterIndex(parameterIndex), x);
    }

    public void setBinaryStream(jdbcPreparedStatement prep, int parameterIndex,
            InputStream x, int length) throws SQLException {
        prep.getVendorObject().setBinaryStream(
                prep.translateParameterIndex(parameterIndex), x, length);
    }

    public boolean needExplicitIndexOnForeignKey() {
        return false;
    }

    public String getDropIndexSQL(String tableName, String uniqueIndexName) {
        return "DROP INDEX " + quote(tableName) + "." + quote(uniqueIndexName);
    }

    public String truncateIndexName(String indexName) {
        return indexName;
    }

    public String getNullConstant() {
        return "NULL";
    }

    public boolean isSystemTable(String tableName) {
        if (tableName == null) {
            return false;
        }
        if (tableName.equals(AUTOINC_TABLE)) {
            return true;
        }
        // todo: DUAL for Oracle, SYS... tables for others
        return false;
    }

    public String quote(String identifier) {
        return "\"" + identifier + "\"";
    }

    public boolean isSystemIndex(String tablename, String indexname) {
        if (indexname.equals("PRIMARY_KEY")) {
            return false;
        }
        if (!indexname.startsWith(tablename + "_")) {
            return true;
        }
        return false;
    }
    
    public boolean isPrimaryKey(String indexname, String pkname) {
        if(indexname.equals(pkname)) {
            return true;
        }
        return false;
    }
    
    public String getForeignKeyName(String tableName, String originalName) throws SQLException {
        return originalName;
    }
    
    public String getDropForeignKeyStatement(String tableName, String fkName) throws SQLException {
        return "ALTER TABLE "+quote(tableName)+" DROP CONSTRAINT "+quote(fkName);
    }
    
    public String getRenameStatement(String tableName, String newName) throws SQLException {
        return "ALTER TABLE "+quote(tableName)+" RENAME TO "+quote(newName);
    }
    
    public String getAddColumnStatement(String tableName, String columnDef) throws SQLException {
        return "ALTER TABLE "+quote(tableName)+" ADD COLUMN "+columnDef;
    }
    
    public String getSelect(boolean distinct, String top, String rest) throws SQLException {
        String select="SELECT ";
        if(distinct) {
            select+="DISTINCT ";
        }
        if(top!=null) {
            select += "TOP "+top+" ";
        }
        select+=rest;
        return select;     
    }
    
    protected void autoIncLoadColumns() throws SQLException {
        autoIncColumns = new Hashtable();
        DatabaseMetaData meta = nativeConn.getMetaData();
        ResultSet rs;
        rs = meta.getTables(null, getDefaultSchema(), AUTOINC_TABLE, null);
        boolean exists = rs.next();
        rs.close();
        Statement stat = nativeConn.createStatement();
        // VARCHAR 250 because a primary key with 255 charater is not allowed
        // in Firebird
        if (!exists) {
            stat.execute("CREATE TABLE " + quote(AUTOINC_TABLE) + "("
                    + "TABLE_NAME VARCHAR(250) NOT NULL PRIMARY KEY,"
                    + "COLUMN_NAME VARCHAR(255),NEXT_KEY INT)");
            // need to commit that for Firebird
            nativeConn.commit();
        } else {
            rs = stat.executeQuery("SELECT * FROM " + quote(AUTOINC_TABLE));
            while (rs.next()) {
                String tableName = rs.getString("TABLE_NAME");
                String columnName = rs.getString("COLUMN_NAME");
                // we don't know the column names yet
                Table table = new Table(tableName, null, columnName);
                autoIncColumns.put(tableName, table);
            }
            rs.close();
        }
        Hashtable tables = new Hashtable();
        // must use the 'clean' list of tables
        meta = ldbcConn.getMetaData();
        rs = meta.getTables(null, null, null, null);
        while (rs.next()) {
            String tableName = rs.getString("TABLE_NAME");
            // we don't know the column names yet
            Table table = new Table(tableName, null, null);
            tables.put(tableName, table);
        }
        rs.close();

        PreparedStatement prep;
        prep = nativeConn.prepareStatement("INSERT INTO " + quote(AUTOINC_TABLE)
                + " VALUES(?,NULL,NULL)");
        for (Enumeration t = tables.keys(); t.hasMoreElements();) {
            String tableName = (String) t.nextElement();
            if (autoIncColumns.get(tableName) == null) {
                prep.setString(1, tableName);
                prep.executeUpdate();
                Table table = new Table(tableName, null, null);
                autoIncColumns.put(tableName, table);
            }
        }
        prep.close();
        // maybe rows are removed from the table too late -
        // because DROP TABLEs are not detected
        // but that's ok as the table may not be used anyway
        // the table will not appear in metadata because that's always fetched
        // from the database
        // and insert will fail anyway because the table doesn't exist
        prep = nativeConn.prepareStatement("DELETE FROM " + quote(AUTOINC_TABLE)
                + " WHERE TABLE_NAME=?");
        for (Enumeration t = autoIncColumns.keys(); t.hasMoreElements();) {
            String tableName = (String) t.nextElement();
            if (tables.get(tableName) == null) {
                prep.setString(1, tableName);
                prep.executeUpdate();
                autoIncColumns.remove(tableName);
            }
        }
        prep.close();
        stat.close();
        // get the column names
        for (Enumeration t = autoIncColumns.keys(); t.hasMoreElements();) {
            String tableName = (String) t.nextElement();
            Table table = (Table) autoIncColumns.get(tableName);
            rs = meta.getColumns(null, null, tableName, null);
            Vector v = new Vector();
            while (rs.next()) {
                v.addElement(rs.getString("COLUMN_NAME"));
            }
            rs.close();
            String[] cols = new String[v.size()];
            v.copyInto(cols);
            table.setColumns(cols);
        }
    }

    public void autoIncAddColumn(String tableName, String[] cols,
            String columnName) throws SQLException {
        if (autoIncColumns == null) {
            autoIncLoadColumns();
        }
        PreparedStatement prep;
        prep = nativeConn.prepareStatement("UPDATE " + quote(AUTOINC_TABLE)
                + " SET COLUMN_NAME=?,NEXT_KEY=1 WHERE TABLE_NAME=?");
        prep.setString(1, columnName);
        prep.setString(2, tableName);
        int count = prep.executeUpdate();
        prep.close();
        if (count == 0) {
            prep = nativeConn.prepareStatement("INSERT INTO " + quote(AUTOINC_TABLE)
                    + " VALUES(?,?,1)");
            prep.setString(1, tableName);
            prep.setString(2, columnName);
            prep.executeUpdate();
            prep.close();
        }
        Table table = new Table(tableName, cols, columnName);
        autoIncColumns.put(tableName, table);
    }

    public String autoIncGetColumn(String tableName) throws SQLException {
        Table table = autoIncGetTable(tableName);
        if (table == null) {
            return null;
        }
        return table.autoIncrementColumn;
    }

    private Table autoIncGetTable(String tableName) throws SQLException {
        if (autoIncColumns == null) {
            autoIncLoadColumns();
        }
        for (int i = 0; i < 2; i++) {
            // maybe it is already in the hashtable, maybe
            // it has to be reloaded
            // check, if found return it, if not reload and try again
            // but reload only once to avoid endless loops
            Table table = (Table) autoIncColumns.get(tableName);
            if (table != null) {
                return table;
            }
            autoIncLoadColumns();
        }
        return null;
    }
    
    public boolean autoIncNeedGeneratedValue() {
        return true;
    }

    public boolean autoIncAutoColumnMissing(String tableName, Vector v)
            throws SQLException {
        Table table = autoIncGetTable(tableName);
        if (table == null) {
            // table not found - no autoincrement column - don't add
            return false;
        }
        String col = table.autoIncrementColumn;
        if (col == null) {
            // table found but no autoincrement column
            return false;
        }
        for (int i = 0; i < v.size(); i++) {
            String c = (String) v.elementAt(i);
            if (c.equals(col)) {
                // autoincrement column is part of the vector -
                // no need to add it
                return false;
            }
        }
        // there is a column but not in the list - add it
        return true;
    }

    public void autoIncAddAllColumns(String tableName, Vector v) throws SQLException {
        Table table = autoIncGetTable(tableName);
        if (table == null) {
            // table not found - no columns
            return;
        }
        String[] cols = table.columns;
        String auto = table.autoIncrementColumn;
        for (int i = 0; i < cols.length; i++) {
            String c = cols[i];
            if (!c.equals(auto)) {
                v.addElement(c);
            }
        }
    }

    private int autoIncGetNextId(String tableName) throws SQLException {
        // this must be done in a transaction
        Connection conn = nativeConn;
        PreparedStatement prep;
        Table table = autoIncGetTable(tableName);
        String columnName = table.autoIncrementColumn;
        // lock the row if possible
        prep = conn.prepareStatement("UPDATE " + quote(AUTOINC_TABLE)
                + " SET NEXT_KEY=NEXT_KEY WHERE TABLE_NAME=?");
        prep.setString(1, tableName);
        prep.execute();
        for (int i = 0;; i++) {
            prep = conn.prepareStatement("SELECT NEXT_KEY FROM "
                    + quote(AUTOINC_TABLE) + " WHERE TABLE_NAME=?");
            prep.setString(1, tableName);
            ResultSet rs = prep.executeQuery();
            rs.next();
            int id = rs.getInt(1);
            rs.close();
            prep.close();
            prep = conn.prepareStatement("UPDATE " + quote(AUTOINC_TABLE)
                    + " SET NEXT_KEY=? WHERE TABLE_NAME=? AND NEXT_KEY=?");
            prep.setInt(1, id + 1);
            prep.setString(2, tableName);
            prep.setInt(3, id);
            int count = prep.executeUpdate();
            prep.close();
            if (count == 0) {
                continue;
            }
            prep = conn.prepareStatement("SELECT COUNT(*) FROM "
                    + quote(tableName) + " WHERE " + quote(columnName) + "=?");
            prep.setInt(1, id);
            rs = prep.executeQuery();
            rs.next();
            int existing = rs.getInt(1);
            rs.close();
            prep.close();
            if (existing == 0) {
                // i should be very small (0 in most cases),
                // otherwise there is something wrong with the algorithm
                return id;
            }
            prep = conn.prepareStatement("SELECT MAX(" + quote(columnName)
                    + ") FROM " + quote(tableName));
            rs = prep.executeQuery();
            rs.next();
            id = rs.getInt(1) + 1;
            rs.close();
            prep.close();
            prep = conn.prepareStatement("UPDATE " + quote(AUTOINC_TABLE)
                    + " SET NEXT_KEY=? WHERE TABLE_NAME=?");
            prep.setInt(1, id);
            prep.setString(2, tableName);
            prep.executeUpdate();
        }
    }

    public void autoIncPreInsert(PreparedStatement nativePrep, boolean autoValue, Command command)
            throws SQLException {
        if(autoValue) {
            String tableName = command.getTableName(); 
            int id = autoIncGetNextId(tableName);
            nativePrep.setInt(1, id);
            autoIncLastIdTry = id;
        }
    }
    
    public void autoIncPostInsert(PreparedStatement nativePrep,Command command) throws SQLException {
        autoIncLastId = autoIncLastIdTry;
    }
    
    public int autoIncGetLastId() throws SQLException {
        return autoIncLastId;
    }
    
    public SQLException convertSQLException(SQLException e) {
    	String state = e.getSQLState();
    	String target = (String)exceptionMap.get(state);
    	if(target==null) {
    		target=state;
    	}
    	return new jdbcSQLException(e.getMessage(), target, e);
    }

}
