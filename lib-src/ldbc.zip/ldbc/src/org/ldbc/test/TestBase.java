package org.ldbc.test;

import java.sql.*;
import java.util.*;

public class TestBase {

    private boolean trace;

    private String url = "jdbc:ldbc:pointbase:sample,new";

    private String user = "PBPUBLIC";

    private String password = "PBPUBLIC";

    void printUsage() {
        print("Usage: java " + getClass().getName());
        print("options:");
        print("-url <url>            database url (jdbc:ldbc:...)");
        print("-user <user>          database user name");
        print("-password <password>  database password");
        print("-trace                show trace info");
        print("-?                    display this message");
    }

    void error(String s) {
        error(new Error("FAIL: " + s));
    }

    void error(Throwable e) {
        e.printStackTrace(System.out);
    }

    void trace(String s) {
        if (trace) {
            print(s);
        }
    }

    void print(String s) {
        System.out.println(s);
    }

    void test(String[] argv) {
        Connection conn = null;
        try {
            for (int i = 0; i < argv.length; i++) {
                String s = argv[i];
                if (s.equals("-url")) {
                    url = argv[++i];
                } else if (s.equals("-user")) {
                    user = argv[++i];
                } else if (s.equals("-password")) {
                    password = argv[++i];
                } else if (s.equals("-trace")) {
                    trace = true;
                } else if (s.equals("-?")) {
                    printUsage();
                }
            }
            print("Running " + getClass().getName());
            Class.forName("org.ldbc.jdbc.jdbcDriver");
            conn = openConnection();
            cleanDatabase(conn);
            test(conn);
        } catch (Throwable e) {
            error(e);
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                // ignore
            }
        }
    }

    /**
     * Opens a connection to the database
     */
    Connection openConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    /**
     * The main test method. Classes that extend this base class need to
     * override this method.
     * 
     * @param conn
     *            the database connection
     */
    void test(Connection conn) throws Throwable {
    }

    /**
     * Clean the database by dropping all data tables
     * 
     * @param conn
     *            the connection
     */
    void cleanDatabase(Connection conn) throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        Statement stat = conn.createStatement();
        Vector tables = new Vector();
        ResultSet rs = meta
                .getTables(null, null, null, new String[] { "TABLE"});
        while (rs.next()) {
            tables.addElement(rs.getString("TABLE_NAME"));
        }
        while (tables.size() > 0) {
            int dropped = 0;
            for (int i = 0; i < tables.size(); i++) {
                try {
                    String table = (String) tables.elementAt(i);
                    trace("Try to drop " + table);
                    stat.execute("DROP TABLE " + table);
                    dropped++;
                    tables.removeElementAt(i);
                    i--;
                } catch (SQLException e) {
                    // error("Failed to drop, maybe a referencial integrity
                    // violation");
                    // error(e);
                }
            }
            // could not drop any table and still tables to drop
            if (dropped == 0 && tables.size() > 0) {
                error("Can not drop all tables");
                break;
            }
        }
    }

    /**
     * Check the result set meta data. Calls error if something wrong.
     * 
     * @param rs
     *            resultset
     * @param columncount
     *            number of columns
     * @param labels
     *            column labels (null if not tested)
     * @param datatypes
     *            SQL data types (null if not tested)
     * @param precision
     *            precision array (null if not tested)
     * @param scale
     *            scale array (null if not tested)
     * @throws SQLException
     *             if a database error occurs
     */
    void testResultSetMeta(ResultSet rs, int columncount, String[] labels,
            int[] datatypes, int[] precision, int[] scale) throws SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        int cc = meta.getColumnCount();
        if (cc != columncount) {
            error("ResultSet contains " + cc + " columns not " + columncount);
        }
        for (int i = 0; i < columncount; i++) {
            if (labels != null) {
                String l = meta.getColumnLabel(i + 1);
                if (!labels[i].equals(l)) {
                    error("column label " + i + " is " + l + " not "
                            + labels[i]);
                }
            }
            if (datatypes != null) {
                int t = meta.getColumnType(i + 1);
                if (datatypes[i] != t) {
                    error("column datatype " + i + " is " + t + " not "
                            + datatypes[i] + " (prec="
                            + meta.getPrecision(i + 1) + " scale="
                            + meta.getScale(i + 1) + ")");
                }
            }
            /*
             * if(precision!=null) { int p=meta.getPrecision(i+1);
             * if(precision[i]!=p) { error("column precision "+i+" is "+p+" not
             * "+precision[i]); } } if(scale!=null) { int s=meta.getScale(i+1);
             * if(scale[i]!=s) { error("column scale "+i+" is "+s+" not
             * "+scale[i]); } }
             */
        }
    }

    /**
     * Check that the ResultSet matches. The order of rows is ignored.
     * 
     * @param rs
     *            the result set
     * @param data
     *            the data as a array of arrays of Strings
     * @throws SQLException
     *             if a database error occurs
     */
    void testResultSetUnordered(ResultSet rs, String[][] data)
            throws SQLException {
        testResultSet(false, rs, data);
    }

    /**
     * Check that the ResultSet matches.
     * 
     * @param rs
     *            the result set
     * @param data
     *            the data as a array of arrays of Strings
     * @throws SQLException
     *             if a database error occurs
     */
    void testResultSetOrdered(ResultSet rs, String[][] data)
            throws SQLException {
        testResultSet(true, rs, data);
    }

    /**
     * Check that the ResultSet matches. The resultset must have the same
     * number of columns.
     * 
     * @param ordered
     *            true if the order matters
     * @param rs
     *            the result set
     * @param data
     *            the data as a array of arrays of Strings
     * @throws SQLException
     *             if a database error occurs
     */
    void testResultSet(boolean ordered, ResultSet rs, String[][] data)
            throws SQLException {
        int len = rs.getMetaData().getColumnCount();
        int rows = data.length;
        if (rows == 0) {
            // special case: no rows
            if (rs.next()) {
                error("testResultSet expected rowcount:" + rows + " got:0");
            }
        }
        int len2 = data[0].length;
        if (len != len2) {
            error("testResultSet expected columncount:" + len2 + " got:" + len);
        }
        for (int i = 0; i < rows; i++) {
            if (!rs.next()) {
                error("testResultSet expected rowcount:" + rows + " got:" + i);
            }
            String[] row = getData(rs, len);
            if (ordered) {
                String[] good = data[i];
                if (!testRow(good, row, good.length)) {
                    error("testResultSet row not equal, got:\n"
                            + formatRow(row) + "\n" + formatRow(good));
                }
            } else {
                boolean found = false;
                for (int j = 0; j < rows; j++) {
                    String[] good = data[i];
                    if (testRow(good, row, good.length)) {
                        found = true;
                        break;
                    }
                }
                if (!found) {
                    error("testResultSet no match for row:" + formatRow(row));
                }
            }
        }
        if (rs.next()) {
            String[] row = getData(rs, len);
            error("testResultSet expected rowcount:" + rows + " got:>="
                    + (rows + 1) + " data:" + formatRow(row));
        }
    }

    String[] getData(ResultSet rs, int len) throws SQLException {
        String[] data = new String[len];
        for (int i = 0; i < len; i++) {
            data[i] = rs.getString(i + 1);
            // just check if it works
            rs.getObject(i + 1);
        }
        return data;
    }

    String formatRow(String[] row) {
        String sb = "";
        for (int i = 0; i < row.length; i++) {
            sb += "{" + row[i] + "}";
        }
        return "{" + sb + "}";
    }

    boolean testRow(String[] a, String[] b, int len) {
        for (int i = 0; i < len; i++) {
            String sa = a[i];
            String sb = b[i];
            if (sa == null || sb == null) {
                if (sa != sb) {
                    return false;
                }
            } else {
                if (!sa.equals(sb)) {
                    return false;
                }
            }
        }
        return true;
    }

    void check(boolean test) {
        if (!test) {
            error("check failed");
        }
    }

    void checkStrings(String a, String b) {
        if (a == null || b == null) {
            if (a != null || b != null) {
                error("check failed; a=" + a + " b=" + b);
            }
            return;
        }
        if (!a.equals(b)) {
            error("check failed; a=" + a + " b=" + b);
        }
    }

    void checkEqual(int a, int b) {
        if (a != b) {
            error("check failed; a=" + a + " b=" + b);
        }
    }
}
