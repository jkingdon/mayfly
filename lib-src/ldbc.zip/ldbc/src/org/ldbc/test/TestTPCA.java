/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */
package org.ldbc.test;

import java.sql.*;
import java.math.BigDecimal;
import java.util.Random;

/**
 * This class implements the TPC-A test. See also:
 * http://www.tpc.org/tpca/spec/tpca_current.pdf
 */
public class TestTPCA extends Thread {

    static final int BRANCHES = 1;
    // should actually be BRANCHES * 10;
    static final int TELLERS = 1;
    static final int ACCOUNTS = BRANCHES * 10000;
    static final String FILLER = "abcdefghijklmnopqrstuvwxyz";
    static final int DELTA = 10000;
    static final String[] CREATE_SQL = {
            "CREATE TABLE branches(Bid INT PRIMARY KEY, Bbalance DECIMAL(15,2), filler VARCHAR(88))",
            "CREATE TABLE tellers(Tid INT PRIMARY KEY, Bid INT, Tbalance DECIMAL(15,2), filler VARCHAR(84))",
            "CREATE TABLE accounts(Aid INT PRIMARY KEY, Bid INT, Abalance DECIMAL(15,2), filler VARCHAR(84))",
            "CREATE TABLE history(Tid INT, Bid INT, Aid INT, delta DECIMAL(15,2), Htime DATETIME, filler VARCHAR(40))"};
    static final String INSERT_BRANCHES = "INSERT INTO branches(Bid,Bbalance,filler) VALUES(?,10000.00,'"
            + FILLER + "')";
    static final String INSERT_TELLERS = "INSERT INTO tellers(Tid,Bid,Tbalance,filler) VALUES(?,?,10000.00,'"
            + FILLER + "')";
    static final String INSERT_ACCOUNTS = "INSERT INTO accounts(Aid,Bid,Abalance,filler) VALUES(?,?,10000.00,'"
            + FILLER + "')";
    static boolean log;
    static boolean trace;

    public static void main(String arg[]) {
        try {
            run(arg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void run(String arg[]) throws Exception {
        String user = "sa";
        String password = "";
        String driver = "org.ldbc.jdbc.jdbcDriver";
        String url = "jdbc:ldbc:hsqldb:sample";
        int scale = 1;
        int trans = 100;
        int count = 12;
        for (int i = 0; i < arg.length; i++) {
            String s = arg[i];
            if (s.equals("-driver")) {
                driver = arg[++i];
            } else if (s.equals("-url")) {
                url = arg[++i];
            } else if (s.equals("-user")) {
                user = arg[++i];
            } else if (s.equals("-password")) {
                password = arg[++i];
            } else if (s.equals("-scale")) {
                scale = Integer.parseInt(arg[++i]);
            } else if (s.equals("-trans")) {
                trans = Integer.parseInt(arg[++i]);
            } else if (s.equals("-count")) {
                count = Integer.parseInt(arg[++i]);
            } else if (s.equals("-trace")) {
                trace = true;
            }
        }
        for (int i = 0; i < count; i++) {
            // don't show the output of the first two runs
            // to avoid bad data due to compiliation of java code
            if (i > 1) {
                log = true;
            }
            long time = System.currentTimeMillis();
            int tpc = run(driver, url, user, password, scale, trans);
            time = System.currentTimeMillis() - time;
            String result = "Time: " + time + " TPC: " + tpc;
            showResult(result);
        }
    }

    static int run(String driver, String url, String user, String password, int scale,
            int trans) throws Exception {
        Class.forName(driver);
        Connection conn = DriverManager.getConnection(url, user, password);
        TestTPCA teller[] = new TestTPCA[scale * TELLERS];
        trace("Driver      : " + driver);
        trace("URL         : " + url);
        trace("Tellers     : " + (scale * TELLERS));
        trace("Scale       : " + scale);
        trace("Transactions: " + trans);
        trace("Preparing database...");
        Statement stat = conn.createStatement();
        dropTable(stat, "branches");
        dropTable(stat, "tellers");
        dropTable(stat, "accounts");
        dropTable(stat, "history");
        for (int i = 0; i < CREATE_SQL.length; i++) {
            stat.executeUpdate(CREATE_SQL[i]);
        }
        PreparedStatement prep;
        prep = conn
                .prepareStatement("INSERT INTO branches(Bid,Bbalance,filler) "
                        + "VALUES(?,10000.00,'" + FILLER + "')");
        for (int i = 0; i < BRANCHES * scale; i++) {
            prep.setInt(1, i);
            prep.executeUpdate();
        }
        prep = conn
                .prepareStatement("INSERT INTO tellers(Tid,Bid,Tbalance,filler) "
                        + "VALUES(?,?,10000.00,'" + FILLER + "')");
        for (int i = 0; i < TELLERS * scale; i++) {
            prep.setInt(1, i);
            prep.setInt(2, i / TELLERS);
            prep.executeUpdate();
        }
        int len = ACCOUNTS * scale;
        prep = conn
                .prepareStatement("INSERT INTO accounts(Aid,Bid,Abalance,filler) "
                        + "VALUES(?,?,10000.00,'" + FILLER + "')");
        long t1 = System.currentTimeMillis();
        for (int i = 0; i < len; i++) {
            prep.setInt(1, i);
            prep.setInt(2, i / ACCOUNTS);
            prep.execute();
            long t2 = System.currentTimeMillis();
            if (t2 > t1 + 1000) {
                trace((i * 100 / len) + "% ");
                t1 = t2;
            }
        }
        trace("100%");
        stat.close();
        conn.close();
        for (int i = 0; i < TELLERS * scale; i++) {
            Connection c;
            c = DriverManager.getConnection(url, user, password);
            c.setAutoCommit(false);
            teller[i] = new TestTPCA(c, i, i / TELLERS, trans, ACCOUNTS * scale);
        }
        trace("Processing...");
        for (int i = 0; i < teller.length; i++) {
            teller[i].start();
        }
        for (int i = 0; i < teller.length; i++) {
            teller[i].join();
        }
        long time = 0;
        for (int i = 0; i < teller.length; i++) {
            time += teller[i].getTime();
        }
        time /= teller.length;
        trace("Average ms: " + time);
        int result = (int) (teller.length * (trans * 1000 / time));
        return result;
    }

    static void dropTable(Statement stat, String table) {
        try {
            stat.executeUpdate("DROP TABLE " + table);
        } catch (SQLException e) {
            // ignore - table may not exist
        }
    }

    static void trace(String s) {
        if (trace) {
            System.out.println(s);
        }
    }

    static void showResult(String s) {
        if (log) {
            System.out.println(s);
        }
    }

    // per instance
    Connection conn;
    int teller;
    int branch;
    int transactions;
    int accounts;
    long time;

    TestTPCA(Connection conn, int teller, int branch, int trans, int accounts) {
        this.conn = conn;
        this.teller = teller;
        this.branch = branch;
        this.transactions = trans;
        this.accounts = accounts;
    }

    public void run() {
        try {
            runTest();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void runTest() throws SQLException {
        PreparedStatement updateAccount = conn
                .prepareStatement("UPDATE accounts SET Abalance=Abalance+? WHERE Aid=?");
        PreparedStatement selectBalance = conn
                .prepareStatement("SELECT Abalance FROM accounts WHERE Aid=?");
        PreparedStatement updateTeller = conn
                .prepareStatement("UPDATE tellers SET Tbalance=Tbalance+? WHERE Tid=?");
        PreparedStatement updateBranch = conn
                .prepareStatement("UPDATE branches SET Bbalance=Bbalance+? WHERE Bid=?");
        PreparedStatement insertHistory = conn
                .prepareStatement("INSERT INTO history(Aid,Tid,Bid,delta,Htime,filler) VALUES(?,?,?,?,?,?)");
        Random random = new Random();
        int accountsPerBranch = TestTPCA.ACCOUNTS / TestTPCA.BRANCHES;
        for (int i = 0; i < transactions; i++) {
            int account;
            if (random.nextInt(100) < 85) {
                account = random.nextInt(accountsPerBranch) + branch
                        * accountsPerBranch;
            } else {
                account = random.nextInt(accounts);
            }
            int max = TestTPCA.DELTA;
            // delta: -max .. +max
            BigDecimal delta = new BigDecimal(""
                    + (random.nextInt(max * 2) - max));
            long current = System.currentTimeMillis();
            updateAccount.setBigDecimal(1, delta);
            updateAccount.setInt(2, account);
            updateAccount.executeUpdate();
            updateTeller.setBigDecimal(1, delta);
            updateTeller.setInt(2, teller);
            updateTeller.executeUpdate();
            updateBranch.setBigDecimal(1, delta);
            updateBranch.setInt(2, branch);
            updateBranch.executeUpdate();
            selectBalance.setInt(1, account);
            ResultSet rs = selectBalance.executeQuery();
            rs.next();
            rs.getBigDecimal(1);
            rs.close();
            insertHistory.setInt(1, account);
            insertHistory.setInt(2, teller);
            insertHistory.setInt(3, branch);
            insertHistory.setBigDecimal(4, delta);
            insertHistory.setDate(5, new java.sql.Date(current));
            insertHistory.setString(6, TestTPCA.FILLER);
            insertHistory.executeUpdate();
            conn.commit();
            time += System.currentTimeMillis() - current;
            // this is to make sure the other threads also run
            Thread.yield();
        }
        updateAccount.close();
        selectBalance.close();
        updateTeller.close();
        updateBranch.close();
        insertHistory.close();
        conn.close();
    }

    public long getTime() {
        return time;
    }
}
