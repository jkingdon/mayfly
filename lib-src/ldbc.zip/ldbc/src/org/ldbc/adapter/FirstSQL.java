/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;

/**
 * Known issues: 
 *
 * DatabaseMetaData.getTables, getColumns, getIndexInfo,...
 * don't return the column labels
 *
 * getIndexInfo throws an exception:
 * java.sql.SQLException: Invalid use of null pointer
 * The spec (JDBC API Tutorial and Reference, Second Edition, page 400)
 * says it should not (catalog and schema can be null).
 *
 * Stores identifiers lowercase (not a bug, but different than most others)
 */
public class FirstSQL extends Base implements Adapter {
    // url: jdbc:dbcp://local;recover=yes;database.path=/test/firstsql/db
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "COM.FirstSQL.Dbcp.DbcpDriver";
    }
}
