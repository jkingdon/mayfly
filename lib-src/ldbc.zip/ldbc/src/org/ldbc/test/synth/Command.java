package org.ldbc.test.synth;

import java.sql.SQLException;
import java.util.HashMap;

class Command {
    final static int CONNECT = 0, RESET = 1, DISCONNECT = 2, 
		CREATE_TABLE = 3, INSERT = 4, DROP_TABLE = 5, 
		SELECT = 6, DELETE = 7, UPDATE = 8, COMMIT = 9, ROLLBACK = 10,
		AUTOCOMMIT_ON = 11, AUTOCOMMIT_OFF = 12,
		CREATE_INDEX = 13, DROP_INDEX = 14;	
    private int type;
    private HashMap tables = new HashMap();
    Table table;
    Index index;
    private Column[] columns;
    private Value[] values;
    String condition;
	private int nextAlias;
	String order;
	String[] selectList;
	private Database database;
	private String join = "";
    
    Command(Database db, int type) {
    	this.database = db;
        this.type = type;
    }

    Command(Database db, int type, String alias, Table table) {
    	this.database = db;
        this.type = type;
        if(alias == null) {
        	alias = table.getName();
        }
        addSubqueryTable(alias, table);
        this.table = table;
    }
    
    Command(Database db, int type, Index index) {
    	this.database = db;
        this.type = type;
        this.index = index;
    }

    void addSubqueryTable(String alias, Table table) {
    	tables.put(alias, table);
    }
    
    void removeSubqueryTable(String alias) {
    	tables.remove(alias);
    }
    
    void prepareInsert() {
    	Generator gen = Generator.getInstance();
    	Column[] c;
    	if(gen.getBoolean(70)) {
			c = table.getColumns();
		} else {
			int len = gen.getInt(table.getColumnCount()-1)+1;
			c = columns = table.getRandomColumns(len);
		}
    	values = new Value[c.length];
    	for(int i=0; i<c.length; i++) {
    		values[i] = c[i].getRandomValue();
    	}
    }
    
    void prepareUpdate() {
    	Generator gen = Generator.getInstance();
		int len = gen.getLog(table.getColumnCount()-1)+1;
		Column[] c = columns = table.getRandomColumns(len);
		values = new Value[c.length];
    	for(int i=0; i<c.length; i++) {
    		values[i] = c[i].getRandomValue();
    	}
    	condition = Expression.getRandomCondition(this).getSQL();
    }
    
    private Result select(Database db) throws SQLException {
		String sql = "SELECT ";
		for(int i=0; i<selectList.length; i++) {
			if(i>0) {
				sql += ", ";
			}
			sql += selectList[i];
		}
		sql += "\n  FROM " + table.getName() + " M";
		sql += " "+join;
		if(condition!=null) {
			sql += "\n  WHERE " + condition;
		}
		if(order.trim().length()>0) {
			sql += "\n  ORDER BY " + order;
		}
		return db.select(sql);
    }
    
    Result run(Database db) throws Exception {
        try {
            switch(type) {
            case CONNECT:
                db.connect();
                return new Result();
            case RESET:
                db.reset();
                return new Result();
            case DISCONNECT:
                db.disconnect();
                return new Result();
            case CREATE_TABLE:
            	db.createTable(table);
            	table.setDatabase(db);
            	return new Result();
            case DROP_TABLE:
            	db.dropTable(table);
            	return new Result();
            case CREATE_INDEX:
            	db.createIndex(index);
            	return new Result();
            case DROP_INDEX:
            	db.dropIndex(index);
            	return new Result();
            case INSERT:
            	db.insert(table, columns, values);
            	return new Result();
            case SELECT:
            	return select(db);
            case DELETE:
            	return db.delete(table, condition);
            case UPDATE:
            	return db.update(table, columns, values, condition);
            case AUTOCOMMIT_ON:
            	db.setAutoCommit(true);
            	return new Result();
            case AUTOCOMMIT_OFF:
            	db.setAutoCommit(false);
            	return new Result();
            case COMMIT:
            	db.commit();
            	return new Result();
            case ROLLBACK:
            	db.rollback();
            	return new Result();
            default:
                throw new Error("internal");
            }
        } catch (SQLException e) {
            System.out.println(" state="+e.getSQLState()+" "+e);
            //e.printStackTrace();
        	// throw e;
        	return new Result(e);
        }
    }

	public String getNextTableAlias() {
		return "S" + nextAlias++;
	}

	public String getRandomTableAlias() {
		Object[] list = tables.keySet().toArray();
		int i = Generator.getInstance().getInt(list.length);
		return (String)list[i];
	}
	
	public Table getTable(String alias) {
		return (Table)tables.get(alias);
	}

	public Database getDatabase() {
		return database;
	}

	public void addJoin(String string) {
		join += string;
	}

}
