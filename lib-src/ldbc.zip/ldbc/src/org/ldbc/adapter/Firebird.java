/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import java.sql.*;

/**
 * Known issues
 *
 * Can't download the documentation from the Firebird homepage.
 * Most of the files are garbage, probably because the file type is not set correctly
 * in the web server.
 *  
 * An index may only contain 255 bytes per row.
 * 
 * A row may only be ~32000 bytes big.
 * 
 * DatabaseMetaData.getPrimaryKeys returns the wrong primary key index name:
 * PK_NAME in getPrimaryKeys is INTEG_487, but INDEX_NAME in getIndexInfo is
 * RDB$PRIMARY242 
 * 
 * DatabaseMetaData.getPrimaryKeys should not support wildcards such as % or _.
 * DatabaseMetaData.getIndexInfo for example works correct.
 * 
 * No way (as far as I see) to specify a binary constant in SQL, as in:
 * INSERT INTO TEST(ID, B) VALUES (1, 0x012345) or
 * INSERT INTO TEST(ID, B) VALUES (1, X'012345')
 * 
 * This database does not seem to support a function 'LENGTH' or 'LEN'! 
 * Wow! That sets a new record.
 * 
 * The function 'MOD' is not supported.
 * The function 'LOWER' is not supported.
 * The function 'NOW' is not supported.
 * 
 * The maximum precision of a DECIMAL is 18.
 * That is about the precision of a java long.
 * 
 * There are some problems with transactions 
 * ('object ... is in use') 
 * but so far more details are unknown.
 * 
 */

public class Firebird extends Base implements Adapter {
    // url: jdbc:firebirdsql:[//host[:port]/]<database>
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "org.firebirdsql.jdbc.FBDriver";
    }
    
    protected final static int CLOB_SIZE = 20000;

    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.DATE:
            return "DATE";
        case Types.TIME:
            return "TIME";
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        case Types.CLOB:
            return "BLOB SUB_TYPE TEXT";
            //return "VARCHAR("+CLOB_SIZE+")";
        case Types.BLOB:
            return "BLOB";
        }
        return getDefaultDataTypeString(type);
    }
    
    public void convertDataType(DataType type) throws SQLException {
        int precision = type.getPrecision();
        int scale = type.getScale();
        switch(type.getDataType()) {
        case Types.LONGVARBINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
        case Types.CHAR:
            type.update(Types.VARCHAR, precision, scale);
            break;
        case Types.NUMERIC:
            type.update(Types.INTEGER, 0, 0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    
    public boolean isPrimaryKey(String indexname, String pkname) {
        if(indexname.equals(pkname)) {
            return true;
        } else if(indexname.startsWith("RDB$PRIMARY")) {
            return true;
        }
        return false;
    }

    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }

    public String getBinaryConstant(String s) {
        return "'"+s+"'";
    }
    
    public void cancel(Statement stat) {
        // Statement.cancel throws an exception.
        // Because of this, the method can not be supported
        // stat.cancel();
    }
    
    public String getDefaultLikeEscape() {
        // escape '\'
        return "ESCAPE '\\'";
    }
    
    public String getLength(String value) throws SQLException {
        return "LEN(" + value + ")";
    }

    
}
