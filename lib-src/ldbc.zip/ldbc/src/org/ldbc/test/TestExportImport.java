package org.ldbc.test;
import java.sql.*;
import org.ldbc.Export;
import org.ldbc.Import;
import java.io.*;

public class TestExportImport extends TestBase {
    String[] SQL=new String[]{
    "CREATE TABLE TEST(ID INT NULL,NAME VARCHAR(100) NOT NULL)",
    "CREATE INDEX I1 ON TEST(ID,NAME)",
    "CREATE UNIQUE INDEX I2 ON TEST(NAME,ID)",
    "INSERT INTO TEST VALUES(1, 'Hello World')",
    "CREATE TABLE TEST_DATA(ID INT PRIMARY KEY, TS TIMESTAMP, BL BLOB, DE DECIMAL(10,2))",
    "INSERT INTO TEST_DATA VALUES(1, DATE '2001-02-03', X'01A0FF', -12.3)",
    "INSERT INTO TEST_DATA VALUES(2, DATE '2004-02-09', X'', 0.1)",
    "INSERT INTO TEST_DATA VALUES(3, NULL, NULL, NULL)",
    
    "CREATE TABLE XREF1(A INT NOT NULL, B INT NOT NULL, PRIMARY KEY(A))",
    "CREATE TABLE XREF2(A INT NOT NULL, B INT NOT NULL, PRIMARY KEY(A), FOREIGN KEY(A) REFERENCES XREF1(A))",    
    
    // MySQL bug
    //"CREATE TABLE XREF_COMPLEX_B(A INT NOT NULL, B INT NOT NULL, C INT NOT NULL, PRIMARY KEY(C,B))",
    //"CREATE INDEX IDX_A ON XREF_COMPLEX_B(A)",
    //"CREATE UNIQUE INDEX IDX_B_C ON XREF_COMPLEX_B(B,C)",
    //"CREATE UNIQUE INDEX IDX_A_C ON XREF_COMPLEX_B(A,C)",
    //"CREATE UNIQUE INDEX IDX_CAB ON XREF_COMPLEX_B(C,A,B)",
    //"CREATE TABLE XREF_COMPLEX_A(A INT NOT NULL, B INT NOT NULL, C INT NOT NULL, "+
    //    "PRIMARY KEY(A,C), "+
    //    "FOREIGN KEY(C,A) REFERENCES XREF_COMPLEX_B(B,C), "+
    //    "FOREIGN KEY(A,C) REFERENCES XREF_COMPLEX_B(C,B))",
    
    "CREATE TABLE UNICODE(ID INT NULL,NAME VARCHAR(255))",
    };
    String[] UNICODE=new String[]{
        null,
        "Hello World",
        "Buonas d�az",
        "Unm�glich",
        "\ttab, ''quote'', \"double quote\" \nnew line",
        // TODO: not all databases support unicode characters
        //"Unicode 0x00fa:\u00fa 0x0123:\u0123 0x1234:\u1234 0xffff:\uffff",
    };
    public static void main(String[] argv) {
        new TestExportImport().test(argv);
    }
    void test(Connection conn) throws Exception {
        Statement stat=conn.createStatement();
        for(int i=0;i<SQL.length;i++) {
            String sql=SQL[i];
            trace(sql);
            stat.executeUpdate(sql);
        }
        PreparedStatement prep;
        prep=conn.prepareStatement("INSERT INTO UNICODE VALUES(?, ?)");
        for(int i=0;i<UNICODE.length;i++) {
            prep.setInt(1, i);
            prep.setString(2, UNICODE[i]);
            prep.executeUpdate();
        }
        StringWriter buffer = new StringWriter();
        PrintWriter writer = new PrintWriter(buffer);
        
        Export export = new Export(conn, writer);
        export.exportFile(null, true, true);
        writer.close();
        String output1 = buffer.toString();
        LineNumberReader reader;
        reader = new LineNumberReader(new StringReader(output1));
        while(true) {
            String s = reader.readLine();
            if(s==null) {
                break;
            }
            trace(s);
        }
        reader = new LineNumberReader(new StringReader(output1));
        
        cleanDatabase(conn);
        Import imp = new Import(conn, reader);
        imp.importFile();
        
        ResultSet rs = stat.executeQuery("SELECT NAME FROM UNICODE ORDER BY ID");
        for(int i=0;i<UNICODE.length;i++) {
            rs.next();
            String got = rs.getString(1);
            String expected = UNICODE[i];
            checkStrings(got, expected);
        }
        check(rs.next()==false);
        
        buffer = new StringWriter();
        writer = new PrintWriter(buffer);
        export = new Export(conn, writer);
        export.exportFile(null, true, true);
        writer.close();
        
        String output2 = buffer.toString();
        reader = new LineNumberReader(new StringReader(output1));
        while(true) {
            String s = reader.readLine();
            if(s==null) {
                break;
            }
            trace(s);
        }
        if(!output1.equals(output2)) {
            this.error("Output1 and 2 are not equal:\n"+output1+"\n------\n"+output2);
        }
    }
}
