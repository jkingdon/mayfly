/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.test.or;

import org.ldbc.or.*;

public class GetSet {
    Database db;
    public GetSet(Database db) {
        this.db = db;
    }
    public int autoidkey;
    public String name;
    public String memoClob;
    public static String firstName;
}