/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.coverage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.Writer;
import java.util.Vector;

/**
 * Tool to instrument java files with profiler calls.
 * The tool can be used for profiling an application and for coverage testing.
 * This class is not used at runtime of the tested application. 
 */
public class Coverage {
	final static String IMPORT = "import "+Coverage.class.getPackage().getName()+".Profile";
	Vector mFiles = new Vector();
	Tokenizer mSt;
	Writer mWriter;
	Writer mData;
	String mToken = "";
	String mAdd = "";
	String mFile;
	int mIndex = 0;
	int mIndent = 0;
	int mLine;
	String mLast;
	String mWord, mFunction;
	boolean mPerClass;
	boolean mPerFunction = true;
    void printUsage() {
		System.out.println(
		"Usage:\n"+
		"- copy all your source files to another directory\n"+
		"  (be carefull, they will be modified - don't take originals!)\n"+
		"- java "+getClass().getName()+" <directory>\n"+
		"  this will modified the source code and create 'Profile.txt'\n"+
		"- compile the modified source files\n"+
		"- run your main application\n"+
		"- after the application exits, a file 'NotCovered.txt' is created,\n"+
		"  which contains the class names, function names and line numbers\n"+
		"  of code that has not been covered\n\n"+
		"Options:\n"+
		"-r     recurse all subdirectories\n"+
		"-c     coverage on a per-class basis\n"+
		"-f     coverage on a per-function basis\n"+
		"<dir>  directory name (. for current directory)"
		);
	}
	public static void main(String[] arg) {
		(new Coverage()).run(arg);
	}
	void run(String[] arg) {
		if(arg.length==0 || arg[0].equals("-?")) {
			printUsage();
			return;
		}
		Coverage c = new Coverage();
		int recurse=1;
		for(int i=0;i<arg.length;i++) {
			String s=arg[i];
			if(s.equals("-r")) {
				// maximum recurse is 100 subdirectories, that should be enough
				recurse = 100;
			} else if(s.equals("-c")) {
				c.mPerClass=true;
			} else if(s.equals("-f")) {
				c.mPerFunction=true;
			} else {
				c.addDir(s,recurse);
			}
		}
		try {
			c.mData = new BufferedWriter(new FileWriter("Profile.txt"));
			c.processAll();
			c.mData.close();
		} catch (Exception e) {
		}
	}
	void addDir(String path,int recurse) {
		File f = new File(path);
		if (f.isFile() && path.endsWith(".java")) {
			mFiles.addElement(path);
		} else if (f.isDirectory() && recurse>0) {
			String list[] = f.list();
			for (int i = 0; i < list.length; i++) {
				addDir(path + File.separatorChar + list[i],recurse-1);
			}
		}
	}
	void processAll() {
		int len = mFiles.size();
		long time = System.currentTimeMillis();
		for (int i = 0; i < len; i++) {
			long t2 = System.currentTimeMillis();
			if (t2 - time > 1000 || i >= len - 1) {
				System.out.println((i + 1) + " of "+len + " "+
						(int)(100 * i / len) + "%");
				time = t2;
			}
			String file = (String) mFiles.elementAt(i);
			processFile(file);
		}
	}
	void processFile(String name) {
		mFile = name;
		int i = name.lastIndexOf(File.separatorChar);
		if (i != -1) {
			mFile = name.substring(i + 1);
		}
		i = mFile.lastIndexOf('.');
		if (i != -1) {
			mFile = mFile.substring(0, i);
		}
		if (name.endsWith("Coverage.java") ||
				name.endsWith("Tokenizer.java") ||
				name.endsWith("Profile.java")) {
			return;
		}
		File f = new File(name);
		File fnew = new File(name + ".new");
		String key = name;
		key = key.replace('\\','.');
		try {
			mWriter = new BufferedWriter(new FileWriter(fnew));
			Reader r = new BufferedReader(new FileReader(f));
			mSt = new Tokenizer(r);
			mIndent = 0;
			try {
				process();
			} catch (Exception e) {
				r.close();
				mWriter.close();
				e.printStackTrace();
				printError(e.getMessage());
				throw e;
			}
			r.close();
			mWriter.close();
			File fbak = new File(name + ".bak");
			fbak.delete();
			f.renameTo(fbak);
			File fcopy = new File(name);
			fnew.renameTo(fcopy);
			if(mPerClass) {
				nextDebug();
			}
		} catch (Exception e) {
			e.printStackTrace();
			printError(e.getMessage());
		}
	}
	void read() throws Exception {
		mLast = mToken;
		String write = mToken;
		mToken = null;
		mSt.initToken();
		int i = mSt.nextToken();
		if (i != Tokenizer.TYPE_EOF) {
			mToken = mSt.getString();
			if (mToken == null) {
				mToken = ""+((char) i);
			} else if (i == '\'') {
				//mToken="'"+getEscape(mToken)+"'";
				mToken = mSt.getToken();
			} else if (i == '\"') {
				//mToken="\""+getEscape(mToken)+"\"";
				mToken = mSt.getToken();
			} else {
				if (write == null) {
					write = "";
				} else {
					write = write + " ";
				}
			}
		}
		if (write == null ||
				(!write.equals("else ") && !write.equals("else") &&
				!write.equals("super ") && !write.equals("super") &&
				!write.equals("this ") && !write.equals("this") &&
				!write.equals("} ") && !write.equals("}"))) {
			if (mAdd != null && !mAdd.equals("")) {
				writeLine();
				write(mAdd);
				if(!mPerClass) {
					nextDebug();
				}
			}
		}
		mAdd = "";
		if (write != null) {
			write(write);
		}
	}
	void readThis(String s) throws Exception {
		if (!mToken.equals(s)) {
			throw new Exception("Expected: "+s + " got:"+mToken);
		}
		read();
	}
	void process() throws Exception {
		boolean bImport = false;
		read();
		do {
			while (true) {
				if (mToken == null || mToken.equals("{")) {
					break;
				} else if (mToken.equals(";")) {
					if (bImport == false) {
						write(";"+IMPORT);
						bImport = true;
					}
				}
				read();
			}
			processClass();
		} while (mToken != null);
	}
	void processInit() throws Exception {
		do {
			if (mToken.equals("{")) {
				read();
				processInit();
			} else if (mToken.equals("}")) {
				read();
				return;
			} else {
				read();
			}
		} while (true);
	}
	void processClass() throws Exception {
		int type = 0;
		while (true) {
			if (mToken == null) {
				break;
			} else if (mToken.equals("class")) {
				read();
				type = 1;
			} else if (mToken.equals("=")) {
				read();
				type = 2;
			} else if (mToken.equals("static")) {
				mWord = "static";
				read();
				type = 3;
			} else if (mToken.equals("(")) {
				mWord = mLast + "(";
				read();
				if(!mToken.equals(")")) {
					mWord = mWord + mToken;
				}
				type = 3;
			} else if (mToken.equals(",")) {
				read();
				mWord = mWord + "," + mToken;
			} else if (mToken.equals(")")) {
				mWord = mWord + ")";
				read();
			} else if (mToken.equals(";")) {
				read();
				type = 0;
			} else if (mToken.equals("{")) {
				read();
				if (type == 1) {
					processClass();
				} else if (type == 2) {
					processInit();
				} else if (type == 3) {
					writeLine();
					setLine();
					processFunction();
					writeLine();
				}
			} else if (mToken.equals("}")) {
				read();
				break;
			} else {
				read();
			}
		}
	}
	void processBraket() throws Exception {
		do {
			if (mToken.equals("(")) {
				read();
				processBraket();
			} else if (mToken.equals(")")) {
				read();
				return;
			} else {
				read();
			}
		} while (true);
	}
	void processFunction() throws Exception {
		mFunction = mWord;
		writeLine();
		do {
			processStatement();
		} while (!mToken.equals("}"));
		read();
		writeLine();
	}
	void processBlockOrStatement() throws Exception {
		if (!mToken.equals("{")) {
			write("{ //++");
			writeLine();
			setLine();
			processStatement();
			write("} //++");
			writeLine();
		} else {
			read();
			setLine();
			processFunction();
		}
	}
	void processStatement() throws Exception {
		while (true) {
			if (mToken.equals("while") || mToken.equals("for") ||
					mToken.equals("synchronized")) {
				read();
				readThis("(");
				processBraket();
				mIndent++;
				processBlockOrStatement();
				mIndent--;
				return;
			} else if (mToken.equals("if")) {
				read();
				readThis("(");
				processBraket();
				mIndent++;
				processBlockOrStatement();
				mIndent--;
				if (mToken.equals("else")) {
					read();
					mIndent++;
					processBlockOrStatement();
					mIndent--;
				}
				return;
			} else if (mToken.equals("try")) {
				read();
				mIndent++;
				processBlockOrStatement();
				mIndent--;
				while(true) {
					if (mToken.equals("catch")) {
						read();
						readThis("(");
						processBraket();
						mIndent++;
						processBlockOrStatement();
						mIndent--;
					} else if(mToken.equals("finally")) {
						read();
						mIndent++;
						processBlockOrStatement();
						mIndent--;
					} else {
						break;
					}
				}
				return;
			} else if (mToken.equals("{")) {
				if(mLast.equals(")")) {
					// process anonymous inner classes (this is a hack)
					read();
					processClass();
					return;
				} else if(mLast.equals("]")) {
					// process object array initialization (another hack)
					while(!mToken.equals("}")) {
						read();
					}
					read();
					return;
				}
				mIndent++;
				processBlockOrStatement();
				mIndent--;
				return;
			} else if (mToken.equals("do")) {
				read();
				mIndent++;
				processBlockOrStatement();
				readThis("while");
				readThis("(");
				processBraket();
				readThis(";");
				setLine();
				mIndent--;
				return;
			} else if (mToken.equals("case")) {
				mAdd = "";
				read();
				while (!mToken.equals(":")) {
					read();
				}
				read();
				setLine();
			} else if (mToken.equals("default")) {
				mAdd = "";
				read();
				readThis(":");
				setLine();
			} else if (mToken.equals("switch")) {
				read();
				readThis("(");
				processBraket();
				mIndent++;
				processBlockOrStatement();
				mIndent--;
				return;
			} else if (mToken.equals("class")) {
				read();
				processClass();
				return;
			} else if (mToken.equals("(")) {
				read();
				processBraket();
			} else if (mToken.equals("=")) {
				read();
				if (mToken.equals("{")) {
					read();
					processInit();
				}
			} else if (mToken.equals(";")) {
				read();
				setLine();
				return;
			} else if (mToken.equals("}")) {
				return;
			} else {
				read();
			}
		}
	}
	void setLine() throws Exception {
		mAdd += "Profile.visit("+mIndex + ");";
		mLine = mSt.getLine();
	}
	void nextDebug() throws Exception {
		if(mPerFunction) {
			mData.write(mFile + "." + mFunction + " " + mLine + " " + mLast + "\r\n");
		} else {
			mData.write(mFile + " " + mLine + "\r\n");
		}
		mIndex++;
	}
	void writeLine() throws Exception {
		write("\r\n");
		for (int i = 0; i < mIndent; i++) {
			mWriter.write(' ');
		}
	}
	void write(String s) throws Exception {
		mWriter.write(s);
		//System.out.print(s);
	}
	void printError(String error) {
		System.out.println("");
		System.out.println("File:"+mFile);
		System.out.println("ERROR: "+error);
	}
}







