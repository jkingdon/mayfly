package org.ldbc.test;
import java.sql.*;

public class TestStatement extends TestBase {
    public static void main(String[] argv) {
        new TestStatement().test(argv);
    }
    void test(Connection conn) throws SQLException {
        Statement stat=conn.createStatement();
        ResultSet rs;
        int count;
        boolean result;
        
        // test a db2 problem
        stat.execute("CREATE TABLE TEST(ID INT)");
        stat.execute("SELECT * FROM TEST");
        stat.execute("DROP TABLE TEST");        
        
        conn.getTypeMap();
        
        // this method should not throw an exception - if not supported, this calls are ignored
       
        stat.cancel();
        stat.setQueryTimeout(10);
        check(stat.getQueryTimeout()==10);
        stat.setQueryTimeout(0);
        check(stat.getQueryTimeout()==0);
        // this is supposed to throw an exception
        try {
            stat.setQueryTimeout(-1);
            error("setQueryTimeout(-1) didn't throw an exception");
        } catch(SQLException e) {
            // exception - ok
        }
        check(stat.getQueryTimeout()==0);     
        trace("executeUpdate");
        count=stat.executeUpdate("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        checkEqual(count,0);
        count=stat.executeUpdate("INSERT INTO TEST VALUES(1,'Hello')");
        checkEqual(count,1);
        count=stat.executeUpdate("INSERT INTO TEST(VALUE,ID) VALUES('JDBC',2)");
        checkEqual(count,1);
        count=stat.executeUpdate("UPDATE TEST SET VALUE='LDBC' WHERE ID=2 OR ID=1");
        checkEqual(count,2);
        count=stat.executeUpdate("UPDATE TEST SET VALUE='\\LDBC\\' WHERE VALUE LIKE 'LDBC' ");
        checkEqual(count,2);
        count=stat.executeUpdate("UPDATE TEST SET VALUE='LDBC' WHERE VALUE LIKE '\\\\LDBC\\\\'");
        trace("count:"+count);
        checkEqual(count,2);
        count=stat.executeUpdate("DELETE FROM TEST WHERE ID=-1");
        checkEqual(count,0);
        count=stat.executeUpdate("DELETE FROM TEST WHERE ID=2");
        checkEqual(count,1);
        try {
            stat.executeUpdate("SELECT * FROM TEST");
            error("executeUpdate allowed SELECT");
        } catch(SQLException e) {
            trace("no error - SELECT not allowed with executeUpdate");
        }
        count=stat.executeUpdate("DROP TABLE TEST");
        check(count==0);
        
        trace("execute");
        result=stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        check(result==false);
        result=stat.execute("INSERT INTO TEST VALUES(1,'Hello')");
        check(result==false);
        result=stat.execute("INSERT INTO TEST(VALUE,ID) VALUES('JDBC',2)");
        check(result==false);
        result=stat.execute("UPDATE TEST SET VALUE='LDBC' WHERE ID=2");
        check(result==false);
        result=stat.execute("DELETE FROM TEST WHERE ID=3");
        check(result==false);
        result=stat.execute("SELECT * FROM TEST");
        check(result==true);
        result=stat.execute("DROP TABLE TEST");
        check(result==false);
        
        trace("executeQuery");
        try {
            stat.executeQuery("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
            error("executeQuery allowed CREATE TABLE");
        } catch(SQLException e) {
            trace("no error - CREATE not allowed with executeQuery");
        }
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        try {
            stat.executeQuery("INSERT INTO TEST VALUES(1,'Hello')");
            error("executeQuery allowed INSERT");
        } catch(SQLException e) {
            trace("no error - INSERT not allowed with executeQuery");
        }
        try {
            stat.executeQuery("UPDATE TEST SET VALUE='LDBC' WHERE ID=2");
            error("executeQuery allowed UPDATE");
        } catch(SQLException e) {
            trace("no error - UPDATE not allowed with executeQuery");
        }
        try {
            stat.executeQuery("DELETE FROM TEST WHERE ID=3");
            error("executeQuery allowed DELETE");
        } catch(SQLException e) {
            trace("no error - DELETE not allowed with executeQuery");
        }
        stat.executeQuery("SELECT * FROM TEST");
        try {
            stat.executeQuery("DROP TABLE TEST");
            error("executeQuery allowed DROP");
        } catch(SQLException e) {
            trace("no error - DROP not allowed with executeQuery");
        }
        // getMoreResults
        rs=stat.executeQuery("SELECT * FROM TEST");
        check(stat.getMoreResults()==false);
        try {
            // supposed to be closed now
            rs.next();
            error("getMoreResults didn't close this resultset");
        } catch(SQLException e) {
            trace("no error - getMoreResults is supposed to close the resultset");
        }
        check(stat.getUpdateCount()==-1);
        count=stat.executeUpdate("DELETE FROM TEST");
        check(stat.getMoreResults()==false);
        check(stat.getUpdateCount()==-1);
        
        stat.execute("DROP TABLE TEST");
        stat.executeUpdate("DROP TABLE IF EXISTS TEST");
        
        check(stat.getWarnings()==null);
        stat.clearWarnings();
        check(stat.getWarnings()==null);
        check(conn==stat.getConnection());
        stat.close();

    }
}
