/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;

/** 
 * Represents a statement.
 */
public class jdbcStatement implements Statement {
    static int counter;
    int id=counter++;
    boolean closed;
    Adapter adapter;
    jdbcConnection conn;
    PreparedStatement prep;
    Statement stat;
    jdbcResultSet resultSet;
    int maxRows;
    boolean maxRowsSet;
    boolean escapeProcessing=true;
    int queryTimeout;
    boolean queryTimeoutSet;
    int fetchSize;
    boolean fetchSizeSet;
    int updateCount;
    
    
    /**
     * Executes a query (select statement) and returns the resultset.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     *
     * @return the resultset 
     */
    public ResultSet executeQuery(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            closeOld();
            checkClosed();
            if(escapeProcessing) {
                sql=conn.translateSQL(sql);
            }
			Command command=conn.translate(sql);
            command.checkQuery();
            jdbcResultSet rs;
            if(command.isPseudo()) {
                ResultSet rs2 = command.executePseudo(conn).getResultset();
                rs=new jdbcResultSet(conn,this,null, rs2,command);
            } else {
                prepare(command);
                rs=new jdbcResultSet(conn,this,null,prep.executeQuery(),command);
                command.postExecuteInsertCreate(prep);
            }
            if(Trace.isEnabled()) Trace.traceResult(rs.getId());
            resultSet=rs;
            updateCount=-1;
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Executes a statement (insert, update, delete, create, drop) 
     * and returns the update count.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     *
     * If the statement is a create or drop and does not throw an exception,
     * the current transaction (if any) is committed after executing the statement.
     * If autocommit is on, this statement will be committed.
     *
     * @param sql the SQL statement
     * @return the update count (number of row affected by an insert, 
     *         update or delete, or 0 if no rows or the statement was a
     *         create, drop, commit or rollback)
     * @throws SQLException if a database error occured or a 
     *         select statement was executed
     */
    public int executeUpdate(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            closeOld();
            checkClosed();
            if(escapeProcessing) {
                sql=conn.translateSQL(sql);
            }
            Command command=conn.translate(sql);
            command.checkHasUpdateCount();
			sql=command.getVendorSQL();
            int count;
            if(!command.needToExecute(conn)) {
                count=0;
            } else if(command.isPseudo()) {
                command.executePseudo(conn);
                count=0;
            } else if(command.isCreateOrDrop()) {
                stat.executeUpdate(sql);
                command.postExecuteInsertCreate(prep);
                // workaround for a PostgreSQL bug
                count=0;
                conn.commitInternal();
            } else {
                prepare(command);
                count = prep.executeUpdate();
                command.postExecuteInsertCreate(prep);
                if(conn.autoCommit) {
                    conn.commitInternal();
                }
            }
            updateCount=count;
            if(Trace.isEnabled()) Trace.traceResult(count);
            return count;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Executes an arbitrary statement.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     *
     * If the statement is a create or drop and does not throw an exception,
     * the current transaction (if any) is committed after executing the statement.
     * If autocommit is on, and the statement is not a select, this statement will be committed.
     *
     * @return true if a resultset is available, false if not
     */
    public boolean execute(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            closeOld();
            checkClosed();
            if(escapeProcessing) {
                sql=conn.translateSQL(sql);
            }
            Command command=conn.translate(sql);
			sql=command.getVendorSQL();
            boolean result;
            jdbcResultSet rs;
            int count;
            if(!command.needToExecute(conn)) {
                result=false;
                count=0;
                rs=null;
            } else if(command.isPseudo()) {
                Result res = command.executePseudo(conn);
                result = res.isResultSet();
                count = res.getUpdateCount();
                if(result) {
                    ResultSet rs2 = res.getResultset();
                    rs=new jdbcResultSet(conn,this,null, rs2, command);
                } else {
                    rs=null;
                } 
            } else if(command.isCreateOrDrop()) {
                result = false;
                stat.executeUpdate(sql);
                // workaround for a PostgreSQL bug
                count=0;
                command.postExecuteInsertCreate(prep);
                conn.commitInternal();
                rs=null;
            } else if(command.hasUpdateCount()) {
                result = false;
                rs = null;
                prepare(command);
                count = prep.executeUpdate();
                command.postExecuteInsertCreate(prep);
            } else {
                result=true;
                count=-1;
                prepare(command);
                rs=new jdbcResultSet(conn,this,null,prep.executeQuery(), command);
                command.postExecuteInsertCreate(prep);
            }
            if(command.isCreateOrDrop() || (conn.autoCommit && command.hasUpdateCount())) {
                conn.commitInternal();
            }
            updateCount=count;
            resultSet=rs;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the last resultset produces by this statement. 
     *
     * @return the resultset 
     */
    public ResultSet getResultSet() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            jdbcResultSet rs = resultSet;
            if(Trace.isEnabled()) Trace.traceResult(rs.getId());
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the last update count (how many rows where updated / deleted)
     * of this statement.
     *
     * @return the update count (number of row affected by an insert, 
     *         update or delete, or 0 if no rows or the statement was a
     *         create, drop, commit or rollback)
     */
    public int getUpdateCount() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            int count = updateCount;
            if(Trace.isEnabled()) Trace.traceResult(count);
            return count;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Closes this statement.
     * All resultsets that where created by this statement 
     * become invalid after calling this method.     
     */
    public void close() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            if(!closed) {
                closed=true;
                if(prep!=null) {
                    prep.close();
                }
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the connection that created this object.
     *
     * @return the connection 
     */
    public Connection getConnection() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            if(Trace.isEnabled()) Trace.traceResult(conn.getId());
            return conn;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the first warning reported by calls on this object.
     * This driver does not support warnings, and will always return null.
     *
     * @return null
     */
    public SQLWarning getWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        return null; 
    }
    /**
     * Clears all warnings. As this driver does not support warnings,
     * this call is ignored.
     */
    public void clearWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
    }
    /**
     * Moves to the next resultset - however there is always only one resultset.
     * This call also closes the current resultset (if there is one).
     * Returns true if there is a next resultset (that means - it always returns false).
     *
     * @return false 
     * @throws SQLException if this object is closed or invalid. 
     */
    public boolean getMoreResults() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the name of the cursor. This call is ignored.
     *
     * @param name - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setCursorName(String name) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),name);
        checkClosed();
    }
    /**
     * Sets the fetch direction. 
     * This call is ignored by this driver. 
     *
     * @param direction - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setFetchDirection(int direction) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),direction);
        checkClosed();
    }
   /**
     * Gets the fetch direction. 
     *
     * @return the direction: FETCH_FORWARD
     * @throws SQLException if this object is closed or invalid 
     */
    public int getFetchDirection() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mStat.getFetchDirection();
            int result=ResultSet.FETCH_FORWARD;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum number of rows for a ResultSet.
     *
     * @return the number of rows where 0 means no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public int getMaxRows() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            int result=maxRows;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum number of rows for a ResultSet.
     *
     * @param max the number of rows where 0 means no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public void setMaxRows(int max) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),max);
            maxRows=max;
            maxRowsSet=true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the number of rows suggested to read in one step.
     * This value can not be higher than the maximum rows (setMaxRows)
     * set by the statement or prepared statement, otherwise an exception
     * is throws.
     *
     * @param rows the number of rows
     * @throws SQLException if this object is closed or invalid 
     */
    public void setFetchSize(int rows) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),rows);
            checkClosed();
            if(rows<0) {
                throw Factory.getInvalidValueException("rows:"+rows);
            }
            if(rows>0) {
                if(maxRows>0 && rows>maxRows) {
                    throw Factory.getInvalidValueException("rows:"+rows+" max:"+maxRows);
                }
            }
            fetchSize=rows;
            fetchSizeSet=true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the number of rows suggested to read in one step.
     *
     * @return the current fetch size
     * @throws SQLException if this object is closed or invalid 
     */
    public int getFetchSize() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=fetchSize;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset concurrency created by this object. 
     *
     * @return the concurrency (CONCUR_READ_ONLY)
     * @throws SQLException if this object is closed or invalid 
     */
    public int getResultSetConcurrency() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=ResultSet.CONCUR_READ_ONLY;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset type created by this object. 
     *
     * @return the concurrency (TYPE_SCROLL_INSENSITIVE)
     * @throws SQLException if this object is closed or invalid 
     */
    public int getResultSetType()  throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=ResultSet.TYPE_SCROLL_INSENSITIVE;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum number of bytes for a resultset column.
     * 
     * @return the maximum number of bytes, 0 means no limit.
     *                currently returns always 0 for no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public int getMaxFieldSize() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=0;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the maximum number of bytes for a resultset column.
     * This method does currently do nothing for this driver.
     *
     * @param max the maximum size - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setMaxFieldSize(int max) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),max);
            checkClosed();
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Enables or disables processing or JDBC escape syntax.
     * See also Connection.nativeSQL.
     *
     * @param enable - true (default) or false (no conversion is attempted)
     * @throws SQLException if this object is closed or invalid 
     */
    public void setEscapeProcessing(boolean enable) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),""+enable);
            checkClosed();
            escapeProcessing=enable;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Cancels a currently running statement, 
     * if that is supported by the database. 
     * This method must be called from within another
     * thread then the execute method. If the database does not support
     * the functionality, this method does nothing.
     *
     * @throws SQLException if this object is closed or invalid 
     */
    public void cancel() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            if(prep != null) {
                adapter.cancel(prep);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the current query timeout in seconds.
     * This method will succeed, even if the functionality is not supported by the database.
     *
     * @return the timeout in seconds
     * @throws SQLException if this object is closed or invalid 
     */
    public int getQueryTimeout() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            int result=queryTimeout;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;            
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the current query timeout in seconds.
     * This method will succeed, even if the functionality is not supported by the database.
     *
     * @param seconds - the timeout in seconds - 
     *                0 means no timeout, values smaller 0 will throw an exception
     * @throws SQLException if this object is closed or invalid 
     */
    public void setQueryTimeout(int seconds) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),seconds);
            if(seconds<0) {
                throw Factory.getInvalidValueException("seconds:"+seconds);
            }
            queryTimeout=seconds;
            queryTimeoutSet=true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Adds a statement to the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void addBatch(String sql) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
        throw Factory.getUnsupportedException(); 
    }
    
    /**
     * Clears the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void clearBatch() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Executes the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @return the array of updatecounts
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int[] executeBatch() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    
    /**
     * Return a resultset that contains the last generated autoincrement key for this connection.
     * 
     * @return the resultset with one row and one column containing the key
     * @throws SQLException if this object is closed or invalid 
     */
    public ResultSet getGeneratedKeys() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            Command command = new Command(adapter);
            command.setType(Command.GET_AUTOINCREMENT_KEY);
            Result result = command.executePseudo(conn);
            ResultSet rs = result.getResultset();
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean getMoreResults(int current) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, String[] columnNames) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, int[] columnIndexes) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, String[] columnNames) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getResultSetHoldability() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
// =============================================================    
    
    jdbcStatement(Adapter adapter,jdbcConnection conn) throws SQLException {
        this.adapter = adapter;
        this.conn = conn;
        this.stat = conn.getVendorObject().createStatement();
    }
    
    void checkClosed() throws SQLException {
        if(closed) {
            throw Factory.getClosedException();
        }
        if(conn.closed) {
            throw Factory.getClosedException();
        }
    }
    
    String getId() {
        return "stat"+id;
    }
    
    SQLException convertThrowable(Throwable e) {
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
    
    void closeOld() {
        if(resultSet!=null) {
            try {
                resultSet.close();
            } catch(SQLException e) {
                // ignore exception on close
            }
            resultSet=null;
        }
        updateCount=-1;
    }
    
    void prepare(Command command) throws SQLException {
        String sql=command.getVendorSQL();
        PreparedStatement prep=conn.getVendorObject().prepareStatement(sql);
        if(queryTimeoutSet) {
            prep.setQueryTimeout(queryTimeout);
        }
        if(fetchSizeSet) {
            prep.setFetchSize(fetchSize);
        }
        if(maxRowsSet) {
            prep.setMaxRows(maxRows);
        }
        this.prep=prep;
        command.preExecuteInsertCreate(prep);
    }
    
}

