package org.ldbc.test.synth;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

class Database {
	private static int nextId;
	private int id;
    private String driver;
    private String url;
    private String user;
    private String password;
    private Connection conn;
    private HashMap tables = new HashMap();
    private boolean connected;
    
    Database(String driver, String url, String user, String password) {
        this.driver = driver;
        this.url = url;
        this.user = user;
        this.password = password;
        id = nextId++;
        print("url="+url);
    }
    
    Command getConnect() {
    	return new Command(this, Command.CONNECT);
    }
    
	Command getReset() {
		return new Command(this, Command.RESET);
	}

	Command getDisconnect() {
    	return new Command(this, Command.DISCONNECT);
    }
    
    Command getCreateTable(Table table) {
    	return new Command(this, Command.CREATE_TABLE, null, table);
    }
    
    Command getDropTable(Table table) {
    	return new Command(this, Command.DROP_TABLE, null, table);
    }
    
    Command getCommit() {
    	return new Command(this, Command.COMMIT);
    }
    
    Command getRollback() {
    	return new Command(this, Command.ROLLBACK);
    }
    
    Command getSetAutoCommit(boolean auto) {
    	int type = auto ? Command.AUTOCOMMIT_ON : Command.AUTOCOMMIT_OFF;
    	return new Command(this, type);
    }
    
    Command getRandomSelectJoin(Table table) {
    	Command command = new Command(this, Command.SELECT, "M", table);
    	Generator gen = Generator.getInstance();
    	int len = gen.getLog(5)+1;
    	String globalJoinCondition = "";
    	for(int i=0; i<len; i++) {
			Table t2 = getRandomTable();
			String alias = "J" + i;
			command.addSubqueryTable(alias, t2);
			Expression joinOn = Expression.getRandomJoinOn(command, alias);
			if(gen.getBoolean(50)) {
    			// regular join
				if(globalJoinCondition.length()>0) {
					globalJoinCondition += " AND ";
		    			
				}
				globalJoinCondition += " (" + joinOn.getSQL() + ") ";
    			command.addJoin(", "+t2.getName()+" "+alias);
    		} else {
    			String join = " JOIN "+t2.getName()+" "+alias+" ON "+joinOn.getSQL();
    			if(gen.getBoolean(20)) {
    				command.addJoin(" LEFT OUTER"+join);
    			} else {
    				command.addJoin(" INNER"+join);
    			}
    		}
    	}
    	command.selectList = Expression.getRandomSelectList(command);
    	// TODO group by, having
    	String cond = Expression.getRandomCondition(command).getSQL();
    	if(globalJoinCondition.length()>0) {
    		if(cond!=null) {
    			cond = "(" + globalJoinCondition + " ) AND (" + cond + ")";
    		} else {
    			cond = globalJoinCondition;
    		}
    	}
    	command.condition = cond;
    	command.order = Expression.getRandomOrder(command);
    	return command;
    }
    
    Command getRandomSelect(Table table) {
    	Command command = new Command(this, Command.SELECT, "M", table);
    	command.selectList = Expression.getRandomSelectList(command);
    	// TODO group by, having, joins
    	command.condition = Expression.getRandomCondition(command).getSQL();
    	command.order = Expression.getRandomOrder(command);
    	return command;
    }
    
    Command getRandomDelete(Table table) {
    	Command command = new Command(this, Command.DELETE, null, table);
    	command.condition = Expression.getRandomCondition(command).getSQL();
    	return command;
    }

    Command getRandomUpdate(Table table) {
    	Command command = new Command(this, Command.UPDATE, null, table);
    	command.prepareUpdate();
    	return command;
    }
    
    Command getCreateIndex(Index index) {
    	return new Command(this, Command.CREATE_INDEX, index);
    }

    Command getRandomInsert(Table table) {
    	Command command = new Command(this, Command.INSERT, null, table);
    	command.prepareInsert();
    	return command;
    }
    
    void reset() throws SQLException {
    	print("reset");
        DatabaseMetaData meta = conn.getMetaData();
        Statement stat = conn.createStatement();
        ArrayList tables = new ArrayList();
        ResultSet rs = meta.getTables(null, null, null, new String[] { "TABLE"});
        while (rs.next()) {
            tables.add(rs.getString("TABLE_NAME"));
        }
        while (tables.size() > 0) {
            int dropped = 0;
            for (int i = 0; i < tables.size(); i++) {
                try {
                    String table = (String) tables.get(i);
                    stat.execute("DROP TABLE " + table);
                    dropped++;
                    tables.remove(i);
                    i--;
                } catch (SQLException e) {
                    // maybe a referencial integrity
                }
            }
            // could not drop any table and still tables to drop
            if (dropped == 0 && tables.size() > 0) {
                throw new Error("Can not drop "+tables);
            }
        }
    }

    void connect() throws Exception {
        if(driver!=null) {
            Class.forName(driver);
        }
        print("connect to "+url);
        conn = DriverManager.getConnection(url, user, password);
        connected = true;
    }
    
    void disconnect() throws SQLException {
        print("disconnect "+url);
        conn.close();
        connected = false;
    }

    public void createTable(Table table) throws SQLException {
    	execute(table.getCreateSQL());
    	tables.put(table.getName(), table);
	}

	public void dropTable(Table table) throws SQLException {
		execute(table.getDropSQL());
		tables.remove(table.getName());
	}
	
	public void createIndex(Index index) throws SQLException {
		execute(index.getCreateSQL());
		index.getTable().addIndex(index);
	}

	public void dropIndex(Index index) throws SQLException {
		execute(index.getDropSQL());
		index.getTable().removeIndex(index);
	}

	public void insert(Table table, Column[] c, Value[] v) throws SQLException {
		execute(table.getInsertSQL(c, v));
	}
	
	private void execute(String sql) throws SQLException {
		print(sql);
		conn.createStatement().execute(sql);
	}

	public Result select(String sql) throws SQLException {
		Statement stat = conn.createStatement();
		print(sql);
		Result result = new Result(stat.executeQuery(sql));
		return result;
	}

	public Result delete(Table table, String condition) throws SQLException {
		String sql = "DELETE FROM " + table.getName();
		if(condition!=null) {
			sql += "\n  WHERE " + condition;
		}
		Statement stat = conn.createStatement();
		print(sql);
		Result result = new Result(stat.executeUpdate(sql));
		return result;
	}

	public Result update(Table table, Column[] columns, Value[] values, String condition) throws SQLException {
		String sql = "UPDATE " + table.getName() + " SET ";
		for(int i=0; i<columns.length; i++) {
			if(i>0) {
				sql += ", ";
			}
			sql += columns[i].getName() + "=" + values[i].getSQL();
		}
		if(condition!=null) {
			sql += "\n  WHERE " + condition;
		}
		Statement stat = conn.createStatement();
		print(sql);
		Result result = new Result(stat.executeUpdate(sql));
		return result;
	}

	public void setAutoCommit(boolean b) throws SQLException {
		print("autoCommit " + b);
		conn.setAutoCommit(b);
	}

	public void commit() throws SQLException {
		print("commit");
		conn.commit();
	}
	
	public void rollback() throws SQLException {
		print("rollback");
		conn.rollback();
	}
	
	private void print(String s) {
		System.out.println("["+id+"] "+s);
	}
	
	public Table getRandomTable() {
		Object[] list = tables.keySet().toArray();
		int id = Generator.getInstance().getInt(list.length);
		return (Table)tables.get(list[id]);
	}

}
