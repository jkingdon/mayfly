package org.ldbc.test;
import java.sql.*;
import java.util.*;

public class TestTransaction extends TestBase {
    public static void main(String[] argv) {
        new TestTransaction().test(argv);
    }
    Statement stat;
    void test(Connection conn) throws SQLException {
        trace("default TransactionIsolation="+conn.getTransactionIsolation());
        conn.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
        check(conn.getTransactionIsolation()==Connection.TRANSACTION_READ_COMMITTED);
        conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);
        check(conn.getTransactionIsolation()==Connection.TRANSACTION_SERIALIZABLE);
        stat=conn.createStatement();
        check(conn.getAutoCommit()==true);
        conn.setAutoCommit(false);
        check(conn.getAutoCommit()==false);
        conn.setAutoCommit(true);
        check(conn.getAutoCommit()==true);
        test("CREATE TABLE TEST(ID INT PRIMARY KEY)");
        conn.commit();
        test("INSERT INTO TEST VALUES(0)");
        conn.rollback();
        testValue("SELECT COUNT(*) FROM TEST","1");
        conn.setAutoCommit(false);
        test("DELETE FROM TEST");
        //testValue("SELECT COUNT(*) FROM TEST","0");
        conn.rollback();
        testValue("SELECT COUNT(*) FROM TEST","1");
        conn.commit();
        conn.setAutoCommit(true);
        testNestedResultSets(conn);
        conn.setAutoCommit(false);
        testNestedResultSets(conn);
    }
    void testNestedResultSets(Connection conn) throws SQLException {
        test("CREATE TABLE NEST1(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        test("CREATE TABLE NEST2(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        DatabaseMetaData meta=conn.getMetaData();
        Vector result;
        ResultSet rs1,rs2;
        result=new Vector();
        rs1=meta.getTables(null,null,"NEST%",null);
        while(rs1.next()) {
            String table=rs1.getString("TABLE_NAME");
            rs2=meta.getColumns(null,null,table,null);
            while(rs2.next()) {
                String column=rs2.getString("COLUMN_NAME");
                trace("Table: "+table+" Column: "+column);
                result.add(table+"."+column);
            }
        }
        if(result.size()!=4) {
            error("Wrong result, should be NEST1.ID, NEST1.NAME, NEST2.ID, NEST2.NAME but is "+result);
        }
        result=new Vector();
        test("INSERT INTO NEST1 VALUES(1,'A')");
        test("INSERT INTO NEST1 VALUES(2,'B')");
        test("INSERT INTO NEST2 VALUES(1,'1')");
        test("INSERT INTO NEST2 VALUES(2,'2')");
        Statement s1=conn.createStatement();
        Statement s2=conn.createStatement();
        rs1=s1.executeQuery("SELECT * FROM NEST1 ORDER BY ID");
        while(rs1.next()) {
            rs2=s2.executeQuery("SELECT * FROM NEST2 ORDER BY ID");
            while(rs2.next()) {
                String v1=rs1.getString("VALUE");
                String v2=rs2.getString("VALUE");
                result.add(v1+"/"+v2);
            }
        }
        if(result.size()!=4) {
            error("Wrong result, should be A/1, A/2, B/1, B/2 but is "+result);
        }
        result=new Vector();
        rs1=s1.executeQuery("SELECT * FROM NEST1 ORDER BY ID");
        rs2=s1.executeQuery("SELECT * FROM NEST2 ORDER BY ID");
        try {
            rs1.next();
            error("next worked on a closed resultset");
        } catch(SQLException e) {
            // ok - ignore
        }
        // this is already closed, so but closing again should no do any harm
        rs1.close();
        while(rs2.next()) {
            String v1=rs2.getString("VALUE");
            result.add(v1);
        }
        if(result.size()!=2) {
            error("Wrong result, should be A, B but is "+result);
        }
        test("DROP TABLE NEST1");
        test("DROP TABLE NEST2");
    }
    void testValue(String sql,String data) throws SQLException {
        ResultSet rs=stat.executeQuery(sql);
        rs.next();
        String s=rs.getString(1);
        if(s==null ? (data!=null) : (!s.equals(data))) {
            error("s= "+s+" should be: "+data);
        }
    }
    void test(String sql) throws SQLException {
        trace(sql);
        stat.execute(sql);
    }
}

