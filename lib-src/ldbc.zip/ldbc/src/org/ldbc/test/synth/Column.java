package org.ldbc.test.synth;

import java.sql.*;

class Column {
	// TODO 		Types.DATE,

	final static int[] TYPES = {
		Types.INTEGER,
		Types.VARCHAR,
		Types.DECIMAL, 
		Types.BLOB,
		Types.CLOB,
	};
    private String name;
    private int type;
    private int precision;
    private int scale;
    private boolean isNullable;
    private boolean isPrimaryKey;
    private boolean isAutoincrement;
    
    Column() {
    }
    
    Column(ResultSetMetaData meta, int index) throws SQLException {
        name = meta.getColumnLabel(index);
        type = meta.getColumnType(index);
        switch(type) {
        case Types.DECIMAL:
        	precision = meta.getPrecision(index);
        	scale = meta.getScale(index);
        case Types.BLOB:
        case Types.BINARY:
        case Types.CLOB:
        case Types.DATE:
        case Types.INTEGER:
        case Types.VARCHAR:
        case Types.CHAR:
        case Types.BIGINT:
        case Types.NUMERIC:
        case Types.TIMESTAMP:
        case Types.NULL:
        case Types.LONGVARBINARY:
        	break;
        default:
        	throw new Error("type="+type);
        }
    }
   
	public static boolean isConditionType(int type) {
		switch(type) {
		case Types.INTEGER:
		case Types.VARCHAR:
		case Types.DECIMAL:
			return true;
		case Types.BLOB:
		case Types.CLOB:
			return false;
		default:
			throw new Error("type="+type);
		}
	}
    
    String getTypeName() {
    	switch(type) {
        case Types.DECIMAL:
        	return "DECIMAL("+precision+", "+scale+")";
        case Types.BLOB:
        	return "BLOB";
        case Types.CLOB:
        	return "CLOB";
        case Types.DATE:
        	return "DATETIME";
        case Types.INTEGER:
        	return "INT";
        case Types.VARCHAR:
        	return "VARCHAR("+precision+")";
        default:
        	throw new Error("type="+type);
        }
    }
    
    public String getCreateSQL() {
        String sql = name + " " + getTypeName();
        if(!isNullable) {
            sql += " NOT NULL";
        }
        if(isAutoincrement) {
        	sql += " AUTOINCREMENT";
        }
        return sql;
    }

	public String getName() {
		return name;
	}

	public Value getRandomValue() {
		return Value.getRandom(type, precision, scale, isNullable);
	}

	public Value getRandomValueNotNull() {
		return Value.getRandom(type, precision, scale, false);
	}

	public static Column getRandomColumn() {
		Generator gen = Generator.getInstance();
		Column column = new Column();
		column.name = gen.randomIdentifier();
		column.type = TYPES[gen.getLog(TYPES.length)];
		column.precision = gen.getInt(20)+2;
		column.scale = gen.getInt(column.precision);
		column.isNullable = gen.getBoolean(50);
		return column;
	}


	public boolean isPrimaryKey() {
		return isPrimaryKey;
	}


	public void setPrimaryKey(boolean b) {
		isPrimaryKey = b;
	}


	public void setNullable(boolean b) {
		isNullable = b;
	}


	public int getType() {
		return type;
	}

}
