/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;
import java.util.*;
import java.net.*;
import java.math.BigDecimal;
import java.util.Calendar;

/**
 * Represents a prepared statement.
 * <p>
 * Some database accept creating a prepared statement object
 * for, let's say, SELECT * FROM TEST, even if the table TEST doesn't exist yet.
 * However, some databases will throw an exception.
 * An application should create a prepared statement object only if all the 
 * required tables are already created. 
 *
 */
public class jdbcPreparedStatement implements PreparedStatement {
    static int counter;
    Command command;
    int id=counter++;
    boolean closed;
    Adapter adapter;
    jdbcConnection conn;
    PreparedStatement prep;
    jdbcResultSet resultSet;
    int maxRows;
    int queryTimeout;
    Vector openResultSets=new Vector();
    int updateCount;

    /**
     * Executes a query (select statement) 
     * and returns the resultset.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     *
     * @return the resultset 
     * @throws SQLException if this object is closed or invalid 
     */
    public ResultSet executeQuery() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            checkClosed();
            command.checkQuery();
            jdbcResultSet rs;
            if(command.isPseudo()) {
                ResultSet rs2 = command.executePseudo(conn).getResultset();
                rs=new jdbcResultSet(conn,null, this, rs2, command);
            } else {
                command.preExecuteInsertCreate(prep);
                ResultSet rs2 = prep.executeQuery();
                rs=new jdbcResultSet(conn, null, this, rs2, command);
                command.postExecuteInsertCreate(prep);
            }
            resultSet=rs;
            updateCount=-1;
            if(Trace.isEnabled()) Trace.traceResult(rs.getId());
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Executes a statement (insert, update, delete, create, drop, commit, rollback) 
     * and returns the update count.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     *
     * If the statement is a create or drop and does not throw an exception,
     * the current transaction (if any) is committed after executing the statement.
     * If autocommit is on, this statement will be committed.
     *
     * @return the update count (number of row affected by an insert, 
     *         update or delete, or 0 if no rows or the statement was a
     *         create, drop, commit or rollback)
     * @throws SQLException if this object is closed or invalid 
     */
    public int executeUpdate() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            checkClosed();
            command.checkHasUpdateCount();
            int count;
            if(!command.needToExecute(conn)) {
                count=0;
            } else if(command.isPseudo()) {
                command.executePseudo(conn);
                count=0;
            } else {
                command.preExecuteInsertCreate(prep);
                count=prep.executeUpdate();
                command.postExecuteInsertCreate(prep);
                if(command.isCreateOrDrop() || conn.autoCommit) {
                    conn.commitInternal();
                }
            }
            updateCount=count;
            if(Trace.isEnabled()) Trace.traceResult(count);
            return count;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Executes an arbitrary statement.
     * If another resultset exists for this statement, this will be closed
     * (even if this statement fails).
     * If autocommit is on, and the statement is not a select, this statement will be committed.
     *
     * @return true if a resultset is available, false if not
     * @throws SQLException if this object is closed or invalid 
     */
    public boolean execute() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            checkClosed();
            boolean result;
            int count;
            jdbcResultSet rs;
            if(!command.needToExecute(conn)) {
                result=false;
                count=0;
                rs=null;
            } else if(command.isPseudo()) {
                Result res = command.executePseudo(conn);
                result = res.isResultSet();
                count = res.getUpdateCount();
                if(result) {
                    ResultSet rs2 = res.getResultset();
                    rs=new jdbcResultSet(conn, null, this, rs2, command);
                } else {
                    rs=null;
                } 
            } else if(command.hasUpdateCount()) {
                command.preExecuteInsertCreate(prep);
                result=prep.execute();
                command.postExecuteInsertCreate(prep);
                if(result) {
                    rs=new jdbcResultSet(conn,null,this,prep.getResultSet(), command);
                    count=-1;
                } else {
                    // workaround for a PostgreSQL bug
                    if(command.isCreateOrDrop()) {
                        count=0;
                    } else {
                        count=prep.getUpdateCount();
                    }
                    rs=null;
                }
            } else {
                result=false;
                count = -1;
                command.preExecuteInsertCreate(prep);
                rs=new jdbcResultSet(conn,null,this,prep.executeQuery(),command);
                command.postExecuteInsertCreate(prep);
            }
            if(command.isCreateOrDrop() || (conn.autoCommit && command.hasUpdateCount())) {
                conn.commitInternal();
            }
            resultSet = rs;
            updateCount = count;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the last resultset produces by this statement. 
     *
     * @return the resultset 
     * @throws SQLException if this object is closed or invalid 
     */
    public ResultSet getResultSet() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            jdbcResultSet rs = resultSet;
            if(Trace.isEnabled()) Trace.traceResult(rs.getId());
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the last update count (how many rows where updated / deleted)
     * of this statement.
     *
     * @return the update count (number of row affected by an insert, 
     *         update or delete, or 0 if no rows or the statement was a
     *         create, drop, commit or rollback; -1 if the statement was a select).
     * @throws SQLException if this object is closed or invalid 
     */
    public int getUpdateCount() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            int result = updateCount;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Closes this prepared statement.
     * All resultsets that where created by this prepared statement 
     * become invalid after calling this method.     
     */
    public void close() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            if(!closed) {
                closed=true;
                prep.close();
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets a parameter to null.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param sqlType the data type (Types.xxx) 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setNull(int parameterIndex, int sqlType) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+sqlType);
            checkClosed();
            adapter.setNull(this,parameterIndex,sqlType);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setInt(int parameterIndex, int x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setInt(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setString(int parameterIndex, String x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            adapter.setString(this,parameterIndex,x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setBigDecimal(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     * The time is ignored (set to 0).
     * The milliseconds and nanoseconds in the value are ignored (set to 0).
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setDate(int parameterIndex, java.sql.Date x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setDate(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     * The date is ignored (set to 1970-01-01).
     * The milliseconds and nanoseconds in the value are ignored (set to 0).
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setTime(int parameterIndex, java.sql.Time x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setTime(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     * The milliseconds and nanoseconds in the value are ignored (set to 0).
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setTimestamp(int parameterIndex, java.sql.Timestamp x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setTimestamp(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Clears all parameters.
     *
     * @throws SQLException if this object is closed or invalid 
     */
    public void clearParameters() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            prep.clearParameters(); 
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Calling this method is not legal on a PreparedStatement.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public ResultSet executeQuery(String sql) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Calling this method is not legal on a PreparedStatement.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void addBatch(String sql) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Calling this method is not legal on a PreparedStatement.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Calling this method is not legal on a PreparedStatement.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the connection that created this object.
     *
     * @return the connection 
     */
    public Connection getConnection() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        if(Trace.isEnabled()) Trace.traceResult(conn.getId());
        return conn;
    }
    /**
     * Gets the first warning reported by calls on this object.
     * This driver does not support warnings, and will always return null.
     *
     * @return null
     */
    public SQLWarning getWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        return null; 
    }
    /**
     * Clears all warnings. As this driver does not support warnings,
     * this call is ignored.
     */
    public void clearWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
    }
    /**
     * Sets the value of a parameter.
     * Supported java objects are:
     *
     * <ul>
     * <li>Integer
     * <li>String
     * <li>java.math.BigDecimal
     * <li>java.sql.Timestamp
     * <li>java.sql.Time
     * <li>java.sql.Date
     * </ul>
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value, null is not allowed here 
     * @throws SQLException if this object is closed or invalid
     */
    public void setObject(int parameterIndex, Object x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x));
            checkClosed();
            if(x==null) {
                throw Factory.getInvalidValueException("x:"+x); 
            }
            prep.setObject(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter. The object is converted, if required,
     * to the specified data type before sending to the database.
     * Supported java objects are:
     *
     * <ul>
     * <li>Integer (Types.INTEGER)
     * <li>String (Types.VARCHAR)
     * <li>java.math.BigDecimal (Types.DECIMAL)
     * <li>java.sql.Timestamp (Types.TIMESTAMP)
     * <li>java.sql.Time (Types.TIME)
     * <li>java.sql.Date (Types.DATE)
     * </ul>
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value, null is allowed 
     * @param targetSqlType the type as defined in java.sql.Types
     * @throws SQLException if this object is closed or invalid
     */
    public void setObject(int parameterIndex, Object x, int targetSqlType) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x)+","+targetSqlType);
            checkClosed();
            // workarounds for Oracle bugs
            x=convertObject(x,targetSqlType);
            if(x==null) {
                setNull(parameterIndex,targetSqlType);
            } else {
                prep.setObject(translateParameterIndex(parameterIndex),x,targetSqlType);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter. The object is converted, if required,
     * to the specified data type before sending to the database.
     * Supported java objects are:
     *
     * <ul>
     * <li>Integer (Types.INTEGER)
     * <li>String (Types.VARCHAR)
     * <li>java.math.BigDecimal (Types.DECIMAL)
     * <li>java.sql.Timestamp (Types.TIMESTAMP)
     * <li>java.sql.Time (Types.TIME)
     * <li>java.sql.Date (Types.DATE)
     * </ul>
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value, null is allowed 
     * @param targetSqlType the type as defined in java.sql.Types
     * @throws SQLException if this object is closed or invalid
     */
    public void setObject(int parameterIndex, Object x, int targetSqlType, int scale) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x)+","+targetSqlType+","+scale);
            checkClosed();
            // workarounds for Oracle bugs
            x=convertObject(x,targetSqlType);
            if(x==null) {
                setNull(parameterIndex,targetSqlType);
            } else {
                prep.setObject(translateParameterIndex(parameterIndex),x,targetSqlType,scale);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setBoolean(int parameterIndex, boolean x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setInt(translateParameterIndex(parameterIndex),(x ? 1 : 0));
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setByte(int parameterIndex, byte x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setInt(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setShort(int parameterIndex, short x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setShort(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setLong(int parameterIndex, long x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setLong(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setFloat(int parameterIndex, float x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setFloat(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value 
     * @throws SQLException if this object is closed or invalid 
     */
    public void setDouble(int parameterIndex, double x) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+x);
            checkClosed();
            prep.setDouble(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Moves to the next resultset - however there is always only one resultset.
     * This call also closes the current resultset (if there is one).
     * Returns true if there is a next resultset (that means - it always returns false).
     *
     * @return false 
     * @throws SQLException if this object is closed or invalid. 
     */
    public boolean getMoreResults() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            closeOld();
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * @deprecated
     * This feature is deprecated and is therefore not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setUnicodeStream(int parameterIndex, java.io.InputStream x, int length) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets a parameter to null.
     *
     * @param paramIndex the parameter index (1, 2, ...)
     * @param sqlType the data type (Types.xxx)
     * @param typeName this parameter is ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setNull(int paramIndex, int sqlType, String typeName) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),paramIndex+","+sqlType+","+typeName);
        setNull(paramIndex,sqlType); 
    }
    /**
     * Sets the name of the cursor. This call is ignored.
     *
     * @param name - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setCursorName(String name) throws SQLException {
        if(Trace.isEnabled()) Trace.traceQuote(getId(),name);
        checkClosed();
    }
    /**
     * Gets the maximum number of bytes for a resultset column.
     * 
     * @return the maximum number of bytes, 0 means no limit.
     *                currently returns always 0 for no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public int getMaxFieldSize() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=0;
            //int result=mPrep.getMaxFieldSize();
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the maximum number of bytes for a resultset column.
     * This method does currently do nothing for this driver.
     *
     * @param max the maximum size - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setMaxFieldSize(int max) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),max);
            checkClosed();
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum number of rows for a ResultSet.
     *
     * @return the number of rows where 0 means no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public int getMaxRows() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            int result=prep.getMaxRows();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum number of rows for a ResultSet.
     *
     * @param max the number of rows where 0 means no limit
     * @throws SQLException if this object is closed or invalid 
     */
    public void setMaxRows(int max) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),max);
            prep.setMaxRows(max);
            maxRows=max;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the fetch direction. 
     * This call is ignored by this driver. 
     *
     * @param direction - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setFetchDirection(int direction) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),direction);
        checkClosed();
    }
   /**
     * Gets the fetch direction. 
     *
     * @return the direction: FETCH_FORWARD
     * @throws SQLException if this object is closed or invalid 
     */
    public int getFetchDirection() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mPrep.getFetchDirection();
            int result=ResultSet.FETCH_FORWARD;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset concurrency created by this object. 
     *
     * @return the concurrency (CONCUR_READ_ONLY)
     * @throws SQLException if this object is closed or invalid 
     */
    public int getResultSetConcurrency() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mPrep.getConcurrency();
            int result=ResultSet.CONCUR_READ_ONLY;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset type created by this object. 
     *
     * @return the concurrency (TYPE_SCROLL_INSENSITIVE)
     * @throws SQLException if this object is closed or invalid 
     */
    public int getResultSetType()  throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mPrep.getConcurrency();
            int result=ResultSet.TYPE_SCROLL_INSENSITIVE;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Enables or disables processing or JDBC escape syntax.
     * This method is ignored as the statement may already have been
     * converted by calling Connection.prepareStatement(..)
     *
     * @param enable - ignored
     * @throws SQLException if this object is closed or invalid 
     */
    public void setEscapeProcessing(boolean enable) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),""+enable);
            checkClosed();
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset metadata of the query returned when the statement is executed.
     * As some databases do not support this method, it returns null.
     *
     * @return null as the method is not supported
     * @throws SQLException if this object is closed or invalid 
     */
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            return null;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Cancels a currently running statement, 
     * if that is supported by the database. 
     * This method must be called from within another
     * thread then the execute method. If the database does not support
     * the functionality, this method does nothing.
     *
     * @throws SQLException if this object is closed or invalid 
     */
    public void cancel() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            adapter.cancel(prep);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the current query timeout in seconds.
     * This method will succeed, even if the functionality is not supported by the database.
     *
     * @return the timeout in seconds
     * @throws SQLException if this object is closed or invalid 
     */
    public int getQueryTimeout() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            int result=queryTimeout;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;            
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the current query timeout in seconds.
     * This method will succeed, even if the functionality is not supported by the database.
     *
     * @param seconds - the timeout in seconds - 
     *                0 means no timeout, values smaller 0 will throw an exception
     * @throws SQLException if this object is closed or invalid 
     */
    public void setQueryTimeout(int seconds) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),seconds);
            if(seconds<0) {
                throw Factory.getInvalidValueException("seconds:"+seconds); 
            }
            queryTimeout=seconds;
            prep.setQueryTimeout(seconds);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the number of rows suggested to read in one step.
     * This value can not be higher than the maximum rows (setMaxRows)
     * set by the statement or prepared statement, otherwise an exception
     * is throws.
     *
     * @param rows the number of rows
     * @throws SQLException if this object is closed or invalid 
     */
    public void setFetchSize(int rows) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),rows);
            checkClosed();
            if(rows<0) {
                throw Factory.getInvalidValueException("rows:"+rows); 
            }
            if(rows>0) {
                if(maxRows>0 && rows>maxRows) {
                    throw Factory.getInvalidValueException("rows:"+rows+" max:"+maxRows); 
                }
            }
            prep.setFetchSize(rows);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the number of rows suggested to read in one step.
     *
     * @return the current fetch size
     * @throws SQLException if this object is closed or invalid 
     */
    public int getFetchSize() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=prep.getFetchSize();
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a column as a reference.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setRef(int i, Ref x) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),Trace.quoteObject(x));
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets the date using a specified timezone.
     * The value will be converted to the local timezone.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param calendar the calendar
     * @throws SQLException if this object is closed or invalid 
     */
    public void setDate(int parameterIndex, java.sql.Date x, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+
                    Trace.quoteObject(x)+","+Trace.quoteObject(calendar));
            checkClosed();
            if(x!=null) {
                // convert this calendars time to local time
                calendar=(Calendar)calendar.clone();
                calendar.setTime(x);
                Calendar local=Calendar.getInstance();
                convertTime(calendar,local);
                x=new java.sql.Date(local.getTime().getTime());
            }
            prep.setDate(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the time using a specified timezone.
     * The value will be converted to the local timezone.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param calendar the calendar
     * @throws SQLException if this object is closed or invalid 
     */
    public void setTime(int parameterIndex, java.sql.Time x, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+
                    Trace.quoteObject(x)+","+Trace.quoteObject(calendar));
            checkClosed();
            if(x!=null) {
                // convert this calendars time to local time
                calendar=(Calendar)calendar.clone();
                calendar.setTime(x);
                Calendar local=Calendar.getInstance();
                convertTime(calendar,local);
                x=new java.sql.Time(local.getTime().getTime());
            }
            prep.setTime(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the timestamp using a specified timezone.
     * The value will be converted to the local timezone.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param calendar the calendar
     * @throws SQLException if this object is closed or invalid 
     */
    public void setTimestamp(int parameterIndex, java.sql.Timestamp x, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+
                    Trace.quoteObject(x)+","+Trace.quoteObject(calendar));
            checkClosed();
            if(x!=null) {
                // convert this calendars time to local time
                calendar=(Calendar)calendar.clone();
                calendar.setTime(x);
                Calendar local=Calendar.getInstance();
                convertTime(calendar,local);
                x=new java.sql.Timestamp(local.getTime().getTime());
            }
            prep.setTimestamp(translateParameterIndex(parameterIndex),x);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Clears the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void clearBatch() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        //mPrep.clearBatch();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Executes the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @return the array of updatecounts
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int[] executeBatch() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        //return mPrep.executeBatch();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Adds the current settings to the batch.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void addBatch() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        //mPrep.addBatch();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets the value of a parameter as a Blob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setBlob(int i, Blob x) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets the value of a parameter as a Clob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setClob(int i, Clob x) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets the value of a parameter as a Array.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setArray(int i, Array x) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Sets the value of a parameter as a byte array.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @throws SQLException if this object is closed or invalid 
     */
    public void setBytes(int parameterIndex, byte x[]) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x));
            checkClosed();
            if(x==null) {
                setNull(parameterIndex,Types.BINARY);
            } else {
                adapter.setBytes(this,parameterIndex,x);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter as an input stream.
     * The stream may or may not be closed by the driver / database.
     * If the length is not correct (more or less data is available)
     * some databases throw an exception, some not. Using 0
     * as 'don't know' is not supported.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param length the number of bytes
     * @throws SQLException if this object is closed or invalid 
     */
    public void setBinaryStream(int parameterIndex, java.io.InputStream x, int length) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x)+","+length);
            checkClosed();
            if(x==null) {
                setNull(parameterIndex,Types.BINARY);
            } else {
                adapter.setBinaryStream(this,parameterIndex,x,length);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter as an ASCII stream.
     * The stream may or may not be closed by the driver / database.
     * If the length is not correct (more or less data is available)
     * some databases throw an exception, some not. Using 0
     * as 'don't know' is not supported.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param length the number of bytes
     * @throws SQLException if this object is closed or invalid 
     */
    public void setAsciiStream(int parameterIndex, java.io.InputStream x, int length) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x)+","+length);
            checkClosed();
            if(x==null) {
                setNull(parameterIndex,Types.CLOB);
            } else {
                adapter.setAsciiStream(this,parameterIndex,x,length);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the value of a parameter as a character stream.
     * The stream may or may not be closed by the driver / database.
     * If the length is not correct (more or less data is available)
     * some databases throw an exception, some not. Using 0
     * as 'don't know' is not supported.
     *
     * @param parameterIndex the parameter index (1, 2, ...)
     * @param x the value
     * @param length the number of bytes
     * @throws SQLException if this object is closed or invalid 
     */
    public void setCharacterStream(int parameterIndex, java.io.Reader x, int length) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),parameterIndex+","+Trace.quoteObject(x)+","+length);
            checkClosed();
            if(x==null) {
                setNull(parameterIndex,Types.CLOB);
            } else {
                adapter.setCharacterStream(this,parameterIndex,x,length);
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Return a resultset that contains the last generated autoincrement key for this connection.
     * 
     * @return the resultset with one row and one column containing the key
     * @throws SQLException if this object is closed or invalid 
     */
    public ResultSet getGeneratedKeys() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            Command command = new Command(adapter);
            command.setType(Command.GET_AUTOINCREMENT_KEY);
            Result result = command.executePseudo(conn);
            ResultSet rs = result.getResultset();
            return rs;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean getMoreResults(int current) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int executeUpdate(String sql, String[] columnNames) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, int[] columnIndexes) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean execute(String sql, String[] columnNames) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getResultSetHoldability() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setURL(int parameterIndex, URL x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
//#ifdef JDK14
    public ParameterMetaData getParameterMetaData() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
//#endif
    
    
        
// =============================================================    

    /**
     * Gets the underlying prepared statement object.
     * This method should only be called if functionality is required
     * that is not yet implemented in LDBC, or for testing.
     *
     * @return the underlying PreparedStatement object
     */
    public PreparedStatement getVendorObject() {
        return prep;
    }
    
    /**
     * THIS METHOD SHOULD NOT BE CALLED BY APPLICATIONS.
     * It is provided for database adapter writers only.
     * Conversion between the parameter index as visible to the user
     * and the native parameter index. In most cases, the index is
     * the same but there are some exceptions, for example if autoincrement
     * columns are used. The translation is required if getVendorObject() is used.
     * The application has to be careful to translate, and to translate only once.
     *
     * @param parameterIndex the index visible to the user
     * @return the native index
     */
    public int translateParameterIndex(int parameterIndex) {
        return command.translateParameterIndex(parameterIndex);
    }
    
    /**
     * THIS METHOD SHOULD NOT BE CALLED BY APPLICATIONS.
     * It is provided for database adapter writers only.
     * Returns the open resultsets for this prepared statement.
     *
     * @return the open resultsets
     */
    public Vector getOpenResultSets() {
        return openResultSets;
    }
    
// =============================================================    
    
    jdbcPreparedStatement(Adapter adapter,jdbcConnection conn,String sql) throws SQLException {
        this.adapter=adapter;
        this.conn=conn;
        command=conn.translate(sql);
        prep=conn.conn.prepareStatement(command.getVendorSQL());
    }
    void checkClosed() throws SQLException {
        if(closed) {
            throw Factory.getClosedException();
        }
        if(conn.closed) {
            throw Factory.getClosedException();
        }
    }
    String getId() {
        return "prep"+id;
    }
    // workaround for Oracle bug
    Object convertObject(Object x,int targetSqlType) {
        if(x==null) {
            return null;
        }
        int originalSqlType;
        if(x instanceof String) {
            originalSqlType=Types.VARCHAR;
        } else if(x instanceof java.math.BigDecimal) {
            originalSqlType=Types.DECIMAL;
        } else if(x instanceof Boolean) {
            originalSqlType=Types.BIT;
        } else if(x instanceof Integer) {
            originalSqlType=Types.INTEGER;
        } else if(x instanceof Long) {
            originalSqlType=Types.BIGINT;
        } else if(x instanceof Float) {
            originalSqlType=Types.REAL;
        } else if(x instanceof Double) {
            originalSqlType=Types.DOUBLE;
        } else if(x instanceof byte[]) {
            originalSqlType=Types.BINARY;
        } else if(x instanceof java.sql.Date) {
            originalSqlType=Types.DATE;
        } else if(x instanceof java.sql.Time) {
            originalSqlType=Types.TIME;
        } else if(x instanceof java.sql.Timestamp) {
            originalSqlType=Types.TIMESTAMP;
        } else {
            return x;
        }
        if(originalSqlType==targetSqlType) {
            return x;
        }
        switch(targetSqlType) {
        case Types.VARCHAR:
            return x.toString();
        case Types.DECIMAL:
            return new java.math.BigDecimal(x.toString());
        case Types.BIT:
            return Boolean.valueOf(x.toString());
        case Types.INTEGER:
            return Integer.valueOf(x.toString());
        case Types.BIGINT:
            return Long.valueOf(x.toString());
        case Types.REAL:
            return Float.valueOf(x.toString());
        case Types.DOUBLE:
            return Double.valueOf(x.toString());
        case Types.BINARY:
            return x;
        case Types.DATE:
            return x;
        case Types.TIME:
            return x;
        case Types.TIMESTAMP:
            return x;
        default:
            return x;
        }
    }
    SQLException convertThrowable(Throwable e) {      
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
    static void convertTime(Calendar from,Calendar to) {
        to.set(Calendar.YEAR,from.get(Calendar.YEAR));
        to.set(Calendar.MONTH,from.get(Calendar.MONTH));
        to.set(Calendar.DAY_OF_MONTH,from.get(Calendar.DAY_OF_MONTH));
        to.set(Calendar.HOUR_OF_DAY,from.get(Calendar.HOUR_OF_DAY));
        to.set(Calendar.MINUTE,from.get(Calendar.MINUTE));
        to.set(Calendar.SECOND,from.get(Calendar.SECOND));
        to.set(Calendar.MILLISECOND,from.get(Calendar.MILLISECOND));
    }
    void closeOld() {
        if(resultSet!=null) {
            try {
                resultSet.close();
            } catch(SQLException e) {
                // ignore exception on close
            }
            resultSet=null;
        }
        updateCount=-1;
    }
}

