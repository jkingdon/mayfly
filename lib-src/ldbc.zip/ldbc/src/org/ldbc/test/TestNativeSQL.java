package org.ldbc.test;
import java.sql.*;

public class TestNativeSQL extends TestBase {
    public static void main(String[] argv) {
        new TestNativeSQL().test(argv);
    }
    final static String[] PAIRS=new String[]{
        "CREATE TABLE TEST(ID INT PRIMARY KEY)",
        "CREATE TABLE TEST(ID INT PRIMARY KEY)",
        
        "INSERT INTO TEST VALUES(1)",
        "INSERT INTO TEST VALUES(1)",
        
        "SELECT '{nothing}' FROM TEST",
        "SELECT '{nothing}' FROM TEST",
        
        "SELECT '{fn ABS(1)}' FROM TEST",
        "SELECT '{fn ABS(1)}' FROM TEST",
        
        "SELECT {d '2001-01-01'} FROM TEST",
        "SELECT DATE '2001-01-01' FROM TEST",
        
        "SELECT {t '20:00:00'} FROM TEST",
        "SELECT TIME '20:00:00' FROM TEST",
        
        "SELECT {ts '2001-01-01 20:00:00'} FROM TEST",
        "SELECT TIMESTAMP '2001-01-01 20:00:00' FROM TEST",
        
        "SELECT {fn CONCAT('{fn x}','{oj}')} FROM TEST",
        "SELECT CONCAT('{fn x}','{oj}') FROM TEST",
        
        "SELECT * FROM {oj TEST T1 LEFT OUTER JOIN TEST T2 ON T1.ID=T2.ID}",
        "SELECT * FROM TEST T1 LEFT OUTER JOIN TEST T2 ON T1.ID=T2.ID",
        
        "SELECT * FROM TEST WHERE '{' LIKE '{{' {escape '{'}",
        "SELECT * FROM TEST WHERE '{' LIKE '{{' escape '{'",
                        
        "SELECT * FROM TEST WHERE '}' LIKE '}}' {escape '}'}",
        "SELECT * FROM TEST WHERE '}' LIKE '}}' escape '}'",
        
        "{call TEST('}')}",
        "call TEST('}')",

        "{?= call TEST('}')}",
        "?= call TEST('}')",

        "{? = call TEST('}')}",
        "? = call TEST('}')",

        "{{{{this is a bug}",
        null,
    };
    Connection conn;
    void test(Connection conn) throws SQLException {
        this.conn=conn;
        for(int i=0;i<PAIRS.length;i+=2) {
            test(PAIRS[i],PAIRS[i+1]);
        }
    }
    void test(String original,String expected) throws SQLException {
        trace("original: <"+original+">");
        trace("expected: <"+expected+">");
        try {
            String result=conn.nativeSQL(original);
            trace("result: <"+result+">");
            check(result.equals(expected));
        } catch(SQLException e) {
            check(expected==null);
            trace("got exception, good");
        }
    }
}
