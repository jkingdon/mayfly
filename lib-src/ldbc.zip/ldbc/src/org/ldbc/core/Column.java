/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.sql.*;

public class Column {
    String name;
    DataType type;
    boolean notNull;
    boolean primaryKey;
	boolean autoIncrement;
    String defaultvalue;
    
    public Column(String name,DataType type,boolean notNull,String defaultvalue) {
        this.name=name;
        this.type=type;
        this.notNull=notNull;
        this.defaultvalue=defaultvalue;
    }
    public void setNotNull() {
        notNull=true;
    }
    public void setPrimaryKey() {
        primaryKey=true;
        notNull=true;
    }
	public void setAutoIncrement() {
		autoIncrement=true;
	}
	public boolean isAutoIncrement() {
		return autoIncrement;
	}
    public String getName() {
        return name;
    }
    public boolean isPrimaryKey() {
        return primaryKey;
    }
    public String getCreateSQL(Adapter adapter) throws SQLException {
        String sql=adapter.getDataTypeString(type, autoIncrement);
        sql=adapter.quote(name)+" "+sql;
        if(notNull) {
            sql+=" NOT NULL";
        }
        if(defaultvalue!=null) {
            sql+=" DEFAULT "+defaultvalue;
        }
        return sql;
    }
}

