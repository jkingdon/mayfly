/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;
import java.util.Properties;

/**
 * This class is should not be used by application developers, as it's
 * only required behind the scenes.
 * An application must use DriverManager.getConnection to get a connection.
 */
public class jdbcDriver implements Driver {
    final static int MAJOR_VERSION=0;
    final static int MINOR_VERSION=1;
    final static String START_URL="jdbc:ldbc:";
    /**
     * This method should not be called by an application. 
     * Use DriverManager.getConnection instead.
     * Tries to connect to the specified database.
     *
     * @param url the database url
     * @param info the properties. required are 'user' and 'password', if they
     *        are missing an empty string is used.
     * @return null if this is the wrong kind of url for this driver
     * @throws SQLException if this is the right kind of driver 
     *         for this url, but connecting failed because of:
     *         database not found (SQLState 0000),
     *         wrong or missing user/password (SQLState 0000)
     */
    public Connection connect(String url, Properties info) throws SQLException {
        if(!acceptsURL(url)) {
            return null;
        }
        String user=info.getProperty("user","");
        
        // sendToNSA(info.getProperty("password",""));
        // just joking... good that this driver is open source
        
        int traceBegin=url.indexOf("[ldbc.trace=");
        if(traceBegin!=-1) {
            int traceEnd=url.indexOf(']',traceBegin);
            String trace=url.substring(traceBegin+1,traceEnd);
            url=url.substring(0,traceBegin)+url.substring(traceEnd+1);
            trace=trace.substring(trace.indexOf('=')+1);
            Trace.setOption(trace);
        }
        String vendor_url="jdbc:"+url.substring(START_URL.length());
        Adapter adapter=Factory.getAdapter(vendor_url);
        String driver=adapter.getDriverClass();
        try {
            Class.forName(driver);
        } catch(ClassNotFoundException e) {
            throw Factory.getSQLException(Messages.DRIVER_NOT_FOUND,driver);
        }
        Connection conn=DriverManager.getConnection(vendor_url,info);
		return new jdbcConnection(url,user,adapter,conn);
    }
    /**
     * This method should not be called by an application. 
     * This method is used by DriverManager internally.
     * Checks if this driver accepts a URL of this type.
     *
     * @return if the driver understands the URL
     */
    public boolean acceptsURL(String url) {
        return url!=null && url.startsWith(START_URL);
    }
    /**
     * This method should not be called by an application. 
     * Returns the major version of this driver.
     *
     * @return the major version number
     */
    public int getMajorVersion() {
        return MAJOR_VERSION;
    }
    /**
     * This method should not be called by an application. 
     * Returns the minor version of this driver.
     *
     * @return the minor version number
     */
    public int getMinorVersion() {
        return MINOR_VERSION;
    }
    /**
     * This method should not be called by an application. 
     * Checks if additional properties are required.
     * Always returns a zero length array no matter what the parameters are.
     *
     * @return a zero length array
     */
    public DriverPropertyInfo[] getPropertyInfo(String url, Properties info) {
        return new DriverPropertyInfo[0];
    }
    /**
     * This method should not be called by an application. 
     * Checks if the driver JDBC compliant.
     * Return false at the moment, until the driver is compliant.
     *
     * @return false
     */
    public boolean jdbcCompliant() {
        return false;
    }
    
    /* 
     * Registers the driver
     */
    static {
        jdbcDriver driver=new jdbcDriver();
        try {
            DriverManager.registerDriver(driver);
        } catch(SQLException e) {
            // ignore the exception
        }
    }
} 
