package org.ldbc.test;

import java.sql.*;

public class HelloWorld extends TestBase {

    public static void main(String[] argv) {
        // create a new application and run the test
        new HelloWorld().test(argv);
    }

    void test(Connection conn) throws SQLException {
        // Regular application need to load
        // the driver on their own. Here this
        // is not required as the connection
        // is passed from the TestBase.

        // load the LDBC JDBC driver
        // Class.forName("org.ldbc.jdbc.jdbcDriver");

        // connect to the specified database
        // Connection conn=DriverManager.getConnection(url,user,password);

        // create a new statement object to run queries
        Statement stat = conn.createStatement();
        // create the HELLO_WORLD table
        stat.executeUpdate("CREATE TABLE HELLO_WORLD(ID INT)");
        // if the row already is inserted, update it
        int rows = stat.executeUpdate("UPDATE HELLO_WORLD SET ID=ID+1");
        // no row yet - insert the row
        if (rows == 0) {
            stat.executeUpdate("INSERT INTO HELLO_WORLD VALUES(1)");
        }
        // query the table
        ResultSet rs = stat.executeQuery("SELECT ID FROM HELLO_WORLD");
        // go to the first row in the result
        rs.next();
        // get the row
        int count = rs.getInt(1);
        // display the result
        trace("Hello World was run " + count + " time(s)");
        // close the connection
        conn.close();
    }
}
