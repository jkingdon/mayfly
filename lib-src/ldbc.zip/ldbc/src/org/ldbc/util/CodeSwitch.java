package org.ldbc.util;
import java.io.*;
import java.util.*;

public class CodeSwitch {
    boolean mRecurse;
    private Vector mList=new Vector();
    private Vector mSwitchOn=new Vector();
    private Vector mSwitchOff=new Vector();
    private Vector mSwitches=new Vector();
    private byte[] mFile;
    private String mEndOfLine;
    private Vector mLines;
    private boolean mChanged;
    
    public static void main(String[] argv) {
        (new CodeSwitch()).run(argv);
    }
    void run(String[] a) {
        if (a.length == 0) {
            showUsage();
            return;
        }
        boolean path = false;
        mRecurse = true;
        for (int i = 0; i < a.length; i++) {
            String p = a[i];
            if (p.startsWith("+")) {
                mSwitchOn.addElement(p.substring(1));
            } else if (p.startsWith("-r+")) {
                // (default)
                mRecurse=true;
            } else if (p.startsWith("-r-")) {
                mRecurse=false;
            } else if (p.startsWith("-")) {
                mSwitchOff.addElement(p.substring(1));
            } else {
                addDir(p,true);
                path = true;
            }
        }
        if (!path) {
            printError("no path specified");
            showUsage();
        }
        process();
        if (mSwitchOff.size() == 0 && mSwitchOn.size() == 0) {
            printSwitches();
        }
    }
    void showUsage() {
        String className=getClass().getName();
        System.out.println("Usage: java "+className+" [-r+] [-r-] paths [+|-][labels]");
        System.out.println("If no labels are specified then all used");
        System.out.println("labels in the source code are shown.");
        System.out.println("-r+ recurse subdirectories (default)");
        System.out.println("-r- do not recurse subdirectories");
        System.out.println("Use +MODE to switch on the things labeld MODE");
        System.out.println("Use -MODE to switch off the things labeld MODE");
        System.out.println("Path: Any number of path or files may be specified.");
        System.out.println(" Use . for the current directory (including sub-directories).");
        System.out.println("Example: java "+className+" +JAVA2 .");
        System.out.println("This example switches on code labeled JAVA2 in all *.java files");
        System.out.println("in the current directory and all subdirectories.");
    }
    void process() {
        int len = mList.size();
        for (int i = 0; i < len; i++) {
            String file = (String) mList.elementAt(i);
            if (!processFile(file)) {
                System.out.println("in file "+file + " - this file is skipped");
            }
        }
    }
    void printSwitches() {
        System.out.println("Used labels:");
        for (int i = 0; i < mSwitches.size(); i++) {
            System.out.println((String)(mSwitches.elementAt(i)));
        }
    }
    void addDir(String path,boolean recurse) {
        File f = new File(path);
        if (f.isFile() && path.endsWith(".java")) {
            mList.addElement(path);
        } else if (f.isDirectory()) {
            if(mRecurse || recurse) {
                // one recursion at least
                String list[] = f.list();
                for (int i = 0; i < list.length; i++) {
                    addDir(path + File.separatorChar + list[i],false);
                }
            }
        }
    }
    
    // lines are terminated with \r, \n or \r\n 
    void breakIntoLines() {
        mLines=new Vector();
        int len=mFile.length;
        int last=0;
        int cr=0,lf=0,crlf=0;
        for(int i=0;i<len;i++) {
            byte c=mFile[i];
            if(c=='\r' || c=='\n') {
                if(c=='\r') {
                    if(i<len-1 && mFile[i+1]=='\n') {
                        i++;
                        crlf++;
                    } else {
                        cr++;
                    }
                } else {
                    lf++;
                }
                if(i<len) {
                    mLines.addElement(new String(mFile,last,i-last+1));
                    last=i+1;
                }
            }
        }
        if(cr>lf && cr>crlf) {
            mEndOfLine="\r";
        } else if(lf>crlf) {
            mEndOfLine="\n";
        } else {
            mEndOfLine="\r\n";
        }
        mLines.addElement(new String(mFile,last,len-last));
    }
    String getLine(int line) {
        return (String)mLines.elementAt(line);
    }
    void insertLine(int line,String s) {
        mLines.insertElementAt(s,line);
        mChanged=true;
    }
    void removeLine(int line) {
        mLines.remove(line);
        mChanged=true;
    }

    boolean processFile(String name) {
        File f = new File(name);
        boolean switchoff = false;
        boolean working = false;
        int state=0;
        try {
            long raw_len=f.length();
            if(raw_len>Integer.MAX_VALUE) {
                printError("Files bigger than Integer.MAX_VALUE are not supported");
                return false;
            }
            int len=(int)raw_len;
            mFile=new byte[len];
            RandomAccessFile read=new RandomAccessFile(f,"r");
            read.readFully(mFile);
            read.close();
            breakIntoLines();
            mChanged=false;

            for(int i=0;i<mLines.size();i++) {
                String line = getLine(i);
                String lineTrim = line.trim();
                if (working) {
                    if (lineTrim.startsWith("/*") || lineTrim.startsWith("*/")) {
                        removeLine(i);
                        i--;
                        continue;
                    }
                }
                if (lineTrim.startsWith("//#")) {
                    if (lineTrim.startsWith("//#ifdef ")) {
                        if (state != 0) {
                            printError("//#ifdef not allowed inside //#ifdef");
                            return false;
                        }
                        state = 1;
                        String s = lineTrim.substring(9);
                        boolean switchedOn=false;
                        boolean switchedOff=false;
                        if(mSwitchOn.indexOf(s) != -1) {
                            switchedOn=true;
                        }
                        if(mSwitchOff.indexOf(s) != -1) {
                            switchedOff=true;
                        }
                        if(s.indexOf("&&")!=-1) {
                            switchedOn=true;
                            s+="&&";
                            while(s.length()>0) {
                                int id=s.indexOf("&&");
                                if(id==-1) {
                                    break;
                                }
                                String s1=s.substring(0,id).trim();
                                s=s.substring(id+2).trim();
                                if (mSwitches.indexOf(s1) == -1) {
                                   mSwitches.addElement(s1);
                                   switchedOn=false;
                                }
                                if(mSwitchOn.indexOf(s1) == -1) {
                                    switchedOff=true;
                                    switchedOn=false;
                                }
                                if(mSwitchOff.indexOf(s1) != -1) {
                                    switchedOff=true;
                                    switchedOn=false;
                                }
                            }
                        }
                        if (switchedOn) {
                            working = true;
                            switchoff = false;
                        } else if (switchedOff) {
                            working = true;
                            insertLine(++i,"/*"+mEndOfLine);
                            switchoff = true;
                        }
                        if (mSwitches.indexOf(s) == -1) {
                            mSwitches.addElement(s);
                        }
                    } else if (lineTrim.startsWith("//#else")) {
                        if (state != 1) {
                            printError("//#else without //#ifdef");
                            return false;
                        }
                        state = 2;
                        if (working) {
                            if(switchoff) {
                                insertLine(++i,"*/"+mEndOfLine);
                                switchoff = false;
                            } else {
                                insertLine(++i,"/*"+mEndOfLine);
                                switchoff = true;
                            }
                        }
                    } else if (lineTrim.startsWith("//#endif")) {
                        if (state == 0) {
                            printError("//#endif without //#ifdef");
                            return false;
                        }
                        state = 0;
                        if (working && switchoff) {
                            insertLine(i++,"*/"+mEndOfLine);
                        }
                        working = false;
                    }
                }
            }
            if (state != 0) {
                printError("//#endif missing");
                return false;
            }
            if(mChanged) {
                File fnew = new File(name + ".new");
                FileWriter write = new FileWriter(fnew);
                for(int i=0;i<mLines.size();i++) {
                    write.write(getLine(i));
                }
                write.close();
                File fbak = new File(name + ".bak");
                fbak.delete();
                f.renameTo(fbak);
                File fcopy = new File(name);
                fnew.renameTo(fcopy);
                fbak.delete();
                System.out.println(name);
            }
            return true;
        } catch (Exception e) {
            printError(e);
            return false;
        }
    }

    /*
    boolean processFileOld(String name) {
        File f = new File(name);
        File fnew = new File(name + ".new");
        int state = 0; // 0=normal 1=inside_if 2=inside_else
        boolean switchoff = false;
        boolean working = false;
        boolean changed = false;
        try {
            LineNumberReader read = new LineNumberReader(new FileReader(f));
            FileWriter write = new FileWriter(fnew);
            while (true) {
                String line = read.readLine();
                if (line == null) {
                    break;
                }
                if (working) {
                    if (line.equals("/"+"*") || line.equals("*"+"/")) {
                        continue;
                    }
                }
                if (!line.startsWith("//#")) {
                    write.write(line + "\r\n");
                } else {
                    if (line.startsWith("//#ifdef ")) {
                        if (state != 0) {
                            printError("'#ifdef' not allowed inside '#ifdef'");
                            return false;
                        }
                        write.write(line + "\r\n");
                        state = 1;
                        String s = line.substring(9);
                        boolean switchedOn=false;
                        boolean switchedOff=false;
                        if(mSwitchOn.indexOf(s) != -1) {
                            switchedOn=true;
                        }
                        if(mSwitchOff.indexOf(s) != -1) {
                            switchedOff=true;
                        }
                        if(s.indexOf("&&")!=-1) {
                            switchedOn=true;
                            s+="&&";
                            while(s.length()>0) {
                                int id=s.indexOf("&&");
                                if(id==-1) {
                                    break;
                                }
                                String s1=s.substring(0,id).trim();
                                s=s.substring(id+2).trim();
                                if (mSwitches.indexOf(s1) == -1) {
                                   mSwitches.addElement(s1);
                                   switchedOn=false;
                                }
                                if(mSwitchOn.indexOf(s1) == -1) {
                                    switchedOff=true;
                                    switchedOn=false;
                                }
                                if(mSwitchOff.indexOf(s1) != -1) {
                                    switchedOff=true;
                                    switchedOn=false;
                                }
                            }
                        }
                        if (switchedOn) {
                            changed = true;
                            working = true;
                            switchoff = false;
                        } else if (switchedOff) {
                            changed = true;
                            working = true;
                            write.write("/*\r\n");
                            switchoff = true;
                        }
                        if (mSwitches.indexOf(s) == -1) {
                            mSwitches.addElement(s);
                        }
                    } else if (line.startsWith("//#else")) {
                        if (state != 1) {
                            printError("'#else' without '#ifdef'");
                            return false;
                        }
                        state = 2;
                        if (!working) {
                            write.write(line + "\r\n");
                        } else if (switchoff) {
                            write.write("*"+"/\r\n");
                            write.write(line + "\r\n");
                            switchoff = false;
                        } else {
                            write.write(line + "\r\n");
                            write.write("/*\r\n");
                            switchoff = true;
                        }
                    } else if (line.startsWith("//#endif")) {
                        if (state == 0) {
                            printError("'#endif' without '#ifdef'");
                            return false;
                        }
                        state = 0;
                        if (working && switchoff) {
                            write.write("*"+"/\r\n");
                        }
                        write.write(line + "\r\n");
                        working = false;
                    } else {
                        write.write(line + "\r\n");
                    }
                }
            }
            if (state != 0) {
                printError("'#endif' missing");
                return false;
            }
            read.close();
            write.flush();
            write.close();
            if(changed) {
                File fbak = new File(name + ".bak");
                fbak.delete();
                f.renameTo(fbak);
                File fcopy = new File(name);
                fnew.renameTo(fcopy);
                fbak.delete();
                System.out.println(name);
                return true;
            } else {
                fnew.delete();
                return true;
            }
        } catch (Exception e) {
            printError(e);
            return false;
        }
    }
    */
    static void printError(Exception e) {
        e.printStackTrace();
    }
    static void printError(String s) {
        System.out.println("ERROR: "+s);
    }
}


