/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import org.ldbc.jdbc.*;
import java.sql.*;
import java.io.*;
import java.util.*;

public interface Adapter {
    String getDriverClass();
    String getName();
    // the adapter should not override the base method
    void setConnection(jdbcConnection externalConn,Connection conn) throws SQLException;
    void init() throws SQLException;
    // workaround for an Oracle issue
    String getDefaultSchema() throws SQLException;
    // workaround for an Oracle issue
    void convertDataType(DataType type) throws SQLException;
    // workaround for a SQL Server issue
    String getStringConcatenation(String a,String b);
    // workaround for a MySQL issue
    String getStringConstant(String s);
    // get the vendor specific String used in CREATE TABLE(...) 
    String getDateConstant(String s);
    String getTimestampConstant(String s);
    String getBinaryConstant(String s);
    String getCast(String value,DataType type) throws SQLException;
    String getLength(String value) throws SQLException;
    String getMod(String v1,String v2) throws SQLException;
    String getNow() throws SQLException;
    String getCreateTable(String tableName, String columns, String option) throws SQLException;
    SQLException convertThrowable(Throwable e);
    SQLException convertSQLException(SQLException e);
    String getDefaultLikeEscape();
    boolean supportsAnsiJoinSyntax();
    void setTransactionIsolation(int level) throws SQLException;
    void cancel(Statement stat) throws SQLException;
    byte[] getBytes(ResultSet rs,int columnIndex) throws SQLException;
    Reader getCharacterStream(ResultSet rs,int columnIndex) throws SQLException;
    String getClobString(ResultSet rs,int columnIndex) throws SQLException;
    void setNull(jdbcPreparedStatement prep,int parameterIndex, int sqlType) throws SQLException;
    void setBytes(jdbcPreparedStatement prep,int parameterIndex, byte[] data) throws SQLException;
    void setBinaryStream(jdbcPreparedStatement prep,int parameterIndex, InputStream x, int length) throws SQLException;
    void setString(jdbcPreparedStatement prep,int parameterIndex, String s) throws SQLException;
    void setCharacterStream(jdbcPreparedStatement prep,int parameterIndex,Reader x,int length) throws SQLException;
    void setAsciiStream(jdbcPreparedStatement prep,int parameterIndex,InputStream x,int length) throws SQLException;
    boolean needExplicitIndexOnForeignKey();
    String getDropIndexSQL(String tableName,String uniqueIndexName);
    String truncateIndexName(String indexName);
    String getNullConstant();
	boolean isSystemTable(String tableName);
    String quote(String identifier);
    boolean isSystemIndex(String tablename, String indexname);
    boolean isPrimaryKey(String indexname, String pkname);
    String getForeignKeyName(String tableName, String originalName) throws SQLException;
    String getDropForeignKeyStatement(String tableName, String fkName) throws SQLException;
    String getRenameStatement(String tableName, String newName) throws SQLException;
    String getAddColumnStatement(String tableName, String columnDef) throws SQLException;
    String getSelect(boolean distinct, String top, String rest) throws SQLException;
    
    void autoIncAddColumn(String tableName,String[] cols,String columnName) throws SQLException;
    String autoIncGetColumn(String tableName) throws SQLException;
    boolean autoIncNeedGeneratedValue();
    boolean autoIncAutoColumnMissing(String tableName,Vector v) throws SQLException;
    void autoIncAddAllColumns(String tableName,Vector v) throws SQLException;
    int autoIncGetLastId() throws SQLException;
    void autoIncPreInsert(PreparedStatement nativePrep, boolean autoValue, Command command) throws SQLException;
    void autoIncPostInsert(PreparedStatement nativePrep,Command command) throws SQLException;
    String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException;
    
}