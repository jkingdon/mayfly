package org.ldbc.antlr;

/* ANTLR Translator Generator
 * Project led by Terence Parr at http://www.jGuru.com
 * Software rights: http://www.antlr.org/RIGHTS.html
 *
 * $Id: FileCopyException.java,v 1.1 2004/06/30 19:18:02 thomasm Exp $
 */

class FileCopyException extends java.io.IOException { 
    public FileCopyException(String msg) { super(msg); }  
}
