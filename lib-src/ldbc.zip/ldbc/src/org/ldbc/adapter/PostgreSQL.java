/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import java.sql.*;

/**
 *
 * Link for docs:
 * Using the PeerDirect native Windows port of PostgreSQL 7.2.1, called UltraSQL
 * http://techdocs.postgresql.org/guides/InstallingOnWindows
 * JDBC driver (7.3)
 * http://jdbc.postgresql.org/
 * Start the service:
 * pg_ctl start
 * stop the service:
 * pg_ctl stop
 * startup URL: jdbc:postgresql:template1
 * CREATE DATABASE ldbc
 * CREATE USER ldbc PASSWORD 'ldbc'
 *
 * Known issues:
 *
 * Executing an invalid statement (for example: SELECT * FROM ABC if ABC does not exist)
 * puts the connection in a different state.
 * Subsequent calls fail (with the message ('No results were returned by the query') 
 * until commit or rollback is called; even in autocommit mode.
 * Therefore, it is not possible to continue a transaction after an exception.
 * This behaviour is not found in any other database.
 * (at least the error message should be meaningfull, 
 * for example: 'Commit or rollback not called after exception')
 *
 * Trailing zeroes are truncated when using the BYTEA data type. 
 *
 * The metadata calls return lowercase identifier names. Other database return uppercase.
 *
 * The name for the BLOB data type is very nonstandard: BYTEA
 *
 * The escaping of binary data is the strangest of all databases. For example, 
 * '\\000\\377'::bytea is X'00ff' (it's using octal values).
 *
 * Escaping strings is non-standard:
 * In PostgreSQL single quotes may alternatively be escaped with a backslash ("\", e.g., 'Dianne\'s horse').
 *
 * In Windows, postgres.exe keeps running if the database was not closed.
 * Subsequent connections may be blocked (due to locking).
 * This may be a problem of the PeerDirect native Windows port.
 *
 * ResultSet.setFetchSize is not implemented and throws an exception.
 *
 * For some reason, Statement.cancel() seems to cancel the _next_ statement (called after 'cancel' is called).
 * Currently, cancel is disabled therefore.
 *
 * According to the specs, executeUpdate("CREATE TABLE...") should return an update count of 0.
 * It currently returns an update count of 1.
 *
 * For PostgreSQL, the value '-1' is boolean false; it should be boolean true.
 * ResultSet.getBoolean
 *
 * The method LOWER returns the data type CLOB instead of VARCHAR
 */

public class PostgreSQL extends Base implements Adapter {
    public static void main(String argv[]) throws Exception {
        Class.forName("org.postgresql.Driver");
        Connection conn=DriverManager.getConnection("jdbc:postgresql:ldbc","ldbc","ldbc");
        Statement stat=conn.createStatement();
        conn.setAutoCommit(false);
        stat.cancel();
        try {
            stat.execute("CREATE TABLE \"TEST2\"(ID INT,V BYTEA)");
        } catch(SQLException e) {
            // exception - ok
        }
        stat.execute("INSERT INTO \"TEST2\" VALUES(1, '\\1\\2\\0'::bytea)");
        ResultSet rs = stat.executeQuery("SELECT * FROM \"TEST2\"");
        while(rs.next()) {
            int i=rs.getInt(1);
            byte[] b=rs.getBytes(2);
            System.out.println("i="+i+" b.length="+b.length+" b[0]="+b[0]+" 1="+b[1]);
        }
        stat.execute("DROP TABLE \"TEST2\"");
        System.out.println("end...");
        conn.close();
    }
    
    
    // url: jdbc:postgresql:mydb
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "org.postgresql.Driver";
    }
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.CLOB:
            return "TEXT";
        case Types.BLOB:
            return "BYTEA";
        }
        return getDefaultDataTypeString(type);
    }
    public String quote(String identifier) {
        return "\""+identifier+"\"";
    }
    public SQLException convertThrowable(Throwable e) {
        SQLException ex=super.convertThrowable(e);
        // this is absolutely non-standard but seems to be the only way
        // to make postgresql at least somewhat compatible to other databases.
        try {
            nativeConn.rollback();
        } catch(SQLException e2) {
            // ignore
        }
        return ex;
    }
    public SQLException convertSQLException(SQLException e) {
        SQLException ex=super.convertSQLException(e);
        // this is absolutely non-standard but seems to be the only way
        // to make postgresql at least somewhat compatible to other databases.
        try {
            nativeConn.rollback();
        } catch(SQLException e2) {
            // ignore
        }
        return ex;
    }
    public void convertDataType(DataType type) throws SQLException {
        String typename=type.getTypeName();
        switch(type.getDataType()) {
        case Types.NUMERIC:
            type.update(Types.DECIMAL,type.getPrecision(),type.getScale());
            break;
        case Types.BINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.VARCHAR:
            if(typename.equals("text")) {
                type.update(Types.CLOB,0,0);
            }
            break;
        case Types.BIGINT:
            type.update(Types.INTEGER,0,0);
            break;
        case Types.OTHER:
            type.update(Types.NULL,0,0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }
    public String getStringConstant(String s) {
        char[] ch=s.toCharArray();
        StringBuffer buff=new StringBuffer();
        buff.append("'");
        for(int i=1;i<ch.length-1;i++) {
            char c=ch[i];
            if(c=='\\') {
                buff.append(c);
            }
            buff.append(c);
        }
        buff.append("'");
        return buff.toString();
    }
    public String getBinaryConstant(String s) {
        StringBuffer buff=new StringBuffer("'");
        for(int i=0;i<s.length();i+=2) {
            int j=Integer.parseInt(s.substring(i,i+2),16);
            buff.append("\\");
            buff.append(Integer.toOctalString(j));
        }
        buff.append("'::bytea");
        return buff.toString();
    }
    public void cancel(Statement stat) {
        // not supported by this database
    }
}
