/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.or;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Types;
import java.util.*;
import java.lang.reflect.*;
import java.math.*;

class Column {
    // TODO: there should be only one set of types
    // TODO: test with all data types, including boolean
    private final static int INT = 0, STRING = 1, DECIMAL = 2, DATETIME = 3, BLOB = 4,
            CLOB = 5, NONE = 6;
    private final static String[] SQL = { "INT", "VARCHAR(255)", "DECIMAL(20,10)",
            "DATETIME", "BLOB", "CLOB"};
    private final static int[] SQLTYPES = { Types.INTEGER, Types.VARCHAR,
            Types.DECIMAL, Types.TIMESTAMP, Types.BLOB, Types.CLOB};
    private final static Class DEFAULT_MAPPING[][] = {
            // INT
            { int.class, short.class, byte.class, char.class, Integer.class,
                    Short.class, Byte.class, Character.class,
                    boolean.class, Boolean.class},
            // STRING
            { String.class},
            // DECIMAL
            { BigDecimal.class, double.class, float.class, Double.class,
                    Float.class},
            // DATETIME
            { Date.class, java.sql.Date.class, java.sql.Time.class,
                    java.sql.Timestamp.class}, 
            // BLOB
            { byte[].class}, 
            // CLOB
            { char[].class}};
    String columnName;
    String fieldName;
    
    private Class fieldClass;
    private boolean autoIncrement;
    private boolean primaryKey;
    private int dataType;
    private Method getter;
    private Method setter;
    private Field field;

    static boolean isKnownType(Class c) {
        return getDataType(c) != NONE;        
    }
    
    private static int getDataType(Class c) {
        for (int i = 0; i < DEFAULT_MAPPING.length; i++) {
            Class[] def = DEFAULT_MAPPING[i];
            for (int j = 0; j < def.length; j++) {
                if (def[j] == c) {
                    return i;
                }
            }
        }
        return NONE;
    }
    
    Column(Method get, Method set) {
        Class getterClass = get.getReturnType();
        Class setterClass = set.getParameterTypes()[0];
        DatabaseException.check(getterClass == setterClass,
                "Getter/setter method type mismatch, getter: " + getter
                        + ", setter: " + setter);
        getter = get;
        setter = set;
        fieldName = get.getName().substring(3); // without the 'get'
        initDataType(getterClass);
    }

    Column(Field field) {
        this.field = field;
        fieldName = field.getName();
        initDataType(field.getType());
    }
    
    void initDataType(Class c) {
        fieldClass = c;
        dataType = getDataType(fieldClass);
        DatabaseException.check(dataType != NONE, "Unknown data type: " + fieldClass);
    }

    void setPrimaryKey() {
        primaryKey = true;
    }
    
    boolean isPrimaryKey() {
        return primaryKey;
    }

    void setAutoIncrement() {
        autoIncrement = true;
    }
    
    boolean isAutoIncrement() {
        return autoIncrement;
    }
    
    void initDefaultMapping() {
        String low = fieldName.toLowerCase();
        if (low.endsWith("key")) {
            setPrimaryKey();
        } else if (low.endsWith("clob") && dataType == Column.STRING) {
            dataType = Column.CLOB;
        }
        if (low.startsWith("auto") && dataType == Column.INT) {
            setAutoIncrement();
        }
    }

    String getCreateSQL() {
        String sql = columnName + " " + SQL[dataType];
        if (autoIncrement) {
            sql += " AUTOINCREMENT";
        }
        if (primaryKey) {
            sql += " PRIMARY KEY";
        }
        return sql;
    }

    Object get(Object obj) {
        Object o = null;
        try {
            if (field != null) {
                o = field.get(obj);
            } else {
                o = getter.invoke(obj, null);
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error reading field " + fieldName
                    + " from object " + obj, e);
        }
        return o;
    }

    void bind(PreparedStatement prep, int index, Object o) {
        try {
            prep.setObject(index, o, SQLTYPES[dataType]);
        } catch (Throwable e) {
            throw new DatabaseException("Error binding column " + index
                    + " to object " + o, e);
        }
    }

    void set(Object obj, ResultSet rs, int index) {
        try {
            // TODO: test if blob and clob are converted to byte array, varchar
            // TODO: test with all databases supported by LDBC
            Object o = rs.getObject(index);
            if (o == null) {
                return;
            }
            if (field != null) {
                field.set(obj, o);
            } else {
                setter.invoke(obj, new Object[] { o});
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error setting field " + fieldName
                    + " in object " + obj, e);
        }
    }
}
