/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.or;

public class DatabaseException extends RuntimeException {

    private DatabaseException(String message) {
        super(message);
    }

    DatabaseException(String message, Throwable cause) {
        super(message);
        initCause(cause);
    }
    
    static void check(boolean test, String message) {
        if(!test) {
            throw new DatabaseException(message);
        }
    }

//#ifdef JDK14
//#else
/*
    Throwable cause;

    void initCause(Throwable cause) {
        this.cause = cause;
    }

    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
        if (cause != null) {
            cause.printStackTrace(s);
        }
    }

    public void printStackTrace(PrintStream s) {
        super.printStackTrace(s);
        if (cause != null) {
            cause.printStackTrace(s);
        }
    }
*/
//#endif
}
