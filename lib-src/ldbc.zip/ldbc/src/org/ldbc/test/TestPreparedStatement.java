package org.ldbc.test;
import java.sql.*;
import java.io.*;

public class TestPreparedStatement extends TestBase {
    public static void main(String[] argv) {
        new TestPreparedStatement().test(argv);
    }
    final static int MAX_BLOB_SIZE=400000;
    final static int MAX_CLOB_SIZE=400000;
    void test(Connection conn) throws SQLException {
        conn.createStatement(ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
        try {
            conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
            error("Should not be supported");
        } catch(SQLException e) {
            trace("not supported");
        }
        Statement stat=conn.createStatement();
        PreparedStatement prep;
        ResultSet rs;
        trace("Create tables");
        stat.execute("CREATE TABLE T_INT(ID INT PRIMARY KEY,VALUE INT)");
        stat.execute("CREATE TABLE T_VARCHAR(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        stat.execute("CREATE TABLE T_DECIMAL_0(ID INT PRIMARY KEY,VALUE DECIMAL(30,0))");
        stat.execute("CREATE TABLE T_DECIMAL_10(ID INT PRIMARY KEY,VALUE DECIMAL(20,10))");
        stat.execute("CREATE TABLE T_DATETIME(ID INT PRIMARY KEY,VALUE DATETIME)");
        prep=conn.prepareStatement("INSERT INTO T_INT VALUES(?,?)", ResultSet.TYPE_FORWARD_ONLY,ResultSet.CONCUR_READ_ONLY);
        prep.setInt(1,1);
        prep.setInt(2,0);
        prep.executeUpdate();
        prep.setInt(1,2);
        prep.setInt(2,-1);
        prep.executeUpdate();
        prep.setInt(1,3);
        prep.setInt(2,3);
        prep.executeUpdate();
        prep.setInt(1,4);
        prep.setNull(2,Types.INTEGER);
        prep.executeUpdate();
        prep.setInt(1,5);
        prep.setBigDecimal(2,new java.math.BigDecimal("0"));
        prep.executeUpdate();
        prep.setInt(1,6);
        prep.setString(2,"-1");
        prep.executeUpdate();
        prep.setInt(1,7);
        prep.setObject(2,new Integer(3));
        prep.executeUpdate();
        try {
            prep.setObject(1,"8");
            // should throw an exception
            prep.setObject(2,null);
            error("Should not be possible to call setObject with null (no data type)");
            prep.executeUpdate();
        } catch(SQLException e) {
            // should throw an exception
        }
        prep.setInt(1,8);
        prep.setObject(2,new Integer(-4),Types.VARCHAR);
        prep.executeUpdate();
        prep.setInt(1,9);
        prep.setObject(2,"5",Types.INTEGER);
        prep.executeUpdate();
        prep.setInt(1,10);
        prep.setObject(2,null,Types.INTEGER);
        prep.executeUpdate();
        prep.setInt(1,11);
        prep.setBoolean(2,true);
        prep.executeUpdate();
        prep.setInt(1,12);
        prep.setBoolean(2,false);
        prep.executeUpdate();
        prep.setInt(1,13);
        prep.setByte(2,(byte)-20);
        prep.executeUpdate();
        prep.setInt(1,14);
        prep.setByte(2,(byte)100);
        prep.executeUpdate();
        prep.setInt(1,15);
        prep.setShort(2,(short)30000);
        prep.executeUpdate();
        prep.setInt(1,16);
        prep.setShort(2,(short)(-30000));
        prep.executeUpdate();
        prep.setInt(1,17);
        prep.setLong(2,Integer.MAX_VALUE);
        prep.executeUpdate();
        prep.setInt(1,18);
        prep.setLong(2,Integer.MIN_VALUE);
        prep.executeUpdate();

        rs=stat.executeQuery("SELECT * FROM T_INT ORDER BY ID");
        testResultSetOrdered(rs,new String[][]{
        {"1","0"},{"2","-1"},{"3","3"},{"4",null},{"5","0"},{"6","-1"},
        {"7","3"},{"8","-4"},{"9","5"},{"10",null},{"11","1"},{"12","0"},
        {"13","-20"},{"14","100"},{"15","30000"},{"16","-30000"},
        {"17",""+Integer.MAX_VALUE},{"18",""+Integer.MIN_VALUE},
        });

        prep=conn.prepareStatement("INSERT INTO T_DECIMAL_0 VALUES(?,?)");
        /*
        prep.setInt(1,1);
        prep.setLong(2,Long.MAX_VALUE);
        prep.executeUpdate();
        prep.setInt(1,2);
        prep.setLong(2,Long.MIN_VALUE);
        prep.executeUpdate();
        */
        prep.setInt(1,3);
        prep.setFloat(2,10);
        prep.executeUpdate();
        prep.setInt(1,4);
        prep.setFloat(2,-20);
        prep.executeUpdate();
        prep.setInt(1,5);
        prep.setFloat(2,30);
        prep.executeUpdate();
        prep.setInt(1,6);
        prep.setFloat(2,-40);
        prep.executeUpdate();
        
        rs=stat.executeQuery("SELECT VALUE FROM T_DECIMAL_0 ORDER BY ID");        
        checkBigDecimal(rs,new String[]{
        //""+Long.MAX_VALUE,""+Long.MIN_VALUE,
        "10","-20","30","-40"
        });

        // getMoreResults
        stat.execute("CREATE TABLE TEST(ID INT)");
        stat.execute("INSERT INTO TEST VALUES(1)");
        prep=conn.prepareStatement("SELECT * FROM TEST");
        // just to check if it doesn't throw an exception - it may be null
        prep.getMetaData();        
        rs=prep.executeQuery();
        check(prep.getMoreResults()==false);
        try {
            // supposed to be closed now
            rs.next();
            error("getMoreResults didn't close this resultset");
        } catch(SQLException e) {
            trace("no error - getMoreResults is supposed to close the resultset");
        }
        check(prep.getUpdateCount()==-1);
        prep=conn.prepareStatement("DELETE FROM TEST");
        prep.executeUpdate();
        check(prep.getMoreResults()==false);
        check(prep.getUpdateCount()==-1);
        testBlob(conn);
        testClob(conn);
    }
    void testBlob(Connection conn) throws SQLException {
        trace("testBlob");
        Statement stat=conn.createStatement();
        PreparedStatement prep;
        ResultSet rs;
        stat.execute("CREATE TABLE T_BLOB(ID INT PRIMARY KEY,V1 BLOB,V2 BLOB)");
        trace("table created");
        prep=conn.prepareStatement("INSERT INTO T_BLOB VALUES(?,?,?)");
        prep.setInt(1,1);
        prep.setBytes(2,null);
        prep.setNull(3,Types.BINARY);
        prep.executeUpdate();
        trace("updated - 1");
        prep.setInt(1,2);
        prep.setBinaryStream(2,null,0);
        prep.setNull(3,Types.BLOB);
        prep.executeUpdate();
        trace("updated - 2");
        byte[] big1=new byte[MAX_BLOB_SIZE];
        byte[] big2=new byte[MAX_BLOB_SIZE];
        for(int i=0;i<big1.length;i++) {
            big1[i]=(byte)((i*11)%254);
            big2[i]=(byte)((i*17)%251);
        }
        prep.setInt(1,3);
        prep.setBytes(2,big1);
        //prep.setBytes(3,big2);
        prep.setNull(3,Types.BLOB);
        prep.executeUpdate();
        trace("updated - 3");
        prep.setInt(1,4);
        ByteArrayInputStream buffer;
        buffer=new ByteArrayInputStream(big2);
        prep.setBinaryStream(2,buffer,big2.length);
        buffer=new ByteArrayInputStream(big1);
        //prep.setBinaryStream(3,buffer,big1.length);
        prep.setNull(3,Types.BLOB);
        prep.executeUpdate();
        trace("updated - 4");
        try {
            buffer.close();
            trace("buffer not closed");
        } catch(IOException e) {
            trace("buffer closed");
        }
        rs=stat.executeQuery("SELECT V1,V2 FROM T_BLOB ORDER BY ID");
        rs.next();
        check(rs.getBytes(1)==null && rs.wasNull());
        check(rs.getBytes(2)==null && rs.wasNull());
        rs.next();
        check(rs.getBytes(1)==null && rs.wasNull());
        check(rs.getBytes(2)==null && rs.wasNull());
        rs.next();
        checkBytes(rs.getBytes(1),big1);
        //checkBytes(rs.getBytes(2),big2);
        rs.next();
        checkBytes(rs.getBytes(1),big2);
        //checkBytes(rs.getBytes(2),big1);
        check(rs.next()==false);        
    }
    void testClob(Connection conn) throws SQLException {
        trace("testClob");
        Statement stat=conn.createStatement();
        PreparedStatement prep;
        ResultSet rs;
        stat.execute("CREATE TABLE T_CLOB(ID INT PRIMARY KEY,V1 CLOB,V2 CLOB)");
        StringBuffer asciibuffer=new StringBuffer();
        for(int i=0;i<MAX_CLOB_SIZE;i++) {
            asciibuffer.append((char)('a'+(i%20)));
        }
        String ascii1=asciibuffer.toString();
        String ascii2="Number2 "+ascii1;
        prep=conn.prepareStatement("INSERT INTO T_CLOB VALUES(?,?,?)");
        prep.setInt(1,1);
        prep.setString(2,null);
        prep.setNull(3,Types.CLOB);
        prep.executeUpdate();
        prep.clearParameters();
        prep.setInt(1,2);
        prep.setAsciiStream(2,null,0);
        prep.setCharacterStream(3,null,0);
        prep.executeUpdate();
        prep.clearParameters();
        prep.setInt(1,4);
        prep.setCharacterStream(2,new StringReader(ascii1),ascii1.length());
        prep.setCharacterStream(3,null,0);
        //prep.setAsciiStream(3,new StringBufferInputStream(ascii2),ascii2.length());
        prep.executeUpdate();
        prep.clearParameters();
        prep.setInt(1,5);
        prep.setString(2,ascii2);
        prep.setCharacterStream(3,null,0);
        //prep.setString(3,ascii1);
        prep.setNull(3,Types.CLOB);
        prep.executeUpdate();
        rs=stat.executeQuery("SELECT V1,V2 FROM T_CLOB ORDER BY ID");
        rs.next();
        check(rs.getCharacterStream(1)==null && rs.wasNull());
        check(rs.getAsciiStream(2)==null && rs.wasNull());
        rs.next();
        check(rs.getString(1)==null && rs.wasNull());
        check(rs.getString(2)==null && rs.wasNull());
        rs.next();
        String c1,c2;
        c1=rs.getString(1);
        c2=rs.getString(2);
        trace("getString 1 len="+c1.length()+" data="+c1.substring(0,20)+"...");
        //trace("getString 2 len="+c2.length()+" data="+c2.substring(0,20)+"...");
        check(c1.equals(ascii1));
        // check(c2.equals(ascii2));
        rs.next();
        c1=rs.getString(1);
        c2=rs.getString(2);
        trace("getString 1 len="+c1.length()+" data="+c1.substring(0,20)+"...");
        //trace("getString 2 len="+c2.length()+" data="+c2.substring(0,20)+"...");
        check(c1.equals(ascii2));
        // check(c2.equals(ascii1));
        check(rs.next()==false);      
        
        check(prep.getWarnings()==null);
        prep.clearWarnings();
        check(prep.getWarnings()==null);
        check(conn==prep.getConnection());

        
    }
    void checkBytes(byte[] test,byte[] good) {
        if(test==null || good==null) {
            check(test==null && good==null);
        } else {
            trace("test.length="+test.length+" good.length="+good.length);
            check(test.length==good.length);
            for(int i=0;i<good.length;i++) {
                check(test[i]==good[i]);
            }
        }
    }
    void checkBigDecimal(ResultSet rs,String[] value) throws SQLException {
        for(int i=0;i<value.length;i++) {
            String v=value[i];
            check(rs.next());
            java.math.BigDecimal x=rs.getBigDecimal(1);
            trace("v="+v+" x="+x);
            if(v==null) {
                check(x==null);
            } else {
                check(x.compareTo(new java.math.BigDecimal(v))==0);
            }
        }
        check(!rs.next());
    }
}
