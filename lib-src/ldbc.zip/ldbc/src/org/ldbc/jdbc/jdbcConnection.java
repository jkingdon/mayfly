/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import org.ldbc.parser.*;
import java.sql.*;

/** 
 * Represents a connection (session) to a database. 
 */
public class jdbcConnection implements Connection {
    static int counter;
    int id=counter++;
    Connection conn;
    String url;
    String user;
	Translator translate;
    Adapter adapter;
    boolean closed;
    boolean readOnlyOptimization;
    int transactionIsolationLevel=Connection.TRANSACTION_READ_COMMITTED;
    boolean autoCommit;
    int lastAutoIncrement;

    /**
     * Creates a new statement.
     *
     * @return the new statement
     * @throws SQLException if the connection is closed 
     */
    public Statement createStatement() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            jdbcStatement stat=new jdbcStatement(adapter,this);
            if(Trace.isEnabled()) Trace.traceResult(stat.getId());
            return stat;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Creates a new prepared statement.
     *
     * @return the prepared statement 
     * @throws SQLException if the connection is closed 
     */
    public PreparedStatement prepareStatement(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            checkClosed();
            sql=translateSQL(sql);
            jdbcPreparedStatement prep=new jdbcPreparedStatement(adapter,this,sql);
            if(Trace.isEnabled()) Trace.traceResult(prep.getId());
            return prep;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the database meta data for this database.
     *
     * @return the database meta data 
     * @throws SQLException if the connection is closed 
     */
    public DatabaseMetaData getMetaData() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            jdbcDatabaseMetaData meta=new jdbcDatabaseMetaData(this,conn.getMetaData());
            if(Trace.isEnabled()) Trace.traceResult(meta.getId());
            return meta; 
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Closes this connection. All open statements, prepared statements and resultsets
     * that where created by this connection become invalid after calling this method.
     * If there is an uncommitted transaction, it will be rolled back.
     */
    public void close() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            if(!closed) {
                try {
                    conn.rollback();
                } catch(SQLException e) {
                    // not valid - ok ignore
                }
                closed=true;
                conn.close();
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Switches autocommit on or off. Calling this function does not commit
     * the current transaction.
     *
     * @param autoCommit true for autocommit on, false for off
     * @throws SQLException if the connection is closed 
     */
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),""+autoCommit);
            checkClosed();
            this.autoCommit=autoCommit;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the current setting for autocommit.
     *
     * @return true for on, false for off 
     * @throws SQLException if the connection is closed 
     */
    public boolean getAutoCommit() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=autoCommit;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Commits the current transaction.
     * This call has only an effect if autocommit is switched off.
     * Calling this method if there is no transaction at this time has no effect.
     *
     * @throws SQLException if the connection is closed 
     */
    public void commit() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            if(autoCommit==false) {
                commitInternal();
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Rolls back the current transaction.
     * This call has only an effect if autocommit is switched off.
     * Calling this method if there is no transaction at this time has no effect.
     *
     * @throws SQLException if the connection is closed 
     */
    public void rollback() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            if(autoCommit==false) {
                conn.rollback();
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Returns true if this connection has been closed.
     *
     * @return true if close was called
     */
    public boolean isClosed() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        if(Trace.isEnabled()) Trace.traceResult(closed);
        return closed;
    }

    /**
     * Translates a SQL statement into the LDBC grammar.
     * This method only deals with the JDBC escape sequences:
     * 
     * <ul>
     * <li>{d '2002-01-01'} > DATE '2002-01-01'
     * <li>{t '2002-01-01 10:0:0'} > TIME '2002-01-01'
     * <li>{ts '2002-01-01 10:0:0'} > TIMESTAMP '2002-01-01'
     * <li>{fn ABS(VAL)} > ABS(VAL)
     * <li>{oj A LEFT OUTER JOIN B ON A.ID=B.ID} > A LEFT OUTER JOIN B ON A.ID=B.ID
     * <li>{escape 'X'} > ESCAPE 'X'
     * <li>{call TEST()} > CALL TEST()
     * <li>{? = call TEST()} > ? = CALL TEST()
     * </ul>
     *
     * There is no space between the left curly brace and the first character after it  allowed.
     * If the escape syntax is incorrect, the original statement is returned.
     * Curly braces inside quotes or double quotes are not converted.
     *
     * @return the translated statement 
     * @throws SQLException if the connection is closed 
     */
    public String nativeSQL(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            checkClosed();
            sql=translateSQL(sql);
            if(Trace.isEnabled()) Trace.traceResultQuote(sql);
            return sql; 
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Enables or disables the read-only mode. According to the JDBC specs, this setting
     * is only a hint to the database to enable optimizations - it does not always
     * cause writes to be prohibited. Therefore, this method does not throw
     * an exception if read only mode is not supported by the database.
     * Currently, calling this method has no effect except on the value
     * returned by isReadOnly().
     *
     * @throws SQLException if the connection is closed 
     */
    public void setReadOnly(boolean readOnly) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),""+readOnly);
            checkClosed();
            readOnlyOptimization=readOnly;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Returns the value set by setReadOnly. The default value is false.
     *
     * @return if read only optimization is switched on
     * @throws SQLException if the connection is closed 
     */
    public boolean isReadOnly() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            if(Trace.isEnabled()) Trace.traceResult(readOnlyOptimization);
            return readOnlyOptimization;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Set the default catalog name. This driver does not support catalogs,
     * and will ignore the call. According to the JDBC specs, this is
     * a legal behavior.
     *
     * @throws SQLException if the connection is closed 
     */
    public void setCatalog(String catalog) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),catalog);
            checkClosed();
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the current catalog name. The method will always return null,
     * meaning there is none.
     *
     * @throws SQLException if the connection is closed 
     */
    public String getCatalog() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            return null;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the first warning reported by calls on this object.
     * This driver does not support warnings, and will always return null.
     *
     * @return null
     */
    public SQLWarning getWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        return null;
    }
    
    /**
     * Clears all warnings. As this driver does not support warnings,
     * this call is ignored.
     */
    public void clearWarnings() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
    }
    
    /**
     * Creates a statement with the specified resultset type and concurrency.
     * Only ResultSet.TYPE_FORWARD_ONLY and CONCUR_READ_ONLY are
     * supported.
     *
     * @return the statement
     * @throws SQLException if the connection is closed
     *                 or the resultset type or concurrency are not supported
     */
    public Statement createStatement(int resultSetType, int resultSetConcurrency)
    throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),resultSetType+","+resultSetConcurrency);
            checkClosed();
            if(resultSetType!=ResultSet.TYPE_FORWARD_ONLY || 
                resultSetConcurrency!=ResultSet.CONCUR_READ_ONLY) {
                throw Factory.getInvalidValueException("resultSetType:"+resultSetType+" resultSetConcurrency:"+resultSetConcurrency);
            }
            jdbcStatement stat=new jdbcStatement(adapter,this);
            if(Trace.isEnabled()) Trace.traceResult(stat.getId());
            return stat;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Creates a prepared statement with the specified resultset type and concurrency.
     * Only ResultSet.TYPE_FORWARD_ONLY and CONCUR_READ_ONLY are
     * supported.
     *
     * @return the prepared statement
     * @throws SQLException if the connection is closed
     *                 or the resultset type or concurrency are not supported
     */
    public PreparedStatement prepareStatement(String sql, int resultSetType,
    int resultSetConcurrency) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),Trace.quote(sql)+","+resultSetType+","+resultSetConcurrency);
            checkClosed();
            if(resultSetType!=ResultSet.TYPE_FORWARD_ONLY || 
                resultSetConcurrency!=ResultSet.CONCUR_READ_ONLY) {
                throw Factory.getInvalidValueException("resultSetType:"+resultSetType+" resultSetConcurrency:"+resultSetConcurrency);
            }
            sql=translateSQL(sql);
            jdbcPreparedStatement prep=new jdbcPreparedStatement(adapter,this,sql);
            if(Trace.isEnabled()) Trace.traceResult(prep.getId());
            return prep;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Changes the current transaction isolation level.
     * Calling this method will commit any open transactions, even
     * if the new level is the same as the old one, but except
     * if the level is not supported. 
     *
     * @param level the new transaction isolation level, 
     *                Connection.TRANSACTION_READ_COMMITTED or
     *                Connection.TRANSACTION_SERIALIZABLE
     * @throws SQLException if the connection is closed
     *                 or the isolation level is not supported
     */
    public void setTransactionIsolation(int level) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),level);
            checkClosed();
            if(level!=Connection.TRANSACTION_READ_COMMITTED &&
                level!=Connection.TRANSACTION_SERIALIZABLE) {
                throw Factory.getInvalidValueException("level:"+level);
            }
            commitInternal();                
            adapter.setTransactionIsolation(level);
            transactionIsolationLevel=level;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Returns the current transaction isolation level.
     *
     * @return the isolation level, 
     *                Connection.TRANSACTION_READ_COMMITTED or
     *                Connection.TRANSACTION_SERIALIZABLE
     * @throws SQLException if the connection is closed
     */
    public int getTransactionIsolation() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            int result=transactionIsolationLevel;
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the type map.
     * This feature is not supported by many databases, 
     * and returns null always.
     *
     * @return null
     * @throws SQLException if the connection is closed
     */
    public java.util.Map getTypeMap() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return null;
    }
    
    /**
     * Sets the type map.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setTypeMap(java.util.Map map) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),Trace.quoteObject(map));
        throw Factory.getUnsupportedException();
    }
    
    /**
     * Creates a new prepared statement
     *
     * @return the new prepared statement 
     * @throws SQLException if the connection is closed or the statement is not valid
     */
    public CallableStatement prepareCall(String sql) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.traceQuote(getId(),sql);
            checkClosed();
            sql=translateSQL(sql);
            jdbcCallableStatement call=new jdbcCallableStatement(adapter,this,sql);
            if(Trace.isEnabled()) Trace.traceResult(call.getId());
            return call;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Creates a prepared statement with the specified resultset type and concurrency.
     * Only ResultSet.TYPE_FORWARD_ONLY and CONCUR_READ_ONLY are
     * supported.
     *
     * @return the prepared statement
     * @throws SQLException if the connection is closed
     *                 or the resultset type or concurrency are not supported
     */
    public CallableStatement prepareCall(String sql, int resultSetType,
    int resultSetConcurrency) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),Trace.quote(sql)+","+resultSetType+","+resultSetConcurrency);
            checkClosed();
            if(resultSetType!=ResultSet.TYPE_FORWARD_ONLY || 
                resultSetConcurrency!=ResultSet.CONCUR_READ_ONLY) {
                throw Factory.getInvalidValueException("resultSetType:"+resultSetType+" resultSetConcurrency:"+resultSetConcurrency);
            }
            sql=translateSQL(sql);
            jdbcCallableStatement call=new jdbcCallableStatement(adapter,this,sql);
            if(Trace.isEnabled()) Trace.traceResult(call.getId());
            return call;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public void setHoldability(int holdability) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public int getHoldability() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
//#ifdef JDK14
    public Savepoint setSavepoint() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public Savepoint setSavepoint(String name) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void rollback(Savepoint savepoint) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    public void releaseSavepoint(Savepoint savepoint) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
//#endif

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
// =============================================================    

    /**
     * Gets the underlying connection object.
     * This method should only be called if functionality is required
     * that is not yet implemented in LDBC, or for testing.
     *
     * @return the underlying Connection object
     */
    public Connection getVendorObject() {
        return conn;
    }

// =============================================================    
   
    /**
     * Creates a new connection using based on a vendor specific connection.
     * This will switch off the autocommit mode of the connection.
	 * It will also initialize the adapter.
     */
    jdbcConnection(String url,String user,Adapter adapter,Connection conn) throws SQLException {
        this.url=url;
        this.user=user;
        this.conn=conn;
        this.adapter=adapter;
		translate=new Translator(adapter);
        autoCommit=true;
        adapter.setConnection(this,conn);
        try {
            conn.setAutoCommit(false);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the adapter for this connection
     */
    Adapter getAdapter() {
        return adapter;
    }
	Command translate(String sql) throws SQLException {
		return translate.translate(sql);
	}
    String translateSQL(String sql) throws SQLException {
        if(sql==null) {
            return null;
        }
        if(sql.indexOf('{')==-1) {
            return sql;
        }
        int len=sql.length();
        int start=-1;
        for(int i=0;i<len;i++) {
            switch(sql.charAt(i)) {
            case '\'':
                i=sql.indexOf('\'',i+1);
                break;
            case '"':
                i=sql.indexOf('"',i+1);
                break;
            case '{':
                if(start!=-1) {
                    throw Factory.getSQLException(Messages.SYNTAX_ERROR, sql);
                }
                start=i;
                break;
            case '}':
                if(start==-1) {
                    throw Factory.getSQLException(Messages.SYNTAX_ERROR, sql);
                }
                String left=sql.substring(0,start);
                String mid=sql.substring(start+1,i);
                String right=sql.substring(i+1);
                String key=mid.toLowerCase();
                if(key.startsWith("fn") || key.startsWith("oj")) {
                    sql=left+mid.substring(3)+right;
                } else if(key.startsWith("ts")) {
                    sql=left+"TIMESTAMP "+mid.substring(3)+right;
                } else if(key.startsWith("t")) {
                    sql=left+"TIME "+mid.substring(2)+right;
                } else if(key.startsWith("d")) {
                    sql=left+"DATE "+mid.substring(2)+right;
                } else {
                    sql=left+mid+right;
                }
                return translateSQL(sql);
            }
        }
        return sql;
    }
    void checkClosed() throws SQLException {
        if(closed) {
            throw Factory.getClosedException();
        }
    }
    String getId() {
        return "conn"+id;
    }
    SQLException convertThrowable(Throwable e) {
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
    void commitInternal() throws SQLException {
        try {
            conn.commit();
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
}

