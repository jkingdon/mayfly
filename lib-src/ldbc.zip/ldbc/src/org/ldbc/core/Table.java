/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

public class Table {
    public String tableName;
    public String[] columns;
	public String autoIncrementColumn;
	public Table(String tableName,String[] cols,String columnName) {
		this.tableName=tableName;
		columns=cols;
		autoIncrementColumn=columnName;
	}
	public void setColumns(String[] cols) {
		columns=cols;
	}
}

