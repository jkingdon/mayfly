package org.ldbc.test.synth;

import java.util.ArrayList;

class Table {
	private String name;
    private Column[] columns;
    private Column[] primaryKeys;
    private ArrayList indexes = new ArrayList();
    private Database database;
    
    public void setDatabase(Database database) {
    	this.database = database;
    }
    
    private Database getDatabase() {
    	return database;
    }
    
    public static Table getRandomTable() {
    	Generator gen = Generator.getInstance();
    	Table table = new Table();
    	table.name = gen.randomIdentifier();
    	int len = gen.getLog(10) + 1;
    	table.columns = new Column[len];
    	for(int i=0; i<len; i++) {
    		Column col = Column.getRandomColumn();
    		table.columns[i] = col;
    	}
    	if(gen.getBoolean(90)) {
    		int pkLen = gen.getLog(len);
    		table.primaryKeys = new Column[pkLen];
    		for(int i=0; i<pkLen; i++) {
    			Column pk = null;
    			do {
    				pk = table.columns[gen.getInt(len)];
    			} while(pk.isPrimaryKey());
    			table.primaryKeys[i] = pk;
    			pk.setPrimaryKey(true);
    			pk.setNullable(false);
    		}
    	}
    	return table;
    }
    
	public Index getRandomIndex() {
    	Generator gen = Generator.getInstance();
    	String name = gen.randomIdentifier();
    	int len = gen.getLog(getColumnCount()-1)+1;
    	boolean unique = gen.getBoolean(50);
    	Column[] columns = getRandomColumns(len);
		Index index = new Index(this, name, columns, unique);
		return index;
	}
	
    public String getDropSQL() {
    	return "DROP TABLE " + name;
    }
	
    public String getCreateSQL() {
    	String sql = "CREATE TABLE " + name + "(\n ";
    	for(int i=0; i<columns.length; i++) {
    		if(i>0) {
    			sql += ",\n ";
    		}
    		Column column = columns[i];
    		sql += column.getCreateSQL();
    		if(primaryKeys!=null && primaryKeys.length==1 && primaryKeys[0]==column) {
    			sql += " PRIMARY KEY";
    		}
    	}
    	if(primaryKeys != null && primaryKeys.length>1) {
    		sql += ",\n ";
    		sql += "PRIMARY KEY(";
    		for(int i=0; i<primaryKeys.length; i++) {
    			if(i>0) {
    				sql += ", ";
    			}
    			Column column = (Column) primaryKeys[i];
    			sql += column.getName();
    		}
    		sql += ")";
    	}
    	sql += "\n)";
		return sql;
	}

	public String getInsertSQL(Column[] c, Value[] v) {
		String sql = "INSERT INTO " + name;
		if(c!=null) {
			sql += "(";
			for(int i=0; i<c.length; i++) {
	    		if(i>0) {
	    			sql += ", ";
	    		}
	    		sql += c[i].getName();
	    	}
			sql += ")";
		}
		sql += " VALUES(";
		for(int i=0; i<v.length; i++) {
    		if(i>0) {
    			sql += ", ";
    		}
    		sql += v[i].getSQL();
    	}
		sql += ")";
		return sql;
	}
	
	public String getName() {
		return name;
	}
	
	public Column getRandomConditionColumn() {
		ArrayList list = new ArrayList();
		for(int i=0; i<columns.length; i++) {
			if(Column.isConditionType(columns[i].getType())) {
				list.add(columns[i]);
			}
		}
		if(list.size() == 0) {
			return null;
		}
    	Generator gen = Generator.getInstance();
    	return (Column) list.get(gen.getInt(list.size()));
	}

	public Column getRandomColumn() {
    	Generator gen = Generator.getInstance();
    	return columns[gen.getInt(columns.length)];
	}
	
	public int getColumnCount() {
		return columns.length;
	}
	
	public Column getRandomColumnOfType(int type) {
		ArrayList list = new ArrayList();
		for(int i=0; i<columns.length; i++) {
			if(columns[i].getType()==type) {
				list.add(columns[i]);
			}
		}
		if(list.size() == 0) {
			return null;
		}
    	Generator gen = Generator.getInstance();
    	return (Column) list.get(gen.getInt(list.size()));
	}

	public Column[] getRandomColumns(int len) {
    	Generator gen = Generator.getInstance();
    	int[] index = new int[columns.length];
    	for(int i=0; i<columns.length; i++) {
    		index[i] = i;
    	}
    	for(int i=0; i<columns.length; i++) {
    		int temp = index[i];
    		int r = index[gen.getInt(columns.length)];
    		index[i] = index[r];
    		index[r] = temp;
    	}
    	Column[] c = new Column[len];
    	for(int i=0; i<len; i++) {
    		c[i] = columns[index[i]];
    	}
    	return c;
	}

	public Column[] getColumns() {
		return columns;
	}
	
	public void addIndex(Index index) {
		indexes.add(index);
	}

	public void removeIndex(Index index) {
		indexes.remove(index);
	}
}
