/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.util.*;

public class Messages extends ListResourceBundle {
    public final static String 
        FEATURE_NOT_SUPPORTED="IM001",
        DRIVER_NOT_FOUND="IM003",
        SYNTAX_ERROR="37000",
        TABLE_NOT_FOUND="42S02",
        COLUMN_NOT_FOUND="42S22",
        UNIQUE_INDEX="23000",
        DATA_CONVERSION_FAILED="22018",
        INVALID_VALUE="HY009",
        OBJECT_CLOSED="24000",        
        GENERAL_ERROR="HY000",
		
        INSERT_NULL="E00001",
		COLUMN_ALREADY_EXISTS="E00002"
		;
    public Object[][] getContents() {
        return contents;
    }
    static final Object[][] contents = {
		{
			COLUMN_ALREADY_EXISTS,
			"Column already exists",
		},
    	{
    		INSERT_NULL,
			"Try to insert null into a non-nullable column"
    	},
        {
            FEATURE_NOT_SUPPORTED, 
            "Feature not supported"
        },
        {
            DRIVER_NOT_FOUND,
            "Database driver not found, check classpath" 
        },
        {
            SYNTAX_ERROR,
            "Syntax error in SQL statement"
        },
        {
            GENERAL_ERROR,
            "General error"
        },
        {
            UNIQUE_INDEX,
            "Unique Index or Primary Key violation"
        },
        {
            TABLE_NOT_FOUND,
            "Table not found"
        },
        {
            COLUMN_NOT_FOUND,
            "Column not found"
        },
        {
            INVALID_VALUE,
            "Invalid value"
        },
        {
            OBJECT_CLOSED,
            "The object is already closed"
        }
            

/*
        -------------------------------------
        
        {
            "22001", "Data truncated",
        }, 
        {
            "22004", "Null value not allowed",
        },
        {
            "22012", "Division by zero",
        },
        {
            "22028", "Row already exists",
        },
        {
            "ZD013", "Primary key or index error",
        },
        {
            "ZD002", "Undefined column",
        },
        {
            "ZD004", "Undefined object",
        },
        {
            "ZD009", "Object already exists",
        },
        {
            "ZB009", "Invalid data type",
        },
        {
            "02000", "No data",
        },
        {
            "ZD020", "Wrong user/password",
        },
        {
            "ZA007", "Only one open connection allowed",
        },
        {
            "ZA002", "The connection was closed",
        },
        {
            "25006", "Database is read only",
        },
        {
            "ZB002", "Missing quote",
        },
        {
            "ZZC01", "Timeout"            
        },
        {
            "ZZF34", "Only Select Statements are allowed here"            
        },
        {
            "ZZF07", "Select Statement is not allowed here"            
        },
        {
            "ZZF35", "Invalid value"            
        },


*/




        
        
    };
}