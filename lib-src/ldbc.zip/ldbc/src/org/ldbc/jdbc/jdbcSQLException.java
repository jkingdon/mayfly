/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import java.sql.*;
import java.io.*;

/** 
 * Represents an exception.
 */
public class jdbcSQLException extends SQLException {
    Throwable cause;
    /**
     * Creates a SQLException a message and SQL state.
     *
     * @param message - the reason
     * @param state - the SQL state
     */
    /*
    public jdbcSQLException(String message,String state) {
        super(message,state);
    }
    */
    /**
     * Creates a SQLException a message, sqlstate and cause.
     *
     * @param message - the reason
     * @param state - the SQL state
     * @param cause - the exception that was the reason for this exception
     */    
    public jdbcSQLException(String message,String state,Throwable cause) {
        super(message,state);
        this.cause=cause;
    }
    /**
     * Prints the stack trace to the standard error stream.
     */
    public void printStackTrace() {
        super.printStackTrace();
        if(cause!=null) {
            cause.printStackTrace();
        }
    }
    /**
     * Prints the stack trace to the specified print writer.
     *
     * @param s - the print writer
     */
    public void printStackTrace(PrintWriter s) {
        super.printStackTrace(s);
        if(cause!=null) {
            cause.printStackTrace(s);
        }
    }
    /**
     * Prints the stack trace to the specified print stream.
     *
     * @param s - the print stream
     */
    public void printStackTrace(PrintStream s) {
        super.printStackTrace(s);
        if(cause!=null) {
            cause.printStackTrace(s);
        }
    }
}
