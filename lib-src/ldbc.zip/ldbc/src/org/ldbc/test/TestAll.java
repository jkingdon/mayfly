package org.ldbc.test;

import java.io.*;
import java.util.*;

public class TestAll {

    final static String DEFAULT_TEST = "/org/ldbc/test/test.properties";

    boolean trace = false;

    public static void main(String[] argv) {
        try {
            TestAll app = new TestAll();
            app.test(argv);
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    void printUsage() {
        print("Usage: java " + getClass().getName());
        print("options:");
        print("-trace  print trace messages");
        print("-?      display this message");
    }

    void print(String s) {
        System.out.println(s);
    }

    void trace(String s) {
        if (trace) {
            print(s);
        }
    }

    void test(String[] argv) throws Exception {
        String file = DEFAULT_TEST;
        for (int i = 0; i < argv.length; i++) {
            String s = argv[i];
            if (s.equals("-trace")) {
                trace = true;
            } else if (s.equals("-?")) {
                printUsage();
            }
        }
        Properties prop = new Properties();
        InputStream in = getClass().getResourceAsStream(file);
        prop.load(in);
        in.close();
        Vector dbs = new Vector();
        Enumeration enum = prop.keys();
        while (enum.hasMoreElements()) {
            String key = (String) enum.nextElement();
            if (key.endsWith("Test")) {
                String db = key.substring(0, key.length() - 4);
                String url = prop.getProperty(db + "URL");
                String user = prop.getProperty(db + "User");
                String password = prop.getProperty(db + "Password");
                String test = prop.getProperty(db + "Test");
                if (test.equals("true")) {
                    String[] data = new String[] { url, user, password};
                    dbs.addElement(data);
                }
            } else if (key.endsWith("URL")) {
            } else if (key.endsWith("User")) {
            } else if (key.endsWith("Password")) {
            } else {
                print("Unsupported property: " + key);
            }
        }
        for (int i = 0; i < dbs.size(); i++) {
            String[] data = (String[]) dbs.elementAt(i);
            String url = data[0];
            String user = data[1];
            String password = data[2];
            testDatabase(argv, url, user, password);
        }
    }

    void testDatabase(String[] param, String url, String user, String password)
            throws Exception {
        if (!url.startsWith("jdbc:ldbc:")) {
            url = "jdbc:ldbc:" + url.substring(5);
        }
        String[] arg = new String[6 + param.length];
        arg[0] = "-url";
        arg[1] = url;
        arg[2] = "-user";
        arg[3] = user;
        arg[4] = "-password";
        arg[5] = password;
        System.arraycopy(param, 0, arg, 6, param.length);
        print("url: <" + url + ">");
        trace("user: <" + user + ">");
        trace("password: <" + password + ">");

        TestDatabaseMetaData.main(arg);
        TestBSPChanges.main(arg);
        TestGrammar.main(arg);        
        HelloWorld.main(arg);
        TestKeywords.main(arg);
        TestExportImport.main(arg);
        TestStatement.main(arg);
        TestGrammarMore.main(arg);
        TestDataTypes.main(arg);
        TestNativeSQL.main(arg);
        TestFunctions.main(arg);
        TestTransaction.main(arg);
        TestPreparedStatement.main(arg);
        TestAutoIncrement.main(arg);
        TestResultSet.main(arg);

        // batch updates are not supported at this time
        //TestBatchUpdates.main(arg);
    }
}
