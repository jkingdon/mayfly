package org.ldbc.test.synth;

public class Index {
	Table table;
	String name;
	Column[] columns;
	boolean unique;
	
	Index(Table table, String name, Column[] columns, boolean unique) {
		this.table = table;
		this.name = name;
		this.columns = columns;
		this.unique = unique;
	}
	
	public String getCreateSQL() {
		String sql = "CREATE ";
		if(unique) {
			sql += "UNIQUE ";
		}
		sql += "INDEX " + name + " ON " + table.getName() + "(";
		for(int i=0; i<columns.length; i++) {
			if(i>0) {
				sql += ", ";
			}
			sql += columns[i].getName();
		}
		sql += ")";
		return sql;
	}
	
	public String getDropSQL() {
		return "DROP INDEX " + name;
	}

	public Table getTable() {
		return table;
	}

}
