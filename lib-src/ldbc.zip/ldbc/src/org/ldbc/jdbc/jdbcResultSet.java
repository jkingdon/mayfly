/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;
import java.io.*;
import java.net.*;
import java.math.BigDecimal;
import java.util.Calendar;

/** 
 * Represents a result set.
 * Values from the columns can be retrieved in any order.
 * Column names are case-insensitive, quotes are not supported.
 * Column index: the first column has index 1. 
 */
public class jdbcResultSet implements ResultSet {
    static int counter;
    int id=counter++;
    jdbcConnection conn;
    jdbcStatement stat;
    jdbcPreparedStatement prep;
    int columnCount;
    Adapter adapter;
    DataType[] dataTypes;
    ResultSet rs;
    ResultSetMetaData meta;
    boolean closed;
    boolean beforeFirst=true;
    boolean afterLast=false;
    int row;
    Command command;
    /**
     * Moves the cursor to the next row of the resultset.
     *
     * @return true if successfull, false if there are no more rows
     * @throws SQLException if the resultset is closed or invalid 
     */
    public boolean next() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            beforeFirst=false;
            boolean result=rs.next();
            row++;
            if(command!=null && !command.isInLimit(row)) {
                result = false;
            }
            if(!result) {
                afterLast=true;
                row=0;
            }
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the meta data of this resultset.
     *
     * @return the meta data 
     * @throws SQLException if the resultset is closed or invalid 
     */
    public ResultSetMetaData getMetaData() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            jdbcResultSetMetaData m=new jdbcResultSetMetaData(this,meta);
            if(Trace.isEnabled()) Trace.traceResult(m.getId());
            return m;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns whether the last column accessed was a null value.
     *
     * @return true if the last column accessed was a null value 
     * @throws SQLException if the resultset is closed or invalid 
     */
    public boolean wasNull() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            boolean result=rs.wasNull();
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Searches for a specific column in the result set.
     *
     * @param columnName the name of the column label
     * @return the column index (1,2,...)
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public int findColumn(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            checkClosed();
            int result=getColumnIndex(columnName);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a String.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public String getString(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            String result;
            int datatype=dataTypes[columnIndex-1].getDataType();
            if(datatype==Types.CLOB) {
                result=adapter.getClobString(rs,columnIndex);
            } else {
                result=rs.getString(columnIndex);
            }
            if(Trace.isDetailed()) Trace.traceResultQuote(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a String.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public String getString(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            String result=getString(columnIndex);
            if(Trace.isDetailed()) Trace.traceResultQuote(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as an int.
     * If the real data type is not INTEGER, a conversion is made:
     * For DECIMAL, the fractional part is ignored and only the
     * low-order 32 bits are returned.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public int getInt(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            int datatype=dataTypes[columnIndex-1].getDataType();
            int result=0;
            switch(datatype) {
            case Types.VARCHAR:
            case Types.INTEGER:
            case Types.SMALLINT:
                result=rs.getInt(columnIndex);
                break;
            case Types.DECIMAL:
                BigDecimal bd=rs.getBigDecimal(columnIndex);
                if(bd==null) {
                    result=0;
                } else {
                    result=bd.intValue();
                }
                break;
            default:
                throw Factory.getGeneralException("datatype:"+datatype);
            }
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as an int.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public int getInt(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            int result=getInt(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a String.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            BigDecimal result=rs.getBigDecimal(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Date.
     * The time in the returned value is zero.
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Date getDate(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            // return mRs.getDate(columnIndex);
            java.sql.Date result=rs.getDate(columnIndex);
            if(result!=null) {
                Calendar cal=Calendar.getInstance();
                cal.setTime(result);
                cal.set(Calendar.HOUR_OF_DAY,0);
                cal.set(Calendar.MINUTE,0);
                cal.set(Calendar.SECOND,0);
                cal.set(Calendar.MILLISECOND,0);
                result=new java.sql.Date(cal.getTime().getTime());
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Time.
     * The date part of the value is set to 1970-01-01. 
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Time getTime(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            // return mRs.getTime(columnIndex);
            java.sql.Time result=rs.getTime(columnIndex);
            if(result!=null) {
                Calendar cal=Calendar.getInstance();
                cal.setTime(result);
                cal.set(Calendar.YEAR,1970);
                cal.set(Calendar.MONTH,0);
                cal.set(Calendar.DAY_OF_MONTH,1);
                result=new java.sql.Time(cal.getTime().getTime());
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Timestamp.
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Timestamp getTimestamp(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            java.sql.Timestamp result=rs.getTimestamp(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a String.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public BigDecimal getBigDecimal(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            BigDecimal result=getBigDecimal(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Date.
     * The time in the returned value is zero.
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Date getDate(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Date result=getDate(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Time.
     * The date part of the value is set to 1970-01-01. 
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Time getTime(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Time result=getTime(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Timestamp.
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Timestamp getTimestamp(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Timestamp result=getTimestamp(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }    
    /**
     * Closes the resultset.
     */
    public void close() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            if(!closed) {
                closed=true;
                rs.close();
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the statement that created this object.
     *
     * @return the statement or prepared statement, or null if created by a DatabaseMetaData call. 
     */
    public Statement getStatement() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            if(stat==null) {
                if(prep==null) {
                    if(Trace.isDetailed()) Trace.traceResult(null);
                }
                if(Trace.isDetailed()) Trace.traceResult(prep.getId());
                return prep;
            }
            if(Trace.isDetailed()) Trace.traceResult(stat.getId());
            return stat;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the first warning reported by calls on this object.
     * This driver does not support warnings, and will always return null.
     *
     * @return null
     */
    public SQLWarning getWarnings() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        return null; 
    }
    /**
     * Clears all warnings. As this driver does not support warnings,
     * this call is ignored.
     */
    public void clearWarnings() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
    }
    /**
     * Returns a column value as a Java object.
     * The following mappings are used:
     * <ul>
     * <li>INT java.lang.Integer
     * <li>VARCHAR java.lang.String
     * <li>DECIMAL java.math.BigDecimal
     * <li>DATETIME java.sql.Timestamp
     * <li>SMALLINT java.lang.Short
     * <li>BIT java.lang.Boolean
     * <li>BLOB byte[]
     * <li>CLOB java.lang.String
     * </ul>
     * Please note that Java objects are not deserialized.
     *
     * @param columnIndex (1,2,...) 
     * @return the value or null
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public Object getObject(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed
            checkColumnIndex(columnIndex);
            // workaround for a Oracle problem
            int i;
            int datatype=dataTypes[columnIndex-1].getDataType();
            Object result=null;
            switch(datatype) {
            case Types.VARCHAR:
            case Types.CLOB:
                result=getString(columnIndex);
                break;
            case Types.INTEGER:
                i=rs.getInt(columnIndex);
                if(!rs.wasNull()) {
                    result=new Integer(i);
                }
                break;
            case Types.DECIMAL:
                result=rs.getBigDecimal(columnIndex);
                break;
            case Types.TIMESTAMP:
                result=rs.getTimestamp(columnIndex);
                break;
            case Types.SMALLINT:
                i=rs.getInt(columnIndex);
                if(!rs.wasNull()) {
                    result=new Short((short)i);
                }
                break;
            case Types.BIT:
                // workaround for PostgreSQL
                boolean b=(rs.getInt(columnIndex) != 0);
                //boolean b=mRs.getBoolean(columnIndex);
                if(!rs.wasNull()) {
                    result=new Boolean(b);
                }
                break;
            case Types.BLOB:
                result=getBytes(columnIndex);
                break;
            default:
                throw Factory.getGeneralException("datatype:"+datatype);        
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns a column value as a Java object.
     * For the type mappings, see getObject(int columnIndex).
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value or null
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public Object getObject(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            Object result=getObject(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a boolean.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public boolean getBoolean(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            // workaround for PostgreSQL
            boolean result=(rs.getInt(columnIndex) != 0);
            //boolean result=mRs.getBoolean(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a boolean.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public boolean getBoolean(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            // workaround for PostgreSQL
            boolean result=(rs.getInt(columnIndex) != 0);
            //boolean result=mRs.getBoolean(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a byte.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public byte getByte(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            byte result=rs.getByte(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a byte.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public byte getByte(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            byte result=rs.getByte(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a short.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public short getShort(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            short result=rs.getShort(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a short.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public short getShort(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            short result=rs.getShort(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a long.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public long getLong(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            long result=rs.getLong(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a long.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public long getLong(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            long result=rs.getLong(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a float.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public float getFloat(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            float result=rs.getFloat(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a float.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public float getFloat(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            float result=rs.getFloat(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a double.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public double getDouble(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            double result=rs.getDouble(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a double.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public double getDouble(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            double result=rs.getDouble(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }

    /**
     * @deprecated
     * This feature is deprecated and is therefore not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),Trace.quote(columnName)+","+scale);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * This feature is deprecated and is therefore not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex+","+scale);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * This feature is deprecated and is therefore not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getUnicodeStream(int columnIndex) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * @deprecated
     * This feature is deprecated and is therefore not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public java.io.InputStream getUnicodeStream(String columnName) throws SQLException {
        if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Gets the cursor name if it was defined.
     * Not all databases support cursor names, and this feature is
     * superseded by updateXXX methods.
     * This method throws a SQLException because cursor names are not supported.
     * This is as defined in the in the JDBC specs.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public String getCursorName() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        throw Factory.getUnsupportedException(); 
    }

    /**
     * Gets the current row number. The first row is row 1, the second 2 and so on.
     * This method returns 0 before the first and after the last row.
     *
     * @return the row number
     * @throws if the resultset is closed or invalid 
     */
    public int getRow() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result=row;
            if(Trace.isDetailed()) Trace.traceResult(""+result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the resultset concurrency.
     *
     * @return the concurrency (CONCUR_READ_ONLY)
     * @throws if the resultset is closed or invalid 
     */
    public int getConcurrency() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mRs.getConcurrency();
            int result=ResultSet.CONCUR_READ_ONLY;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the fetch direction. 
     *
     * @return the direction: FETCH_FORWARD
     * @throws if the resultset is closed or invalid 
     */
    public int getFetchDirection() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mRs.getFetchDirection();
            int result=ResultSet.FETCH_FORWARD;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the number of rows suggested to read in one step.
     *
     * @return the current fetch size
     * @throws if the resultset is closed or invalid 
     */
    public int getFetchSize() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            int result;
            try {
                result=rs.getFetchSize();
            } catch(AbstractMethodError e) {
                // IBM DB2 problem - ignore
                result=0;
            }
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets the number of rows suggested to read in one step.
     * This value can not be higher than the maximum rows (setMaxRows)
     * set by the statement or prepared statement, otherwise an exception
     * is throws.
     *
     * @param rows the number of rows
     * @throws if the resultset is closed or invalid 
     */
    public void setFetchSize(int rows) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),rows);
            checkClosed();
            if(rows<0) {
                throw Factory.getInvalidValueException("rows:"+rows+" min:0");
            }
            if(rows>0) {
                if(stat!=null && stat.maxRows>0 && rows>stat.maxRows) {
                    throw Factory.getInvalidValueException("rows:"+rows+" maxrows:"+stat.maxRows);
                }
                if(prep!=null && prep.maxRows>0 && rows>prep.maxRows) {
                    throw Factory.getInvalidValueException("rows:"+rows+" maxrows:"+prep.maxRows);
                }
            }
            try {
                rs.setFetchSize(rows);
            } catch(AbstractMethodError e) {
                // IBM DB2 problem - ignore
            } catch(SQLException e) {
                // PostgreSQL problem - ignore
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Sets (changes) the fetch direction for this resultset. 
     * This method should only be called for scrollable resultsets,
     * otherwise it will throw an exception (no matter what direction is used).
     *
     * @param direction - the new fetch direction
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     *                if the method is called for a forward-only resultset
     */
    public void setFetchDirection(int direction) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),direction);
        throw Factory.getUnsupportedException();
    }
    /**
     * Get the result set type.
     *
     * @return the result set type (TYPE_FORWARD_ONLY, 
     *                TYPE_SCROLL_INSENSITIVE or TYPE_SCROLL_SENSITIVE)
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public int getType() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            checkClosed();
            //int result=mRs.getType();
            int result=ResultSet.TYPE_FORWARD_ONLY;
            if(Trace.isDetailed()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if the current position is before the first row, that means
     * next() was not called yet.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return if the current position is before the first row
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean isBeforeFirst() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Checks if the current position is after the first row, that means
     * next() was called and returned false.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return if the current position is after the last row
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean isAfterLast() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Checks if the current position is row 1, that means
     * next() was called once and returned true.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return if the current position is the first row
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean isFirst() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Checks if the current position is the last row, that means
     * next() was called and did not yet returned false, but will in the next call.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return if the current position is the last row
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean isLast() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to before the first row, that means
     * resets the resultset.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public void beforeFirst() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to after the last row, that means
     * after the end.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public void afterLast() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to the first row. This is the same as calling
     * beforeFirst() followed by next()
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return true if there is a row available, false if not
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean first() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to last row.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @return true if there is a row available, false if not
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean last() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to a specific row.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @param row the row number.
     *                0 is not allowed, 1 means the first row, 2 the second.
     *                -1 means the last row, -2 the row before the last row.
     *               If the value is too large, the position is moved after the last row,
     *               if if the value is too small it is moved before the first row.
     * @return true if there is a row available, false if not
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean absolute(int row) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),row);
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to a specific row relative to the
     * current row.
     * For resultsets of type ResultSet.TYPE_FORWARD_ONLY, an
     * exception is thrown
     *
     * @param rows - 0 means don't do anything, 1 is the next row, -1 the previous.
     *               If the value is too large, the position is moved after the last row,
     *               if if the value is too small it is moved before the first row.
     * @return true if there is a row available, false if not
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean relative(int rows) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),rows);
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the cursor to the last row, or row before first row if the
     * current position is the first row.
     *
     * @return true if there is a row available, false if not
     * @throws SQLException if the type is ResultSet.TYPE_FORWARD_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean previous() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to the insert row.
     * The current row is remembered.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public void moveToInsertRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Moves the current position to the current row.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public void moveToCurrentRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Detects if the row was updated (by somebody else or the caller). 
     *
     * @return true if the row was updated
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean rowUpdated() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Detects if the row was inserted. 
     *
     * @return true if the row was inserted
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean rowInserted() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Detects if the row was deleted (by somebody else or the caller). 
     *
     * @return true if the row was deleted
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid 
     */
    public boolean rowDeleted() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Inserts the current row. The current position must be the insert row.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid, or the current row is not 
     *                 the insert row
     */
    public void insertRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates the current row. 
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid, or the current row is the insert row
     *                 or before the first or after the last row
     */
    public void updateRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Deletes the current row.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid, or the current row is the insert row
     *                 or before the first or after the last row
     */
    public void deleteRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Re-reads the current row from the database.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid, or the current row is the insert row
     *                 or before the first or after the last row
     */
    public void refreshRow() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Cancels updating a row.
     *
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid, or the current row is the insert row
     *                 or before the first or after the last row
     */
    public void cancelRowUpdates() throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId());
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Gets a column as a object using the specified type mapping.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(int columnIndex, java.util.Map map) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex+","+Trace.quoteObject(map));
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Gets a column as a object using the specified type mapping.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Object getObject(String columnName, java.util.Map map) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),Trace.quote(columnName)+","+Trace.quoteObject(map));
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Gets a column as a reference.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef(int columnIndex) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Gets a column as a reference.
     * This feature is not supported by many databases, 
     * and therefore always throws an exception.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Ref getRef(String columnName) throws SQLException {
        if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
        checkClosed();
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the value of the specified column as a java.sql.Date
     * using a specified timezone.
     * The time in the returned value is zero.
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...)
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Date getDate(int columnIndex, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex+","+Trace.quoteObject(calendar));
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            // return mRs.getDate(columnIndex);
            java.sql.Date result=rs.getDate(columnIndex);
            if(result!=null) {
                Calendar cal=Calendar.getInstance();
                cal.setTime(result);
                cal.set(Calendar.HOUR_OF_DAY,0);
                cal.set(Calendar.MINUTE,0);
                cal.set(Calendar.SECOND,0);
                cal.set(Calendar.MILLISECOND,0);
                result=new java.sql.Date(cal.getTime().getTime());
                // convert local time to this calendars time
                calendar=(Calendar)calendar.clone();
                Calendar local=Calendar.getInstance();
                local.setTime(result);
                jdbcPreparedStatement.convertTime(local,calendar);
                result=new java.sql.Date(calendar.getTime().getTime());
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Date
     * using a specified timezone.
     * The time in the returned value is zero.
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Date getDate(String columnName, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),Trace.quote(columnName)+","+Trace.quoteObject(calendar));
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Date result=getDate(columnIndex,calendar);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Time
     * using a specified timezone.
     * The date part of the value is set to 1970-01-01. 
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...) 
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Time getTime(int columnIndex, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex+","+Trace.quoteObject(calendar));
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            // return mRs.getTime(columnIndex);
            java.sql.Time result=rs.getTime(columnIndex);
            if(result!=null) {
                Calendar cal=Calendar.getInstance();
                cal.setTime(result);
                cal.set(Calendar.YEAR,1970);
                cal.set(Calendar.MONTH,0);
                cal.set(Calendar.DAY_OF_MONTH,1);
                result=new java.sql.Time(cal.getTime().getTime());
                // convert local time to this calendars time
                calendar=(Calendar)calendar.clone();
                Calendar local=Calendar.getInstance();
                local.setTime(result);
                jdbcPreparedStatement.convertTime(local,calendar);
                result=new java.sql.Time(calendar.getTime().getTime());
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Time
     * using a specified timezone.
     * The date part of the value is set to 1970-01-01. 
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Time getTime(String columnName, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),Trace.quote(columnName)+","+Trace.quoteObject(calendar));
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Time result=getTime(columnIndex,calendar);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Timestamp
     * using a specified timezone.
     * The milliseconds and nanoseconds in the returned value are zero.
     *
     * @param columnIndex (1,2,...) 
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Timestamp getTimestamp(int columnIndex, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex+","+Trace.quoteObject(calendar));
            // checkColumnIndex already calls checkClosed 
            checkColumnIndex(columnIndex);
            java.sql.Timestamp result=rs.getTimestamp(columnIndex);
            if(result!=null) {
                // convert local time to this calendars time
                calendar=(Calendar)calendar.clone();
                Calendar local=Calendar.getInstance();
                local.setTime(result);
                jdbcPreparedStatement.convertTime(local,calendar);
                result=new java.sql.Timestamp(calendar.getTime().getTime());
            }
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a java.sql.Timestamp.
     * The milliseconds and nanoseconds in the returned value are zero.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param calendar the calendar
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.sql.Timestamp getTimestamp(String columnName, Calendar calendar) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),Trace.quote(columnName)+","+Trace.quoteObject(calendar));
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            java.sql.Timestamp result=getTimestamp(columnIndex,calendar);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }   
    /**
     * Returns the value of the specified column as a Blob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob(int columnIndex) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
        throw Factory.getUnsupportedException();
    }
    /**
     * Returns the value of the specified column as a Blob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Blob getBlob(String columnName) throws SQLException {
        if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
        throw Factory.getUnsupportedException();
    }
    /**
     * Returns the value of the specified column as a byte array.
     * Some database do not allow to read binary column multiple times.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public byte[] getBytes(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            checkColumnIndex(columnIndex);
            byte[] result=adapter.getBytes(rs,columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a byte array.
     * Some database do not allow to read binary column multiple times.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public byte[] getBytes(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            byte[] result=adapter.getBytes(rs,columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.InputStream getBinaryStream(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            checkColumnIndex(columnIndex);
            InputStream result=rs.getBinaryStream(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.InputStream getBinaryStream(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            InputStream result=rs.getBinaryStream(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as a Clob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob(int columnIndex) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the value of the specified column as a Clob.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Clob getClob(String columnName) throws SQLException {
        if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the value of the specified column as a Array.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray(int columnIndex) throws SQLException {
        if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the value of the specified column as a Array.
     * Many databases do not support batch updates correctly,
     * therefore this feature is not supported.
     *
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public Array getArray(String columnName) throws SQLException {
        if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.InputStream getAsciiStream(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            checkColumnIndex(columnIndex);
            InputStream result=rs.getAsciiStream(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.InputStream getAsciiStream(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            InputStream result=rs.getAsciiStream(columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     *
     * @param columnIndex (1,2,...) 
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.Reader getCharacterStream(int columnIndex) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),columnIndex);
            checkColumnIndex(columnIndex);
            Reader result=adapter.getCharacterStream(rs,columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the value of the specified column as input stream.
     * Some database do not allow to read binary column multiple times.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @return the value 
     * @throws SQLException if the column is not found
     *                 or if the resultset is closed or invalid 
     */
    public java.io.Reader getCharacterStream(String columnName) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.traceQuote(getId(),columnName);
            // getColumnIndex already calls checkClosed 
            int columnIndex=getColumnIndex(columnName);
            Reader result=adapter.getCharacterStream(rs,columnIndex);
            if(Trace.isDetailed()) Trace.traceResult(Trace.quoteObject(result));
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...) 
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateNull(int columnIndex) throws SQLException {  
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateNull(String columnName) throws SQLException {  
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBoolean(int columnIndex, boolean x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBoolean(String columnName, boolean x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateByte(int columnIndex, byte x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateByte(String columnName, byte x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBytes(int columnIndex, byte[] x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBytes(String columnName, byte[] x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateShort(int columnIndex, short x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateShort(String columnName, short x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateInt(int columnIndex, int x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateInt(String columnName, int x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateLong(int columnIndex, long x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateLong(String columnName, long x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateFloat(int columnIndex, float x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateFloat(String columnName, float x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateDouble(int columnIndex, double x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateDouble(String columnName, double x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateString(int columnIndex, String x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateString(String columnName, String x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateDate(int columnIndex, java.sql.Date x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateDate(String columnName, java.sql.Date x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateTime(int columnIndex, java.sql.Time x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateTime(String columnName, java.sql.Time x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateTimestamp(int columnIndex, java.sql.Timestamp x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateTimestamp(String columnName, java.sql.Timestamp x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateAsciiStream(int columnIndex, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateAsciiStream(String columnName, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBinaryStream(int columnIndex, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateBinaryStream(String columnName, java.io.InputStream x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateCharacterStream(int columnIndex, java.io.Reader x, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param reader the value
     * @param length the number of characters
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateCharacterStream(String columnName, java.io.Reader reader, int length) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @param scale the scale
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateObject(int columnIndex, Object x, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @param scale the scale
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateObject(String columnName, Object x, int scale) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     *
     * @param columnIndex (1,2,...)
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateObject(int columnIndex, Object x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * Updates a column in the current or insert row.
     * A case-insensitive search is made.
     *
     * @param columnName the name of the column label
     * @param x the value
     * @throws SQLException if the concurrency is ResultSet.CONCUR_READ_ONLY 
     *                 or if the resultset is closed or invalid
     */
    public void updateObject(String columnName, Object x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public URL getURL(int columnIndex) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public URL getURL(String columnName) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateRef(int columnIndex, Ref x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateRef(String columnName,  Ref x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateBlob(int columnIndex, Blob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateBlob(String columnName, Blob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateClob(int columnIndex, Clob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateClob(String columnName, Clob x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateArray(int columnIndex, Array x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */    
    public void updateArray(String columnName, Array x) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    

// =============================================================    
    
    /**
     * Gets the underlying resultset object.
     * This method should only be called if functionality is required
     * that is not yet implemented in LDBC, or for testing.
     *
     * @return the underlying ResultSet object
     */
    public ResultSet getVendorObject() {
        return rs;
    }
    
    /**
     * Constructs a ResultSet from a resultset in memory.
     * This method should not be called by an application.
     */
    public jdbcResultSet(jdbcConnection conn,MemoryResultSet rs) throws SQLException {
        this.conn=conn;
        this.adapter=conn.adapter;
        this.rs=rs;
        this.meta=rs.getMetaData();
        this.columnCount=meta.getColumnCount();
        this.dataTypes=new DataType[columnCount];
        for(int i=0;i<columnCount;i++) {
            int datatype=meta.getColumnType(i+1);
            String typename=meta.getColumnTypeName(i+1);
            int precision=meta.getPrecision(i+1);
            int scale=meta.getScale(i+1);
            DataType type=new DataType(typename,datatype,precision,scale);
            dataTypes[i]=type;
        }
    }
    

// =============================================================    
    
    int getColumnIndex(String columnName) throws SQLException {
        checkClosed();
        return rs.findColumn(columnName);
    }
    /**
     * Checks if the column index is ok.
     * @param columnIndex (1,2,...)
     * @throws SQLException if not ok
     */
    void checkColumnIndex(int columnIndex) throws SQLException {
        checkClosed();        
        if(columnIndex<1 || columnIndex>columnCount) {
            throw Factory.getInvalidValueException("columnIndex:"+columnIndex+" min:1 max:"+columnCount);
        }
    }
    jdbcResultSet(jdbcConnection conn,
            jdbcStatement stat,jdbcPreparedStatement prep,
            ResultSet rs, Command command) throws SQLException {
        this.conn=conn;
        this.command = command;
        this.stat=stat;
        this.prep=prep;
        this.adapter=conn.adapter;
        this.rs=rs;
        this.meta=rs.getMetaData();
        this.columnCount=meta.getColumnCount();
        this.dataTypes=new DataType[columnCount];
        for(int i=0;i<columnCount;i++) {
            int datatype=meta.getColumnType(i+1);
            String typename=meta.getColumnTypeName(i+1);
            int precision;
            try {
                precision=meta.getPrecision(i+1);
            } catch(NumberFormatException e) {
                // workaround for a Oracle bug
                precision=Integer.MAX_VALUE;
            }
            int scale=meta.getScale(i+1);
            DataType type=new DataType(typename,datatype,precision,scale);
            adapter.convertDataType(type);
            dataTypes[i]=type;
        }
    }
    void checkClosed() throws SQLException {
        if(closed) {
            throw Factory.getClosedException();
        }
        if(stat!=null && stat.closed) {
            throw Factory.getClosedException();
        }
        if(prep!=null && prep.closed) {
            throw Factory.getClosedException();
        }
        if(conn.closed) {
            throw Factory.getClosedException();
        }
    }
    String getId() {
        return "rs"+id;
    }
    SQLException convertThrowable(Throwable e) {
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
}

