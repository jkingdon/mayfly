// $ANTLR 2.7.1: "org/ldbc/parser/sql.g" -> "SQLParser.java"$

package org.ldbc.parser;

import org.ldbc.antlr.TokenBuffer;
import org.ldbc.antlr.TokenStreamException;
import org.ldbc.antlr.TokenStreamIOException;
import org.ldbc.antlr.ANTLRException;
import org.ldbc.antlr.LLkParser;
import org.ldbc.antlr.Token;
import org.ldbc.antlr.TokenStream;
import org.ldbc.antlr.RecognitionException;
import org.ldbc.antlr.NoViableAltException;
import org.ldbc.antlr.MismatchedTokenException;
import org.ldbc.antlr.SemanticException;
import org.ldbc.antlr.ParserSharedInputState;
import org.ldbc.antlr.collections.impl.BitSet;
import org.ldbc.antlr.collections.AST;
import org.ldbc.antlr.ASTPair;
import org.ldbc.antlr.collections.impl.ASTArray;

public class SQLParser extends org.ldbc.antlr.LLkParser
       implements SQLTokenTypes
 {

protected SQLParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public SQLParser(TokenBuffer tokenBuf) {
  this(tokenBuf,3);
}

protected SQLParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public SQLParser(TokenStream lexer) {
  this(lexer,3);
}

public SQLParser(ParserSharedInputState state) {
  super(state,3);
  tokenNames = _tokenNames;
}

	public final void condition() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST condition_AST = null;
		
		cond_or();
		astFactory.addASTChild(currentAST, returnAST);
		condition_AST = (AST)currentAST.root;
		condition_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CONDITION,"condition")).add(condition_AST));
		currentAST.root = condition_AST;
		currentAST.child = condition_AST!=null &&condition_AST.getFirstChild()!=null ?
			condition_AST.getFirstChild() : condition_AST;
		currentAST.advanceChildToEnd();
		condition_AST = (AST)currentAST.root;
		returnAST = condition_AST;
	}
	
	public final void cond_or() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_or_AST = null;
		
		cond_and();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop4:
		do {
			if ((LA(1)==LITERAL_or)) {
				AST tmp1_AST = null;
				tmp1_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp1_AST);
				match(LITERAL_or);
				cond_and();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop4;
			}
			
		} while (true);
		}
		cond_or_AST = (AST)currentAST.root;
		returnAST = cond_or_AST;
	}
	
	public final void cond_and() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_and_AST = null;
		
		cond_neg();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop7:
		do {
			if ((LA(1)==LITERAL_and)) {
				AST tmp2_AST = null;
				tmp2_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp2_AST);
				match(LITERAL_and);
				cond_neg();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop7;
			}
			
		} while (true);
		}
		cond_and_AST = (AST)currentAST.root;
		returnAST = cond_and_AST;
	}
	
	public final void cond_neg() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_neg_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_exists:
		case OPEN_PAREN:
		case LITERAL_null:
		case MINUS:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			cond_bin();
			astFactory.addASTChild(currentAST, returnAST);
			cond_neg_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_not:
		{
			{
			{
			AST tmp3_AST = null;
			tmp3_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_not);
			cond_bin();
			astFactory.addASTChild(currentAST, returnAST);
			}
			cond_neg_AST = (AST)currentAST.root;
			cond_neg_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NOT,"not")).add(cond_neg_AST));
			currentAST.root = cond_neg_AST;
			currentAST.child = cond_neg_AST!=null &&cond_neg_AST.getFirstChild()!=null ?
				cond_neg_AST.getFirstChild() : cond_neg_AST;
			currentAST.advanceChildToEnd();
			}
			cond_neg_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = cond_neg_AST;
	}
	
	public final void cond_bin() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_bin_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_exists:
		{
			cond_exists();
			astFactory.addASTChild(currentAST, returnAST);
			cond_bin_AST = (AST)currentAST.root;
			break;
		}
		case OPEN_PAREN:
		case LITERAL_null:
		case MINUS:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			cond_rel();
			astFactory.addASTChild(currentAST, returnAST);
			cond_bin_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = cond_bin_AST;
	}
	
	public final void cond_exists() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_exists_AST = null;
		
		{
		AST tmp4_AST = null;
		tmp4_AST = (AST)astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp4_AST);
		match(LITERAL_exists);
		AST tmp5_AST = null;
		tmp5_AST = (AST)astFactory.create(LT(1));
		match(OPEN_PAREN);
		select();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp6_AST = null;
		tmp6_AST = (AST)astFactory.create(LT(1));
		match(CLOSE_PAREN);
		}
		cond_exists_AST = (AST)currentAST.root;
		returnAST = cond_exists_AST;
	}
	
	public final void cond_rel() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_rel_AST = null;
		
		cond_exp();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop32:
		do {
			switch ( LA(1)) {
			case LITERAL_between:
			{
				{
				AST tmp7_AST = null;
				tmp7_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_between);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp8_AST = null;
				tmp8_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_and);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				cond_rel_AST = (AST)currentAST.root;
				cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(BETWEEN,"between")).add(cond_rel_AST));
				currentAST.root = cond_rel_AST;
				currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
					cond_rel_AST.getFirstChild() : cond_rel_AST;
				currentAST.advanceChildToEnd();
				break;
			}
			case LITERAL_like:
			{
				{
				AST tmp9_AST = null;
				tmp9_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_like);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				cond_rel_AST = (AST)currentAST.root;
				cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(LIKE,"like")).add(cond_rel_AST));
				currentAST.root = cond_rel_AST;
				currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
					cond_rel_AST.getFirstChild() : cond_rel_AST;
				currentAST.advanceChildToEnd();
				break;
			}
			case EQUAL:
			{
				{
				AST tmp10_AST = null;
				tmp10_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp10_AST);
				match(EQUAL);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case BIGGER:
			{
				{
				AST tmp11_AST = null;
				tmp11_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp11_AST);
				match(BIGGER);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case SMALLER:
			{
				{
				AST tmp12_AST = null;
				tmp12_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp12_AST);
				match(SMALLER);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case NOT_EQUAL:
			{
				{
				AST tmp13_AST = null;
				tmp13_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp13_AST);
				match(NOT_EQUAL);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case NOT_EQUAL_2:
			{
				{
				AST tmp14_AST = null;
				tmp14_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp14_AST);
				match(NOT_EQUAL_2);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case BIGGER_EQUAL:
			{
				{
				AST tmp15_AST = null;
				tmp15_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp15_AST);
				match(BIGGER_EQUAL);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case SMALLER_EQUAL:
			{
				{
				AST tmp16_AST = null;
				tmp16_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp16_AST);
				match(SMALLER_EQUAL);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				}
				break;
			}
			case LITERAL_in:
			{
				{
				AST tmp17_AST = null;
				tmp17_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp17_AST);
				match(LITERAL_in);
				AST tmp18_AST = null;
				tmp18_AST = (AST)astFactory.create(LT(1));
				match(OPEN_PAREN);
				cond_exp();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop31:
				do {
					if ((LA(1)==COMMA)) {
						AST tmp19_AST = null;
						tmp19_AST = (AST)astFactory.create(LT(1));
						match(COMMA);
						cond_exp();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop31;
					}
					
				} while (true);
				}
				AST tmp20_AST = null;
				tmp20_AST = (AST)astFactory.create(LT(1));
				match(CLOSE_PAREN);
				}
				break;
			}
			default:
				if ((LA(1)==LITERAL_not) && (LA(2)==LITERAL_between)) {
					{
					AST tmp21_AST = null;
					tmp21_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_not);
					AST tmp22_AST = null;
					tmp22_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_between);
					cond_exp();
					astFactory.addASTChild(currentAST, returnAST);
					AST tmp23_AST = null;
					tmp23_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_and);
					cond_exp();
					astFactory.addASTChild(currentAST, returnAST);
					}
					cond_rel_AST = (AST)currentAST.root;
					cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NOT_BETWEEN,"not_between")).add(cond_rel_AST));
					currentAST.root = cond_rel_AST;
					currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
						cond_rel_AST.getFirstChild() : cond_rel_AST;
					currentAST.advanceChildToEnd();
				}
				else if ((LA(1)==LITERAL_not) && (LA(2)==LITERAL_like)) {
					{
					AST tmp24_AST = null;
					tmp24_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_not);
					AST tmp25_AST = null;
					tmp25_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_like);
					cond_exp();
					astFactory.addASTChild(currentAST, returnAST);
					}
					cond_rel_AST = (AST)currentAST.root;
					cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NOT_LIKE,"not_like")).add(cond_rel_AST));
					currentAST.root = cond_rel_AST;
					currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
						cond_rel_AST.getFirstChild() : cond_rel_AST;
					currentAST.advanceChildToEnd();
				}
				else if ((LA(1)==LITERAL_is) && (LA(2)==LITERAL_null)) {
					{
					AST tmp26_AST = null;
					tmp26_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_is);
					AST tmp27_AST = null;
					tmp27_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_null);
					}
					cond_rel_AST = (AST)currentAST.root;
					cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(IS_NULL,"is_null")).add(cond_rel_AST));
					currentAST.root = cond_rel_AST;
					currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
						cond_rel_AST.getFirstChild() : cond_rel_AST;
					currentAST.advanceChildToEnd();
				}
				else if ((LA(1)==LITERAL_is) && (LA(2)==LITERAL_not)) {
					{
					AST tmp28_AST = null;
					tmp28_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_is);
					AST tmp29_AST = null;
					tmp29_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_not);
					AST tmp30_AST = null;
					tmp30_AST = (AST)astFactory.create(LT(1));
					match(LITERAL_null);
					}
					cond_rel_AST = (AST)currentAST.root;
					cond_rel_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(IS_NOT_NULL,"is_not_null")).add(cond_rel_AST));
					currentAST.root = cond_rel_AST;
					currentAST.child = cond_rel_AST!=null &&cond_rel_AST.getFirstChild()!=null ?
						cond_rel_AST.getFirstChild() : cond_rel_AST;
					currentAST.advanceChildToEnd();
				}
			else {
				break _loop32;
			}
			}
		} while (true);
		}
		cond_rel_AST = (AST)currentAST.root;
		returnAST = cond_rel_AST;
	}
	
	public final void select() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST select_AST = null;
		
		AST tmp31_AST = null;
		tmp31_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_select);
		{
		switch ( LA(1)) {
		case LITERAL_distinct:
		{
			AST tmp32_AST = null;
			tmp32_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp32_AST);
			match(LITERAL_distinct);
			break;
		}
		case OPEN_PAREN:
		case LITERAL_null:
		case MINUS:
		case ASTERISK:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case LITERAL_top:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_top:
		{
			AST tmp33_AST = null;
			tmp33_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp33_AST);
			match(LITERAL_top);
			AST tmp34_AST = null;
			tmp34_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp34_AST);
			match(NUMBER);
			break;
		}
		case OPEN_PAREN:
		case LITERAL_null:
		case MINUS:
		case ASTERISK:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case ASTERISK:
		{
			AST tmp35_AST = null;
			tmp35_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp35_AST);
			match(ASTERISK);
			break;
		}
		case OPEN_PAREN:
		case LITERAL_null:
		case MINUS:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			select_list();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp36_AST = null;
		tmp36_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_from);
		table_list();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case LITERAL_where:
		{
			AST tmp37_AST = null;
			tmp37_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_where);
			condition();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case LITERAL_group:
		case LITERAL_having:
		case LITERAL_order:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_group:
		{
			AST tmp38_AST = null;
			tmp38_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_group);
			AST tmp39_AST = null;
			tmp39_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_by);
			group_by();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case LITERAL_having:
		case LITERAL_order:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_having:
		{
			AST tmp40_AST = null;
			tmp40_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp40_AST);
			match(LITERAL_having);
			condition();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case LITERAL_order:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_order:
		{
			AST tmp41_AST = null;
			tmp41_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_order);
			AST tmp42_AST = null;
			tmp42_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_by);
			order_by();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		select_AST = (AST)currentAST.root;
		select_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SELECT,"select")).add(select_AST));
		currentAST.root = select_AST;
		currentAST.child = select_AST!=null &&select_AST.getFirstChild()!=null ?
			select_AST.getFirstChild() : select_AST;
		currentAST.advanceChildToEnd();
		select_AST = (AST)currentAST.root;
		returnAST = select_AST;
	}
	
	public final void cond_exp() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_exp_AST = null;
		
		cond_sum();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop35:
		do {
			if ((LA(1)==VERTBARS)) {
				AST tmp43_AST = null;
				tmp43_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp43_AST);
				match(VERTBARS);
				cond_sum();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop35;
			}
			
		} while (true);
		}
		cond_exp_AST = (AST)currentAST.root;
		returnAST = cond_exp_AST;
	}
	
	public final void cond_sum() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_sum_AST = null;
		
		cond_factor();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop39:
		do {
			if ((LA(1)==PLUS||LA(1)==MINUS)) {
				{
				switch ( LA(1)) {
				case PLUS:
				{
					AST tmp44_AST = null;
					tmp44_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp44_AST);
					match(PLUS);
					break;
				}
				case MINUS:
				{
					AST tmp45_AST = null;
					tmp45_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp45_AST);
					match(MINUS);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				cond_factor();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop39;
			}
			
		} while (true);
		}
		cond_sum_AST = (AST)currentAST.root;
		returnAST = cond_sum_AST;
	}
	
	public final void cond_factor() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_factor_AST = null;
		
		cond_term();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop43:
		do {
			if ((LA(1)==ASTERISK||LA(1)==DIVIDE)) {
				{
				switch ( LA(1)) {
				case ASTERISK:
				{
					AST tmp46_AST = null;
					tmp46_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp46_AST);
					match(ASTERISK);
					break;
				}
				case DIVIDE:
				{
					AST tmp47_AST = null;
					tmp47_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp47_AST);
					match(DIVIDE);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				cond_term();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop43;
			}
			
		} while (true);
		}
		cond_factor_AST = (AST)currentAST.root;
		returnAST = cond_factor_AST;
	}
	
	public final void cond_term() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_term_AST = null;
		
		switch ( LA(1)) {
		case OPEN_PAREN:
		case LITERAL_null:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			cond_end();
			astFactory.addASTChild(currentAST, returnAST);
			cond_term_AST = (AST)currentAST.root;
			break;
		}
		case MINUS:
		{
			{
			AST tmp48_AST = null;
			tmp48_AST = (AST)astFactory.create(LT(1));
			match(MINUS);
			cond_end();
			astFactory.addASTChild(currentAST, returnAST);
			}
			cond_term_AST = (AST)currentAST.root;
			cond_term_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NEGATIVE,"negative")).add(cond_term_AST));
			currentAST.root = cond_term_AST;
			currentAST.child = cond_term_AST!=null &&cond_term_AST.getFirstChild()!=null ?
				cond_term_AST.getFirstChild() : cond_term_AST;
			currentAST.advanceChildToEnd();
			cond_term_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = cond_term_AST;
	}
	
	public final void cond_end() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cond_end_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_null:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			value_or_column();
			astFactory.addASTChild(currentAST, returnAST);
			cond_end_AST = (AST)currentAST.root;
			break;
		}
		case OPEN_PAREN:
		{
			{
			AST tmp49_AST = null;
			tmp49_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp49_AST);
			match(OPEN_PAREN);
			condition();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp50_AST = null;
			tmp50_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			}
			cond_end_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		{
			function();
			astFactory.addASTChild(currentAST, returnAST);
			cond_end_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		{
			aggregate();
			astFactory.addASTChild(currentAST, returnAST);
			cond_end_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = cond_end_AST;
	}
	
	public final void value_or_column() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST value_or_column_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_null:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		{
			value();
			astFactory.addASTChild(currentAST, returnAST);
			value_or_column_AST = (AST)currentAST.root;
			break;
		}
		case IDENTIFIER:
		{
			column();
			astFactory.addASTChild(currentAST, returnAST);
			value_or_column_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = value_or_column_AST;
	}
	
	public final void function() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST function_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		{
			simple_function();
			astFactory.addASTChild(currentAST, returnAST);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_cast:
		{
			AST tmp51_AST = null;
			tmp51_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp51_AST);
			match(LITERAL_cast);
			AST tmp52_AST = null;
			tmp52_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp53_AST = null;
			tmp53_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_as);
			datatype();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp54_AST = null;
			tmp54_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_convert:
		{
			AST tmp55_AST = null;
			tmp55_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp55_AST);
			match(LITERAL_convert);
			AST tmp56_AST = null;
			tmp56_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp57_AST = null;
			tmp57_AST = (AST)astFactory.create(LT(1));
			match(COMMA);
			datatype();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp58_AST = null;
			tmp58_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_length:
		{
			AST tmp59_AST = null;
			tmp59_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp59_AST);
			match(LITERAL_length);
			AST tmp60_AST = null;
			tmp60_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp61_AST = null;
			tmp61_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_char_length:
		{
			AST tmp62_AST = null;
			tmp62_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp62_AST);
			match(LITERAL_char_length);
			AST tmp63_AST = null;
			tmp63_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp64_AST = null;
			tmp64_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_character_length:
		{
			AST tmp65_AST = null;
			tmp65_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp65_AST);
			match(LITERAL_character_length);
			AST tmp66_AST = null;
			tmp66_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp67_AST = null;
			tmp67_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_mod:
		{
			AST tmp68_AST = null;
			tmp68_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp68_AST);
			match(LITERAL_mod);
			AST tmp69_AST = null;
			tmp69_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp70_AST = null;
			tmp70_AST = (AST)astFactory.create(LT(1));
			match(COMMA);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp71_AST = null;
			tmp71_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_concat:
		{
			AST tmp72_AST = null;
			tmp72_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp72_AST);
			match(LITERAL_concat);
			AST tmp73_AST = null;
			tmp73_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp74_AST = null;
			tmp74_AST = (AST)astFactory.create(LT(1));
			match(COMMA);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp75_AST = null;
			tmp75_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lower:
		{
			AST tmp76_AST = null;
			tmp76_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp76_AST);
			match(LITERAL_lower);
			AST tmp77_AST = null;
			tmp77_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp78_AST = null;
			tmp78_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lcase:
		{
			AST tmp79_AST = null;
			tmp79_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp79_AST);
			match(LITERAL_lcase);
			AST tmp80_AST = null;
			tmp80_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp81_AST = null;
			tmp81_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_upper:
		{
			AST tmp82_AST = null;
			tmp82_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp82_AST);
			match(LITERAL_upper);
			AST tmp83_AST = null;
			tmp83_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp84_AST = null;
			tmp84_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_ucase:
		{
			AST tmp85_AST = null;
			tmp85_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp85_AST);
			match(LITERAL_ucase);
			AST tmp86_AST = null;
			tmp86_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp87_AST = null;
			tmp87_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			function_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = function_AST;
	}
	
	public final void aggregate() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST aggregate_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_count:
		{
			AST tmp88_AST = null;
			tmp88_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp88_AST);
			match(LITERAL_count);
			AST tmp89_AST = null;
			tmp89_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			{
			switch ( LA(1)) {
			case LITERAL_distinct:
			{
				AST tmp90_AST = null;
				tmp90_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp90_AST);
				match(LITERAL_distinct);
				break;
			}
			case ASTERISK:
			case QUOTED_STRING:
			case NUMBER:
			case LITERAL_date:
			case LITERAL_timestamp:
			case DOT:
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			case PARAMETER:
			case HEX:
			case IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case ASTERISK:
			{
				AST tmp91_AST = null;
				tmp91_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp91_AST);
				match(ASTERISK);
				break;
			}
			case IDENTIFIER:
			{
				column();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			{
				function();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case QUOTED_STRING:
			case NUMBER:
			case LITERAL_date:
			case LITERAL_timestamp:
			case DOT:
			case PARAMETER:
			case HEX:
			{
				value_no_null();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp92_AST = null;
			tmp92_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			aggregate_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_min:
		{
			AST tmp93_AST = null;
			tmp93_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp93_AST);
			match(LITERAL_min);
			AST tmp94_AST = null;
			tmp94_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			{
			switch ( LA(1)) {
			case IDENTIFIER:
			{
				column();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			{
				function();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp95_AST = null;
			tmp95_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			aggregate_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_max:
		{
			AST tmp96_AST = null;
			tmp96_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp96_AST);
			match(LITERAL_max);
			AST tmp97_AST = null;
			tmp97_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			{
			switch ( LA(1)) {
			case IDENTIFIER:
			{
				column();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			{
				function();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp98_AST = null;
			tmp98_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			aggregate_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_sum:
		{
			AST tmp99_AST = null;
			tmp99_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp99_AST);
			match(LITERAL_sum);
			AST tmp100_AST = null;
			tmp100_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			{
			switch ( LA(1)) {
			case IDENTIFIER:
			{
				column();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			{
				function();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp101_AST = null;
			tmp101_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			aggregate_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_avg:
		{
			AST tmp102_AST = null;
			tmp102_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp102_AST);
			match(LITERAL_avg);
			AST tmp103_AST = null;
			tmp103_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			{
			switch ( LA(1)) {
			case IDENTIFIER:
			{
				column();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case LITERAL_now:
			case LITERAL_current_date:
			case LITERAL_current_time:
			case LITERAL_current_timestamp:
			case LITERAL_curdate:
			case LITERAL_curtime:
			case LITERAL_cast:
			case LITERAL_convert:
			case LITERAL_length:
			case LITERAL_char_length:
			case LITERAL_character_length:
			case LITERAL_mod:
			case LITERAL_concat:
			case LITERAL_lower:
			case LITERAL_lcase:
			case LITERAL_upper:
			case LITERAL_ucase:
			{
				function();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp104_AST = null;
			tmp104_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			aggregate_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = aggregate_AST;
	}
	
	public final void expression() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expression_AST = null;
		
		expr_exp();
		astFactory.addASTChild(currentAST, returnAST);
		expression_AST = (AST)currentAST.root;
		expression_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(EXPRESSION,"expression")).add(expression_AST));
		currentAST.root = expression_AST;
		currentAST.child = expression_AST!=null &&expression_AST.getFirstChild()!=null ?
			expression_AST.getFirstChild() : expression_AST;
		currentAST.advanceChildToEnd();
		expression_AST = (AST)currentAST.root;
		returnAST = expression_AST;
	}
	
	public final void expr_exp() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_exp_AST = null;
		
		expr_sum();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop51:
		do {
			if ((LA(1)==VERTBARS)) {
				AST tmp105_AST = null;
				tmp105_AST = (AST)astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp105_AST);
				match(VERTBARS);
				expr_sum();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop51;
			}
			
		} while (true);
		}
		expr_exp_AST = (AST)currentAST.root;
		returnAST = expr_exp_AST;
	}
	
	public final void expr_sum() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_sum_AST = null;
		
		expr_factor();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop55:
		do {
			if ((LA(1)==PLUS||LA(1)==MINUS)) {
				{
				switch ( LA(1)) {
				case PLUS:
				{
					AST tmp106_AST = null;
					tmp106_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp106_AST);
					match(PLUS);
					break;
				}
				case MINUS:
				{
					AST tmp107_AST = null;
					tmp107_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp107_AST);
					match(MINUS);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expr_factor();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop55;
			}
			
		} while (true);
		}
		expr_sum_AST = (AST)currentAST.root;
		returnAST = expr_sum_AST;
	}
	
	public final void expr_factor() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_factor_AST = null;
		
		expr_term();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop59:
		do {
			if ((LA(1)==ASTERISK||LA(1)==DIVIDE)) {
				{
				switch ( LA(1)) {
				case ASTERISK:
				{
					AST tmp108_AST = null;
					tmp108_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp108_AST);
					match(ASTERISK);
					break;
				}
				case DIVIDE:
				{
					AST tmp109_AST = null;
					tmp109_AST = (AST)astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp109_AST);
					match(DIVIDE);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expr_term();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop59;
			}
			
		} while (true);
		}
		expr_factor_AST = (AST)currentAST.root;
		returnAST = expr_factor_AST;
	}
	
	public final void expr_term() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_term_AST = null;
		
		switch ( LA(1)) {
		case OPEN_PAREN:
		case LITERAL_null:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			expr_end();
			astFactory.addASTChild(currentAST, returnAST);
			expr_term_AST = (AST)currentAST.root;
			break;
		}
		case MINUS:
		{
			{
			AST tmp110_AST = null;
			tmp110_AST = (AST)astFactory.create(LT(1));
			match(MINUS);
			expr_end();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expr_term_AST = (AST)currentAST.root;
			expr_term_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NEGATIVE,"negative")).add(expr_term_AST));
			currentAST.root = expr_term_AST;
			currentAST.child = expr_term_AST!=null &&expr_term_AST.getFirstChild()!=null ?
				expr_term_AST.getFirstChild() : expr_term_AST;
			currentAST.advanceChildToEnd();
			expr_term_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = expr_term_AST;
	}
	
	public final void expr_end() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_end_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_null:
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		case IDENTIFIER:
		{
			value_or_column();
			astFactory.addASTChild(currentAST, returnAST);
			expr_end_AST = (AST)currentAST.root;
			break;
		}
		case OPEN_PAREN:
		{
			{
			AST tmp111_AST = null;
			tmp111_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp111_AST);
			match(OPEN_PAREN);
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp112_AST = null;
			tmp112_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			}
			expr_end_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		case LITERAL_cast:
		case LITERAL_convert:
		case LITERAL_length:
		case LITERAL_char_length:
		case LITERAL_character_length:
		case LITERAL_mod:
		case LITERAL_concat:
		case LITERAL_lower:
		case LITERAL_lcase:
		case LITERAL_upper:
		case LITERAL_ucase:
		{
			function();
			astFactory.addASTChild(currentAST, returnAST);
			expr_end_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_count:
		case LITERAL_min:
		case LITERAL_max:
		case LITERAL_sum:
		case LITERAL_avg:
		{
			aggregate();
			astFactory.addASTChild(currentAST, returnAST);
			expr_end_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = expr_end_AST;
	}
	
	public final void statement() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST statement_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_select:
		{
			select();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_update:
		{
			update();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_delete:
		{
			delete();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_insert:
		{
			insert();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_alter:
		{
			alter_table();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_commit:
		{
			commit();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_rollback:
		{
			rollback();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_set:
		{
			set_autocommit();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_get:
		{
			get_autoincrement_key();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		default:
			if ((LA(1)==LITERAL_create) && (LA(2)==LITERAL_table)) {
				create_table();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else if ((LA(1)==LITERAL_create) && (LA(2)==LITERAL_unique||LA(2)==LITERAL_index)) {
				create_index();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else if ((LA(1)==LITERAL_drop) && (LA(2)==LITERAL_table)) {
				drop_table();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else if ((LA(1)==LITERAL_drop) && (LA(2)==LITERAL_index)) {
				drop_index();
				astFactory.addASTChild(currentAST, returnAST);
			}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp113_AST = null;
		tmp113_AST = (AST)astFactory.create(LT(1));
		match(Token.EOF_TYPE);
		statement_AST = (AST)currentAST.root;
		returnAST = statement_AST;
	}
	
	public final void update() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST update_AST = null;
		
		AST tmp114_AST = null;
		tmp114_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_update);
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp115_AST = null;
		tmp115_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_set);
		update_set();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop134:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp116_AST = null;
				tmp116_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				update_set();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop134;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case LITERAL_where:
		{
			AST tmp117_AST = null;
			tmp117_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_where);
			condition();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		update_AST = (AST)currentAST.root;
		update_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(UPDATE,"update")).add(update_AST));
		currentAST.root = update_AST;
		currentAST.child = update_AST!=null &&update_AST.getFirstChild()!=null ?
			update_AST.getFirstChild() : update_AST;
		currentAST.advanceChildToEnd();
		update_AST = (AST)currentAST.root;
		returnAST = update_AST;
	}
	
	public final void delete() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST delete_AST = null;
		
		AST tmp118_AST = null;
		tmp118_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_delete);
		AST tmp119_AST = null;
		tmp119_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_from);
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case LITERAL_where:
		{
			AST tmp120_AST = null;
			tmp120_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_where);
			condition();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		delete_AST = (AST)currentAST.root;
		delete_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DELETE,"delete")).add(delete_AST));
		currentAST.root = delete_AST;
		currentAST.child = delete_AST!=null &&delete_AST.getFirstChild()!=null ?
			delete_AST.getFirstChild() : delete_AST;
		currentAST.advanceChildToEnd();
		delete_AST = (AST)currentAST.root;
		returnAST = delete_AST;
	}
	
	public final void insert() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST insert_AST = null;
		
		AST tmp121_AST = null;
		tmp121_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_insert);
		AST tmp122_AST = null;
		tmp122_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_into);
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case OPEN_PAREN:
		{
			column_list();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_values:
		case LITERAL_select:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		insert_values();
		astFactory.addASTChild(currentAST, returnAST);
		insert_AST = (AST)currentAST.root;
		insert_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(INSERT,"insert")).add(insert_AST));
		currentAST.root = insert_AST;
		currentAST.child = insert_AST!=null &&insert_AST.getFirstChild()!=null ?
			insert_AST.getFirstChild() : insert_AST;
		currentAST.advanceChildToEnd();
		insert_AST = (AST)currentAST.root;
		returnAST = insert_AST;
	}
	
	public final void create_table() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST create_table_AST = null;
		
		AST tmp123_AST = null;
		tmp123_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_create);
		AST tmp124_AST = null;
		tmp124_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_table);
		{
		switch ( LA(1)) {
		case LITERAL_if:
		{
			AST tmp125_AST = null;
			tmp125_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp125_AST);
			match(LITERAL_if);
			AST tmp126_AST = null;
			tmp126_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_not);
			AST tmp127_AST = null;
			tmp127_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_exists);
			break;
		}
		case IDENTIFIER:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case LITERAL_option:
		{
			AST tmp128_AST = null;
			tmp128_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp128_AST);
			match(LITERAL_option);
			AST tmp129_AST = null;
			tmp129_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp130_AST = null;
			tmp130_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp130_AST);
			match(QUOTED_STRING);
			AST tmp131_AST = null;
			tmp131_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			break;
		}
		case OPEN_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp132_AST = null;
		tmp132_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp132_AST);
		match(OPEN_PAREN);
		column_def();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop82:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp133_AST = null;
				tmp133_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				column_def();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop82;
			}
			
		} while (true);
		}
		AST tmp134_AST = null;
		tmp134_AST = (AST)astFactory.create(LT(1));
		match(CLOSE_PAREN);
		create_table_AST = (AST)currentAST.root;
		create_table_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CREATE_TABLE,"create_table")).add(create_table_AST));
		currentAST.root = create_table_AST;
		currentAST.child = create_table_AST!=null &&create_table_AST.getFirstChild()!=null ?
			create_table_AST.getFirstChild() : create_table_AST;
		currentAST.advanceChildToEnd();
		create_table_AST = (AST)currentAST.root;
		returnAST = create_table_AST;
	}
	
	public final void create_index() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST create_index_AST = null;
		
		AST tmp135_AST = null;
		tmp135_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_create);
		{
		switch ( LA(1)) {
		case LITERAL_unique:
		{
			AST tmp136_AST = null;
			tmp136_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp136_AST);
			match(LITERAL_unique);
			break;
		}
		case LITERAL_index:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp137_AST = null;
		tmp137_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_index);
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp138_AST = null;
		tmp138_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_on);
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		column_list();
		astFactory.addASTChild(currentAST, returnAST);
		create_index_AST = (AST)currentAST.root;
		create_index_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(CREATE_INDEX,"create_index")).add(create_index_AST));
		currentAST.root = create_index_AST;
		currentAST.child = create_index_AST!=null &&create_index_AST.getFirstChild()!=null ?
			create_index_AST.getFirstChild() : create_index_AST;
		currentAST.advanceChildToEnd();
		create_index_AST = (AST)currentAST.root;
		returnAST = create_index_AST;
	}
	
	public final void drop_table() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST drop_table_AST = null;
		
		AST tmp139_AST = null;
		tmp139_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_drop);
		AST tmp140_AST = null;
		tmp140_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_table);
		{
		switch ( LA(1)) {
		case LITERAL_if:
		{
			AST tmp141_AST = null;
			tmp141_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp141_AST);
			match(LITERAL_if);
			AST tmp142_AST = null;
			tmp142_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_exists);
			break;
		}
		case IDENTIFIER:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		drop_table_AST = (AST)currentAST.root;
		drop_table_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DROP_TABLE,"drop_table")).add(drop_table_AST));
		currentAST.root = drop_table_AST;
		currentAST.child = drop_table_AST!=null &&drop_table_AST.getFirstChild()!=null ?
			drop_table_AST.getFirstChild() : drop_table_AST;
		currentAST.advanceChildToEnd();
		drop_table_AST = (AST)currentAST.root;
		returnAST = drop_table_AST;
	}
	
	public final void drop_index() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST drop_index_AST = null;
		
		AST tmp143_AST = null;
		tmp143_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_drop);
		AST tmp144_AST = null;
		tmp144_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_index);
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp145_AST = null;
		tmp145_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_on);
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		drop_index_AST = (AST)currentAST.root;
		drop_index_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DROP_INDEX,"drop_index")).add(drop_index_AST));
		currentAST.root = drop_index_AST;
		currentAST.child = drop_index_AST!=null &&drop_index_AST.getFirstChild()!=null ?
			drop_index_AST.getFirstChild() : drop_index_AST;
		currentAST.advanceChildToEnd();
		drop_index_AST = (AST)currentAST.root;
		returnAST = drop_index_AST;
	}
	
	public final void alter_table() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alter_table_AST = null;
		
		AST tmp146_AST = null;
		tmp146_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_alter);
		AST tmp147_AST = null;
		tmp147_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_table);
		{
		if ((LA(1)==IDENTIFIER) && (LA(2)==LITERAL_drop)) {
			alter_table_drop_constraint();
			astFactory.addASTChild(currentAST, returnAST);
		}
		else if ((LA(1)==IDENTIFIER) && (LA(2)==LITERAL_rename)) {
			alter_table_rename();
			astFactory.addASTChild(currentAST, returnAST);
		}
		else if ((LA(1)==IDENTIFIER) && (LA(2)==LITERAL_add)) {
			alter_table_add_column();
			astFactory.addASTChild(currentAST, returnAST);
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		alter_table_AST = (AST)currentAST.root;
		returnAST = alter_table_AST;
	}
	
	public final void commit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST commit_AST = null;
		
		AST tmp148_AST = null;
		tmp148_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_commit);
		commit_AST = (AST)currentAST.root;
		commit_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(COMMIT,"commit")).add(commit_AST));
		currentAST.root = commit_AST;
		currentAST.child = commit_AST!=null &&commit_AST.getFirstChild()!=null ?
			commit_AST.getFirstChild() : commit_AST;
		currentAST.advanceChildToEnd();
		commit_AST = (AST)currentAST.root;
		returnAST = commit_AST;
	}
	
	public final void rollback() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rollback_AST = null;
		
		AST tmp149_AST = null;
		tmp149_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_rollback);
		rollback_AST = (AST)currentAST.root;
		rollback_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ROLLBACK,"rollback")).add(rollback_AST));
		currentAST.root = rollback_AST;
		currentAST.child = rollback_AST!=null &&rollback_AST.getFirstChild()!=null ?
			rollback_AST.getFirstChild() : rollback_AST;
		currentAST.advanceChildToEnd();
		rollback_AST = (AST)currentAST.root;
		returnAST = rollback_AST;
	}
	
	public final void set_autocommit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST set_autocommit_AST = null;
		
		if ((LA(1)==LITERAL_set) && (LA(2)==LITERAL_autocommit) && (LA(3)==LITERAL_true)) {
			AST tmp150_AST = null;
			tmp150_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_set);
			AST tmp151_AST = null;
			tmp151_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_autocommit);
			AST tmp152_AST = null;
			tmp152_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_true);
			set_autocommit_AST = (AST)currentAST.root;
			set_autocommit_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SET_AUTOCOMMIT_TRUE,"set_autocommit_true")).add(set_autocommit_AST));
			currentAST.root = set_autocommit_AST;
			currentAST.child = set_autocommit_AST!=null &&set_autocommit_AST.getFirstChild()!=null ?
				set_autocommit_AST.getFirstChild() : set_autocommit_AST;
			currentAST.advanceChildToEnd();
			set_autocommit_AST = (AST)currentAST.root;
		}
		else if ((LA(1)==LITERAL_set) && (LA(2)==LITERAL_autocommit) && (LA(3)==LITERAL_false)) {
			AST tmp153_AST = null;
			tmp153_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_set);
			AST tmp154_AST = null;
			tmp154_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_autocommit);
			AST tmp155_AST = null;
			tmp155_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_false);
			set_autocommit_AST = (AST)currentAST.root;
			set_autocommit_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SET_AUTOCOMMIT_FALSE,"set_autocommit_false")).add(set_autocommit_AST));
			currentAST.root = set_autocommit_AST;
			currentAST.child = set_autocommit_AST!=null &&set_autocommit_AST.getFirstChild()!=null ?
				set_autocommit_AST.getFirstChild() : set_autocommit_AST;
			currentAST.advanceChildToEnd();
			set_autocommit_AST = (AST)currentAST.root;
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		returnAST = set_autocommit_AST;
	}
	
	public final void get_autoincrement_key() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST get_autoincrement_key_AST = null;
		
		AST tmp156_AST = null;
		tmp156_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_get);
		AST tmp157_AST = null;
		tmp157_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_autoincrement);
		AST tmp158_AST = null;
		tmp158_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_key);
		get_autoincrement_key_AST = (AST)currentAST.root;
		get_autoincrement_key_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(GET_AUTOINCREMENT_KEY,"get_autoincrement_key")).add(get_autoincrement_key_AST));
		currentAST.root = get_autoincrement_key_AST;
		currentAST.child = get_autoincrement_key_AST!=null &&get_autoincrement_key_AST.getFirstChild()!=null ?
			get_autoincrement_key_AST.getFirstChild() : get_autoincrement_key_AST;
		currentAST.advanceChildToEnd();
		get_autoincrement_key_AST = (AST)currentAST.root;
		returnAST = get_autoincrement_key_AST;
	}
	
	public final void table_name() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST table_name_AST = null;
		
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		table_name_AST = (AST)currentAST.root;
		returnAST = table_name_AST;
	}
	
	public final void column_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST column_list_AST = null;
		
		AST tmp159_AST = null;
		tmp159_AST = (AST)astFactory.create(LT(1));
		match(OPEN_PAREN);
		column_name();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop77:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp160_AST = null;
				tmp160_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				column_name();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop77;
			}
			
		} while (true);
		}
		AST tmp161_AST = null;
		tmp161_AST = (AST)astFactory.create(LT(1));
		match(CLOSE_PAREN);
		column_list_AST = (AST)currentAST.root;
		column_list_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(COLUMN_LIST,"column_list")).add(column_list_AST));
		currentAST.root = column_list_AST;
		currentAST.child = column_list_AST!=null &&column_list_AST.getFirstChild()!=null ?
			column_list_AST.getFirstChild() : column_list_AST;
		currentAST.advanceChildToEnd();
		column_list_AST = (AST)currentAST.root;
		returnAST = column_list_AST;
	}
	
	public final void insert_values() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST insert_values_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_select:
		{
			select();
			astFactory.addASTChild(currentAST, returnAST);
			insert_values_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_values:
		{
			AST tmp162_AST = null;
			tmp162_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp162_AST);
			match(LITERAL_values);
			AST tmp163_AST = null;
			tmp163_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			insert_value();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop74:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp164_AST = null;
					tmp164_AST = (AST)astFactory.create(LT(1));
					match(COMMA);
					insert_value();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop74;
				}
				
			} while (true);
			}
			AST tmp165_AST = null;
			tmp165_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			insert_values_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = insert_values_AST;
	}
	
	public final void insert_value() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST insert_value_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_null:
		{
			{
			AST tmp166_AST = null;
			tmp166_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp166_AST);
			match(LITERAL_null);
			insert_value_AST = (AST)currentAST.root;
			insert_value_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NULL_INSERT,"null_insert")).add(insert_value_AST));
			currentAST.root = insert_value_AST;
			currentAST.child = insert_value_AST!=null &&insert_value_AST.getFirstChild()!=null ?
				insert_value_AST.getFirstChild() : insert_value_AST;
			currentAST.advanceChildToEnd();
			}
			insert_value_AST = (AST)currentAST.root;
			break;
		}
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		{
			value_no_null();
			astFactory.addASTChild(currentAST, returnAST);
			insert_value_AST = (AST)currentAST.root;
			break;
		}
		case MINUS:
		{
			{
			AST tmp167_AST = null;
			tmp167_AST = (AST)astFactory.create(LT(1));
			match(MINUS);
			decimal_value();
			astFactory.addASTChild(currentAST, returnAST);
			insert_value_AST = (AST)currentAST.root;
			insert_value_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NEGATIVE,"negative")).add(insert_value_AST));
			currentAST.root = insert_value_AST;
			currentAST.child = insert_value_AST!=null &&insert_value_AST.getFirstChild()!=null ?
				insert_value_AST.getFirstChild() : insert_value_AST;
			currentAST.advanceChildToEnd();
			}
			insert_value_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_now:
		case LITERAL_current_date:
		case LITERAL_current_time:
		case LITERAL_current_timestamp:
		case LITERAL_curdate:
		case LITERAL_curtime:
		{
			simple_function();
			astFactory.addASTChild(currentAST, returnAST);
			insert_value_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = insert_value_AST;
	}
	
	public final void column_name() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST column_name_AST = null;
		
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		column_name_AST = (AST)currentAST.root;
		returnAST = column_name_AST;
	}
	
	public final void column_def() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST column_def_AST = null;
		
		switch ( LA(1)) {
		case IDENTIFIER:
		{
			identifier();
			astFactory.addASTChild(currentAST, returnAST);
			datatype();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case LITERAL_autoincrement:
			{
				AST tmp168_AST = null;
				tmp168_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp168_AST);
				match(LITERAL_autoincrement);
				break;
			}
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_null:
			case COMMA:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_not:
			case LITERAL_null:
			{
				{
				switch ( LA(1)) {
				case LITERAL_not:
				{
					AST tmp169_AST = null;
					tmp169_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp169_AST);
					match(LITERAL_not);
					break;
				}
				case LITERAL_null:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp170_AST = null;
				tmp170_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp170_AST);
				match(LITERAL_null);
				break;
			}
			case CLOSE_PAREN:
			case COMMA:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_primary:
			{
				AST tmp171_AST = null;
				tmp171_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp171_AST);
				match(LITERAL_primary);
				AST tmp172_AST = null;
				tmp172_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp172_AST);
				match(LITERAL_key);
				break;
			}
			case CLOSE_PAREN:
			case COMMA:
			case LITERAL_default:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case LITERAL_default:
			{
				AST tmp173_AST = null;
				tmp173_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp173_AST);
				match(LITERAL_default);
				default_value();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case CLOSE_PAREN:
			case COMMA:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			column_def_AST = (AST)currentAST.root;
			column_def_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(COLUMN_DEF,"column_def")).add(column_def_AST));
			currentAST.root = column_def_AST;
			currentAST.child = column_def_AST!=null &&column_def_AST.getFirstChild()!=null ?
				column_def_AST.getFirstChild() : column_def_AST;
			currentAST.advanceChildToEnd();
			column_def_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_primary:
		{
			AST tmp174_AST = null;
			tmp174_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_primary);
			AST tmp175_AST = null;
			tmp175_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_key);
			AST tmp176_AST = null;
			tmp176_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			column_name();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop103:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp177_AST = null;
					tmp177_AST = (AST)astFactory.create(LT(1));
					match(COMMA);
					column_name();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop103;
				}
				
			} while (true);
			}
			AST tmp178_AST = null;
			tmp178_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			column_def_AST = (AST)currentAST.root;
			column_def_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(PRIMARY_KEY,"primary_key")).add(column_def_AST));
			currentAST.root = column_def_AST;
			currentAST.child = column_def_AST!=null &&column_def_AST.getFirstChild()!=null ?
				column_def_AST.getFirstChild() : column_def_AST;
			currentAST.advanceChildToEnd();
			column_def_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_constraint:
		case LITERAL_foreign:
		{
			{
			switch ( LA(1)) {
			case LITERAL_constraint:
			{
				AST tmp179_AST = null;
				tmp179_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_constraint);
				identifier();
				break;
			}
			case LITERAL_foreign:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp180_AST = null;
			tmp180_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_foreign);
			AST tmp181_AST = null;
			tmp181_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_key);
			column_list();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp182_AST = null;
			tmp182_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_references);
			table_name();
			astFactory.addASTChild(currentAST, returnAST);
			column_list();
			astFactory.addASTChild(currentAST, returnAST);
			column_def_AST = (AST)currentAST.root;
			column_def_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(FOREIGN_KEY,"foreign_key")).add(column_def_AST));
			currentAST.root = column_def_AST;
			currentAST.child = column_def_AST!=null &&column_def_AST.getFirstChild()!=null ?
				column_def_AST.getFirstChild() : column_def_AST;
			currentAST.advanceChildToEnd();
			column_def_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = column_def_AST;
	}
	
	public final void identifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST identifier_AST = null;
		
		AST tmp183_AST = null;
		tmp183_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp183_AST);
		match(IDENTIFIER);
		identifier_AST = (AST)currentAST.root;
		returnAST = identifier_AST;
	}
	
	public final void alter_table_drop_constraint() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alter_table_drop_constraint_AST = null;
		
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp184_AST = null;
		tmp184_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_drop);
		AST tmp185_AST = null;
		tmp185_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_constraint);
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		alter_table_drop_constraint_AST = (AST)currentAST.root;
		alter_table_drop_constraint_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ALTER_TABLE_DROP_CONSTRAINT,"alter_table_drop_constraint")).add(alter_table_drop_constraint_AST));
		currentAST.root = alter_table_drop_constraint_AST;
		currentAST.child = alter_table_drop_constraint_AST!=null &&alter_table_drop_constraint_AST.getFirstChild()!=null ?
			alter_table_drop_constraint_AST.getFirstChild() : alter_table_drop_constraint_AST;
		currentAST.advanceChildToEnd();
		alter_table_drop_constraint_AST = (AST)currentAST.root;
		returnAST = alter_table_drop_constraint_AST;
	}
	
	public final void alter_table_rename() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alter_table_rename_AST = null;
		
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp186_AST = null;
		tmp186_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_rename);
		AST tmp187_AST = null;
		tmp187_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_to);
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		alter_table_rename_AST = (AST)currentAST.root;
		alter_table_rename_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ALTER_TABLE_RENAME,"alter_table_rename")).add(alter_table_rename_AST));
		currentAST.root = alter_table_rename_AST;
		currentAST.child = alter_table_rename_AST!=null &&alter_table_rename_AST.getFirstChild()!=null ?
			alter_table_rename_AST.getFirstChild() : alter_table_rename_AST;
		currentAST.advanceChildToEnd();
		alter_table_rename_AST = (AST)currentAST.root;
		returnAST = alter_table_rename_AST;
	}
	
	public final void alter_table_add_column() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alter_table_add_column_AST = null;
		
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp188_AST = null;
		tmp188_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_add);
		AST tmp189_AST = null;
		tmp189_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_column);
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		datatype();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case LITERAL_not:
		case LITERAL_null:
		{
			{
			switch ( LA(1)) {
			case LITERAL_not:
			{
				AST tmp190_AST = null;
				tmp190_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp190_AST);
				match(LITERAL_not);
				break;
			}
			case LITERAL_null:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp191_AST = null;
			tmp191_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp191_AST);
			match(LITERAL_null);
			break;
		}
		case EOF:
		case LITERAL_default:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case LITERAL_default:
		{
			AST tmp192_AST = null;
			tmp192_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp192_AST);
			match(LITERAL_default);
			default_value();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		alter_table_add_column_AST = (AST)currentAST.root;
		alter_table_add_column_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ALTER_TABLE_ADD_COLUMN,"alter_table_add_column")).add(alter_table_add_column_AST));
		currentAST.root = alter_table_add_column_AST;
		currentAST.child = alter_table_add_column_AST!=null &&alter_table_add_column_AST.getFirstChild()!=null ?
			alter_table_add_column_AST.getFirstChild() : alter_table_add_column_AST;
		currentAST.advanceChildToEnd();
		alter_table_add_column_AST = (AST)currentAST.root;
		returnAST = alter_table_add_column_AST;
	}
	
	public final void datatype() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST datatype_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_int:
		case LITERAL_integer:
		case LITERAL_tinyint:
		case LITERAL_smallint:
		case LITERAL_mediumint:
		case LITERAL_bit:
		case LITERAL_boolean:
		{
			type_int();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_PAREN:
			{
				AST tmp193_AST = null;
				tmp193_AST = (AST)astFactory.create(LT(1));
				match(OPEN_PAREN);
				AST tmp194_AST = null;
				tmp194_AST = (AST)astFactory.create(LT(1));
				match(NUMBER);
				AST tmp195_AST = null;
				tmp195_AST = (AST)astFactory.create(LT(1));
				match(CLOSE_PAREN);
				break;
			}
			case EOF:
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_null:
			case COMMA:
			case LITERAL_autoincrement:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		case LITERAL_varchar:
		case LITERAL_char:
		{
			type_varchar();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp196_AST = null;
			tmp196_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp197_AST = null;
			tmp197_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp197_AST);
			match(NUMBER);
			AST tmp198_AST = null;
			tmp198_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			break;
		}
		case LITERAL_decimal:
		case LITERAL_numeric:
		case LITERAL_dec:
		case LITERAL_real:
		case LITERAL_float:
		case LITERAL_double:
		case LITERAL_bigint:
		{
			type_decimal();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_PAREN:
			{
				AST tmp199_AST = null;
				tmp199_AST = (AST)astFactory.create(LT(1));
				match(OPEN_PAREN);
				AST tmp200_AST = null;
				tmp200_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp200_AST);
				match(NUMBER);
				{
				switch ( LA(1)) {
				case COMMA:
				{
					AST tmp201_AST = null;
					tmp201_AST = (AST)astFactory.create(LT(1));
					match(COMMA);
					AST tmp202_AST = null;
					tmp202_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp202_AST);
					match(NUMBER);
					break;
				}
				case CLOSE_PAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				AST tmp203_AST = null;
				tmp203_AST = (AST)astFactory.create(LT(1));
				match(CLOSE_PAREN);
				break;
			}
			case EOF:
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_null:
			case COMMA:
			case LITERAL_autoincrement:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		case LITERAL_datetime:
		case LITERAL_date:
		case LITERAL_timestamp:
		case LITERAL_time:
		{
			type_datetime();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LITERAL_blob:
		case LITERAL_tinyblob:
		case LITERAL_mediumblob:
		case LITERAL_longblob:
		case LITERAL_binary:
		case LITERAL_varbinary:
		case LITERAL_longvarbinary:
		case LITERAL_image:
		{
			type_blob();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_PAREN:
			{
				AST tmp204_AST = null;
				tmp204_AST = (AST)astFactory.create(LT(1));
				match(OPEN_PAREN);
				AST tmp205_AST = null;
				tmp205_AST = (AST)astFactory.create(LT(1));
				match(NUMBER);
				AST tmp206_AST = null;
				tmp206_AST = (AST)astFactory.create(LT(1));
				match(CLOSE_PAREN);
				break;
			}
			case EOF:
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_null:
			case COMMA:
			case LITERAL_autoincrement:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		case LITERAL_clob:
		case LITERAL_tinytext:
		case LITERAL_mediumtext:
		case LITERAL_longtext:
		case LITERAL_text:
		case LITERAL_longvarchar:
		{
			type_clob();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case OPEN_PAREN:
			{
				AST tmp207_AST = null;
				tmp207_AST = (AST)astFactory.create(LT(1));
				match(OPEN_PAREN);
				AST tmp208_AST = null;
				tmp208_AST = (AST)astFactory.create(LT(1));
				match(NUMBER);
				AST tmp209_AST = null;
				tmp209_AST = (AST)astFactory.create(LT(1));
				match(CLOSE_PAREN);
				break;
			}
			case EOF:
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_null:
			case COMMA:
			case LITERAL_autoincrement:
			case LITERAL_default:
			case LITERAL_primary:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		datatype_AST = (AST)currentAST.root;
		datatype_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DATATYPE,"datatype")).add(datatype_AST));
		currentAST.root = datatype_AST;
		currentAST.child = datatype_AST!=null &&datatype_AST.getFirstChild()!=null ?
			datatype_AST.getFirstChild() : datatype_AST;
		currentAST.advanceChildToEnd();
		datatype_AST = (AST)currentAST.root;
		returnAST = datatype_AST;
	}
	
	public final void default_value() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST default_value_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_null:
		{
			{
			AST tmp210_AST = null;
			tmp210_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp210_AST);
			match(LITERAL_null);
			default_value_AST = (AST)currentAST.root;
			default_value_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NULL_INSERT,"null_insert")).add(default_value_AST));
			currentAST.root = default_value_AST;
			currentAST.child = default_value_AST!=null &&default_value_AST.getFirstChild()!=null ?
				default_value_AST.getFirstChild() : default_value_AST;
			currentAST.advanceChildToEnd();
			}
			default_value_AST = (AST)currentAST.root;
			break;
		}
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		{
			value_no_null();
			astFactory.addASTChild(currentAST, returnAST);
			default_value_AST = (AST)currentAST.root;
			break;
		}
		case MINUS:
		{
			{
			AST tmp211_AST = null;
			tmp211_AST = (AST)astFactory.create(LT(1));
			match(MINUS);
			decimal_value();
			astFactory.addASTChild(currentAST, returnAST);
			default_value_AST = (AST)currentAST.root;
			default_value_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(NEGATIVE,"negative")).add(default_value_AST));
			currentAST.root = default_value_AST;
			currentAST.child = default_value_AST!=null &&default_value_AST.getFirstChild()!=null ?
				default_value_AST.getFirstChild() : default_value_AST;
			currentAST.advanceChildToEnd();
			}
			default_value_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = default_value_AST;
	}
	
	public final void type_int() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_int_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_int:
		{
			AST tmp212_AST = null;
			tmp212_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp212_AST);
			match(LITERAL_int);
			break;
		}
		case LITERAL_integer:
		{
			AST tmp213_AST = null;
			tmp213_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp213_AST);
			match(LITERAL_integer);
			break;
		}
		case LITERAL_tinyint:
		{
			AST tmp214_AST = null;
			tmp214_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp214_AST);
			match(LITERAL_tinyint);
			break;
		}
		case LITERAL_smallint:
		{
			AST tmp215_AST = null;
			tmp215_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp215_AST);
			match(LITERAL_smallint);
			break;
		}
		case LITERAL_mediumint:
		{
			AST tmp216_AST = null;
			tmp216_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp216_AST);
			match(LITERAL_mediumint);
			break;
		}
		case LITERAL_bit:
		{
			AST tmp217_AST = null;
			tmp217_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp217_AST);
			match(LITERAL_bit);
			break;
		}
		case LITERAL_boolean:
		{
			AST tmp218_AST = null;
			tmp218_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp218_AST);
			match(LITERAL_boolean);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_int_AST = (AST)currentAST.root;
		type_int_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_INT,"type_int")).add(type_int_AST));
		currentAST.root = type_int_AST;
		currentAST.child = type_int_AST!=null &&type_int_AST.getFirstChild()!=null ?
			type_int_AST.getFirstChild() : type_int_AST;
		currentAST.advanceChildToEnd();
		type_int_AST = (AST)currentAST.root;
		returnAST = type_int_AST;
	}
	
	public final void type_varchar() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_varchar_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_varchar:
		{
			AST tmp219_AST = null;
			tmp219_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp219_AST);
			match(LITERAL_varchar);
			break;
		}
		case LITERAL_char:
		{
			AST tmp220_AST = null;
			tmp220_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp220_AST);
			match(LITERAL_char);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_varchar_AST = (AST)currentAST.root;
		type_varchar_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_VARCHAR,"type_varchar")).add(type_varchar_AST));
		currentAST.root = type_varchar_AST;
		currentAST.child = type_varchar_AST!=null &&type_varchar_AST.getFirstChild()!=null ?
			type_varchar_AST.getFirstChild() : type_varchar_AST;
		currentAST.advanceChildToEnd();
		type_varchar_AST = (AST)currentAST.root;
		returnAST = type_varchar_AST;
	}
	
	public final void type_decimal() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_decimal_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_decimal:
		{
			AST tmp221_AST = null;
			tmp221_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp221_AST);
			match(LITERAL_decimal);
			break;
		}
		case LITERAL_numeric:
		{
			AST tmp222_AST = null;
			tmp222_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp222_AST);
			match(LITERAL_numeric);
			break;
		}
		case LITERAL_dec:
		{
			AST tmp223_AST = null;
			tmp223_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp223_AST);
			match(LITERAL_dec);
			break;
		}
		case LITERAL_real:
		{
			AST tmp224_AST = null;
			tmp224_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp224_AST);
			match(LITERAL_real);
			break;
		}
		case LITERAL_float:
		{
			AST tmp225_AST = null;
			tmp225_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp225_AST);
			match(LITERAL_float);
			break;
		}
		case LITERAL_double:
		{
			AST tmp226_AST = null;
			tmp226_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp226_AST);
			match(LITERAL_double);
			break;
		}
		case LITERAL_bigint:
		{
			AST tmp227_AST = null;
			tmp227_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp227_AST);
			match(LITERAL_bigint);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_decimal_AST = (AST)currentAST.root;
		type_decimal_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_DECIMAL,"type_decimal")).add(type_decimal_AST));
		currentAST.root = type_decimal_AST;
		currentAST.child = type_decimal_AST!=null &&type_decimal_AST.getFirstChild()!=null ?
			type_decimal_AST.getFirstChild() : type_decimal_AST;
		currentAST.advanceChildToEnd();
		type_decimal_AST = (AST)currentAST.root;
		returnAST = type_decimal_AST;
	}
	
	public final void type_datetime() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_datetime_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_datetime:
		{
			AST tmp228_AST = null;
			tmp228_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp228_AST);
			match(LITERAL_datetime);
			break;
		}
		case LITERAL_date:
		{
			AST tmp229_AST = null;
			tmp229_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp229_AST);
			match(LITERAL_date);
			break;
		}
		case LITERAL_timestamp:
		{
			AST tmp230_AST = null;
			tmp230_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp230_AST);
			match(LITERAL_timestamp);
			break;
		}
		case LITERAL_time:
		{
			AST tmp231_AST = null;
			tmp231_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp231_AST);
			match(LITERAL_time);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_datetime_AST = (AST)currentAST.root;
		type_datetime_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_DATETIME,"type_datetime")).add(type_datetime_AST));
		currentAST.root = type_datetime_AST;
		currentAST.child = type_datetime_AST!=null &&type_datetime_AST.getFirstChild()!=null ?
			type_datetime_AST.getFirstChild() : type_datetime_AST;
		currentAST.advanceChildToEnd();
		type_datetime_AST = (AST)currentAST.root;
		returnAST = type_datetime_AST;
	}
	
	public final void type_blob() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_blob_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_blob:
		{
			AST tmp232_AST = null;
			tmp232_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp232_AST);
			match(LITERAL_blob);
			break;
		}
		case LITERAL_tinyblob:
		{
			AST tmp233_AST = null;
			tmp233_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp233_AST);
			match(LITERAL_tinyblob);
			break;
		}
		case LITERAL_mediumblob:
		{
			AST tmp234_AST = null;
			tmp234_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp234_AST);
			match(LITERAL_mediumblob);
			break;
		}
		case LITERAL_longblob:
		{
			AST tmp235_AST = null;
			tmp235_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp235_AST);
			match(LITERAL_longblob);
			break;
		}
		case LITERAL_binary:
		{
			AST tmp236_AST = null;
			tmp236_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp236_AST);
			match(LITERAL_binary);
			break;
		}
		case LITERAL_varbinary:
		{
			AST tmp237_AST = null;
			tmp237_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp237_AST);
			match(LITERAL_varbinary);
			break;
		}
		case LITERAL_longvarbinary:
		{
			AST tmp238_AST = null;
			tmp238_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp238_AST);
			match(LITERAL_longvarbinary);
			break;
		}
		case LITERAL_image:
		{
			AST tmp239_AST = null;
			tmp239_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp239_AST);
			match(LITERAL_image);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_blob_AST = (AST)currentAST.root;
		type_blob_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_BLOB,"type_blob")).add(type_blob_AST));
		currentAST.root = type_blob_AST;
		currentAST.child = type_blob_AST!=null &&type_blob_AST.getFirstChild()!=null ?
			type_blob_AST.getFirstChild() : type_blob_AST;
		currentAST.advanceChildToEnd();
		type_blob_AST = (AST)currentAST.root;
		returnAST = type_blob_AST;
	}
	
	public final void type_clob() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_clob_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_clob:
		{
			AST tmp240_AST = null;
			tmp240_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp240_AST);
			match(LITERAL_clob);
			break;
		}
		case LITERAL_tinytext:
		{
			AST tmp241_AST = null;
			tmp241_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp241_AST);
			match(LITERAL_tinytext);
			break;
		}
		case LITERAL_mediumtext:
		{
			AST tmp242_AST = null;
			tmp242_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp242_AST);
			match(LITERAL_mediumtext);
			break;
		}
		case LITERAL_longtext:
		{
			AST tmp243_AST = null;
			tmp243_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp243_AST);
			match(LITERAL_longtext);
			break;
		}
		case LITERAL_text:
		{
			AST tmp244_AST = null;
			tmp244_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp244_AST);
			match(LITERAL_text);
			break;
		}
		case LITERAL_longvarchar:
		{
			AST tmp245_AST = null;
			tmp245_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp245_AST);
			match(LITERAL_longvarchar);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		type_clob_AST = (AST)currentAST.root;
		type_clob_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TYPE_CLOB,"type_clob")).add(type_clob_AST));
		currentAST.root = type_clob_AST;
		currentAST.child = type_clob_AST!=null &&type_clob_AST.getFirstChild()!=null ?
			type_clob_AST.getFirstChild() : type_clob_AST;
		currentAST.advanceChildToEnd();
		type_clob_AST = (AST)currentAST.root;
		returnAST = type_clob_AST;
	}
	
	public final void select_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST select_list_AST = null;
		
		{
		select_item();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop142:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp246_AST = null;
				tmp246_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				select_item();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop142;
			}
			
		} while (true);
		}
		}
		select_list_AST = (AST)currentAST.root;
		returnAST = select_list_AST;
	}
	
	public final void table_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST table_list_AST = null;
		
		selected_table();
		astFactory.addASTChild(currentAST, returnAST);
		table_list_more();
		astFactory.addASTChild(currentAST, returnAST);
		table_list_AST = (AST)currentAST.root;
		returnAST = table_list_AST;
	}
	
	public final void group_by() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST group_by_AST = null;
		
		column();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop191:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp247_AST = null;
				tmp247_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				column();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop191;
			}
			
		} while (true);
		}
		group_by_AST = (AST)currentAST.root;
		group_by_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(GROUP_BY,"group_by")).add(group_by_AST));
		currentAST.root = group_by_AST;
		currentAST.child = group_by_AST!=null &&group_by_AST.getFirstChild()!=null ?
			group_by_AST.getFirstChild() : group_by_AST;
		currentAST.advanceChildToEnd();
		group_by_AST = (AST)currentAST.root;
		returnAST = group_by_AST;
	}
	
	public final void order_by() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST order_by_AST = null;
		
		order_item();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop194:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp248_AST = null;
				tmp248_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				order_item();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop194;
			}
			
		} while (true);
		}
		order_by_AST = (AST)currentAST.root;
		order_by_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ORDER_BY,"order_by")).add(order_by_AST));
		currentAST.root = order_by_AST;
		currentAST.child = order_by_AST!=null &&order_by_AST.getFirstChild()!=null ?
			order_by_AST.getFirstChild() : order_by_AST;
		currentAST.advanceChildToEnd();
		order_by_AST = (AST)currentAST.root;
		returnAST = order_by_AST;
	}
	
	public final void update_set() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST update_set_AST = null;
		
		column_name();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp249_AST = null;
		tmp249_AST = (AST)astFactory.create(LT(1));
		match(EQUAL);
		expression();
		astFactory.addASTChild(currentAST, returnAST);
		update_set_AST = (AST)currentAST.root;
		update_set_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(UPDATE_SET,"update_set")).add(update_set_AST));
		currentAST.root = update_set_AST;
		currentAST.child = update_set_AST!=null &&update_set_AST.getFirstChild()!=null ?
			update_set_AST.getFirstChild() : update_set_AST;
		currentAST.advanceChildToEnd();
		update_set_AST = (AST)currentAST.root;
		returnAST = update_set_AST;
	}
	
	public final void select_item() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST select_item_AST = null;
		
		{
		if ((LA(1)==IDENTIFIER) && (LA(2)==DOT) && (LA(3)==ASTERISK)) {
			{
			table_name();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp250_AST = null;
			tmp250_AST = (AST)astFactory.create(LT(1));
			match(DOT);
			AST tmp251_AST = null;
			tmp251_AST = (AST)astFactory.create(LT(1));
			match(ASTERISK);
			select_item_AST = (AST)currentAST.root;
			select_item_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TABLE_ASTERISK,"table_asterisk")).add(select_item_AST));
			currentAST.root = select_item_AST;
			currentAST.child = select_item_AST!=null &&select_item_AST.getFirstChild()!=null ?
				select_item_AST.getFirstChild() : select_item_AST;
			currentAST.advanceChildToEnd();
			}
		}
		else if ((_tokenSet_0.member(LA(1))) && (_tokenSet_1.member(LA(2))) && (_tokenSet_2.member(LA(3)))) {
			{
			expression();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case LITERAL_as:
			case IDENTIFIER:
			{
				alias();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case COMMA:
			case LITERAL_from:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			select_item_AST = (AST)currentAST.root;
			select_item_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SELECT_ITEM,"select_item")).add(select_item_AST));
			currentAST.root = select_item_AST;
			currentAST.child = select_item_AST!=null &&select_item_AST.getFirstChild()!=null ?
				select_item_AST.getFirstChild() : select_item_AST;
			currentAST.advanceChildToEnd();
			}
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		select_item_AST = (AST)currentAST.root;
		returnAST = select_item_AST;
	}
	
	public final void selected_table() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST selected_table_AST = null;
		
		{
		table_name();
		astFactory.addASTChild(currentAST, returnAST);
		}
		{
		switch ( LA(1)) {
		case IDENTIFIER:
		{
			identifier();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case COMMA:
		case LITERAL_on:
		case LITERAL_where:
		case LITERAL_group:
		case LITERAL_having:
		case LITERAL_order:
		case LITERAL_inner:
		case LITERAL_left:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		selected_table_AST = (AST)currentAST.root;
		selected_table_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SELECTED_TABLE,"selected_table")).add(selected_table_AST));
		currentAST.root = selected_table_AST;
		currentAST.child = selected_table_AST!=null &&selected_table_AST.getFirstChild()!=null ?
			selected_table_AST.getFirstChild() : selected_table_AST;
		currentAST.advanceChildToEnd();
		selected_table_AST = (AST)currentAST.root;
		returnAST = selected_table_AST;
	}
	
	public final void table_list_more() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST table_list_more_AST = null;
		
		switch ( LA(1)) {
		case EOF:
		case CLOSE_PAREN:
		case COMMA:
		case LITERAL_where:
		case LITERAL_group:
		case LITERAL_having:
		case LITERAL_order:
		{
			{
			{
			_loop147:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp252_AST = null;
					tmp252_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp252_AST);
					match(COMMA);
					selected_table();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop147;
				}
				
			} while (true);
			}
			}
			table_list_more_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_inner:
		case LITERAL_left:
		{
			join();
			astFactory.addASTChild(currentAST, returnAST);
			table_list_more_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = table_list_more_AST;
	}
	
	public final void join() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST join_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_inner:
		{
			AST tmp253_AST = null;
			tmp253_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp253_AST);
			match(LITERAL_inner);
			break;
		}
		case LITERAL_left:
		{
			AST tmp254_AST = null;
			tmp254_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp254_AST);
			match(LITERAL_left);
			AST tmp255_AST = null;
			tmp255_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_outer);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		AST tmp256_AST = null;
		tmp256_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_join);
		selected_table();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp257_AST = null;
		tmp257_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_on);
		condition();
		astFactory.addASTChild(currentAST, returnAST);
		{
		switch ( LA(1)) {
		case LITERAL_inner:
		case LITERAL_left:
		{
			join();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case LITERAL_where:
		case LITERAL_group:
		case LITERAL_having:
		case LITERAL_order:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		join_AST = (AST)currentAST.root;
		returnAST = join_AST;
	}
	
	public final void alias() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST alias_AST = null;
		
		{
		switch ( LA(1)) {
		case LITERAL_as:
		{
			AST tmp258_AST = null;
			tmp258_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_as);
			break;
		}
		case IDENTIFIER:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		identifier();
		astFactory.addASTChild(currentAST, returnAST);
		alias_AST = (AST)currentAST.root;
		returnAST = alias_AST;
	}
	
	public final void column() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST column_AST = null;
		
		{
		if ((LA(1)==IDENTIFIER) && (LA(2)==DOT)) {
			table_name();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp259_AST = null;
			tmp259_AST = (AST)astFactory.create(LT(1));
			match(DOT);
		}
		else if ((LA(1)==IDENTIFIER) && (_tokenSet_3.member(LA(2)))) {
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		column_name();
		astFactory.addASTChild(currentAST, returnAST);
		column_AST = (AST)currentAST.root;
		column_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(COLUMN,"column")).add(column_AST));
		currentAST.root = column_AST;
		currentAST.child = column_AST!=null &&column_AST.getFirstChild()!=null ?
			column_AST.getFirstChild() : column_AST;
		currentAST.advanceChildToEnd();
		column_AST = (AST)currentAST.root;
		returnAST = column_AST;
	}
	
	public final void value_no_null() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST value_no_null_AST = null;
		
		switch ( LA(1)) {
		case NUMBER:
		case DOT:
		{
			decimal_value();
			astFactory.addASTChild(currentAST, returnAST);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		case QUOTED_STRING:
		{
			AST tmp260_AST = null;
			tmp260_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp260_AST);
			match(QUOTED_STRING);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		case PARAMETER:
		{
			AST tmp261_AST = null;
			tmp261_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp261_AST);
			match(PARAMETER);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_date:
		{
			date();
			astFactory.addASTChild(currentAST, returnAST);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_timestamp:
		{
			timestamp();
			astFactory.addASTChild(currentAST, returnAST);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		case HEX:
		{
			binary();
			astFactory.addASTChild(currentAST, returnAST);
			value_no_null_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = value_no_null_AST;
	}
	
	public final void simple_function() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simple_function_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_now:
		{
			AST tmp262_AST = null;
			tmp262_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp262_AST);
			match(LITERAL_now);
			AST tmp263_AST = null;
			tmp263_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp264_AST = null;
			tmp264_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_date:
		{
			AST tmp265_AST = null;
			tmp265_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp265_AST);
			match(LITERAL_current_date);
			AST tmp266_AST = null;
			tmp266_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp267_AST = null;
			tmp267_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_time:
		{
			AST tmp268_AST = null;
			tmp268_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp268_AST);
			match(LITERAL_current_time);
			AST tmp269_AST = null;
			tmp269_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp270_AST = null;
			tmp270_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_timestamp:
		{
			AST tmp271_AST = null;
			tmp271_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp271_AST);
			match(LITERAL_current_timestamp);
			AST tmp272_AST = null;
			tmp272_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp273_AST = null;
			tmp273_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_curdate:
		{
			AST tmp274_AST = null;
			tmp274_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp274_AST);
			match(LITERAL_curdate);
			AST tmp275_AST = null;
			tmp275_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp276_AST = null;
			tmp276_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_curtime:
		{
			AST tmp277_AST = null;
			tmp277_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp277_AST);
			match(LITERAL_curtime);
			AST tmp278_AST = null;
			tmp278_AST = (AST)astFactory.create(LT(1));
			match(OPEN_PAREN);
			AST tmp279_AST = null;
			tmp279_AST = (AST)astFactory.create(LT(1));
			match(CLOSE_PAREN);
			simple_function_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = simple_function_AST;
	}
	
	public final void value() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST value_AST = null;
		
		switch ( LA(1)) {
		case QUOTED_STRING:
		case NUMBER:
		case LITERAL_date:
		case LITERAL_timestamp:
		case DOT:
		case PARAMETER:
		case HEX:
		{
			value_no_null();
			astFactory.addASTChild(currentAST, returnAST);
			value_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_null:
		{
			AST tmp280_AST = null;
			tmp280_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp280_AST);
			match(LITERAL_null);
			value_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = value_AST;
	}
	
	public final void decimal_value() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST decimal_value_AST = null;
		
		{
		if ((LA(1)==NUMBER) && (_tokenSet_4.member(LA(2)))) {
			AST tmp281_AST = null;
			tmp281_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp281_AST);
			match(NUMBER);
		}
		else if ((LA(1)==DOT)) {
			AST tmp282_AST = null;
			tmp282_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp282_AST);
			match(DOT);
			AST tmp283_AST = null;
			tmp283_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp283_AST);
			match(NUMBER);
		}
		else if ((LA(1)==NUMBER) && (LA(2)==DOT)) {
			AST tmp284_AST = null;
			tmp284_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp284_AST);
			match(NUMBER);
			AST tmp285_AST = null;
			tmp285_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp285_AST);
			match(DOT);
			{
			switch ( LA(1)) {
			case NUMBER:
			{
				AST tmp286_AST = null;
				tmp286_AST = (AST)astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp286_AST);
				match(NUMBER);
				break;
			}
			case EOF:
			case LITERAL_or:
			case LITERAL_and:
			case LITERAL_not:
			case CLOSE_PAREN:
			case LITERAL_between:
			case LITERAL_like:
			case LITERAL_is:
			case EQUAL:
			case BIGGER:
			case SMALLER:
			case NOT_EQUAL:
			case NOT_EQUAL_2:
			case BIGGER_EQUAL:
			case SMALLER_EQUAL:
			case LITERAL_in:
			case COMMA:
			case VERTBARS:
			case PLUS:
			case MINUS:
			case ASTERISK:
			case DIVIDE:
			case LITERAL_from:
			case LITERAL_where:
			case LITERAL_group:
			case LITERAL_having:
			case LITERAL_order:
			case LITERAL_inner:
			case LITERAL_left:
			case LITERAL_as:
			case IDENTIFIER:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
		}
		else {
			throw new NoViableAltException(LT(1), getFilename());
		}
		
		}
		decimal_value_AST = (AST)currentAST.root;
		decimal_value_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DECIMAL_VALUE,"decimal_value")).add(decimal_value_AST));
		currentAST.root = decimal_value_AST;
		currentAST.child = decimal_value_AST!=null &&decimal_value_AST.getFirstChild()!=null ?
			decimal_value_AST.getFirstChild() : decimal_value_AST;
		currentAST.advanceChildToEnd();
		decimal_value_AST = (AST)currentAST.root;
		returnAST = decimal_value_AST;
	}
	
	public final void date() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST date_AST = null;
		
		AST tmp287_AST = null;
		tmp287_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_date);
		AST tmp288_AST = null;
		tmp288_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp288_AST);
		match(QUOTED_STRING);
		date_AST = (AST)currentAST.root;
		date_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(DATE,"date")).add(date_AST));
		currentAST.root = date_AST;
		currentAST.child = date_AST!=null &&date_AST.getFirstChild()!=null ?
			date_AST.getFirstChild() : date_AST;
		currentAST.advanceChildToEnd();
		date_AST = (AST)currentAST.root;
		returnAST = date_AST;
	}
	
	public final void timestamp() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST timestamp_AST = null;
		
		AST tmp289_AST = null;
		tmp289_AST = (AST)astFactory.create(LT(1));
		match(LITERAL_timestamp);
		AST tmp290_AST = null;
		tmp290_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp290_AST);
		match(QUOTED_STRING);
		timestamp_AST = (AST)currentAST.root;
		timestamp_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(TIMESTAMP,"timestamp")).add(timestamp_AST));
		currentAST.root = timestamp_AST;
		currentAST.child = timestamp_AST!=null &&timestamp_AST.getFirstChild()!=null ?
			timestamp_AST.getFirstChild() : timestamp_AST;
		currentAST.advanceChildToEnd();
		timestamp_AST = (AST)currentAST.root;
		returnAST = timestamp_AST;
	}
	
	public final void binary() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST binary_AST = null;
		
		AST tmp291_AST = null;
		tmp291_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp291_AST);
		match(HEX);
		binary_AST = (AST)currentAST.root;
		binary_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(BINARY,"binary")).add(binary_AST));
		currentAST.root = binary_AST;
		currentAST.child = binary_AST!=null &&binary_AST.getFirstChild()!=null ?
			binary_AST.getFirstChild() : binary_AST;
		currentAST.advanceChildToEnd();
		binary_AST = (AST)currentAST.root;
		returnAST = binary_AST;
	}
	
	public final void order_item() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST order_item_AST = null;
		
		{
		column();
		astFactory.addASTChild(currentAST, returnAST);
		}
		{
		switch ( LA(1)) {
		case LITERAL_asc:
		{
			AST tmp292_AST = null;
			tmp292_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp292_AST);
			match(LITERAL_asc);
			break;
		}
		case LITERAL_desc:
		{
			AST tmp293_AST = null;
			tmp293_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp293_AST);
			match(LITERAL_desc);
			break;
		}
		case EOF:
		case CLOSE_PAREN:
		case COMMA:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		order_item_AST = (AST)currentAST.root;
		order_item_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(ORDER_ITEM,"order_item")).add(order_item_AST));
		currentAST.root = order_item_AST;
		currentAST.child = order_item_AST!=null &&order_item_AST.getFirstChild()!=null ?
			order_item_AST.getFirstChild() : order_item_AST;
		currentAST.advanceChildToEnd();
		order_item_AST = (AST)currentAST.root;
		returnAST = order_item_AST;
	}
	
	public final void quoted_string() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST quoted_string_AST = null;
		
		AST tmp294_AST = null;
		tmp294_AST = (AST)astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp294_AST);
		match(QUOTED_STRING);
		quoted_string_AST = (AST)currentAST.root;
		returnAST = quoted_string_AST;
	}
	
	public final void keyword() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST keyword_AST = null;
		
		switch ( LA(1)) {
		case LITERAL_abs:
		{
			AST tmp295_AST = null;
			tmp295_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp295_AST);
			match(LITERAL_abs);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_add:
		{
			AST tmp296_AST = null;
			tmp296_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp296_AST);
			match(LITERAL_add);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_all:
		{
			AST tmp297_AST = null;
			tmp297_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp297_AST);
			match(LITERAL_all);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_alter:
		{
			AST tmp298_AST = null;
			tmp298_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp298_AST);
			match(LITERAL_alter);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_and:
		{
			AST tmp299_AST = null;
			tmp299_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp299_AST);
			match(LITERAL_and);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_as:
		{
			AST tmp300_AST = null;
			tmp300_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp300_AST);
			match(LITERAL_as);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_asc:
		{
			AST tmp301_AST = null;
			tmp301_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp301_AST);
			match(LITERAL_asc);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_avg:
		{
			AST tmp302_AST = null;
			tmp302_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp302_AST);
			match(LITERAL_avg);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_before:
		{
			AST tmp303_AST = null;
			tmp303_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp303_AST);
			match(LITERAL_before);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_between:
		{
			AST tmp304_AST = null;
			tmp304_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp304_AST);
			match(LITERAL_between);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_bigint:
		{
			AST tmp305_AST = null;
			tmp305_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp305_AST);
			match(LITERAL_bigint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_binary:
		{
			AST tmp306_AST = null;
			tmp306_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp306_AST);
			match(LITERAL_binary);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_bit:
		{
			AST tmp307_AST = null;
			tmp307_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp307_AST);
			match(LITERAL_bit);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_blob:
		{
			AST tmp308_AST = null;
			tmp308_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp308_AST);
			match(LITERAL_blob);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_boolean:
		{
			AST tmp309_AST = null;
			tmp309_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp309_AST);
			match(LITERAL_boolean);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_both:
		{
			AST tmp310_AST = null;
			tmp310_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp310_AST);
			match(LITERAL_both);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_by:
		{
			AST tmp311_AST = null;
			tmp311_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp311_AST);
			match(LITERAL_by);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_cached:
		{
			AST tmp312_AST = null;
			tmp312_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp312_AST);
			match(LITERAL_cached);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_cascade:
		{
			AST tmp313_AST = null;
			tmp313_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp313_AST);
			match(LITERAL_cascade);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_case:
		{
			AST tmp314_AST = null;
			tmp314_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp314_AST);
			match(LITERAL_case);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_cast:
		{
			AST tmp315_AST = null;
			tmp315_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp315_AST);
			match(LITERAL_cast);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_char:
		{
			AST tmp316_AST = null;
			tmp316_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp316_AST);
			match(LITERAL_char);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_character:
		{
			AST tmp317_AST = null;
			tmp317_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp317_AST);
			match(LITERAL_character);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_character_length:
		{
			AST tmp318_AST = null;
			tmp318_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp318_AST);
			match(LITERAL_character_length);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_char_length:
		{
			AST tmp319_AST = null;
			tmp319_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp319_AST);
			match(LITERAL_char_length);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_clob:
		{
			AST tmp320_AST = null;
			tmp320_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp320_AST);
			match(LITERAL_clob);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_column:
		{
			AST tmp321_AST = null;
			tmp321_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp321_AST);
			match(LITERAL_column);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_commit:
		{
			AST tmp322_AST = null;
			tmp322_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp322_AST);
			match(LITERAL_commit);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_concat:
		{
			AST tmp323_AST = null;
			tmp323_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp323_AST);
			match(LITERAL_concat);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_constraint:
		{
			AST tmp324_AST = null;
			tmp324_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp324_AST);
			match(LITERAL_constraint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_convert:
		{
			AST tmp325_AST = null;
			tmp325_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp325_AST);
			match(LITERAL_convert);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_count:
		{
			AST tmp326_AST = null;
			tmp326_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp326_AST);
			match(LITERAL_count);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_create:
		{
			AST tmp327_AST = null;
			tmp327_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp327_AST);
			match(LITERAL_create);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_cross:
		{
			AST tmp328_AST = null;
			tmp328_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp328_AST);
			match(LITERAL_cross);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_curdate:
		{
			AST tmp329_AST = null;
			tmp329_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp329_AST);
			match(LITERAL_curdate);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_date:
		{
			AST tmp330_AST = null;
			tmp330_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp330_AST);
			match(LITERAL_current_date);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_time:
		{
			AST tmp331_AST = null;
			tmp331_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp331_AST);
			match(LITERAL_current_time);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_current_timestamp:
		{
			AST tmp332_AST = null;
			tmp332_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp332_AST);
			match(LITERAL_current_timestamp);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_curtime:
		{
			AST tmp333_AST = null;
			tmp333_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp333_AST);
			match(LITERAL_curtime);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_database:
		{
			AST tmp334_AST = null;
			tmp334_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp334_AST);
			match(LITERAL_database);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_date:
		{
			AST tmp335_AST = null;
			tmp335_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp335_AST);
			match(LITERAL_date);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_datetime:
		{
			AST tmp336_AST = null;
			tmp336_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp336_AST);
			match(LITERAL_datetime);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_dec:
		{
			AST tmp337_AST = null;
			tmp337_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp337_AST);
			match(LITERAL_dec);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_decimal:
		{
			AST tmp338_AST = null;
			tmp338_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp338_AST);
			match(LITERAL_decimal);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_default:
		{
			AST tmp339_AST = null;
			tmp339_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp339_AST);
			match(LITERAL_default);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_delete:
		{
			AST tmp340_AST = null;
			tmp340_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp340_AST);
			match(LITERAL_delete);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_desc:
		{
			AST tmp341_AST = null;
			tmp341_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp341_AST);
			match(LITERAL_desc);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_distinct:
		{
			AST tmp342_AST = null;
			tmp342_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp342_AST);
			match(LITERAL_distinct);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_double:
		{
			AST tmp343_AST = null;
			tmp343_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp343_AST);
			match(LITERAL_double);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_drop:
		{
			AST tmp344_AST = null;
			tmp344_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp344_AST);
			match(LITERAL_drop);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_exists:
		{
			AST tmp345_AST = null;
			tmp345_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp345_AST);
			match(LITERAL_exists);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_extract:
		{
			AST tmp346_AST = null;
			tmp346_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp346_AST);
			match(LITERAL_extract);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_false:
		{
			AST tmp347_AST = null;
			tmp347_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp347_AST);
			match(LITERAL_false);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_float:
		{
			AST tmp348_AST = null;
			tmp348_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp348_AST);
			match(LITERAL_float);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_for:
		{
			AST tmp349_AST = null;
			tmp349_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp349_AST);
			match(LITERAL_for);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_foreign:
		{
			AST tmp350_AST = null;
			tmp350_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp350_AST);
			match(LITERAL_foreign);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_from:
		{
			AST tmp351_AST = null;
			tmp351_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp351_AST);
			match(LITERAL_from);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_grant:
		{
			AST tmp352_AST = null;
			tmp352_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp352_AST);
			match(LITERAL_grant);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_group:
		{
			AST tmp353_AST = null;
			tmp353_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp353_AST);
			match(LITERAL_group);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_having:
		{
			AST tmp354_AST = null;
			tmp354_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp354_AST);
			match(LITERAL_having);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_if:
		{
			AST tmp355_AST = null;
			tmp355_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp355_AST);
			match(LITERAL_if);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_image:
		{
			AST tmp356_AST = null;
			tmp356_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp356_AST);
			match(LITERAL_image);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_in:
		{
			AST tmp357_AST = null;
			tmp357_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp357_AST);
			match(LITERAL_in);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_index:
		{
			AST tmp358_AST = null;
			tmp358_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp358_AST);
			match(LITERAL_index);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_infile:
		{
			AST tmp359_AST = null;
			tmp359_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp359_AST);
			match(LITERAL_infile);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_inner:
		{
			AST tmp360_AST = null;
			tmp360_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp360_AST);
			match(LITERAL_inner);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_insert:
		{
			AST tmp361_AST = null;
			tmp361_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp361_AST);
			match(LITERAL_insert);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_int:
		{
			AST tmp362_AST = null;
			tmp362_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp362_AST);
			match(LITERAL_int);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_integer:
		{
			AST tmp363_AST = null;
			tmp363_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp363_AST);
			match(LITERAL_integer);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_into:
		{
			AST tmp364_AST = null;
			tmp364_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp364_AST);
			match(LITERAL_into);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_is:
		{
			AST tmp365_AST = null;
			tmp365_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp365_AST);
			match(LITERAL_is);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_join:
		{
			AST tmp366_AST = null;
			tmp366_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp366_AST);
			match(LITERAL_join);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_key:
		{
			AST tmp367_AST = null;
			tmp367_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp367_AST);
			match(LITERAL_key);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_kill:
		{
			AST tmp368_AST = null;
			tmp368_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp368_AST);
			match(LITERAL_kill);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lcase:
		{
			AST tmp369_AST = null;
			tmp369_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp369_AST);
			match(LITERAL_lcase);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_leading:
		{
			AST tmp370_AST = null;
			tmp370_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp370_AST);
			match(LITERAL_leading);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_left:
		{
			AST tmp371_AST = null;
			tmp371_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp371_AST);
			match(LITERAL_left);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_length:
		{
			AST tmp372_AST = null;
			tmp372_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp372_AST);
			match(LITERAL_length);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_like:
		{
			AST tmp373_AST = null;
			tmp373_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp373_AST);
			match(LITERAL_like);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_limit:
		{
			AST tmp374_AST = null;
			tmp374_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp374_AST);
			match(LITERAL_limit);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lineno:
		{
			AST tmp375_AST = null;
			tmp375_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp375_AST);
			match(LITERAL_lineno);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_load:
		{
			AST tmp376_AST = null;
			tmp376_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp376_AST);
			match(LITERAL_load);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lob:
		{
			AST tmp377_AST = null;
			tmp377_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp377_AST);
			match(LITERAL_lob);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_local:
		{
			AST tmp378_AST = null;
			tmp378_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp378_AST);
			match(LITERAL_local);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_locate:
		{
			AST tmp379_AST = null;
			tmp379_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp379_AST);
			match(LITERAL_locate);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lock:
		{
			AST tmp380_AST = null;
			tmp380_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp380_AST);
			match(LITERAL_lock);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_long:
		{
			AST tmp381_AST = null;
			tmp381_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp381_AST);
			match(LITERAL_long);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_longvarbinary:
		{
			AST tmp382_AST = null;
			tmp382_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp382_AST);
			match(LITERAL_longvarbinary);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_longvarchar:
		{
			AST tmp383_AST = null;
			tmp383_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp383_AST);
			match(LITERAL_longvarchar);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_lower:
		{
			AST tmp384_AST = null;
			tmp384_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp384_AST);
			match(LITERAL_lower);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_match:
		{
			AST tmp385_AST = null;
			tmp385_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp385_AST);
			match(LITERAL_match);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_max:
		{
			AST tmp386_AST = null;
			tmp386_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp386_AST);
			match(LITERAL_max);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_mediumint:
		{
			AST tmp387_AST = null;
			tmp387_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp387_AST);
			match(LITERAL_mediumint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_min:
		{
			AST tmp388_AST = null;
			tmp388_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp388_AST);
			match(LITERAL_min);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_mod:
		{
			AST tmp389_AST = null;
			tmp389_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp389_AST);
			match(LITERAL_mod);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_natural:
		{
			AST tmp390_AST = null;
			tmp390_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp390_AST);
			match(LITERAL_natural);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_not:
		{
			AST tmp391_AST = null;
			tmp391_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp391_AST);
			match(LITERAL_not);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_now:
		{
			AST tmp392_AST = null;
			tmp392_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp392_AST);
			match(LITERAL_now);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_null:
		{
			AST tmp393_AST = null;
			tmp393_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp393_AST);
			match(LITERAL_null);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_numeric:
		{
			AST tmp394_AST = null;
			tmp394_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp394_AST);
			match(LITERAL_numeric);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_object:
		{
			AST tmp395_AST = null;
			tmp395_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp395_AST);
			match(LITERAL_object);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_octet_length:
		{
			AST tmp396_AST = null;
			tmp396_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp396_AST);
			match(LITERAL_octet_length);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_on:
		{
			AST tmp397_AST = null;
			tmp397_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp397_AST);
			match(LITERAL_on);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_option:
		{
			AST tmp398_AST = null;
			tmp398_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp398_AST);
			match(LITERAL_option);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_or:
		{
			AST tmp399_AST = null;
			tmp399_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp399_AST);
			match(LITERAL_or);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_order:
		{
			AST tmp400_AST = null;
			tmp400_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp400_AST);
			match(LITERAL_order);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_other:
		{
			AST tmp401_AST = null;
			tmp401_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp401_AST);
			match(LITERAL_other);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_outer:
		{
			AST tmp402_AST = null;
			tmp402_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp402_AST);
			match(LITERAL_outer);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_outfile:
		{
			AST tmp403_AST = null;
			tmp403_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp403_AST);
			match(LITERAL_outfile);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_position:
		{
			AST tmp404_AST = null;
			tmp404_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp404_AST);
			match(LITERAL_position);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_precision:
		{
			AST tmp405_AST = null;
			tmp405_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp405_AST);
			match(LITERAL_precision);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_primary:
		{
			AST tmp406_AST = null;
			tmp406_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp406_AST);
			match(LITERAL_primary);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_privileges:
		{
			AST tmp407_AST = null;
			tmp407_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp407_AST);
			match(LITERAL_privileges);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_procedure:
		{
			AST tmp408_AST = null;
			tmp408_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp408_AST);
			match(LITERAL_procedure);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_read:
		{
			AST tmp409_AST = null;
			tmp409_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp409_AST);
			match(LITERAL_read);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_real:
		{
			AST tmp410_AST = null;
			tmp410_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp410_AST);
			match(LITERAL_real);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_references:
		{
			AST tmp411_AST = null;
			tmp411_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp411_AST);
			match(LITERAL_references);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_rename:
		{
			AST tmp412_AST = null;
			tmp412_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp412_AST);
			match(LITERAL_rename);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_replace:
		{
			AST tmp413_AST = null;
			tmp413_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp413_AST);
			match(LITERAL_replace);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_restrict:
		{
			AST tmp414_AST = null;
			tmp414_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp414_AST);
			match(LITERAL_restrict);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_returns:
		{
			AST tmp415_AST = null;
			tmp415_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp415_AST);
			match(LITERAL_returns);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_revoke:
		{
			AST tmp416_AST = null;
			tmp416_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp416_AST);
			match(LITERAL_revoke);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_right:
		{
			AST tmp417_AST = null;
			tmp417_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp417_AST);
			match(LITERAL_right);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_rollback:
		{
			AST tmp418_AST = null;
			tmp418_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp418_AST);
			match(LITERAL_rollback);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_savepoint:
		{
			AST tmp419_AST = null;
			tmp419_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp419_AST);
			match(LITERAL_savepoint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_select:
		{
			AST tmp420_AST = null;
			tmp420_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp420_AST);
			match(LITERAL_select);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_session_user:
		{
			AST tmp421_AST = null;
			tmp421_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp421_AST);
			match(LITERAL_session_user);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_set:
		{
			AST tmp422_AST = null;
			tmp422_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp422_AST);
			match(LITERAL_set);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_smallint:
		{
			AST tmp423_AST = null;
			tmp423_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp423_AST);
			match(LITERAL_smallint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_sqrt:
		{
			AST tmp424_AST = null;
			tmp424_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp424_AST);
			match(LITERAL_sqrt);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_substring:
		{
			AST tmp425_AST = null;
			tmp425_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp425_AST);
			match(LITERAL_substring);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_sum:
		{
			AST tmp426_AST = null;
			tmp426_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp426_AST);
			match(LITERAL_sum);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_sysdate:
		{
			AST tmp427_AST = null;
			tmp427_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp427_AST);
			match(LITERAL_sysdate);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_table:
		{
			AST tmp428_AST = null;
			tmp428_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp428_AST);
			match(LITERAL_table);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_temp:
		{
			AST tmp429_AST = null;
			tmp429_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp429_AST);
			match(LITERAL_temp);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_text:
		{
			AST tmp430_AST = null;
			tmp430_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp430_AST);
			match(LITERAL_text);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_time:
		{
			AST tmp431_AST = null;
			tmp431_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp431_AST);
			match(LITERAL_time);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_timestamp:
		{
			AST tmp432_AST = null;
			tmp432_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp432_AST);
			match(LITERAL_timestamp);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_tinyint:
		{
			AST tmp433_AST = null;
			tmp433_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp433_AST);
			match(LITERAL_tinyint);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_to:
		{
			AST tmp434_AST = null;
			tmp434_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp434_AST);
			match(LITERAL_to);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_top:
		{
			AST tmp435_AST = null;
			tmp435_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp435_AST);
			match(LITERAL_top);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_trailing:
		{
			AST tmp436_AST = null;
			tmp436_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp436_AST);
			match(LITERAL_trailing);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_trigger:
		{
			AST tmp437_AST = null;
			tmp437_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp437_AST);
			match(LITERAL_trigger);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_trim:
		{
			AST tmp438_AST = null;
			tmp438_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp438_AST);
			match(LITERAL_trim);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_true:
		{
			AST tmp439_AST = null;
			tmp439_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp439_AST);
			match(LITERAL_true);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_ucase:
		{
			AST tmp440_AST = null;
			tmp440_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp440_AST);
			match(LITERAL_ucase);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_union:
		{
			AST tmp441_AST = null;
			tmp441_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp441_AST);
			match(LITERAL_union);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_unique:
		{
			AST tmp442_AST = null;
			tmp442_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp442_AST);
			match(LITERAL_unique);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_unsigned:
		{
			AST tmp443_AST = null;
			tmp443_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp443_AST);
			match(LITERAL_unsigned);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_update:
		{
			AST tmp444_AST = null;
			tmp444_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp444_AST);
			match(LITERAL_update);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_upper:
		{
			AST tmp445_AST = null;
			tmp445_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp445_AST);
			match(LITERAL_upper);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_user:
		{
			AST tmp446_AST = null;
			tmp446_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp446_AST);
			match(LITERAL_user);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_using:
		{
			AST tmp447_AST = null;
			tmp447_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp447_AST);
			match(LITERAL_using);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_values:
		{
			AST tmp448_AST = null;
			tmp448_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp448_AST);
			match(LITERAL_values);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_varbinary:
		{
			AST tmp449_AST = null;
			tmp449_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp449_AST);
			match(LITERAL_varbinary);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_varchar:
		{
			AST tmp450_AST = null;
			tmp450_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp450_AST);
			match(LITERAL_varchar);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_varchar_ignorecase:
		{
			AST tmp451_AST = null;
			tmp451_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp451_AST);
			match(LITERAL_varchar_ignorecase);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_when:
		{
			AST tmp452_AST = null;
			tmp452_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp452_AST);
			match(LITERAL_when);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_where:
		{
			AST tmp453_AST = null;
			tmp453_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp453_AST);
			match(LITERAL_where);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_with:
		{
			AST tmp454_AST = null;
			tmp454_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp454_AST);
			match(LITERAL_with);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_write:
		{
			AST tmp455_AST = null;
			tmp455_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp455_AST);
			match(LITERAL_write);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_x:
		{
			AST tmp456_AST = null;
			tmp456_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp456_AST);
			match(LITERAL_x);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_y:
		{
			AST tmp457_AST = null;
			tmp457_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp457_AST);
			match(LITERAL_y);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		case LITERAL_zerofill:
		{
			AST tmp458_AST = null;
			tmp458_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp458_AST);
			match(LITERAL_zerofill);
			keyword_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = keyword_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"COLUMN_LIST",
		"CREATE_TABLE",
		"UPDATE",
		"INSERT",
		"SELECT",
		"SELECT_ONE_COLUMN",
		"DELETE",
		"COLUMN_DEF",
		"PRIMARY_KEY",
		"CREATE_INDEX",
		"DROP_TABLE",
		"DROP_INDEX",
		"UPDATE_SET",
		"EXPRESSION",
		"CONDITION",
		"SELECTED_TABLE",
		"SELECT_ITEM",
		"GROUP_BY",
		"ORDER_BY",
		"ORDER_ITEM",
		"NOT",
		"BETWEEN",
		"NOT_BETWEEN",
		"LIKE",
		"NOT_LIKE",
		"IS_NULL",
		"IS_NOT_NULL",
		"NEGATIVE",
		"NULL_INSERT",
		"DECIMAL_VALUE",
		"DATE",
		"TIME",
		"TIMESTAMP",
		"BINARY",
		"COLUMN",
		"DATATYPE",
		"AGGREGATE",
		"COMMIT",
		"ROLLBACK",
		"TYPE_INT",
		"TYPE_VARCHAR",
		"TYPE_DECIMAL",
		"TYPE_DATETIME",
		"TYPE_BLOB",
		"TYPE_CLOB",
		"FOREIGN_KEY",
		"SET_AUTOCOMMIT_TRUE",
		"SET_AUTOCOMMIT_FALSE",
		"GET_AUTOINCREMENT_KEY",
		"ALTER_TABLE_DROP_CONSTRAINT",
		"ALTER_TABLE_RENAME",
		"ALTER_TABLE_ADD_COLUMN",
		"TABLE_ASTERISK",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"exists\"",
		"OPEN_PAREN",
		"CLOSE_PAREN",
		"\"between\"",
		"\"like\"",
		"\"is\"",
		"\"null\"",
		"EQUAL",
		"BIGGER",
		"SMALLER",
		"NOT_EQUAL",
		"NOT_EQUAL_2",
		"BIGGER_EQUAL",
		"SMALLER_EQUAL",
		"\"in\"",
		"COMMA",
		"VERTBARS",
		"PLUS",
		"MINUS",
		"ASTERISK",
		"DIVIDE",
		"\"commit\"",
		"\"rollback\"",
		"\"get\"",
		"\"autoincrement\"",
		"\"key\"",
		"\"set\"",
		"\"autocommit\"",
		"\"true\"",
		"\"false\"",
		"\"insert\"",
		"\"into\"",
		"\"values\"",
		"\"create\"",
		"\"table\"",
		"\"if\"",
		"\"option\"",
		"QUOTED_STRING",
		"\"unique\"",
		"\"index\"",
		"\"on\"",
		"\"drop\"",
		"\"alter\"",
		"\"add\"",
		"\"column\"",
		"\"default\"",
		"\"constraint\"",
		"\"rename\"",
		"\"to\"",
		"\"primary\"",
		"\"foreign\"",
		"\"references\"",
		"NUMBER",
		"\"int\"",
		"\"integer\"",
		"\"tinyint\"",
		"\"smallint\"",
		"\"mediumint\"",
		"\"bit\"",
		"\"boolean\"",
		"\"varchar\"",
		"\"char\"",
		"\"decimal\"",
		"\"numeric\"",
		"\"dec\"",
		"\"real\"",
		"\"float\"",
		"\"double\"",
		"\"bigint\"",
		"\"datetime\"",
		"\"date\"",
		"\"timestamp\"",
		"\"time\"",
		"\"blob\"",
		"\"tinyblob\"",
		"\"mediumblob\"",
		"\"longblob\"",
		"\"binary\"",
		"\"varbinary\"",
		"\"longvarbinary\"",
		"\"image\"",
		"\"clob\"",
		"\"tinytext\"",
		"\"mediumtext\"",
		"\"longtext\"",
		"\"text\"",
		"\"longvarchar\"",
		"\"select\"",
		"\"distinct\"",
		"\"top\"",
		"\"from\"",
		"\"where\"",
		"\"group\"",
		"\"by\"",
		"\"having\"",
		"\"order\"",
		"\"update\"",
		"\"delete\"",
		"\"inner\"",
		"\"left\"",
		"\"outer\"",
		"\"join\"",
		"DOT",
		"\"as\"",
		"\"count\"",
		"\"min\"",
		"\"max\"",
		"\"sum\"",
		"\"avg\"",
		"\"now\"",
		"\"current_date\"",
		"\"current_time\"",
		"\"current_timestamp\"",
		"\"curdate\"",
		"\"curtime\"",
		"\"cast\"",
		"\"convert\"",
		"\"length\"",
		"\"char_length\"",
		"\"character_length\"",
		"\"mod\"",
		"\"concat\"",
		"\"lower\"",
		"\"lcase\"",
		"\"upper\"",
		"\"ucase\"",
		"PARAMETER",
		"HEX",
		"\"asc\"",
		"\"desc\"",
		"IDENTIFIER",
		"\"abs\"",
		"\"all\"",
		"\"before\"",
		"\"both\"",
		"\"cached\"",
		"\"cascade\"",
		"\"case\"",
		"\"character\"",
		"\"cross\"",
		"\"database\"",
		"\"extract\"",
		"\"for\"",
		"\"grant\"",
		"\"infile\"",
		"\"kill\"",
		"\"leading\"",
		"\"limit\"",
		"\"lineno\"",
		"\"load\"",
		"\"lob\"",
		"\"local\"",
		"\"locate\"",
		"\"lock\"",
		"\"long\"",
		"\"match\"",
		"\"natural\"",
		"\"object\"",
		"\"octet_length\"",
		"\"other\"",
		"\"outfile\"",
		"\"position\"",
		"\"precision\"",
		"\"privileges\"",
		"\"procedure\"",
		"\"read\"",
		"\"replace\"",
		"\"restrict\"",
		"\"returns\"",
		"\"revoke\"",
		"\"right\"",
		"\"savepoint\"",
		"\"session_user\"",
		"\"sqrt\"",
		"\"substring\"",
		"\"sysdate\"",
		"\"temp\"",
		"\"trailing\"",
		"\"trigger\"",
		"\"trim\"",
		"\"union\"",
		"\"unsigned\"",
		"\"user\"",
		"\"using\"",
		"\"varchar_ignorecase\"",
		"\"when\"",
		"\"with\"",
		"\"write\"",
		"\"x\"",
		"\"y\"",
		"\"zerofill\"",
		"WS",
		"START_END_REMARK",
		"SINGLE_LINE_COMMENT"
	};
	
	private static final long _tokenSet_0_data_[] = { 2305843009213693952L, 281483566661636L, 5764607471494627340L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 2305843009213693952L, 281483566774276L, 5764607505858560012L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 6917529027641081856L, 281483566774276L, 5764607505859608588L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	private static final long _tokenSet_3_data_[] = { -3602879701896396798L, 131067L, 8070450570059579392L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_3 = new BitSet(_tokenSet_3_data_);
	private static final long _tokenSet_4_data_[] = { -3602879701896396798L, 131067L, 4611686056239038464L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_4 = new BitSet(_tokenSet_4_data_);
	
	}
