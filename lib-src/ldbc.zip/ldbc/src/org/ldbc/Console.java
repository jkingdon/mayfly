/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc;

import java.sql.*;
import java.io.*;
import java.util.*;

public class Console {

    public static void main(String[] argv) {
        (new Console()).run(argv);
    }

    Connection conn;

    BufferedReader reader;

    void run(String[] a) {
        try {
            runIt(a);
        } catch (Throwable e) {
            e.printStackTrace();
            showUsage();
        }
    }

    void runIt(String[] a) throws Exception {
        String url = null;
        String user = "";
        String password = "";
        boolean hide = false;
        String driver = "org.ldbc.jdbc.jdbcDriver";
        for (int i = 0; i < a.length; i++) {
            String s = a[i];
            if (s.equals("-url")) {
                url = a[++i];
            } else if (s.equals("-driver")) {
                driver = a[++i];
            } else if (s.equals("-user")) {
                user = a[++i];
            } else if (s.equals("-password")) {
                password = a[++i];
            } else if (s.equals("-hide")) {
                hide = true;
            }
        }
        if (url == null) {
            url = getLine("URL", "jdbc:ldbc:hsqldb:sample");
            if (!url.startsWith("jdbc:ldbc:")) {
                driver = getLine("Driver", "org.ldbc.jdbc.jdbcDriver");
            }
            user = getLine("User", "sa");
            password = hide ? getPassword() : getLine("Password", "");
        }
        Class.forName(driver);
        conn = DriverManager.getConnection(url, user, password);
        System.out.println("Connected to " + url);

        reader = new BufferedReader(new InputStreamReader(System.in));
        showHelp();
        while (true) {
            System.out.print("console>");
            String line = reader.readLine().trim();
            if (line.equals("help")) {
                showHelp();
            } else if (line.equals("quit") || line.equals("exit")) {
                break;
            } else if (line.equals("tables")) {
                showResultSet(conn.getMetaData().getTables(null, null, null,
                        null));
            } else if (line.startsWith("columns ")) {
                int index = line.indexOf(' ');
                String table = line.substring(index).trim().toUpperCase();
                showResultSet(conn.getMetaData().getColumns(null, null, table,
                        null));
            } else if (line.startsWith("indexes ")) {
                int index = line.indexOf(' ');
                String table = line.substring(index).trim().toUpperCase();
                showResultSet(conn.getMetaData().getIndexInfo(null, null,
                        table, false, false));
            } else if (line.startsWith("primarykeys ")) {
                int index = line.indexOf(' ');
                String table = line.substring(index).trim().toUpperCase();
                showResultSet(conn.getMetaData().getPrimaryKeys(null, null,
                        table));
            } else if (line.startsWith("importedkeys ")) {
                int index = line.indexOf(' ');
                String table = line.substring(index).trim().toUpperCase();
                showResultSet(conn.getMetaData().getImportedKeys(null, null,
                        table));
            } else if (line.length() == 0) {
                // do nothing
            } else {
                while (!line.endsWith(";")) {
                    System.out.print("    ...>");
                    String more = reader.readLine().trim();
                    if (more.length() == 0) {
                        // add a ; so it can be removed later
                        line += ";";
                    } else {
                        line += " "+more;
                    }
                }
                // remove the trailing ;
                line = line.substring(0, line.length() - 1);
                if (line.length() > 0) {
                    showResult(line);
                }
            }
        }

        conn.close();
        reader.close();
    }

    void showResult(String sql) {
        try {
            Statement stat = conn.createStatement();
            boolean result = stat.execute(sql);
            if (result) {
                showResultSet(stat.getResultSet());
            } else {
                System.out.println("Update count: " + stat.getUpdateCount());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    void showResultSet(ResultSet rs) throws SQLException {
        ResultSetMetaData m = rs.getMetaData();
        int count = m.getColumnCount();
        String[] head = new String[count];
        int[] max = new int[count];
        ArrayList data = new ArrayList();
        for (int i = 0; i < count; i++) {
            String s = m.getColumnLabel(i + 1);
            int l = s.length();
            if (l > max[i]) {
                max[i] = l;
            }
            head[i] = s;
        }
        while (rs.next()) {
            String[] row = new String[count];
            for (int i = 0; i < count; i++) {
                String s = rs.getString(i + 1);
                if (s == null) {
                    s = "(null)";
                }
                int l = s.length();
                if (l > max[i]) {
                    max[i] = l;
                }
                row[i] = s;
            }
            data.add(row);
        }
        rs.close();
        StringBuffer buff = new StringBuffer();
        addRow(buff, head, max);
        addRow(buff, null, max);
        for (int i = 0; i < data.size(); i++) {
            addRow(buff, (String[]) data.get(i), max);
        }
        buff.append("\nRow count: " + data.size());
        Object[] objarray = data.toArray();
        String[][] strarray = new String[data.size()][count];
        System.arraycopy(objarray, 0, strarray, 0, data.size());
        System.out.println(buff.toString());
    }

    void addRow(StringBuffer b, String[] row, int[] max) {
        int count = max.length;
        for (int i = 0; i < count; i++) {
            if (i > 0) {
                b.append(' ');
            }
            if (row == null) {
                for (int j = 0; j < max[i]; j++) {
                    b.append('-');
                }
            } else {
                String s = row[i];
                int l = s.length();
                b.append(s);
                for (int j = l; j < max[i]; j++) {
                    b.append(' ');
                }
            }
        }
        b.append('\n');
    }

    void showHelp() {
        System.out
                .println("Internal (non-SQL) commands are:\n"
                        + "  quit (or exit)       Close connection and exit\n"
                        + "  help                 Display help information\n"
                        + "  tables               Display the list of tables\n"
                        + "  columns <table>      Display the list of columns for a table\n"
                        + "  indexes <table>      Display the indexes for a table\n"
                        + "  primarykeys <table>  Display the primary keys for a table\n"
                        + "  importedkeys <table> Display the imported keys for a table\n"
                        + "Some SQL commands examples:\n"
                        + "  create table test(id int primary key, name varchar(255);\n"
                        + "  insert into test values(1, 'Hello');\n"
                        + "  select * from test;\n"
                        + "SQL statements must be terminated with ';' or an empty line.");
    }

    public String getLine(String prompt, String defaultValue) throws Exception {
        BufferedReader stdin = new BufferedReader(new InputStreamReader(
                System.in));
        System.out.print(prompt + " (default: " + defaultValue + "):  ");
        String word = stdin.readLine().trim();
        if (word.length() == 0) {
            word = defaultValue;
        }
        return word;
    }

    public String getPassword() throws Exception {
        class Eraser extends Thread {

            boolean stop;

            public void halt() {
                stop = true;
            }

            public void run() {
                try {
                    while (!stop) {
                        System.out.print("\b\b <");
                        Thread.sleep(1);
                    }
                } catch (Throwable e) {
                    // ignore
                }
            }
        }
        BufferedReader stdin = new BufferedReader(new InputStreamReader(
                System.in));
        System.out.print("Password:  ");
        Eraser eraser = new Eraser();
        eraser.start();

        String password = stdin.readLine();
        eraser.halt();
        eraser.join();
        System.out.print("\b\b");
        return password;
    }

    void showUsage() {
        String className = getClass().getName();
        System.out.println("Usage: java " + className + " [options]\n"
                + "Options:\n"
                + "-driver <url>    database driver class name\n"
                + "-url <url>       database url\n"
                + "-user <user>     user name (default: empty string)\n"
                + "-password <pwd>  password (default: empty string)\n"                + "-hide            hides the input when prompting for password\n"                + "                 (may not work in some consoles)");
    }

}
