/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import java.sql.*;

/**
 *
 * Failures:
 *
 * TestDatabaseMetaData
 * TestStatement
 * TestResultSet
 * TestGrammar
 * TestFunctions
 * TestPreparedStatement
 *
 * Known issues:
 *
 * DatabaseMetaData.getIndexInfo should return the index name only. QED returns the
 * the schema (or database?) name, dot, and the index name (example: LDBC.TEST_IDX_DATE instead of TEST_IDX_DATE)
 *
 * According to the specs, Statement.setQueryTimeout must not throw an exception, 
 * even if the functionality is not supported by the database.
 * Unfortunately QED throws an exception.
 *
 * It seems that an index is not automatically deleted if the table is deleted.
 *
 * Can't find documentation on how to build a hex string (the doc says: HEXSTR)
 * The two usual syntaxes don't work (X'01ab' and 0x01ab)
 *
 * The following code fails:
 * stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,I INT)");
 * ResultSet rs=stat.executeQuery("SELECT I FROM TEST ORDER BY ID"); 
 * The exceptio is:2003-07-15 23:30:26.970: [main] bad col: ID, c = ItemsCursor: LDBC.TEST {I} : 
 * (cursor = IndexCursor: PrimaryKeyConstraint_0 {LDBC.TEST.ID,LDBC.TEST.I})
 * Exception in thread "main" java.sql.SQLException: Bad column name: ID
 *        at com.quadcap.sql.OrderByCursor.<init>(OrderByCursor.java:96)
 *        at com.quadcap.sql.SelectStmt.execute(SelectStmt.java:81)
 *        at com.quadcap.sql.Session.doStatement(Session.java:266)
 *        at com.quadcap.jdbc.Statement.execute(Statement.java:228)
 *        at com.quadcap.jdbc.Statement.executeQuery(Statement.java:328)
 *        at org.ldbc.adapter.QED.main(QED.java:50)
 */
  
public class QED extends Base implements Adapter {
    public static void main(String argv[]) throws Exception {
        Class.forName("com.quadcap.jdbc.JdbcDriver");
        Connection conn=DriverManager.getConnection("jdbc:qed:sample;create=true","ldbc","ldbc");
        Statement stat=conn.createStatement();
        try {
            stat.execute("DROP INDEX IDX_TEST");
        } catch(SQLException e) {
            // exception - ok
        }
        try {
            stat.execute("DROP TABLE TEST");
        } catch(SQLException e) {
            // exception - ok
        }
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,I INT)");
        stat.executeQuery("SELECT I FROM TEST ORDER BY ID");        
        
        stat.execute("CREATE INDEX IDX_TEST ON TEST(NAME)");
        // this should also delete the index
        stat.execute("DROP TABLE TEST");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,NAME VARCHAR(255))");
        stat.execute("CREATE INDEX IDX_TEST ON TEST(NAME)");
        conn.close();
    }

    // url: jdbc:qed:sample;create=true
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "com.quadcap.jdbc.JdbcDriver";
    }
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        }
        return getDefaultDataTypeString(type);
    }
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }
    public String getBinaryConstant(String s) {
        return "0x"+s;
    }
    public void setTransactionIsolation(int level) {
        // only Connection.TRANSACTION_SERIALIZABLE is supported
    }
    public void convertDataType(DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.OTHER:
            type.update(Types.INTEGER,0,0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
}
