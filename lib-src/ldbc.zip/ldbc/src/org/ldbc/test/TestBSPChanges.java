/**
  * Created on 26.06.2004
  */
package org.ldbc.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
  * @author bsp
  */
public class TestBSPChanges extends TestBase {

    public static void main(String[] argv) {
        new TestBSPChanges().test(argv);
    }

    void test(Connection conn) throws SQLException {
        PreparedStatement ps = conn
                .prepareStatement("CREATE TABLE testClob (clobField TEXT)");
        ps.execute();
        ps.close();

        testChar(conn, "testClob", 'R', 100);
        testChar(conn, "testClob", 'R', 1000);
        testChar(conn, "testClob", 'R', 3000);
        testChar(conn, "testClob", 'R', 6000);

        testChar(conn, "testClob", '�', 100);
        testChar(conn, "testClob", '�', 1000);
        testChar(conn, "testClob", '�', 3000);
        testChar(conn, "testClob", '�', 6000);

        ps = conn.prepareStatement("DROP TABLE testClob");
        ps.execute();
        ps.close();

        ps = conn
                .prepareStatement("CREATE TABLE testVarChar (textField varchar(255))");
        ps.execute();
        ps.close();

        testChar(conn, "testVarChar", 'R', 100);
        testChar(conn, "testVarChar", 'R', 200);
        testChar(conn, "testVarChar", 'R', 255);

        testChar(conn, "testVarChar", '�', 100);
        testChar(conn, "testVarChar", '�', 200);
        testChar(conn, "testVarChar", '�', 255);

        ps = conn.prepareStatement("DROP TABLE testVarChar");
        ps.execute();
        ps.close();

        ps = conn.prepareStatement("CREATE TABLE testCount (testField int)");
        ps.execute();
        ps.close();

        ps = conn.prepareStatement("INSERT INTO testCount VALUES (?)");
        ps.setInt(1, 1);
        ps.execute();
        ps.setInt(1, 2);
        ps.execute();
        ps.setInt(1, 2);
        ps.execute();
        ps.setInt(1, 3);
        ps.execute();
        ps.setInt(1, 3);
        ps.execute();
        ps.setInt(1, 3);
        ps.execute();
        ps.close();

        ps = conn.prepareStatement("SELECT COUNT(testField) FROM testCount");
        ResultSet rs = ps.executeQuery();
        rs.next();
        if (rs.getInt(1) != 6) {
            error("Wrong COUNT() behaviour");
        }
        rs.close();
        ps.close();

        ps = conn
                .prepareStatement("SELECT COUNT(DISTINCT testField) FROM testCount");
        rs = ps.executeQuery();
        rs.next();
        if (rs.getInt(1) != 3) {
            error("Wrong COUNT(DISTINCT ...) behaviour");
        }
        rs.close();
        ps.close();

        ps = conn.prepareStatement("DROP TABLE testCount");
        ps.execute();
        ps.close();
    }

    private void testChar(Connection conn, String tableName, char someChar,
            int length) throws SQLException {
        PreparedStatement ps = conn.prepareStatement("INSERT INTO " + tableName
                + " VALUES (?)");
        try {
            StringBuffer temp = new StringBuffer();
            for (int i = 0; i < length; i++) {
                temp.append(someChar);
            }

            ps.setString(1, temp.toString());
            ps.execute();
        } catch (Exception exc) {
            error(exc);
        } finally {
            ps.close();
        }
    }
}