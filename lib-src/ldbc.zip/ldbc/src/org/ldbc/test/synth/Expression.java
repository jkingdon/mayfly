package org.ldbc.test.synth;

import java.sql.Types;
import java.util.ArrayList;

public class Expression {
	private boolean isCondition;

	private String sql;

	private Command command;

	public static String[] getRandomSelectList(Command command) {
		Generator gen = Generator.getInstance();
		if (gen.getBoolean(30)) {
			return new String[] { "*" };
		}
		ArrayList exp = new ArrayList();
		String sql = "";
		if (gen.getBoolean(10)) {
			sql += "DISTINCT ";
		}
		int len = gen.getLog(8) + 1;
		for (int i = 0; i < len; i++) {
			sql += getRandomExpression(command).getSQL();
			sql += " AS A" + i + " ";
			exp.add(sql);
			sql = "";
		}
		String[] list = new String[exp.size()];
		exp.toArray(list);
		return list;
	}

	public static Expression getRandomCondition(Command command) {
		Expression condition = new Expression(command, true);
		if (Generator.getInstance().getBoolean(50)) {
			condition.create();
		}
		return condition;
	}

	public static Expression getRandomExpression(Command command) {
		Expression expression = new Expression(command, false);
		String alias = command.getRandomTableAlias();
		Column column = command.getTable(alias).getRandomConditionColumn();
		expression.createExpression(alias, column);
		return expression;
	}

	public static Expression getRandomJoinOn(Command command, String alias) {
		Expression expression = new Expression(command, true);
		expression.createJoinComparison(alias);
		return expression;
	}

	public static String getRandomOrder(Command command) {
		Generator gen = Generator.getInstance();
		int len = gen.getLog(6);
		String sql = "";
		for (int i = 0; i < len; i++) {
			if (i > 0) {
				sql += ", ";
			}
			int max = command.selectList.length;
			int idx = gen.getInt(max);
			// sql += getRandomExpression(command).getSQL();
			if (max > 1 && gen.getBoolean(50)) {
				sql += "A" + idx;
			} else {
				sql += String.valueOf(idx + 1);
			}
			if (gen.getBoolean(50)) {
				if (gen.getBoolean(10)) {
					sql += " ASC";
				} else {
					sql += " DESC";
				}
			}
		}
		return sql;
	}

	public String getSQL() {
		return sql.trim().length() == 0 ? null : sql.trim();
	}

	private Expression(Command command, boolean isCondition) {
		this.isCondition = isCondition;
		this.command = command;
		sql = "";
	}

	private Generator getGenerator() {
		return Generator.getInstance();
	}

	private boolean is(int percent) {
		return getGenerator().getBoolean(percent);
	}

	private void oneOf(String[] list) {
		int i = getGenerator().getInt(list.length);
		if (!sql.endsWith(" ")) {
			sql += " ";
		}
		sql += list[i] + " ";
	}

	private String getColumnName(String alias, Column column) {
		if (alias == null) {
			return column.getName();
		}
		return alias + "." + column.getName();
	}

	private void createJoinComparison(String alias) {
		int len = getGenerator().getLog(5) + 1;
		for (int i = 0; i < len; i++) {
			if (i > 0) {
				sql += "AND ";
			}
			Column column = command.getTable(alias).getRandomConditionColumn();
			sql += getColumnName(alias, column);
			sql += "=";
			String a2;
			do {
				a2 = command.getRandomTableAlias();
			} while (a2.equals(alias));
			Table t2 = command.getTable(a2);
			Column c2 = t2.getRandomColumnOfType(column.getType());
			if (c2 == null) {
				sql += column.getRandomValue().getSQL();
			} else {
				sql += getColumnName(a2, c2);
			}
			sql += " ";
		}
	}

	private void create() {
		createComparison();
		while (is(50)) {
			oneOf(new String[] { "AND", "OR" });
			createComparison();
		}
	}

	private void createSubquery() {
		String alias = command.getRandomTableAlias();
		Table t1 = command.getTable(alias);
		Database db = command.getDatabase();
		Table t2 = db.getRandomTable();
		String a2 = command.getNextTableAlias();
		sql += "SELECT * FROM " + t2.getName() + " " + a2 + " WHERE ";
		command.addSubqueryTable(a2, t2);
		createComparison();
		command.removeSubqueryTable(a2);
	}

	private void createComparison() {
		if (is(5)) {
			sql += " NOT ";
		}
		if (is(10)) {
			sql += " EXISTS(";
			createSubquery();
			sql += ")";
			return;
		} else if (is(10)) {
			sql += "(";
			create();
			sql += ")";
			return;
		}
		String alias = command.getRandomTableAlias();
		Column column = command.getTable(alias).getRandomConditionColumn();
		boolean columnFirst = is(90);
		if (columnFirst) {
			sql += getColumnName(alias, column);
		} else {
			Value v = column.getRandomValue();
			sql += v.getSQL();
		}
		if (is(10)) {
			oneOf(new String[] { "IS NULL", "IS NOT NULL" });
		} else if (is(10)) {
			oneOf(new String[] { "BETWEEN", "NOT BETWEEN" });
			Value v = column.getRandomValue();
			sql += v.getSQL();
			sql += " AND ";
			v = column.getRandomValue();
			sql += v.getSQL();
		} else if (is(10)) {
			oneOf(new String[] { "IN", "NOT IN" });
			sql += "(";
			int len = Generator.getInstance().getInt(5) + 1;
			for (int i = 0; i < len; i++) {
				if (i > 0) {
					sql += ", ";
				}
				sql += column.getRandomValueNotNull().getSQL();
			}
			sql += ")";
		} else {
			if(column.getType()==Types.VARCHAR) {
				oneOf(new String[] { "=", "=", "=", "<", ">", "<=", ">=", "LIKE",
				"NOT LIKE" });
			} else {
				oneOf(new String[] { "=", "=", "=", "<", ">", "<=", ">=" });
			}
			if (columnFirst) {
				Value v = column.getRandomValue();
				sql += v.getSQL();
			} else {
				sql += getColumnName(alias, column);
			}
		}
	}

	public boolean isEmpty() {
		return sql == null || sql.trim().length() == 0;
	}

	void createExpression(String alias, Column type) {
		boolean op = is(20);
		// no null values if there is an operation
		boolean allowNull = !op;
		
		createTerm(alias, type, allowNull);
		if (op) {
			switch (type.getType()) {
			case Types.INTEGER:
			case Types.DECIMAL:
				oneOf(new String[] { "+", "-", "*", "/" });
				createTerm(alias, type, allowNull);
				break;
			case Types.VARCHAR:
				sql += " || ";
				createTerm(alias, type, allowNull);
				break;
			case Types.BLOB:
			case Types.CLOB:
			case Types.DATE:
				break;
			}
		}
	}

	void createTerm(String alias, Column type, boolean allowNull) {
		int dt = type.getType();
		if (is(5) && (dt == Types.INTEGER) || (dt == Types.DECIMAL)) {
			sql += " - ";
			allowNull = false;
		}
		if (is(10)) {
			sql += "(";
			createTerm(alias, type, allowNull);
			sql += ")";
			return;
		}
		if (is(20)) {
			if (is(10)) {
				sql += "CAST(";
				// TODO
				Column c = Column.getRandomColumn();
				createTerm(alias, c, allowNull);
				sql += " AS ";
				sql += type.getTypeName();
				sql += ")";
				return;
			}
			switch (dt) {
			case Types.INTEGER:
				oneOf(new String[] { "LENGTH", "MOD" });
				sql += "(";
				createTerm(alias, type, allowNull);
				sql += ")";
				break;
			case Types.VARCHAR:
				oneOf(new String[] { "LOWER", "UPPER" });
				sql += "(";
				createTerm(alias, type, allowNull);
				sql += ")";
				break;
			case Types.DATE:
				sql += "NOW()";
				break;
			default:
				createTerm(alias, type, allowNull);
			}
			return;
		}
		if (is(60)) {
			String a2 = command.getRandomTableAlias();
			Column column = command.getTable(a2).getRandomColumnOfType(dt);
			if (column != null) {
				sql += getColumnName(a2, column);
				return;
			}
		}

		Value v = Value.getRandom(dt, 20, 2, allowNull);
		sql += v.getSQL();
	}

	public String toString() {
		throw new Error("hey!");
	}

}