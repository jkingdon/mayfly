/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import java.sql.*;

/**
 *
 * Failures:
 *
 * TestDatabaseMetaData
 * TestStatement 
 * TestResultSet 
 * TestGrammar 
 * TestKeywords 
 * TestFunctions 
 *
 * Known issues:
 *
 * DatabaseMetaData.getIndexInfo returns no rows.
 *
 * The escape syntax for strings is not clear. This query fails:
 * INSERT INTO TEST VALUES(1, '\\LDBC\\')
 * Exception in thread "main" com.mckoi.database.jdbc.MSQLException: 
 * Lexical error at line 1, column 30.  Encountered: "L" (76), after : "\'\\"
 *
 * ResultSetMeta.getXXX with column name must do a case insensitive search,
 * however in Mckoi the search is case sensitive. Example:
 * SELECT "VALUE" FROM "TEST"
 * ResultsetMetaData.getString("value"); // fails
 *
 * CREATE TABLE THISMUSTWORK(I INT PRIMARY KEY,THISMUSTWORK INT)
 * SELECT I AS THISMUSTWORK,THISMUSTWORK FROM THISMUSTWORK
 * fails with the exception:
 * com.mckoi.database.jdbc.MSQLException: Ambiguous reference 'THISMUSTWORK'
 *
 * rs=stat.executeQuery("SELECT MOD(10,3) FROM TEST");
 * rs.getString(1) should return "1";
 * but Mckoi returns "1.0"
 *
 * String concatenation with || doesn't work in Mckoi
 * (workaround using STRCAT implemented in the adapter)
 *
 */
public class Mckoi extends Base implements Adapter {
    public static void main(String argv[]) throws Exception {
        Class.forName("com.mckoi.JDBCDriver");
        Connection conn=DriverManager.getConnection("jdbc:mckoi://localhost/","ldbc","ldbc");
        Statement stat=conn.createStatement();
        conn.setAutoCommit(false);
        stat.cancel();
        try {
            stat.execute("DROP TABLE TEST");
        } catch(SQLException e) {
            // exception - ok
        }
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,NAME VARCHAR(255))");
        stat.execute("INSERT INTO TEST VALUES(1, '\\LDBC\\'");
        conn.close();
    }

    // url: jdbc:mckoi://localhost/
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "com.mckoi.JDBCDriver";
    }
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        }
        return getDefaultDataTypeString(type);
    }  
    public void convertDataType(DataType type) throws SQLException {
        int precision=type.getPrecision();
        int scale=type.getScale();
        switch(type.getDataType()) {
        case Types.NUMERIC:
        case Types.DECIMAL:
            if((precision==0 || precision==32) && scale==0) {
                type.update(Types.INTEGER,0,0);
            } else {
                type.update(Types.DECIMAL,precision,scale);
            }
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    public String getStringConcatenation(String a,String b) {
        return "CONCAT("+a+","+b+")";
    }
    public String getNow() throws SQLException {
        return "DATEOB()";
    }
    public void setTransactionIsolation(int level) {
        // only Connection.TRANSACTION_SERIALIZABLE is supported
    }

}

