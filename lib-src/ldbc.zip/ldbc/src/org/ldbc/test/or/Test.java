/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.test.or;

import org.ldbc.or.*;
import java.sql.*;
import java.util.*;

public class Test {

    public static void main(String[] argv) {
        (new Test()).test();
    }

    private Database db;
    private int id;
    private String firstName;
    
    void test() {
        final String CREATE_TEST = "CREATE TABLE Test_Tab("
        + "Id INT AUTOINCREMENT PRIMARY KEY, "
        + "/* firstName */ First_Name VARCHAR(255))";
        final String URL = "jdbc:hsqldb:test";
        // final String URL = "jdbc:hsqldb:test[ldbc.trace=on]";
        Database db = Database.connect(URL, "sa", "");
        //db=Database.connect("jdbc:hsqldb:test[ldbc.trace=on]","sa","");
        try {
            Connection conn = db.getConnection();
            Statement stat = conn.createStatement();
            stat.executeUpdate("DROP TABLE IF EXISTS TEST_TAB");
            stat.executeUpdate("DROP TABLE IF EXISTS GETSET");
        } catch(SQLException e) {
            e.printStackTrace();            
            check(false);
        }
        
        db.map(Test.class, CREATE_TEST);
        db.close();
        db = Database.connect(URL, "sa", "");
        db.map(Test.class, CREATE_TEST);
        
        
        Test o = (Test) db.load(Test.class, 0);
        if (o != null) {
            o.print();
        }
        o = (Test) db.load(Test.class, new Integer(0));
        if (o == null) {
            o = new Test();
            o.firstName = "Joe";
            db.save(o);
        }
        o.print();
        o.firstName += "+";
        o.id += 1;
        db.save(o);
        Command query = db.createCommand(Test.class, "FIRST_NAME LIKE ? ORDER BY ID DESC");
        query.setString("%");
        ArrayList list = query.loadArrayList();
        log("elements: ");
        for (int i = 0; i < list.size(); i++) {
            Test t = (Test)list.get(i);
            t.print();
        }
        db.close();
        
        db = Database.connect(URL, "sa", "");
        db.map(GetSet.class);
        db.map(GetSet.class);
        GetSet gs = new GetSet(db);
        gs.name="Hallo";
        db.save(gs);
        gs.name="Hello";
        db.save(gs);
        
        GetSet gsnull=new GetSet(db);
        gsnull.autoidkey = 0;
        gsnull.name = null;
        db.save(gsnull);
        
        db.close();
        db = Database.connect(URL, "sa", "");
        
        GetSet gs2 = (GetSet)db.load(GetSet.class, gs.autoidkey);
        check(gs.autoidkey == gs2.autoidkey);
        check(gs.name.equals(gs2.name));
        
        Command q = db.createCommand(GetSet.class, "AUTOIDKEY=?");
        q.setInt(1);
        GetSet gs3 = (GetSet)q.load();
        check(gs3.autoidkey == gs.autoidkey);
        check(gs3.name.equals(gs.name));
        q.clearParameters();
        q.setObject(new Integer(1), Types.INTEGER);
        gs3 = (GetSet)q.load();
        check(gs3.autoidkey == gs.autoidkey);
        check(gs3.name.equals(gs.name));
        
        q.clearParameters();
        q.setString("20");
        gs3 = (GetSet)q.load();
        check(gs3==null);
        
        q = db.createCommand(GetSet.class, "NAME='Hello'");
        GetSet gs4 = (GetSet)q.load();
        check(gs4.autoidkey == gs.autoidkey);
        check(gs4.name.equals(gs.name));
        check(gs4.db==db);
        
        list = db.createCommand(GetSet.class, null).loadArrayList();
        check(list.size() == 2);

        list = db.createCommand(GetSet.class, "ORDER BY NAME").loadArrayList();
        check(list.size() == 2);
       
        list = db.createCommand(GetSet.class, "SELECT * FROM GETSET").loadArrayList();
        check(list.size() == 2);
        
        db.delete(gs2);
        db.delete(gs2);
        
        db.close();
    }

    void check(boolean test) {
        if (!test) {
            throw new Error("Error");
         }
    }

    public int getId() {
        return id;
    }
    
    public void foo() {
    }
    
    public void initId(int id) {
        this.id = 1000;
    }
    
    public int getId(int scope) {
        return id + 2000;
    }
    
    public void setId(int scope, int id) {
        this.id = 3000 + id;
    }

    public int getScope() {
        return 4000;
    }
    
    public static String getLastName() {
        return "LastName";
    }
    
    public static void setLastName(String lastName) {
        // do nothing
    }
    
    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    void print() {
        log("id=" + id + " firstName=" + firstName);
    }

    void log(String s) {
        // System.out.println(s);
    }
}
