/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import org.ldbc.jdbc.*;
import java.sql.*;
import java.util.*;
import java.io.*;

public class Factory {
    private static ListResourceBundle MESSAGES=new Messages();
    private static Factory instance;
    private Properties adapterMap=new Properties();
    
    static {
        instance = new Factory();
        String filename = "/org/ldbc/adapter/adapters.properties";
        try {
            InputStream in = Factory.class.getResourceAsStream(filename);
            if(in == null) {
                throw new RuntimeException("Could not read resource "+filename);
            }
            instance.adapterMap.load(in);
        } catch (IOException e) {
            throw new RuntimeException("Error reading resource "+filename+": "+e);
        }
    }
    private Factory() {
    }
    /**
     * Get the adapter for this vendor
     * @param url the jdbc url (example: jdbc:acme:dbname)
     * @return the adapter 
     */
    public static Adapter getAdapter(String url) throws SQLException {
        int i1=url.indexOf(':')+1;
        int i2=url.indexOf(':',i1+1);
        url=url.substring(i1,i2);String adapterClass=(String)instance.adapterMap.get(url);
        if(adapterClass==null) {
            throw getSQLException(Messages.DRIVER_NOT_FOUND,url);
        }
        Adapter adapter;
        try {
            adapter=(Adapter)Class.forName(adapterClass).newInstance();
            return adapter;
        } catch(Exception e) {
            throw getSQLException(Messages.DRIVER_NOT_FOUND,adapterClass);
        }
    }
    /**
     * Gets the SQL Exception object for a specific SQLState.
     * Supported sqlstates are:
     *
     * @param sqlstate - the SQL State
     * @param param - the parameter of the message
     * @return the SQLException object
     */
    public static SQLException getSQLException(String sqlstate,String param) {
        return getSQLException(sqlstate,param,null);
    }
    public static SQLException getSQLException(String sqlstate,String param,Throwable th) {
        String message;
        try {
            message=MESSAGES.getString(sqlstate);
        } catch(MissingResourceException e) {
            message="Resource not found: "+sqlstate;
        }
        if(param!=null) {
            message+=": "+param;
        }
        return new jdbcSQLException(message,sqlstate,th);
    }
    /**
     * Gets the SQL Exception object for a specific SQLState.
     *
     * @param sqlstate - the SQL State
     * @return the SQLException object
     */
    public static SQLException getSQLException(String sqlstate) {
        return getSQLException(sqlstate,null);
    }
    public static SQLException getUnsupportedException() {
        return getSQLException(Messages.FEATURE_NOT_SUPPORTED);
    }
    public static SQLException getGeneralException(String param) {
        return getSQLException(Messages.GENERAL_ERROR,param);
    }
    public static SQLException getInvalidValueException(String param) {
        return getSQLException(Messages.INVALID_VALUE,param);
    }
    public static SQLException getClosedException() {
        return getSQLException(Messages.OBJECT_CLOSED);
    }
    
    /**
     * Checks if a SQL statement is legal or not
     *
     * @throws SQLException if the syntax is not valid
     */
    /*
    public static void checkStatement(String sql) throws SQLException {
        try {
            StringReader in=new StringReader(sql);
            SQLLexer lexer=new SQLLexer(in);
            SQLParser parser=new SQLParser(lexer);
            parser.statement();
        } catch(Throwable e) {
            throw getSQLException(Messages.SYNTAX_ERROR,sql+" "+e.toString());
        }
    }
    */
}