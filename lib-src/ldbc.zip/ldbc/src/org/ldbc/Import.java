/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc;

import java.io.*;
import java.sql.*;
import java.math.*;

public class Import {

    public static void main(String[] argv) {
        try {
            (new Import()).run(argv);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    Import() {
    }

    /**
     * Create a new Import tool with the specified connection and reader.
     */
    public Import(Connection conn, LineNumberReader reader) {
        this.conn = conn;
        this.reader = reader;
    }

    Connection conn;

    LineNumberReader reader;

    void run(String[] a) throws Exception {
        if (a.length == 0) {
            showUsage();
            return;
        }
        Class.forName("org.ldbc.jdbc.jdbcDriver");
        String url = "";
        String user = "";
        String password = "";
        String filename = "import.txt";
        for (int i = 0; i < a.length; i++) {
            String s = a[i];
            if (s.equals("-url")) {
                url = a[++i];
                if (url.startsWith("jdbc:ldbc:")) {
                    // url is already correct
                } else if (url.startsWith("jdbc:")) {
                    // jdbc:<vendor> is converted to jdbc:ldbc:<vendor>
                    url = "jdbc:ldbc:" + url.substring("jdbc:".length());
                } else {
                    url = "jdbc:ldbc:" + url;
                }
            } else if (s.equals("-user")) {
                user = a[++i];
            } else if (s.equals("-password")) {
                password = a[++i];
            } else if (s.equals("-file")) {
                filename = a[++i];
            }
        }
        conn = DriverManager.getConnection(url, user, password);
        reader = new LineNumberReader(new BufferedReader(new FileReader(
                filename)));
        importFile();
        reader.close();
    }

    /**
     * Import all data from the reader to the connection. The connection and
     * the reader are not closed afterwards.
     */
    public void importFile() throws Exception {
        String command = null;
        PreparedStatement prep = null;
        Statement stat = conn.createStatement();
        while (true) {
            String s = reader.readLine();
            if (s == null) {
                break;
            }
            s = s.trim();
            if (s.startsWith("--") || s.length() == 0) {
                continue;
            }
            char last = s.charAt(s.length() - 1);
            if (command == null) {
                command = s;
            } else {
                command += " " + s;
            }
            if (last != ';' && last != '{' && last != '}') {
                continue;
            }
            if (last == ';') {
                command = command.substring(0, command.length() - 1);
                if (prep == null) {
                    stat.execute(command);
                } else {
                    prepare(prep, command);
                    prep.execute();
                }
            } else if (last == '{') {
                command = command.substring(0, command.length() - 1);
                if (prep != null) {
                    throw new Exception(
                            "nested prepared statements are not allowed");
                }
                prep = conn.prepareStatement(command);
            } else if (last == '}') {
                if (command.length() != 1) {
                    throw new Exception("'}' must be on it's own line");
                }
                prep = null;
            }
            command = null;
        }
    }

    void prepare(PreparedStatement prep, String line) throws Exception {
        int index = 1;
        while (line.length() > 0) {
            char c = Character.toUpperCase(line.charAt(0));
            StringBuffer buffer = new StringBuffer();
            if (c == '-' || c == '.' || c >= '0' && c <= '9') {
                int i = 1;
                while (true) {
                    buffer.append(c);
                    if (i >= line.length()) {
                        break;
                    }
                    c = line.charAt(i);
                    if (c != '-' && c != '.' && (c < '0' || c > '9')) {
                        break;
                    }
                    i++;
                }
                String s = buffer.toString();
                BigDecimal bd;
                try {
                    bd = new BigDecimal(s);
                } catch (Throwable e) {
                    throw new Exception("Can't parse decimal: <" + s + ">");
                }
                prep.setBigDecimal(index, bd);
                line = line.substring(i);
            } else if (c == ',') {
                index++;
                line = line.substring(1);
            } else if (c == '"') {
                line = line.substring(1);
                line = parseString(line, buffer);
                String s = buffer.toString();
                prep.setString(index, s);
            } else if (c == 'X') {
                line = consume(line, "X'");
                int i = 0;
                while (true) {
                    if (i >= line.length()) {
                        throw new Exception(
                                "Unexpected end of line parsing binary at: "
                                        + line);
                    }
                    c = line.charAt(i++);
                    if (c == '\'') {
                        break;
                    }
                    buffer.append(c);
                }
                byte[] bytes = convertToBytes(buffer.toString());
                prep.setBytes(index, bytes);
                line = line.substring(i);
            } else if (c == 'N') {
                line = consume(line, "NULL");
                int i = 0;
                while (true) {
                    if (i >= line.length()) {
                        break;
                    }
                    c = line.charAt(i);
                    if (!Character.isLetter(c)) {
                        break;
                    }
                    buffer.append(c);
                    i++;
                }
                String s = buffer.toString();
                int datatype = getDataType(s);
                prep.setNull(index, datatype);
                line = line.substring(i);
            } else if (c == 'T') {
                line = consume(line, "TIMESTAMP");
                line = consume(line, "'");
                int i = 0;
                while (true) {
                    if (i >= line.length()) {
                        throw new Exception(
                                "Unexpected end of line parsing timestamp at: "
                                        + line);
                    }
                    c = line.charAt(i++);
                    if (c == '\'') {
                        break;
                    }
                    buffer.append(c);
                }
                String s = buffer.toString();
                Timestamp ts;
                try {
                    ts = Timestamp.valueOf(s);
                } catch (Throwable e) {
                    throw new Exception("Can't parse timestamp: <" + s + ">");
                }
                prep.setTimestamp(index, ts);
                line = line.substring(i);
            } else {
                throw new Exception("Unexpected token at: " + line);
            }
        }
    }

    String consume(String line, String expected) throws Exception {
        String got = line.substring(0, expected.length()).toUpperCase();
        expected = expected.toUpperCase();
        if (!got.equals(expected)) {
            throw new Exception("Expected '" + expected + "' but got: " + got
                    + " at:" + line);
        }
        return line.substring(expected.length()).trim();
    }

    int getDataType(String typename) throws Exception {
        if (typename == null) {
            throw new Exception("Unknown data type ''");
        }
        typename = typename.toUpperCase();
        if (typename.equals("INTEGER")) {
            return Types.INTEGER;
        } else if (typename.equals("DECIMAL")) {
            return Types.DECIMAL;
        } else if (typename.equals("CLOB")) {
            return Types.CLOB;
        } else if (typename.equals("VARCHAR")) {
            return Types.DECIMAL;
        } else if (typename.equals("TIMESTAMP")) {
            return Types.TIMESTAMP;
        } else if (typename.equals("BLOB")) {
            return Types.BLOB;
        }
        throw new Exception("Unknown data type " + typename);
    }

    String parseString(String line, StringBuffer target) throws Exception {
        int i = 0;
        while (true) {
            if (line.length() <= i) {
                throw new Exception("Unexpected end of line in string: " + line);
            }
            char c = line.charAt(i++);
            if (c == '\"') {
                break;
            } else if (c == '\\') {
                if (line.length() <= i) {
                    throw new Exception(
                            "Unexpected end of line in escape processing: "
                                    + line);
                }
                c = line.charAt(i++);
                switch (c) {
                case '\\':
                case '\'':
                case '\"':
                    break;
                case 'b':
                    c = 0x8;
                    break;
                case 'f':
                    c = 0xc;
                    break;
                case 'n':
                    c = 0xa;
                    break;
                case 'r':
                    c = 0xd;
                    break;
                case 't':
                    c = 0x9;
                    break;
                case 'u':
                    if (line.length() <= i + 4) {
                        throw new Exception(
                                "Unexpected end of line in unicode escape processing: "
                                        + line);
                    }
                    String hex = line.substring(i, i += 4);
                    c = (char) Integer.parseInt(hex, 16);
                    break;
                default:
                    throw new Exception("Invalid escape sequence: \\" + c
                            + "in line: " + line);
                }
            }
            target.append(c);
        }
        return line.substring(i);
    }

    byte[] convertToBytes(String hex) throws Exception {
        int len = hex.length();
        if ((len % 2) != 0) {
            throw new Exception("Odd length for hex string not allowed: len="
                    + len + " hex=" + hex);
        }
        byte bytes[] = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            byte b = (byte) (Integer.parseInt(hex.substring(i, i + 2), 16));
            bytes[i / 2] = b;
        }
        return bytes;
    }

    void showUsage() {
        String className = getClass().getName();
        System.out
                .println("Usage: java "
                        + className
                        + " [options]\n"
                        + "Options:\n"
                        + "-url <url>       database url without the starting 'jdbc:ldbc:'\n"
                        + "-user <user>     user name (default: empty string)\n"
                        + "-password <pwd>  password (default: empty string)\n"
                        + "-file <filename> specify import file name (default: import.sql)\n"
                        + "Example: java " + className
                        + " -url hsqldb:sample -user sa -password sa");
    }

}
