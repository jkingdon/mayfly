/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import java.sql.*;

/** 
 * Represents the meta data for a ResultSet.
 */
public class jdbcResultSetMetaData implements ResultSetMetaData {
    static int counter;
    int id=counter++;
    jdbcResultSet rs;
    Adapter adapter;
    ResultSetMetaData meta;

    /**
     * Returns the number of columns.
     *
     * @return the number of columns
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int getColumnCount() throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            rs.checkClosed();
            int count=rs.columnCount;
            if(Trace.isEnabled()) Trace.traceResult(count);
            return count;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the column label.
     *
     * @param column the column index (1,2,...)
     * @return the column label
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getColumnLabel(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            String result=meta.getColumnLabel(column);
            if(Trace.isEnabled()) Trace.traceResultQuote(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the column name.
     *
     * @param column the column index (1,2,...)
     * @return the column name 
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getColumnName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            String result=meta.getColumnName(column);
            if(Trace.isEnabled()) Trace.traceResultQuote(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the data type of a column.
     *
     * @param column the column index (1,2,...)
     * @return the data type 
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int getColumnType(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            int result=rs.dataTypes[column-1].getDataType();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the data type name of a column.
     *
     * @param column the column index (1,2,...)
     * @return the data type 
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getColumnTypeName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // getColumnType already calls checkClosed
            int type=getColumnType(column);
            String result=DataType.getDataTypeString(type);
            if(Trace.isEnabled()) Trace.traceResultQuote(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the schema name. 
     * This methods always returns an empty String.
     *
     * @return ""
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getSchemaName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return "";
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the table name. 
     * This methods always returns an empty String.
     *
     * @return ""
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getTableName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return "";
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the catalog name. 
     * This methods always returns an empty String.
     *
     * @return ""
     * @throws SQLException if the resultset is closed or invalid 
     */
	public String getCatalogName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return "";
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this an autoincrement column.
     * It always returns false.
     *
     * @return false
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isAutoIncrement(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this column is case sensitive.
     * It always returns true.
     *
     * @return true
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isCaseSensitive(int column) throws SQLException {	
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this column is searchable.
     * It always returns true.
     *
     * @return true
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isSearchable(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this is a currency column.
     * It always returns false.
     *
     * @return false
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isCurrency(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this is a currency column.
     * It always returns ResultSetMetaData.columnNullableUnknown.
     *
     * @return ResultSetMetaData.columnNullableUnknown
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int isNullable(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return ResultSetMetaData.columnNullableUnknown;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this column is signed.
     * It always returns true.
     *
     * @return true
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isSigned(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if this column is read only.
     * It always returns false.
     *
     * @return false
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isReadOnly(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks whether it is possible for a write on this column to succeed.
     * It always returns true.
     *
     * @return true
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isWritable(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks whether a write on this column will definitely succeed.
     * It always returns false.
     *
     * @return false
     * @throws SQLException if the resultset is closed or invalid 
     */
	public boolean isDefinitelyWritable(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return false;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the Java class name of the object that will be returned
     * if ResultSet.getObject is called.
     * One of the following values is returned:
     * 
     * <ul>
     * <li>java.lang.Integer
     * <li>java.lang.String
     * <li>java.math.BigDecimal
     * <li>java.sql.Timestamp
     * <li>java.lang.Short
     * <li>java.lang.Boolean
     * </ul>
     *
     * @return the Java class name
     * @throws SQLException if the resultset is closed or invalid 
     */
    public String getColumnClassName(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // getColumnType already calls checkClosed
            int type=getColumnType(column);
            String result="";
            switch(type) {
            case Types.INTEGER:
                result=Integer.class.getClass().getName();
            case Types.VARCHAR:
                result=String.class.getClass().getName();
            case Types.DECIMAL:
                result=java.math.BigDecimal.class.getClass().getName();
            case Types.TIMESTAMP:
                result=java.sql.Timestamp.class.getClass().getName();
            case Types.SMALLINT:
                result=java.lang.Short.class.getClass().getName();
            case Types.BIT:
                result=java.lang.Boolean.class.getClass().getName();
            }
             if(Trace.isEnabled()) Trace.traceResultQuote(result);
             return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the precision for this column.
     * This method always returns 0.
     *
     * @return 0
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int getPrecision(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return 0; 
            /*
            mRs.checkColumnIndex(column);
            return mRs.mDataTypes[column-1].getPrecision();
            */
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the scale for this column.
     * This method always returns 0.
     *
     * @return 0
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int getScale(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId(),column);
            // checkColumnIndex already calls checkClosed
            rs.checkColumnIndex(column);
            return 0; 
            /*
            mRs.checkColumnIndex(column);
            return mRs.mDataTypes[column-1].getScale();
            */
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the maximum display size for this column.
     *
     * As the precision and scale is not known, the values returned
     * are fixed depending on the data type:
     *
     * <ul>
     * <li>Types.VARCHAR: 255
     * <li>Types.DEICMAL: 40
     * <li>everything else: 10
     * </ul>
     *
     * @return the display size
     * @throws SQLException if the resultset is closed or invalid 
     */
	public int getColumnDisplaySize(int column) throws SQLException {
        try {
            if(Trace.isDetailed()) Trace.trace(getId());
            // getColumnType already calls checkClosed
            int type=getColumnType(column);
            int result=10;
            switch(type) {
            case Types.VARCHAR:
                result=255;
            case Types.DECIMAL:
                result=40;
            }
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    
    /**
     * Gets the underlying resultset metadata object.
     * This method should only be called if functionality is required
     * that is not yet implemented in LDBC, or for testing.
     *
     * @return the underlying ResultSetMetaData object
     */
    public ResultSetMetaData getVendorObject() {
        return meta;
    }
    
    jdbcResultSetMetaData(jdbcResultSet rs,ResultSetMetaData meta) {
        this.meta=meta;
        this.rs=rs;
        this.adapter=rs.adapter;
    }
    String getId() {
        return "meta"+id;
    }
    SQLException convertThrowable(Throwable e) {
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
}
