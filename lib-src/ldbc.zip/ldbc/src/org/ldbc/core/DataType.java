/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.sql.*;

/** 
 * Represents a data type including size.
 * May be an 'invalid' type - whatever is returned by 
 * database or resultset meta data.
 * The adapters can convert it to a 'correct' data type
 */
public class DataType {
    final static int DEFAULT=-1;
    String typeName;
    int dataType;
    int precision;
    int scale;
    
    public DataType(String typeName,int dataType,int precision,int scale) {
        this.typeName=typeName;
        this.dataType=dataType;
        this.precision=precision;
        this.scale=scale;
    }
    public String getTypeName() {
        return typeName;
    }
    public int getDataType() {
        return dataType;
    }
    public int getPrecision() {
        return precision;
    }
    public int getScale() {
        return scale;
    }
    public void update(int dataType,int precision,int scale) throws SQLException {
        this.dataType=dataType;
        typeName=getDataTypeString(dataType);
        switch(dataType) {
        case Types.NULL:
        case Types.CLOB:
        case Types.BLOB:
        case Types.INTEGER:
        case Types.TIMESTAMP:
            precision=scale=DEFAULT;
            break;
        case Types.VARCHAR:
            scale=DEFAULT;
            break;
        case Types.DECIMAL:
            break;
        default:
            throw Factory.getGeneralException("datatype:"+dataType);
        }
        if(precision==DEFAULT) {
            precision=getDefaultPrecision(dataType);
        }
        if(scale==DEFAULT) {
            scale=getDefaultScale(dataType);
        }
        this.precision=precision;
        this.scale=scale;
    }
    public static int getDefaultPrecision(int datatype) throws SQLException {
        switch(datatype) {
        case Types.NULL:
            return 0;
        case Types.INTEGER:
            return 9;
        case Types.VARCHAR:
            return 255;
        case Types.DECIMAL:
            return 20;
        case Types.TIMESTAMP:
            return 0;
        case Types.BLOB:
        case Types.CLOB:
            return 1000000000;
        case Types.SMALLINT:
            return 4;
        case Types.BIT:
            return 0;
        default:
            throw Factory.getGeneralException("datatype:"+datatype);
        }
    }
    public static int getDefaultScale(int datatype) throws SQLException {
        switch(datatype) {
        case Types.NULL:
        case Types.TIMESTAMP:
        case Types.INTEGER:
        case Types.VARCHAR:
        case Types.BLOB:
        case Types.CLOB:
        case Types.SMALLINT:
        case Types.BIT:
            return 0;
        case Types.DECIMAL:
            return 2;
        default:
            throw Factory.getGeneralException("datatype:"+datatype);
        }
    }
    public static String getDataTypeString(int datatype) throws SQLException {
        switch(datatype) {
        case Types.NULL:
            return "NULL";
        case Types.INTEGER:
            return "INTEGER";
        case Types.VARCHAR:
            return "VARCHAR";
        case Types.DECIMAL:
            return "DECIMAL";
        case Types.TIMESTAMP:
            return "DATETIME";
        case Types.BLOB:
            return "BLOB";
        case Types.CLOB:
            return "CLOB";
        // required for DatabaseMetaData
        case Types.SMALLINT:
            return "SMALLINT";
        case Types.BIT:
            return "BIT";
        default:
            throw Factory.getGeneralException("datatype:"+datatype);
        }
    }
}

