/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import org.ldbc.jdbc.*;
import java.sql.*;
import java.io.*;
import java.util.*;
import java.lang.reflect.*;

/**
 *
 * Link for docs:
 * http://otn.oracle.com/doc/oracle8i_816/mix.816/a76991/toc.htm
 * Oracle Thin driver CLOB/BLOB problem
 * http://castor.exolab.org/list-archive/msg06802.html
 * Oracle JDBC driver readme:
 * Known Problems/Limitations In This Release
 * There is a limitation regarding the use of stream input for LOB types....
 *
 * Known issues:
 *
 * DatabaseMetaData.getTables returns system tables as well 
 * DUAL
 * HELP
 * DEF$_TEMP$LOB
 * TABLE_PRIVILEGE_MAP
 * SYSTEM_PRIVILEGE_MAP
 * STMT_AUDIT_OPTION_MAP
 * PSTUBTBL
 * AUDIT_ACTIONS
 * MTS_PROXY_INFO
 * OGIS_SPATIAL_REFERENCE_SYSTEMS
 * MD$DICTVER
 * CS_SRS
 * as data tables (table type "TABLE"). Currently filtering out
 * the tables using the user name as the schema name for all DatabaseMetaData calls.
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getTables:
 * column TABLE_REMARKS has the wrong name, it must be called REMARKS according 
 * to the specs.
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getColumns:
 * The driver doesn't return INTEGER data type, instead it returns 3 ("NUMBER") 
 * with column precision of 22 and scale 0.
 * (workaround implemented in the JDBC driver)
 *
 * DatabaseMetaData.getTables (probably also getColumns):
 * Wildcards are not pocessed correctly, search for table T\\_2 doesnt return table T_2
 * (workaround implemented in the JDBC driver)
 *
 * In Oracle, an empty String is the same as NULL.
 * Example: SELECT '' FROM DUAL results in NULL
 *
 * Oracle doesn't support TIME and TIMESTAMP data types. Only DATE is supported,
 * and precision is only up to one second.
 *
 * ResultSet.getObject returns objects of the wrong type.
 * getObject on INT returns BigDecimal
 *
 * Statement and PreparedStatement getUpdateCount are supposed to return -1 after 
 * getMoreResults is called.
 * See JDBC API Tutorial and Reference, Second Edition, page 839, getUpdateCount.
 * Oracle returns 0.
 *
 * PreparedStatement.setObject(parameterIndex,x,targetSqlType) is supposed to
 * convert the SQL type if required.
 * See JDBC API Tutorial and Reference, Second Edition, page 562 and 563, Examples.
 * Oracle throws a java.lang.ClassCastException: java.lang.Integer
 * when calling prep.setObject(2,new Integer(-4),Types.VARCHAR);
 *
 * prep.setObject(2,null,Types.INTEGER);
 * throws a NullPointerException
 *  
 * DatabaseMetaData.getSQLKeyword resports a keyword called
 * 'ALL_PL_SQL_RESERVED_ WORDS' (with a space)
 *
 * DatabaseMetaData.getSearchStringEscape() returns // (2 characters)
 * All other database return \
 *
 * The LIKE escape character can only be used to escape \ or %, not any other character.
 * CREATE TABLE TEST(ID INT)
 * SELECT * FROM TEST WHERE 'X' LIKE '\X' ESCAPE '\'
 * Throws an exception:
 * ORA-01424: missing or illegal character following the escape character
 * All other database have no problem with this.
 *
 * Oracle 8.1 doesn't support the ANSI standard outer and inner join syntax, such as
 * SELECT * FROM TEST T1 INNER JOIN TEST T2 ON T1.ID=T2.ID WHERE T1.ID=1
 * SELECT * FROM TEST T1 LEFT OUTER JOIN TEST T2 ON T1.ID=T2.ID WHERE T1.ID=1 
 * Oracle 9i is required for this
 * (currently no workaround implemented for Oracle 8i)
 *
 * ResultSet.setFetchSize(100) after Statement.setMaxRows(50) should throw
 * an exception, but doesn't.
 *
 * JDBC Driver for Oracle 9i doesn't work with Oracle 8i databases if {ts ...} is used.
 * The 9i driver converts this to 
 * TO_TIMESTAMP ('2011-11-11 00:00:00.0', 'YYYY-MM-DD HH24:MI:SS.FF')
 * which is a method not available in 8i.
 * The 8i driver converts it to
 * TO_DATE ('2011-11-11 00:00:00', 'YYYY-MM-DD HH24:MI:SS')
 *
 * PreparedStatement.getMetaData() throws an exception:
 * java.sql.SQLException: ORA-01003: no statement parsed
 * It should return null because the driver cannot return a ResultSetMetaData object
 * (see JDBC API Tutorial an Reference, Second Edition, page 552, 
 * PreparedStatement.getMetaData())
 *
 * Oracle only supports
 * Connection.TRANSACTION_READ_COMMITTED and
 * Connection.TRANSACTION_SERIALIZABLE.
 *
 * If other methods than commit() or rollback() are called before 
 * Connection.setTransactionIsolation(int level), then 
 * the following exception is throws:
 * java.sql.SQLException: ORA-01453: 
 * SET TRANSACTION must be first statement of transaction
 * This is not standard JDBC behavior.  
 *
 * Statement.cancel will cancel the _next_ statement that is executed against
 * the database. It should only cancel the currently executed statement. 
 *
 * Both 8i and 9i do not support batch updated corrrectly.
 * The update counts returned are not valid (they contain -2 instead of the update count).
 *  
 * ResultSetMetaData.getPrecision on a BLOB column throws a exception:
 * java.lang.NumberFormatException: 4294967295
 *    at java.lang.Integer.parseInt(Integer.java:426)
 *    at java.lang.Integer.parseInt(Integer.java:463)
 *    at oracle.jdbc.driver.OracleResultSetMetaData.getPrecision(OracleResultSetMetaData.java:331)
 *
 * ResultSet.getBytes returns for some reason (?) 86 bytes instead of 4 bytes after this statements:
 * CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE BLOB)
 * INSERT INTO TEST VALUES(1,HEXTORAW('01010101'))
 * SELECT VALUE FROM TEST ORDER BY ID 
 * However, ResultSet.getBinaryStream works
 *
 * PreparedStatement.setBinaryStream works only with up to 4000 bytes.
 * This is true for both Oracle 8i and 9i, using the Thin driver.
 *
 * Oracle doesn't support ResultSet.getString on a CLOB.
 * getString returns null.
 * This conversion is required according to the 
 * JDBC API Tutorial an Reference, Second Edition, page 935,
 * 47.9.6, Conversions by ResultSet.getXXX Methods).
 *
 * It seems that every Statement object has one ResultSet object, and this
 * ResultSet object is re-used. This can lead to problems.
 *
 * DatabaseMetaData.getImportedKeys, getExportedKeys and getCrossReference
 * return the wrong data type for many columns. 
 * 
 * ALTER TABLE ... ADD COLUMN ... has a strange syntax: COLUMN is not necessary (and not allowed)
 */
public class Oracle extends Base implements Adapter {
    // url: jdbc:oracle:thin:@localhost:1521:orcl
    protected boolean isOracle9i;
    protected boolean supportsAnsiJoinSyntax;
    protected String defaultSchema;
    private final int MAX_CHAR2CLOB_BUFFER = 1024;
    
    public String getName() {
        return getClass().getName();
    }
    
    public String getDriverClass() {
        return "oracle.jdbc.driver.OracleDriver";
    }
    
    public void init() throws SQLException {
        DatabaseMetaData meta=nativeConn.getMetaData();
        defaultSchema=meta.getUserName();
        String version=meta.getDatabaseProductVersion();
        // todo: if Oracle 10 is available, add it here
        if(version.startsWith("Oracle9i")) {
            isOracle9i=true;
            supportsAnsiJoinSyntax=true;
        } else {
            isOracle9i=false;
            supportsAnsiJoinSyntax=false;
        }
    }
    
    public String getDefaultSchema() throws SQLException {
        return defaultSchema;
    }
    
    public void convertDataType(DataType type) throws SQLException {
        int precision=type.getPrecision();
        int scale=type.getScale();
        String typename=type.getTypeName();
        switch(type.getDataType()) {
        case Types.DATE:
            type.update(Types.TIMESTAMP,0,0);
            break;
        case Types.OTHER:
            if(typename.equals("BLOB")) {
                type.update(Types.BLOB,precision,scale);
            } if(typename.equals("CLOB")) {
                type.update(Types.CLOB,precision,scale);
            }
            break;
        case Types.DECIMAL:
            if(typename.equals("NUMBER")) {
                if(precision==22 && scale==0) {
                    type.update(Types.INTEGER,0,0);
                }
            }
            break;
        case Types.NUMERIC:
            // ResultSetMetaData returns this...
            // CREATE TABLE TEST(ID INT)
            // precision==22 example: SELECT ID FROM TEST
            // precision==0 example: SELECT CAST(ID AS INTEGER) FROM TEST
            if((precision==38 && scale==0) || (precision==0 && scale==0)) {
                type.update(Types.INTEGER,0,0);
            } else {
                type.update(Types.DECIMAL,precision,scale);
            }
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.TIMESTAMP:
            return "DATE";
        case Types.VARCHAR:
            return "VARCHAR(" + type.getPrecision() + " CHAR)";            
        }
        return getDefaultDataTypeString(type);
    }
    
    public String getBinaryConstant(String s) {
        return "HEXTORAW('"+s+"')";
    }
    
    public String getNow() throws SQLException {
        return "SYSDATE";
    }
    
    public String getDateConstant(String s) {
        s=java.sql.Date.valueOf(s).toString();
        return "TO_DATE('"+s+" 00:00:00', 'YYYY-MM-DD HH24:MI:SS')";
    }
    
    public String getTimestampConstant(String s) {
        s=java.sql.Timestamp.valueOf(s).toString();
        int i=s.indexOf('.');
        if(i!=-1) {
            s=s.substring(0,i);
        }
        return "TO_DATE('"+s+"', 'YYYY-MM-DD HH24:MI:SS')";
    }
    public String getDefaultLikeEscape() {
        // escape '\'
        return "ESCAPE '\\'";
    }
    public boolean supportsAnsiJoinSyntax() {
        return supportsAnsiJoinSyntax;
    }
    public void cancel(Statement stat) {
        // Statement.cancel will cancel the _next_ statement that is executed against
        // the database. It should only cancel the currently executed statement.
        // because of this, the method can not be supported
        // stat.cancel();
    }
    public byte[] getBytes(ResultSet rs,int columnIndex) throws SQLException {
        InputStream in=rs.getBinaryStream(columnIndex);
        if(in==null) {
            return null;
        }
        ByteArrayOutputStream out=new ByteArrayOutputStream(); 
        try {
            while(true) {
                int b=in.read();
                if(b==-1) {
                    break;
                }
                out.write(b);
            }
            return out.toByteArray();
        } catch(IOException e) {
            throw convertThrowable(e);
        }
    }
    public String getClobString(ResultSet rs,int columnIndex) throws SQLException {
        Reader reader=rs.getCharacterStream(columnIndex);
        if(reader==null) {
            return null;
        }
        StringBuffer buffer=new StringBuffer();
        try {
            while(true) {
                int c=reader.read();
                if(c==-1) {
                    break;
                }
                buffer.append((char)c);
            }
            return buffer.toString();
        } catch(IOException e) {
            throw convertThrowable(e);
        }
    }
    public void setBytes(jdbcPreparedStatement prep,int parameterIndex, byte[] x) throws SQLException {
        if(x==null || x.length<4000) {
            prep.getVendorObject().setBytes(prep.translateParameterIndex(parameterIndex),x);
        } else {
            setBinaryStream(prep,parameterIndex,new ByteArrayInputStream(x),x.length);
        }
    }
    synchronized public void setBinaryStream(jdbcPreparedStatement prep,int parameterIndex, InputStream x, int length) throws SQLException {
        if(x==null) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.CLOB);
            return;
        }
        Connection conn=nativeConn;
        Statement stat=conn.createStatement();
        createTempLobTable(conn);
        try {        
            ResultSet rsLockAll=stat.executeQuery("SELECT ID FROM LDBC$LOB ORDER BY ID DESC FOR UPDATE");
            int id;
            if(rsLockAll.next()) {
                id=rsLockAll.getInt(1)+1;
            } else {
                id=0;
            }
            stat.executeUpdate("INSERT INTO LDBC$LOB VALUES("+id+",EMPTY_BLOB(),NULL)");
            ResultSet rs=stat.executeQuery("SELECT B FROM LDBC$LOB WHERE ID="+id+" FOR UPDATE");
            rsLockAll.close();
            rs.next();
            
            // oracle.sql.BLOB lob=((oracle.jdbc.OracleResultSet)rs).getBLOB(1);
            Blob lob = (Blob)callMethod(rs, "getBLOB", 
                new Class[]{int.class}, 
                new Object[]{new Integer(1)}
            );
            // OutputStream out=lob.getBinaryOutputStream();
            OutputStream out=(OutputStream)callMethod(lob, "getBinaryOutputStream", null, null);
            
            byte[] buffer=new byte[10*1024];
            int remaining=length;
            while(true) {
                //int max=Math.max(buffer.length,remaining);
                int max=buffer.length;
                int len=x.read(buffer,0,max);
                if(len==-1) {
                    break;
                }
                remaining-=len;
                out.write(buffer,0,len);
            }
            out.close();
            prep.getVendorObject().setBlob(prep.translateParameterIndex(parameterIndex),lob);
            Vector openResultSets=prep.getOpenResultSets();
            if(openResultSets.size()<parameterIndex+1) {
                openResultSets.setSize(parameterIndex+1);
            }
            openResultSets.set(parameterIndex,rs);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }

    public void setString(jdbcPreparedStatement prep,int parameterIndex,String x) throws SQLException {
        boolean needStream = false;
        if (x != null) {
            if (x.length() >= 4000) {
                needStream = true;
            } else {
                try {
                    needStream = x.getBytes("utf-8").length >= 4000;
                } catch (UnsupportedEncodingException exc) {
                    needStream = true;
                }
            }
        }
        if(needStream) {
            setCharacterStream(prep,parameterIndex,new StringReader(x),x.length());
        } else {
            prep.getVendorObject().setString(prep.translateParameterIndex(parameterIndex),x);
        }
    }
    
    public void setAsciiStream(jdbcPreparedStatement prep,int parameterIndex,InputStream x,int length) throws SQLException {
        if(x==null) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.CLOB);
            return;
        }
        StringBuffer buffer=new StringBuffer();
        try {
            for(int i=0;i<length;i++) {
                int c=x.read();
                if(c==-1) {
                    throw Factory.getGeneralException("stream is closed at i:"+i+" length:"+length);
                }
                buffer.append((char)c);
            }
            setString(prep,parameterIndex,buffer.toString());
        } catch(IOException e) {
            throw convertThrowable(e);
        }
    }
    synchronized public void setCharacterStream(jdbcPreparedStatement prep,int parameterIndex,Reader x,int length) throws SQLException {
        if(x==null) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.CLOB);
            return;
        }
        Connection conn=nativeConn;
        Statement stat=conn.createStatement();
        createTempLobTable(conn);
        try {        
            ResultSet rsLockAll=stat.executeQuery("SELECT ID FROM LDBC$LOB ORDER BY ID DESC FOR UPDATE");
            int id;
            if(rsLockAll.next()) {
                id=rsLockAll.getInt(1)+1;
            } else {
                id=0;
            }
            stat.executeUpdate("INSERT INTO LDBC$LOB VALUES("+id+",NULL,EMPTY_CLOB())");
            ResultSet rs=stat.executeQuery("SELECT C FROM LDBC$LOB WHERE ID="+id+" FOR UPDATE");
            rsLockAll.close();
            rs.next();

            // oracle.sql.CLOB lob=((oracle.jdbc.OracleResultSet)rs).getCLOB(1);
            Clob lob = (Clob)callMethod(rs, "getCLOB", 
                new Class[]{int.class}, 
                new Object[]{new Integer(1)}
            );
            // Writer out=lob.getCharacterOutputStream();
            Writer out=(Writer)callMethod(lob, "getCharacterOutputStream", null, null);

            char[] buffer=new char[MAX_CHAR2CLOB_BUFFER];
            int remaining=length;
            while(true) {
                //int max=Math.max(buffer.length,remaining);
                int max=buffer.length;
                int len=x.read(buffer,0,max);
                if(len==-1) {
                    break;
                }
                remaining-=len;
                out.write(buffer,0,len);
            }
            out.close();
            prep.getVendorObject().setClob(prep.translateParameterIndex(parameterIndex), lob);
            Vector openResultSets=prep.getOpenResultSets();
            if(openResultSets.size()<parameterIndex+1) {
                openResultSets.setSize(parameterIndex+1);
            }
            openResultSets.set(parameterIndex,rs);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    private Object callMethod(Object o, String method, Class[] pclasses, Object[] params) throws SQLException {
        try {
            Method m = o.getClass().getMethod(method, pclasses);
            return m.invoke(o, params);
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    private void createTempLobTable(Connection conn) throws SQLException {
        Statement stat=conn.createStatement();
        try {
            stat.execute("CREATE GLOBAL TEMPORARY TABLE LDBC$LOB(ID INT, B BLOB, C CLOB) ON COMMIT PRESERVE ROWS");
        } catch(SQLException e) {
            // ignore - already exists
            //e.printStackTrace();
            //System.exit(0);
        }
    }
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }
    public boolean isSystemTable(String tableName) {
        if(tableName==null) {
            return false;
        }
        tableName=tableName.toUpperCase();
        if(tableName.equals("LDBC$LOB")) {
            return true;
        }
        return super.isSystemTable(tableName);
    }
    
    public String getAddColumnStatement(String tableName, String columnDef) throws SQLException {
        return "ALTER TABLE "+quote(tableName)+" ADD "+columnDef;
    }
    
    public String getSelect(boolean distinct, String top, String rest) throws SQLException {
        String select="SELECT ";
        if(distinct) {
            select+="DISTINCT ";
        }
        select+=rest;
        return select;     
    }

}
