package org.ldbc.test;
import java.sql.*;
import java.math.*;
import java.io.*;

public class TestResultSet extends TestBase {
    public static void main(String[] argv) {
        new TestResultSet().test(argv);
    }
    void test(Connection conn) throws SQLException {
        Statement stat=conn.createStatement();
        
        trace("max rows="+stat.getMaxRows());
        stat.setMaxRows(6);
        trace("max rows after set to 6="+stat.getMaxRows());
        check(stat.getMaxRows()==6);
        
        ResultSet rs;
        Object o;
        
        trace("Test INT");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE INT)");
        stat.execute("INSERT INTO TEST VALUES(1,-1)");
        stat.execute("INSERT INTO TEST VALUES(2,0)");
        stat.execute("INSERT INTO TEST VALUES(3,1)");
        stat.execute("INSERT INTO TEST VALUES(4,"+Integer.MAX_VALUE+")");
        stat.execute("INSERT INTO TEST VALUES(5,"+Integer.MIN_VALUE+")");
        stat.execute("INSERT INTO TEST VALUES(6,NULL)");
        // this should not be read - maxrows=6
        stat.execute("INSERT INTO TEST VALUES(7,NULL)");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        
        ResultSetMetaData meta = rs.getMetaData();
        check(meta.getColumnCount()==2);
        check("".equals(meta.getCatalogName(1)));
        check("".equals(meta.getSchemaName(2)));
        check("".equals(meta.getTableName(1)));
        check("ID".equals(meta.getColumnName(1)));
        check("VALUE".equals(meta.getColumnName(2)));
        check(meta.isAutoIncrement(1)==false);
        
        check(rs.getRow()==0);
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.INTEGER},
            new int[]{9,9},
            new int[]{0,0}
            );
        rs.next();
        check(rs.getConcurrency()==ResultSet.CONCUR_READ_ONLY);
        check(rs.getFetchDirection()==ResultSet.FETCH_FORWARD);        
        trace("default fetch size="+rs.getFetchSize());
        // 0 should be an allowed value (but it's not defined what is actually means)
        rs.setFetchSize(0);
        trace("after set to 0, fetch size="+rs.getFetchSize());
        // this should break
        try {
            rs.setFetchSize(-1);
            error("fetch size -1 is not allowed");
        } catch(SQLException e) {
            // exception - ok good
            trace(e.toString());
        }
        trace("after try to set to -1, fetch size="+rs.getFetchSize());
        try {
            rs.setFetchSize(100);
            error("fetch size 100 is bigger than maxrows - not allowed");
        } catch(SQLException e) {
            // exception - ok good
            trace(e.toString());
        }
        trace("after try set to 100, fetch size="+rs.getFetchSize());
        rs.setFetchSize(6);
        
        
        check(rs.getRow()==1);
        check(rs.findColumn("VALUE")==2);
        check(rs.findColumn("value")==2);
        check(rs.findColumn("Value")==2);
        check(rs.findColumn("Value")==2);
        check(rs.findColumn("ID")==1);
        check(rs.findColumn("id")==1);
        check(rs.findColumn("Id")==1);
        check(rs.findColumn("iD")==1);
        check(rs.getInt(2)==-1 && rs.wasNull()==false);
        check(rs.getInt("VALUE")==-1 && rs.wasNull()==false);
        check(rs.getInt("value")==-1 && rs.wasNull()==false);
        check(rs.getInt("Value")==-1 && rs.wasNull()==false);
        check(rs.getString("Value").equals("-1") && rs.wasNull()==false);
        
        o=rs.getObject("value");
        trace(o.getClass().getName());
        check(o instanceof Integer);
        check(((Integer)o).intValue()==-1);
        o=rs.getObject(2);
        trace(o.getClass().getName());
        check(o instanceof Integer);
        check(((Integer)o).intValue()==-1);
        check(rs.getBoolean("Value")==true);
        check(rs.getByte("Value")==(byte)-1);
        check(rs.getShort("Value")==(short)-1);
        check(rs.getLong("Value")==-1);
        check(rs.getFloat("Value")==-1.0);
        check(rs.getDouble("Value")==-1.0);
        
        check(rs.getString("Value").equals("-1") && rs.wasNull()==false);
        check(rs.getInt("ID")==1 && rs.wasNull()==false);
        check(rs.getInt("id")==1 && rs.wasNull()==false);
        check(rs.getInt("Id")==1 && rs.wasNull()==false);
        check(rs.getInt(1)==1 && rs.wasNull()==false);
        rs.next();
        check(rs.getRow()==2);
        check(rs.getInt(2)==0 && rs.wasNull()==false);
        check(rs.getBoolean(2)==false);
        check(rs.getByte(2)==0);
        check(rs.getShort(2)==0);
        check(rs.getLong(2)==0);
        check(rs.getFloat(2)==0.0);
        check(rs.getDouble(2)==0.0);
        check(rs.getString(2).equals("0") && rs.wasNull()==false);
        check(rs.getInt(1)==2 && rs.wasNull()==false);
        rs.next();
        check(rs.getRow()==3);
        check(rs.getInt("ID")==3 && rs.wasNull()==false);
        check(rs.getInt("VALUE")==1 && rs.wasNull()==false);
        rs.next();
        check(rs.getRow()==4);
        check(rs.getInt("ID")==4 && rs.wasNull()==false);
        check(rs.getInt("VALUE")==Integer.MAX_VALUE && rs.wasNull()==false);
        rs.next();
        check(rs.getRow()==5);
        check(rs.getInt("id")==5 && rs.wasNull()==false);
        check(rs.getInt("value")==Integer.MIN_VALUE && rs.wasNull()==false);
        check(rs.getString(1).equals("5") && rs.wasNull()==false);
        rs.next();
        check(rs.getRow()==6);
        check(rs.getInt("id")==6 && rs.wasNull()==false);
        check(rs.getInt("value")==0 && rs.wasNull()==true);
        check(rs.getInt(2)==0 && rs.wasNull()==true);
        check(rs.getInt(1)==6 && rs.wasNull()==false);
        check(rs.getString(1).equals("6") && rs.wasNull()==false);
        check(rs.getString(2)==null && rs.wasNull()==true);
        o=rs.getObject(2);
        check(o==null);
        check(rs.wasNull()==true);
        check(rs.next()==false);
        check(rs.getRow()==0);
        // there is one more row, but because of setMaxRows we don't get it 
        
        stat.execute("DROP TABLE TEST");
        stat.setMaxRows(0);
        
        trace("Test VARCHAR");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE VARCHAR(255))");
        /*
        // oracle problem - empty string is converted to null
        stat.execute("INSERT INTO TEST VALUES(1,'')");
        stat.execute("INSERT INTO TEST VALUES(2,' ')");
        stat.execute("INSERT INTO TEST VALUES(3,'  ')");
        */
        stat.execute("INSERT INTO TEST VALUES(4,NULL)");
        
        stat.execute("INSERT INTO TEST VALUES(5,'Hi')");
        /*
        stat.execute("INSERT INTO TEST VALUES(6,' Hi ')");
        */
        stat.execute("INSERT INTO TEST VALUES(7,'Joe''s')");
        stat.execute("INSERT INTO TEST VALUES(8,'{escape}')");
        stat.execute("INSERT INTO TEST VALUES(9,'\\n')");
        stat.execute("INSERT INTO TEST VALUES(10,'\\''')");
        stat.execute("INSERT INTO TEST VALUES(11,'\\%')");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.VARCHAR},
            new int[]{9,255},
            new int[]{0,0}
            );
        String value;
        /*
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <>)");
        check(value!=null && value.equals("") && rs.wasNull()==false);
        check(rs.getInt(1)==1 && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: < >)");
        check(rs.getString(2).equals(" ") && rs.wasNull()==false);
        check(rs.getInt(1)==2 && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <  >)");
        check(rs.getString(2).equals("  ") && rs.wasNull()==false);
        check(rs.getInt(1)==3 && rs.wasNull()==false);
        */
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <null>)");
        check(rs.getString(2)==null && rs.wasNull()==true);
        check(rs.getInt(1)==4 && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <Hi>)");
        check(rs.getInt(1)==5 && rs.wasNull()==false);
        check(rs.getString(2).equals("Hi") && rs.wasNull()==false);
        o=rs.getObject("value");
        trace(o.getClass().getName());
        check(o instanceof String);
        check(o.toString().equals("Hi"));
        
        /*
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: < Hi >)");
        check(rs.getInt(1)==6 && rs.wasNull()==false);
        check(rs.getString(2).equals(" Hi ") && rs.wasNull()==false);
        */
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <Joe's>)");
        check(rs.getInt(1)==7 && rs.wasNull()==false);
        check(rs.getString(2).equals("Joe's") && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <{escape}>)");
        check(rs.getInt(1)==8 && rs.wasNull()==false);
        check(rs.getString(2).equals("{escape}")&& rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <\\n>)");
        check(rs.getInt(1)==9 && rs.wasNull()==false);
        check(rs.getString(2).equals("\\n") && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <\\'>)");
        check(rs.getInt(1)==10 && rs.wasNull()==false);
        check(rs.getString(2).equals("\\'") && rs.wasNull()==false);
        rs.next();
        value=rs.getString(2);
        trace("Value: <"+value+"> (should be: <\\%>)");
        check(rs.getInt(1)==11 && rs.wasNull()==false);
        check(rs.getString(2).equals("\\%") && rs.wasNull()==false);
        check(rs.next()==false);
        stat.execute("DROP TABLE TEST");
        
        trace("Test DECIMAL");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE DECIMAL(10,2))");
        stat.execute("INSERT INTO TEST VALUES(1,-1)");
        stat.execute("INSERT INTO TEST VALUES(2,.0)");
        stat.execute("INSERT INTO TEST VALUES(3,1.)");
        stat.execute("INSERT INTO TEST VALUES(4,12345678.89)");
        stat.execute("INSERT INTO TEST VALUES(6,99999999.99)");
        stat.execute("INSERT INTO TEST VALUES(7,-99999999.99)");
        stat.execute("INSERT INTO TEST VALUES(8,NULL)");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.DECIMAL},
            new int[]{9,10},
            new int[]{0,2}
            );
        BigDecimal bd;
        rs.next();
        check(rs.getInt(1)==1);
        check(rs.wasNull()==false);
        check(rs.getInt(2)==-1);
        check(rs.wasNull()==false);
        bd=rs.getBigDecimal(2);
        check(bd.compareTo(new BigDecimal("-1.00"))==0);
        check(rs.wasNull()==false);
        o=rs.getObject(2);
        trace(o.getClass().getName());
        check(o instanceof BigDecimal);
        check(((BigDecimal)o).compareTo(new BigDecimal("-1.00"))==0);
        rs.next();
        check(rs.getInt(1)==2);
        check(rs.wasNull()==false);
        check(rs.getInt(2)==0);
        check(rs.wasNull()==false);
        bd=rs.getBigDecimal(2);
        check(bd.compareTo(new BigDecimal("0.00"))==0);
        check(rs.wasNull()==false);
        rs.next();
        checkColumnBigDecimal(rs,2,1,"1.00");
        rs.next();
        checkColumnBigDecimal(rs,2,12345678,"12345678.89");
        rs.next();
        checkColumnBigDecimal(rs,2,99999999,"99999999.99");
        rs.next();
        checkColumnBigDecimal(rs,2,-99999999,"-99999999.99");
        rs.next();
        checkColumnBigDecimal(rs,2,0,null);
        check(rs.next()==false);
        stat.execute("DROP TABLE TEST");

        trace("Test DATETIME");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE DATETIME)");
        stat.execute("INSERT INTO TEST VALUES(1,DATE '2011-11-11')");
        stat.execute("INSERT INTO TEST VALUES(2,TIMESTAMP '2002-02-02 02:02:02')");
        stat.execute("INSERT INTO TEST VALUES(3,TIMESTAMP '1800-1-1 0:0:0')");
        stat.execute("INSERT INTO TEST VALUES(4,TIMESTAMP '9999-12-31 23:59:59')");
        stat.execute("INSERT INTO TEST VALUES(5,NULL)");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.TIMESTAMP},
            new int[]{0,0},
            new int[]{0,0}
            );
        rs.next();
        java.sql.Date date;
        java.sql.Time time;
        java.sql.Timestamp ts;
        date=rs.getDate(2);
        check(!rs.wasNull());
        time=rs.getTime(2);
        check(!rs.wasNull());
        ts=rs.getTimestamp(2);
        check(!rs.wasNull());
        trace("Date: "+date.toString()+" Time:"+time.toString()+" Timestamp:"+ts.toString());
        trace("Date ms: "+date.getTime()+" Time ms:"+time.getTime()+" Timestamp ms:"+ts.getTime());
        trace("1970 ms: "+java.sql.Timestamp.valueOf("1970-01-01 00:00:00.0").getTime());
        check(date.getTime()==java.sql.Timestamp.valueOf("2011-11-11 00:00:00.0").getTime());
        check(time.getTime()==java.sql.Timestamp.valueOf("1970-01-01 00:00:00.0").getTime());
        check(ts.getTime()==java.sql.Timestamp.valueOf("2011-11-11 00:00:00.0").getTime());
        check(date.equals(java.sql.Timestamp.valueOf("2011-11-11 00:00:00.0")));
        check(time.equals(java.sql.Timestamp.valueOf("1970-01-01 00:00:00.0")));
        check(ts.equals(java.sql.Timestamp.valueOf("2011-11-11 00:00:00.0")));
        check(rs.wasNull()==false);
        o=rs.getObject(2);
        trace(o.getClass().getName());
        check(o instanceof java.sql.Timestamp);
        check(((java.sql.Timestamp)o).equals(java.sql.Timestamp.valueOf("2011-11-11 00:00:00.0")));
        check(rs.wasNull()==false);
        rs.next();
        
        date=rs.getDate("VALUE");
        check(!rs.wasNull());
        time=rs.getTime("VALUE");
        check(!rs.wasNull());
        ts=rs.getTimestamp("VALUE");
        check(!rs.wasNull());
        trace("Date: "+date.toString()+" Time:"+time.toString()+" Timestamp:"+ts.toString());
        check(date.equals(java.sql.Date.valueOf("2002-02-02")));
        check(time.equals(java.sql.Time.valueOf("2:2:2")));
        check(ts.equals(java.sql.Timestamp.valueOf("2002-02-02 02:02:02")));
        rs.next();
        check(rs.getDate("value").equals(java.sql.Date.valueOf("1800-1-1")));
        check(rs.getTime("value").equals(java.sql.Time.valueOf("0:0:0")));
        check(rs.getTimestamp("value").equals(java.sql.Timestamp.valueOf("1800-1-1 0:0:0")));
        rs.next();
        check(rs.getDate("Value").equals(java.sql.Date.valueOf("9999-12-31")));
        check(rs.getTime("Value").equals(java.sql.Time.valueOf("23:59:59")));
        check(rs.getTimestamp("Value").equals(java.sql.Timestamp.valueOf("9999-12-31 23:59:59")));
        rs.next();
        check(rs.getDate("Value")==null && rs.wasNull());
        check(rs.getTime("vALUe")==null && rs.wasNull());
        check(rs.getTimestamp(2)==null && rs.wasNull());
        check(rs.next()==false);
        stat.execute("DROP TABLE TEST");

        trace("Test BLOB");
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE BLOB)");
        stat.execute("INSERT INTO TEST VALUES(1,X'01010101')");
        stat.execute("INSERT INTO TEST VALUES(2,X'02020202')");
        // postgresql problem: trailing 0s are truncated
        /*
        stat.execute("INSERT INTO TEST VALUES(3,X'00')");
        */
        stat.execute("INSERT INTO TEST VALUES(4,X'ffFFff')");
        stat.execute("INSERT INTO TEST VALUES(5,X'0bcec1')");
        stat.execute("INSERT INTO TEST VALUES(6,NULL)");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.BLOB},
            new int[]{0,0},
            new int[]{0,0}
        );
        rs.next();
        checkBytes(rs.getBytes(2),new byte[]{(byte)0x01,(byte)0x01,(byte)0x01,(byte)0x01});
        check(!rs.wasNull());
        rs.next();
        checkBytes(rs.getBytes("value"),new byte[]{(byte)0x02,(byte)0x02,(byte)0x02,(byte)0x02});
        check(!rs.wasNull());
        /*
        rs.next();
        checkBytes(readAllBytes(rs.getBinaryStream(2)),new byte[]{(byte)0x00});
        check(!rs.wasNull());
        */
        rs.next();        
        checkBytes(readAllBytes(rs.getBinaryStream("VaLuE")),new byte[]{(byte)0xff,(byte)0xff,(byte)0xff});
        check(!rs.wasNull());
        rs.next();
        checkBytes((byte[])rs.getObject("value"),new byte[]{(byte)0x0b,(byte)0xce,(byte)0xc1});
        check(!rs.wasNull());
        rs.next();        
        checkBytes(readAllBytes(rs.getBinaryStream("VaLuE")),null);
        check(rs.wasNull());
        check(rs.next()==false);
        stat.execute("DROP TABLE TEST");
        
        trace("Test CLOB");
        String string;
        stat.execute("CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE CLOB)");
        stat.execute("INSERT INTO TEST VALUES(1,'Test')");
        stat.execute("INSERT INTO TEST VALUES(2,'Hello')");
        stat.execute("INSERT INTO TEST VALUES(3,'World!')");
        stat.execute("INSERT INTO TEST VALUES(4,'Hallo')");
        stat.execute("INSERT INTO TEST VALUES(5,'Welt!')");
        stat.execute("INSERT INTO TEST VALUES(6,NULL)");
        stat.execute("INSERT INTO TEST VALUES(7,NULL)");
        rs=stat.executeQuery("SELECT * FROM TEST ORDER BY ID");
        testResultSetMeta(rs,2,
            new String[]{"ID","VALUE"},
            new int[]{Types.INTEGER,Types.CLOB},
            new int[]{0,0},
            new int[]{0,0}
            );
        rs.next();
        string=rs.getString(2);
        check(string!=null && string.equals("Test"));
        check(!rs.wasNull());
        rs.next();
        InputStreamReader reader=null;
        try {
            reader=new InputStreamReader(rs.getAsciiStream(2),"ISO-8859-1");
        } catch(Exception e) {
            check(false);
        }
        string=readString(reader);
        check(!rs.wasNull());
        trace(string);
        check(string!=null && string.equals("Hello"));
        rs.next();
        try {
            reader=new InputStreamReader(rs.getAsciiStream("value"),"ISO-8859-1");
        } catch(Exception e) {
            check(false);
        }
        string=readString(reader);
        check(!rs.wasNull());
        trace(string);
        check(string!=null && string.equals("World!"));
        rs.next();
        string=readString(rs.getCharacterStream(2));
        check(!rs.wasNull());
        trace(string);
        check(string!=null && string.equals("Hallo"));
        rs.next();
        string=readString(rs.getCharacterStream("value"));
        check(!rs.wasNull());
        trace(string);
        check(string!=null && string.equals("Welt!"));
        rs.next();
        check(rs.getCharacterStream(2)==null);
        check(rs.wasNull());
        rs.next();
        check(rs.getAsciiStream("Value")==null);
        check(rs.wasNull());

        check(rs.getStatement()==stat);
        check(rs.getWarnings()==null);
        rs.clearWarnings();
        check(rs.getWarnings()==null);
        check(rs.getFetchDirection()==ResultSet.FETCH_FORWARD);
        check(rs.getConcurrency()==ResultSet.CONCUR_READ_ONLY);
        rs.next();
        
        stat.execute("DROP TABLE TEST");
        
    }
    String readString(Reader reader) {
        if(reader==null) {
            return null;
        }
        StringBuffer buffer=new StringBuffer();
        try {
            while(true) {
                int c=reader.read();
                if(c==-1) {
                    break;
                }
                buffer.append((char)c);
            }
            return buffer.toString();
        } catch(Exception e) {
            check(false);
            return null;
        }
    }
    byte[] readAllBytes(InputStream in) {
        if(in==null) {
            return null;
        }
        ByteArrayOutputStream out=new ByteArrayOutputStream(); 
        try {
            while(true) {
                int b=in.read();
                if(b==-1) {
                    break;
                }
                out.write(b);
            }
            return out.toByteArray();
        } catch(IOException e) {
            check(false);
            return null;
        }
    }
    void checkBytes(byte[] test,byte[] good) {
        if(test==null || good==null) {
            check(test==null && good==null);
        } else {
            trace("test.length="+test.length+" good.length="+good.length);
            check(test.length==good.length);
            for(int i=0;i<good.length;i++) {
                check(test[i]==good[i]);
            }
        }
    }
    void checkColumnBigDecimal(ResultSet rs,int column,int i,String bd) throws SQLException {
        BigDecimal bd1=rs.getBigDecimal(column);
        int i1=rs.getInt(column);
        if(bd==null) {
            trace("should be: null");
            check(rs.wasNull());
        } else {
            trace("BigDecimal i="+i+" bd="+bd+" ; i1="+i1+" bd1="+bd1);
            check(!rs.wasNull());
            check(i1==i);
            check(bd1.compareTo(new BigDecimal(bd))==0);
        }
    }
}
