// $ANTLR 2.7.1: "org/ldbc/parser/sql.g" -> "SQLLexer.java"$

package org.ldbc.parser;

import java.io.InputStream;
import org.ldbc.antlr.TokenStreamException;
import org.ldbc.antlr.TokenStreamIOException;
import org.ldbc.antlr.TokenStreamRecognitionException;
import org.ldbc.antlr.CharStreamException;
import org.ldbc.antlr.CharStreamIOException;
import org.ldbc.antlr.ANTLRException;
import java.io.Reader;
import java.util.Hashtable;
import org.ldbc.antlr.CharScanner;
import org.ldbc.antlr.InputBuffer;
import org.ldbc.antlr.ByteBuffer;
import org.ldbc.antlr.CharBuffer;
import org.ldbc.antlr.Token;
import org.ldbc.antlr.CommonToken;
import org.ldbc.antlr.RecognitionException;
import org.ldbc.antlr.NoViableAltForCharException;
import org.ldbc.antlr.MismatchedCharException;
import org.ldbc.antlr.TokenStream;
import org.ldbc.antlr.ANTLRHashString;
import org.ldbc.antlr.LexerSharedInputState;
import org.ldbc.antlr.collections.impl.BitSet;
import org.ldbc.antlr.SemanticException;

public class SQLLexer extends org.ldbc.antlr.CharScanner implements SQLTokenTypes, TokenStream
 {
public SQLLexer(InputStream in) {
	this(new ByteBuffer(in));
}
public SQLLexer(Reader in) {
	this(new CharBuffer(in));
}
public SQLLexer(InputBuffer ib) {
	this(new LexerSharedInputState(ib));
}
public SQLLexer(LexerSharedInputState state) {
	super(state);
	literals = new Hashtable();
	literals.put(new ANTLRHashString("local", this), new Integer(211));
	literals.put(new ANTLRHashString("now", this), new Integer(169));
	literals.put(new ANTLRHashString("blob", this), new Integer(133));
	literals.put(new ANTLRHashString("varchar_ignorecase", this), new Integer(244));
	literals.put(new ANTLRHashString("before", this), new Integer(193));
	literals.put(new ANTLRHashString("cached", this), new Integer(195));
	literals.put(new ANTLRHashString("sysdate", this), new Integer(235));
	literals.put(new ANTLRHashString("tinytext", this), new Integer(142));
	literals.put(new ANTLRHashString("smallint", this), new Integer(116));
	literals.put(new ANTLRHashString("between", this), new Integer(63));
	literals.put(new ANTLRHashString("time", this), new Integer(132));
	literals.put(new ANTLRHashString("autocommit", this), new Integer(87));
	literals.put(new ANTLRHashString("case", this), new Integer(197));
	literals.put(new ANTLRHashString("option", this), new Integer(96));
	literals.put(new ANTLRHashString("substring", this), new Integer(234));
	literals.put(new ANTLRHashString("delete", this), new Integer(157));
	literals.put(new ANTLRHashString("tinyint", this), new Integer(115));
	literals.put(new ANTLRHashString("curdate", this), new Integer(173));
	literals.put(new ANTLRHashString("database", this), new Integer(200));
	literals.put(new ANTLRHashString("object", this), new Integer(217));
	literals.put(new ANTLRHashString("concat", this), new Integer(181));
	literals.put(new ANTLRHashString("abs", this), new Integer(191));
	literals.put(new ANTLRHashString("limit", this), new Integer(207));
	literals.put(new ANTLRHashString("timestamp", this), new Integer(131));
	literals.put(new ANTLRHashString("distinct", this), new Integer(148));
	literals.put(new ANTLRHashString("insert", this), new Integer(90));
	literals.put(new ANTLRHashString("binary", this), new Integer(137));
	literals.put(new ANTLRHashString("grant", this), new Integer(203));
	literals.put(new ANTLRHashString("where", this), new Integer(151));
	literals.put(new ANTLRHashString("mediumtext", this), new Integer(143));
	literals.put(new ANTLRHashString("alter", this), new Integer(102));
	literals.put(new ANTLRHashString("varbinary", this), new Integer(138));
	literals.put(new ANTLRHashString("trailing", this), new Integer(237));
	literals.put(new ANTLRHashString("integer", this), new Integer(114));
	literals.put(new ANTLRHashString("write", this), new Integer(247));
	literals.put(new ANTLRHashString("locate", this), new Integer(212));
	literals.put(new ANTLRHashString("match", this), new Integer(215));
	literals.put(new ANTLRHashString("decimal", this), new Integer(122));
	literals.put(new ANTLRHashString("select", this), new Integer(147));
	literals.put(new ANTLRHashString("cascade", this), new Integer(196));
	literals.put(new ANTLRHashString("lock", this), new Integer(213));
	literals.put(new ANTLRHashString("to", this), new Integer(108));
	literals.put(new ANTLRHashString("and", this), new Integer(58));
	literals.put(new ANTLRHashString("unsigned", this), new Integer(241));
	literals.put(new ANTLRHashString("outer", this), new Integer(160));
	literals.put(new ANTLRHashString("float", this), new Integer(126));
	literals.put(new ANTLRHashString("not", this), new Integer(59));
	literals.put(new ANTLRHashString("constraint", this), new Integer(106));
	literals.put(new ANTLRHashString("returns", this), new Integer(228));
	literals.put(new ANTLRHashString("position", this), new Integer(221));
	literals.put(new ANTLRHashString("lob", this), new Integer(210));
	literals.put(new ANTLRHashString("numeric", this), new Integer(123));
	literals.put(new ANTLRHashString("date", this), new Integer(130));
	literals.put(new ANTLRHashString("using", this), new Integer(243));
	literals.put(new ANTLRHashString("longblob", this), new Integer(136));
	literals.put(new ANTLRHashString("key", this), new Integer(85));
	literals.put(new ANTLRHashString("from", this), new Integer(150));
	literals.put(new ANTLRHashString("bigint", this), new Integer(128));
	literals.put(new ANTLRHashString("null", this), new Integer(66));
	literals.put(new ANTLRHashString("count", this), new Integer(164));
	literals.put(new ANTLRHashString("real", this), new Integer(125));
	literals.put(new ANTLRHashString("temp", this), new Integer(236));
	literals.put(new ANTLRHashString("sqrt", this), new Integer(233));
	literals.put(new ANTLRHashString("mod", this), new Integer(180));
	literals.put(new ANTLRHashString("add", this), new Integer(103));
	literals.put(new ANTLRHashString("upper", this), new Integer(184));
	literals.put(new ANTLRHashString("like", this), new Integer(64));
	literals.put(new ANTLRHashString("natural", this), new Integer(216));
	literals.put(new ANTLRHashString("when", this), new Integer(245));
	literals.put(new ANTLRHashString("lcase", this), new Integer(183));
	literals.put(new ANTLRHashString("char_length", this), new Integer(178));
	literals.put(new ANTLRHashString("inner", this), new Integer(158));
	literals.put(new ANTLRHashString("leading", this), new Integer(206));
	literals.put(new ANTLRHashString("text", this), new Integer(145));
	literals.put(new ANTLRHashString("character", this), new Integer(198));
	literals.put(new ANTLRHashString("trim", this), new Integer(239));
	literals.put(new ANTLRHashString("with", this), new Integer(246));
	literals.put(new ANTLRHashString("octet_length", this), new Integer(218));
	literals.put(new ANTLRHashString("set", this), new Integer(86));
	literals.put(new ANTLRHashString("current_time", this), new Integer(171));
	literals.put(new ANTLRHashString("outfile", this), new Integer(220));
	literals.put(new ANTLRHashString("foreign", this), new Integer(110));
	literals.put(new ANTLRHashString("join", this), new Integer(161));
	literals.put(new ANTLRHashString("rollback", this), new Integer(82));
	literals.put(new ANTLRHashString("commit", this), new Integer(81));
	literals.put(new ANTLRHashString("is", this), new Integer(65));
	literals.put(new ANTLRHashString("or", this), new Integer(57));
	literals.put(new ANTLRHashString("create", this), new Integer(93));
	literals.put(new ANTLRHashString("kill", this), new Integer(205));
	literals.put(new ANTLRHashString("dec", this), new Integer(124));
	literals.put(new ANTLRHashString("if", this), new Integer(95));
	literals.put(new ANTLRHashString("double", this), new Integer(127));
	literals.put(new ANTLRHashString("length", this), new Integer(177));
	literals.put(new ANTLRHashString("autoincrement", this), new Integer(84));
	literals.put(new ANTLRHashString("min", this), new Integer(165));
	literals.put(new ANTLRHashString("as", this), new Integer(163));
	literals.put(new ANTLRHashString("by", this), new Integer(153));
	literals.put(new ANTLRHashString("all", this), new Integer(192));
	literals.put(new ANTLRHashString("union", this), new Integer(240));
	literals.put(new ANTLRHashString("drop", this), new Integer(101));
	literals.put(new ANTLRHashString("order", this), new Integer(155));
	literals.put(new ANTLRHashString("privileges", this), new Integer(223));
	literals.put(new ANTLRHashString("extract", this), new Integer(201));
	literals.put(new ANTLRHashString("both", this), new Integer(194));
	literals.put(new ANTLRHashString("primary", this), new Integer(109));
	literals.put(new ANTLRHashString("current_date", this), new Integer(170));
	literals.put(new ANTLRHashString("lineno", this), new Integer(208));
	literals.put(new ANTLRHashString("longtext", this), new Integer(144));
	literals.put(new ANTLRHashString("values", this), new Integer(92));
	literals.put(new ANTLRHashString("ucase", this), new Integer(185));
	literals.put(new ANTLRHashString("character_length", this), new Integer(179));
	literals.put(new ANTLRHashString("int", this), new Integer(113));
	literals.put(new ANTLRHashString("for", this), new Integer(202));
	literals.put(new ANTLRHashString("savepoint", this), new Integer(231));
	literals.put(new ANTLRHashString("revoke", this), new Integer(229));
	literals.put(new ANTLRHashString("tinyblob", this), new Integer(134));
	literals.put(new ANTLRHashString("boolean", this), new Integer(119));
	literals.put(new ANTLRHashString("cross", this), new Integer(199));
	literals.put(new ANTLRHashString("varchar", this), new Integer(120));
	literals.put(new ANTLRHashString("char", this), new Integer(121));
	literals.put(new ANTLRHashString("bit", this), new Integer(118));
	literals.put(new ANTLRHashString("index", this), new Integer(99));
	literals.put(new ANTLRHashString("default", this), new Integer(105));
	literals.put(new ANTLRHashString("zerofill", this), new Integer(250));
	literals.put(new ANTLRHashString("clob", this), new Integer(141));
	literals.put(new ANTLRHashString("false", this), new Integer(89));
	literals.put(new ANTLRHashString("convert", this), new Integer(176));
	literals.put(new ANTLRHashString("session_user", this), new Integer(232));
	literals.put(new ANTLRHashString("exists", this), new Integer(60));
	literals.put(new ANTLRHashString("table", this), new Integer(94));
	literals.put(new ANTLRHashString("mediumint", this), new Integer(117));
	literals.put(new ANTLRHashString("asc", this), new Integer(188));
	literals.put(new ANTLRHashString("mediumblob", this), new Integer(135));
	literals.put(new ANTLRHashString("y", this), new Integer(249));
	literals.put(new ANTLRHashString("left", this), new Integer(159));
	literals.put(new ANTLRHashString("lower", this), new Integer(182));
	literals.put(new ANTLRHashString("load", this), new Integer(209));
	literals.put(new ANTLRHashString("replace", this), new Integer(226));
	literals.put(new ANTLRHashString("desc", this), new Integer(189));
	literals.put(new ANTLRHashString("get", this), new Integer(83));
	literals.put(new ANTLRHashString("max", this), new Integer(166));
	literals.put(new ANTLRHashString("longvarbinary", this), new Integer(139));
	literals.put(new ANTLRHashString("sum", this), new Integer(167));
	literals.put(new ANTLRHashString("datetime", this), new Integer(129));
	literals.put(new ANTLRHashString("on", this), new Integer(100));
	literals.put(new ANTLRHashString("cast", this), new Integer(175));
	literals.put(new ANTLRHashString("image", this), new Integer(140));
	literals.put(new ANTLRHashString("restrict", this), new Integer(227));
	literals.put(new ANTLRHashString("top", this), new Integer(149));
	literals.put(new ANTLRHashString("longvarchar", this), new Integer(146));
	literals.put(new ANTLRHashString("into", this), new Integer(91));
	literals.put(new ANTLRHashString("x", this), new Integer(248));
	literals.put(new ANTLRHashString("curtime", this), new Integer(174));
	literals.put(new ANTLRHashString("rename", this), new Integer(107));
	literals.put(new ANTLRHashString("right", this), new Integer(230));
	literals.put(new ANTLRHashString("in", this), new Integer(74));
	literals.put(new ANTLRHashString("avg", this), new Integer(168));
	literals.put(new ANTLRHashString("precision", this), new Integer(222));
	literals.put(new ANTLRHashString("other", this), new Integer(219));
	literals.put(new ANTLRHashString("procedure", this), new Integer(224));
	literals.put(new ANTLRHashString("infile", this), new Integer(204));
	literals.put(new ANTLRHashString("update", this), new Integer(156));
	literals.put(new ANTLRHashString("true", this), new Integer(88));
	literals.put(new ANTLRHashString("long", this), new Integer(214));
	literals.put(new ANTLRHashString("read", this), new Integer(225));
	literals.put(new ANTLRHashString("group", this), new Integer(152));
	literals.put(new ANTLRHashString("trigger", this), new Integer(238));
	literals.put(new ANTLRHashString("having", this), new Integer(154));
	literals.put(new ANTLRHashString("column", this), new Integer(104));
	literals.put(new ANTLRHashString("user", this), new Integer(242));
	literals.put(new ANTLRHashString("unique", this), new Integer(98));
	literals.put(new ANTLRHashString("references", this), new Integer(111));
	literals.put(new ANTLRHashString("current_timestamp", this), new Integer(172));
caseSensitiveLiterals = false;
setCaseSensitive(false);
}

public Token nextToken() throws TokenStreamException {
	Token theRetToken=null;
tryAgain:
	for (;;) {
		Token _token = null;
		int _ttype = Token.INVALID_TYPE;
		resetText();
		try {   // for char stream error handling
			try {   // for lexical error handling
				switch ( LA(1)) {
				case '\'':
				{
					mQUOTED_STRING(true);
					theRetToken=_returnToken;
					break;
				}
				case '.':
				{
					mDOT(true);
					theRetToken=_returnToken;
					break;
				}
				case ',':
				{
					mCOMMA(true);
					theRetToken=_returnToken;
					break;
				}
				case '*':
				{
					mASTERISK(true);
					theRetToken=_returnToken;
					break;
				}
				case '(':
				{
					mOPEN_PAREN(true);
					theRetToken=_returnToken;
					break;
				}
				case ')':
				{
					mCLOSE_PAREN(true);
					theRetToken=_returnToken;
					break;
				}
				case '+':
				{
					mPLUS(true);
					theRetToken=_returnToken;
					break;
				}
				case '|':
				{
					mVERTBARS(true);
					theRetToken=_returnToken;
					break;
				}
				case '?':
				{
					mPARAMETER(true);
					theRetToken=_returnToken;
					break;
				}
				case '=':
				{
					mEQUAL(true);
					theRetToken=_returnToken;
					break;
				}
				case '!':
				{
					mNOT_EQUAL_2(true);
					theRetToken=_returnToken;
					break;
				}
				case '0':  case '1':  case '2':  case '3':
				case '4':  case '5':  case '6':  case '7':
				case '8':  case '9':
				{
					mNUMBER(true);
					theRetToken=_returnToken;
					break;
				}
				case '\t':  case '\n':  case '\r':  case ' ':
				{
					mWS(true);
					theRetToken=_returnToken;
					break;
				}
				default:
					if ((LA(1)=='<') && (LA(2)=='>')) {
						mNOT_EQUAL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='>') && (LA(2)=='=')) {
						mBIGGER_EQUAL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='<') && (LA(2)=='=')) {
						mSMALLER_EQUAL(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='x') && (LA(2)=='\'')) {
						mHEX(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='/') && (LA(2)=='*')) {
						mSTART_END_REMARK(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='-') && (LA(2)=='-')) {
						mSINGLE_LINE_COMMENT(true);
						theRetToken=_returnToken;
					}
					else if (((LA(1) >= 'a' && LA(1) <= 'z')) && (true)) {
						mIDENTIFIER(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='-') && (true)) {
						mMINUS(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='/') && (true)) {
						mDIVIDE(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='>') && (true)) {
						mBIGGER(true);
						theRetToken=_returnToken;
					}
					else if ((LA(1)=='<') && (true)) {
						mSMALLER(true);
						theRetToken=_returnToken;
					}
				else {
					if (LA(1)==EOF_CHAR) {uponEOF(); _returnToken = makeToken(Token.EOF_TYPE);}
				else {throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine());}
				}
				}
				if ( _returnToken==null ) continue tryAgain; // found SKIP token
				_ttype = _returnToken.getType();
				_ttype = testLiteralsTable(_ttype);
				_returnToken.setType(_ttype);
				return _returnToken;
			}
			catch (RecognitionException e) {
				throw new TokenStreamRecognitionException(e);
			}
		}
		catch (CharStreamException cse) {
			if ( cse instanceof CharStreamIOException ) {
				throw new TokenStreamIOException(((CharStreamIOException)cse).io);
			}
			else {
				throw new TokenStreamException(cse.getMessage());
			}
		}
	}
}

	public final void mIDENTIFIER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = IDENTIFIER;
		int _saveIndex;
		
		matchRange('a','z');
		{
		_loop203:
		do {
			switch ( LA(1)) {
			case 'a':  case 'b':  case 'c':  case 'd':
			case 'e':  case 'f':  case 'g':  case 'h':
			case 'i':  case 'j':  case 'k':  case 'l':
			case 'm':  case 'n':  case 'o':  case 'p':
			case 'q':  case 'r':  case 's':  case 't':
			case 'u':  case 'v':  case 'w':  case 'x':
			case 'y':  case 'z':
			{
				matchRange('a','z');
				break;
			}
			case '0':  case '1':  case '2':  case '3':
			case '4':  case '5':  case '6':  case '7':
			case '8':  case '9':
			{
				matchRange('0','9');
				break;
			}
			case '_':
			{
				match('_');
				break;
			}
			default:
			{
				break _loop203;
			}
			}
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mQUOTED_STRING(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = QUOTED_STRING;
		int _saveIndex;
		
		match('\'');
		{
		_loop206:
		do {
			if ((_tokenSet_0.member(LA(1)))) {
				matchNot('\'');
			}
			else {
				break _loop206;
			}
			
		} while (true);
		}
		match('\'');
		{
		_loop208:
		do {
			if ((LA(1)=='\'') && ((LA(2) >= '\u0003' && LA(2) <= '\u01ff')) && (true) && (true)) {
				mQUOTED_STRING(false);
			}
			else {
				break _loop208;
			}
			
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mDOT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DOT;
		int _saveIndex;
		
		match('.');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mCOMMA(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = COMMA;
		int _saveIndex;
		
		match(',');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mASTERISK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = ASTERISK;
		int _saveIndex;
		
		match('*');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mOPEN_PAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = OPEN_PAREN;
		int _saveIndex;
		
		match('(');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mCLOSE_PAREN(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = CLOSE_PAREN;
		int _saveIndex;
		
		match(')');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mPLUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = PLUS;
		int _saveIndex;
		
		match('+');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mMINUS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = MINUS;
		int _saveIndex;
		
		match('-');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mDIVIDE(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = DIVIDE;
		int _saveIndex;
		
		match('/');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mVERTBARS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = VERTBARS;
		int _saveIndex;
		
		match("||");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mPARAMETER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = PARAMETER;
		int _saveIndex;
		
		match('?');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mEQUAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = EQUAL;
		int _saveIndex;
		
		match('=');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBIGGER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BIGGER;
		int _saveIndex;
		
		match('>');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSMALLER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SMALLER;
		int _saveIndex;
		
		match('<');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNOT_EQUAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NOT_EQUAL;
		int _saveIndex;
		
		match("<>");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNOT_EQUAL_2(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NOT_EQUAL_2;
		int _saveIndex;
		
		match("!=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mBIGGER_EQUAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = BIGGER_EQUAL;
		int _saveIndex;
		
		match(">=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSMALLER_EQUAL(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SMALLER_EQUAL;
		int _saveIndex;
		
		match("<=");
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mHEX(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = HEX;
		int _saveIndex;
		
		match('x');
		match('\'');
		{
		_loop228:
		do {
			if ((_tokenSet_0.member(LA(1)))) {
				matchNot('\'');
			}
			else {
				break _loop228;
			}
			
		} while (true);
		}
		match('\'');
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mNUMBER(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = NUMBER;
		int _saveIndex;
		
		matchRange('0','9');
		{
		_loop231:
		do {
			if (((LA(1) >= '0' && LA(1) <= '9'))) {
				matchRange('0','9');
			}
			else {
				break _loop231;
			}
			
		} while (true);
		}
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mWS(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = WS;
		int _saveIndex;
		
		{
		switch ( LA(1)) {
		case ' ':
		{
			match(' ');
			break;
		}
		case '\t':
		{
			match('\t');
			break;
		}
		case '\n':
		{
			match('\n');
			break;
		}
		case '\r':
		{
			match('\r');
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine());
		}
		}
		}
		_ttype = Token.SKIP;
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSTART_END_REMARK(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = START_END_REMARK;
		int _saveIndex;
		
		match("/*");
		{
		_loop236:
		do {
			if (((LA(1)=='*') && ((LA(2) >= '\u0003' && LA(2) <= '\u01ff')) && ((LA(3) >= '\u0003' && LA(3) <= '\u01ff')))&&( LA(2)!='/' )) {
				match('*');
			}
			else if ((_tokenSet_1.member(LA(1)))) {
				matchNot('*');
			}
			else {
				break _loop236;
			}
			
		} while (true);
		}
		match("*/");
		_ttype = Token.SKIP;
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	public final void mSINGLE_LINE_COMMENT(boolean _createToken) throws RecognitionException, CharStreamException, TokenStreamException {
		int _ttype; Token _token=null; int _begin=text.length();
		_ttype = SINGLE_LINE_COMMENT;
		int _saveIndex;
		
		match("--");
		{
		_loop240:
		do {
			if ((_tokenSet_2.member(LA(1)))) {
				{
				match(_tokenSet_2);
				}
			}
			else {
				break _loop240;
			}
			
		} while (true);
		}
		{
		switch ( LA(1)) {
		case '\n':
		{
			match('\n');
			break;
		}
		case '\r':
		{
			match('\r');
			{
			if ((LA(1)=='\n')) {
				match('\n');
			}
			else {
			}
			
			}
			break;
		}
		default:
		{
			throw new NoViableAltForCharException((char)LA(1), getFilename(), getLine());
		}
		}
		}
		_ttype = Token.SKIP;
		if ( _createToken && _token==null && _ttype!=Token.SKIP ) {
			_token = makeToken(_ttype);
			_token.setText(new String(text.getBuffer(), _begin, text.length()-_begin));
		}
		_returnToken = _token;
	}
	
	
	private static final long _tokenSet_0_data_[] = { -549755813896L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { -4398046511112L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { -9224L, -1L, -1L, -1L, -1L, -1L, -1L, -1L, 0L, 0L, 0L, 0L, 0L, 0L, 0L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	
	}
