package org.ldbc.test.synth;

import java.util.HashSet;
import java.util.Random;
import java.util.StringTokenizer;

public class Generator {
	private static Generator instance;
	private Random random = new Random();
	private HashSet identifiers = new HashSet();
	
	public static Generator getInstance() {
		if(instance==null) {
			instance = new Generator();
		}
		return instance;
	}
	
	private Generator() {
		String ids = 
		        "ABS,ADD,ALL,ALTER,AND,AS,ASC,AVG,BEFORE,BETWEEN,"+
		        "BIGINT,BINARY,BIT,BLOB,BOOLEAN,BOTH,BY,CACHED,"+
		        "CASCADE,CASE,CAST,CHAR,CHARACTER,CHARACTER_LENGTH,"+
		        "CHAR_LENGTH,CLOB,COLUMN,COMMIT,CONCAT,CONSTRAINT,"+
		        "COUNT,CREATE,CROSS,CURRENT_DATE,CURRENT_TIME,"+
		        "CURRENT_TIMESTAMP,DATABASE,DATE,DATETIME,DEC,"+
		        "DECIMAL,DEFAULT,DELETE,DESC,DISTINCT,DOUBLE,DROP,"+
		        "EXISTS,EXTRACT,FALSE,FLOAT,FOR,FOREIGN,FROM,GRANT,"+
		        "GROUP,HAVING,IF,IMAGE,IN,INDEX,INFILE,INNER,INSERT,"+
		        "INT,INTEGER,INTO,IS,JOIN,KEY,KILL,LEADING,LEFT,"+
		        "LENGTH,LIKE,LIMIT,LINENO,LOAD,LOB,LOCAL,LOCATE,"+
		        "LOCK,LONG,LONGVARBINARY,LONGVARCHAR,LOWER,MATCH,"+
		        "MAX,MEDIUMINT,MIN,MOD,NATURAL,NOT,NULL,NUMERIC,"+
		        "OBJECT,OCTET_LENGTH,ON,OPTION,OR,ORDER,OTHER,OUTER,"+
		        "OUTFILE,POSITION,PRECISION,PRIMARY,PRIVILEGES,"+
		        "PROCEDURE,READ,REAL,REFERENCES,RENAME,REPLACE,"+
		        "RESTRICT,RETURNS,REVOKE,RIGHT,ROLLBACK,SAVEPOINT,"+
		        "SELECT,SESSION_USER,SET,SMALLINT,SQRT,SUBSTRING,"+
		        "SUM,SYSDATE,TABLE,TEMP,TEXT,TIME,TIMESTAMP,TINYINT,"+
		        "TO,TOP,TRAILING,TRIGGER,TRIM,TRUE,UNION,UNIQUE,"+
		        "UNSIGNED,UPDATE,UPPER,USER,USING,VALUES,VARBINARY,"+
		        "VARCHAR,VARCHAR_IGNORECASE,WHEN,WHERE,WITH,WRITE,"+
		        "ZEROFILL";
		StringTokenizer st = new StringTokenizer(ids, ",");
		while (st.hasMoreTokens()) {
	         String s = st.nextToken();
			identifiers.add(s);
		}
	}
	
	public boolean getBoolean(int percent) {
		return random.nextInt(100) <= percent;
	}
	
	public int getInt(int max) {
		return max==0 ? 0 : random.nextInt(max);
	}
	
	public String randomIdentifier() {
		Generator gen = Generator.getInstance();
		int len = gen.getLog(8)+2;
		while(true) {
			String s = randomString(len);
			if(!identifiers.contains(s.toUpperCase())) {
				return s;
			}
		}
	}
	
	public String randomString(int len) {
		Generator gen = Generator.getInstance();
		StringBuffer buff = new StringBuffer();
		for(int i=0; i<len; i++) {
			String from = (i%2==0)?"bdfghklmnpqrst":"aeiou";
			buff.append(from.charAt(gen.getInt(from.length())));
		}
		return buff.toString();
	}
	
	public int getLog(int max) {
		if(max==0) {
			return 0;
		}
		while(true) {
			int d = Math.abs((int)(random.nextGaussian()/2.*max));
			if(d<max) {
				return d;
			}
		}
	}
	
	public void getBytes(byte[] data) {
		random.nextBytes(data);
	}
}
