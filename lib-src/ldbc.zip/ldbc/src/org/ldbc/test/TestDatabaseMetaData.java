package org.ldbc.test;

import java.sql.*;

public class TestDatabaseMetaData extends TestBase {

    public static void main(String[] argv) {
        new TestDatabaseMetaData().test(argv);
    }

    void test(Connection conn) throws SQLException {
        DatabaseMetaData meta = conn.getMetaData();
        Statement stat = conn.createStatement();
        ResultSet rs;
        
        conn.setReadOnly(true);
        check(conn.isReadOnly());
        check(conn.isReadOnly() == meta.isReadOnly());
        conn.setReadOnly(false);
        check(!conn.isReadOnly());
        check(conn.isReadOnly() == meta.isReadOnly());
        
        check(conn==meta.getConnection());
        
        // currently, setCatalog is ignored
        conn.setCatalog("XYZ");
        trace(conn.getCatalog());
        
        String product = meta.getDatabaseProductName();
        trace("meta.getDatabaseProductName:" + product);

        String version = meta.getDatabaseProductVersion();
        trace("meta.getDatabaseProductVersion:" + version);

        int major = meta.getDriverMajorVersion();
        trace("meta.getDriverMajorVersion:" + major);

        int minor = meta.getDriverMinorVersion();
        trace("meta.getDriverMinorVersion:" + minor);

        String drivername = meta.getDriverName();
        trace("meta.getDriverName:" + drivername);

        String driverversion = meta.getDriverVersion();
        trace("meta.getDriverVersion:" + driverversion);

        meta.getSearchStringEscape();

        String url = meta.getURL();
        trace("meta.getURL:" + url);

        String user = meta.getUserName();
        trace("meta.getUserName:" + user);

        trace("meta.nullsAreSortedHigh:" + meta.nullsAreSortedHigh());
        trace("meta.nullsAreSortedLow:" + meta.nullsAreSortedLow());
        trace("meta.nullsAreSortedAtStart:" + meta.nullsAreSortedAtStart());
        trace("meta.nullsAreSortedAtEnd:" + meta.nullsAreSortedAtEnd());
        int count = (meta.nullsAreSortedHigh() ? 1 : 0)
                + (meta.nullsAreSortedLow() ? 1 : 0)
                + (meta.nullsAreSortedAtStart() ? 1 : 0)
                + (meta.nullsAreSortedAtEnd() ? 1 : 0);
        check(count == 1);
        
        trace("meta.allProceduresAreCallable:" + meta.allProceduresAreCallable());
        check(meta.allProceduresAreCallable());

        trace("meta.allTablesAreSelectable:" + meta.allTablesAreSelectable());
        check(meta.allTablesAreSelectable());
        
        check("".equals(meta.getExtraNameCharacters()));
        check(meta.supportsColumnAliasing());
        check(meta.nullPlusNonNullIsNull());
        check(!meta.supportsConvert());
        check(meta.supportsTableCorrelationNames());
        check(!meta.supportsDifferentTableCorrelationNames());
        check(meta.supportsExpressionsInOrderBy());
        check(meta.supportsOrderByUnrelated());
        check(meta.supportsGroupBy());
        check(!meta.supportsLikeEscapeClause());
        check(meta.supportsMinimumSQLGrammar());
        check(meta.supportsANSI92EntryLevelSQL());
        check(!meta.supportsANSI92IntermediateSQL());
        check(!meta.supportsANSI92FullSQL());
        check(meta.supportsOuterJoins());
        check(meta.supportsTransactions());
        check(meta.storesUpperCaseIdentifiers());
        check(!meta.storesLowerCaseIdentifiers());
        check(!meta.storesMixedCaseIdentifiers());

        trace("getTables");
        rs = meta.getTables(null, null, null, new String[] { "TABLE"});
        testResultSetMeta(rs, 5, new String[] { "TABLE_CAT", "TABLE_SCHEM",
                "TABLE_NAME", "TABLE_TYPE", "REMARKS"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR}, null, null);
        if (rs.next()) {
            error("Database is not empty after dropping all tables");
        }
        stat.executeUpdate("CREATE TABLE TEST(" + "ID INT PRIMARY KEY,"
                + "TEXT_V VARCHAR(120)," + "DEC_V DECIMAL(12,3),"
                + "DATE_V DATETIME," + "BLOB_V BLOB," + "CLOB_V CLOB" + ")");
        //rs=meta.getTables(null,null,"TEST",new String[]{"TABLE"});
        rs = meta.getTables(null, null, null, null);
        testResultSetOrdered(rs, new String[][] { { null, null, "TEST",
                "TABLE", null}});
        trace("getColumns");
        rs = meta.getColumns(null, null, "TEST", null);
        testResultSetMeta(rs, 18, new String[] { "TABLE_CAT", "TABLE_SCHEM",
                "TABLE_NAME", "COLUMN_NAME", "DATA_TYPE", "TYPE_NAME",
                "COLUMN_SIZE", "BUFFER_LENGTH", "DECIMAL_DIGITS",
                "NUM_PREC_RADIX", "NULLABLE", "REMARKS", "COLUMN_DEF",
                "SQL_DATA_TYPE", "SQL_DATETIME_SUB", "CHAR_OCTET_LENGTH",
                "ORDINAL_POSITION", "IS_NULLABLE"}, new int[] { Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.SMALLINT,
                Types.VARCHAR, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.INTEGER, Types.INTEGER, Types.VARCHAR, Types.VARCHAR,
                Types.INTEGER, Types.INTEGER, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR}, null, null);
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TEST", "ID", "" + Types.INTEGER, "INTEGER", "9",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "1", "NO"},
                { null, null, "TEST", "TEXT_V", "" + Types.VARCHAR, "VARCHAR",
                        "120", null, "0", "10",
                        "" + DatabaseMetaData.columnNullable, null, null, null,
                        null, null, "2", "YES"},
                { null, null, "TEST", "DEC_V", "" + Types.DECIMAL, "DECIMAL",
                        "12", null, "3", "10",
                        "" + DatabaseMetaData.columnNullable, null, null, null,
                        null, null, "3", "YES"},
                { null, null, "TEST", "DATE_V", "" + Types.TIMESTAMP,
                        "DATETIME", "0", null, "0", "10",
                        "" + DatabaseMetaData.columnNullable, null, null, null,
                        null, null, "4", "YES"},
                { null, null, "TEST", "BLOB_V", "" + Types.BLOB, "BLOB",
                        "1000000000", null, "0", "10",
                        "" + DatabaseMetaData.columnNullable, null, null, null,
                        null, null, "5", "YES"},
                { null, null, "TEST", "CLOB_V", "" + Types.CLOB, "CLOB",
                        "1000000000", null, "0", "10",
                        "" + DatabaseMetaData.columnNullable, null, null, null,
                        null, null, "6", "YES"}});
        // bug 'MySQL meta.getColumns unreadable' however the problem is with
        // all databases
        /*
         * rs=meta.getColumns(null,null,"TEST",null); while(rs.next()) { int
         * datatype=rs.getInt(5); }
         */
        trace("getIndexInfo");
        stat.executeUpdate("CREATE INDEX IDX_TEXT_DEC ON TEST(TEXT_V,DEC_V)");
        stat.executeUpdate("CREATE UNIQUE INDEX IDX_DATE ON TEST(DATE_V)");
        rs = meta.getIndexInfo(null, null, "TEST", false, false);
        testResultSetMeta(rs, 13, new String[] { "TABLE_CAT", "TABLE_SCHEM",
                "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME",
                "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC",
                "CARDINALITY", "PAGES", "FILTER_CONDITION"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIT,
                Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.SMALLINT,
                Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR}, null, null);
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TEST", "false", null, "IDX_DATE",
                        "" + DatabaseMetaData.tableIndexOther, "1", "DATE_V",
                        "A", null, null, null},
                { null, null, "TEST", "false", null, "PRIMARY_KEY",
                        "" + DatabaseMetaData.tableIndexOther, "1", "ID", "A",
                        null, null, null},
                { null, null, "TEST", "true", null, "IDX_TEXT_DEC",
                        "" + DatabaseMetaData.tableIndexOther, "1", "TEXT_V",
                        "A", null, null, null},
                { null, null, "TEST", "true", null, "IDX_TEXT_DEC",
                        "" + DatabaseMetaData.tableIndexOther, "2", "DEC_V",
                        "A", null, null, null},});
        stat.executeUpdate("DROP INDEX IDX_TEXT_DEC ON TEST");
        stat.executeUpdate("DROP INDEX IDX_DATE ON TEST");
        rs = meta.getIndexInfo(null, null, "TEST", false, false);
        testResultSetMeta(rs, 13, new String[] { "TABLE_CAT", "TABLE_SCHEM",
                "TABLE_NAME", "NON_UNIQUE", "INDEX_QUALIFIER", "INDEX_NAME",
                "TYPE", "ORDINAL_POSITION", "COLUMN_NAME", "ASC_OR_DESC",
                "CARDINALITY", "PAGES", "FILTER_CONDITION"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.BIT,
                Types.VARCHAR, Types.VARCHAR, Types.SMALLINT, Types.SMALLINT,
                Types.VARCHAR, Types.VARCHAR, Types.INTEGER, Types.INTEGER,
                Types.VARCHAR}, null, null);
        testResultSetOrdered(rs, new String[][] { { null, null, "TEST",
                "false", null, "PRIMARY_KEY",
                "" + DatabaseMetaData.tableIndexOther, "1", "ID", "A", null,
                null, null}});
        trace("getPrimaryKeys");
        rs = meta.getPrimaryKeys(null, null, "TEST");
        testResultSetMeta(rs, 6, new String[] { "TABLE_CAT", "TABLE_SCHEM",
                "TABLE_NAME", "COLUMN_NAME", "KEY_SEQ", "PK_NAME"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.SMALLINT, Types.VARCHAR}, null, null);
        testResultSetOrdered(rs, new String[][] { { null, null, "TEST", "ID",
                "1", "PRIMARY_KEY"},});
        trace("getTables - using a wildcard");
        stat
                .executeUpdate("CREATE TABLE T_2(B INT,A VARCHAR(6),C INT,PRIMARY KEY(C,A,B))");
        stat
                .executeUpdate("CREATE TABLE TX2(B INT,A VARCHAR(6),C INT,PRIMARY KEY(C,A,B))");
        rs = meta.getTables(null, null, "T_2", null);
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TX2", "TABLE", null},
                { null, null, "T_2", "TABLE", null}});
        trace("getTables - using a quoted _ character");
        rs = meta.getTables(null, null, "T\\_2", null);
        testResultSetOrdered(rs, new String[][] { { null, null, "T_2", "TABLE",
                null}});
        trace("getTables - using the % wildcard");
        rs = meta.getTables(null, null, "%", null);
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TEST", "TABLE", null},
                { null, null, "TX2", "TABLE", null},
                { null, null, "T_2", "TABLE", null}});
        stat.execute("DROP TABLE TEST");

        trace("getColumns - using wildcards");
        rs = meta.getColumns(null, null, "___", "B%");
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TX2", "B", "" + Types.INTEGER, "INTEGER", "9",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "1", "NO"},
                { null, null, "T_2", "B", "" + Types.INTEGER, "INTEGER", "9",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "1", "NO"},});
        trace("getColumns - using wildcards");
        rs = meta.getColumns(null, null, "_\\__", "%");
        testResultSetOrdered(rs, new String[][] {
                { null, null, "T_2", "B", "" + Types.INTEGER, "INTEGER", "9",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "1", "NO"},
                { null, null, "T_2", "A", "" + Types.VARCHAR, "VARCHAR", "6",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "2", "NO"},
                { null, null, "T_2", "C", "" + Types.INTEGER, "INTEGER", "9",
                        null, "0", "10", "" + DatabaseMetaData.columnNoNulls,
                        null, null, null, null, null, "3", "NO"},});
        trace("getIndexInfo");
        stat.executeUpdate("CREATE UNIQUE INDEX A_INDEX ON TX2(B,C,A)");
        stat.executeUpdate("CREATE INDEX B_INDEX ON TX2(A,B,C)");
        rs = meta.getIndexInfo(null, null, "TX2", false, false);
        testResultSetOrdered(rs, new String[][] {
                { null, null, "TX2", "false", null, "A_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "1", "B", "A",
                        null, null, null},
                { null, null, "TX2", "false", null, "A_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "2", "C", "A",
                        null, null, null},
                { null, null, "TX2", "false", null, "A_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "3", "A", "A",
                        null, null, null},
                { null, null, "TX2", "false", null, "PRIMARY_KEY",
                        "" + DatabaseMetaData.tableIndexOther, "1", "C", "A",
                        null, null, null},
                { null, null, "TX2", "false", null, "PRIMARY_KEY",
                        "" + DatabaseMetaData.tableIndexOther, "2", "A", "A",
                        null, null, null},
                { null, null, "TX2", "false", null, "PRIMARY_KEY",
                        "" + DatabaseMetaData.tableIndexOther, "3", "B", "A",
                        null, null, null},
                { null, null, "TX2", "true", null, "B_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "1", "A", "A",
                        null, null, null},
                { null, null, "TX2", "true", null, "B_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "2", "B", "A",
                        null, null, null},
                { null, null, "TX2", "true", null, "B_INDEX",
                        "" + DatabaseMetaData.tableIndexOther, "3", "C", "A",
                        null, null, null},});
        trace("getPrimaryKeys");
        rs = meta.getPrimaryKeys(null, null, "T_2");
        testResultSetOrdered(rs, new String[][] {
                { null, null, "T_2", "A", "2", "PRIMARY_KEY"},
                { null, null, "T_2", "B", "3", "PRIMARY_KEY"},
                { null, null, "T_2", "C", "1", "PRIMARY_KEY"},});
        stat.executeUpdate("DROP TABLE TX2");
        stat.executeUpdate("DROP TABLE T_2");
        stat.executeUpdate("CREATE TABLE PARENT(ID INT PRIMARY KEY)");
        stat
                .executeUpdate("CREATE TABLE CHILD(P_ID INT,ID INT,PRIMARY KEY(P_ID,ID),FOREIGN KEY(P_ID) REFERENCES PARENT(ID))");
        
        trace("getImportedKeys");
        rs = meta.getImportedKeys(null, null, "CHILD");
        testResultSetMeta(rs, 14, new String[] { "PKTABLE_CAT",
                "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME",
                "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME",
                "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE",
                "FK_NAME", "PK_NAME", "DEFERRABILITY"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.VARCHAR,
                Types.VARCHAR, Types.SMALLINT}, null, null);
        // MySQL bug
        // testResultSetOrdered(rs, new String[][] { { null, null, "PARENT", "ID",
        //        null, null, "CHILD", "P_ID", "1",
        //        "" + DatabaseMetaData.importedKeyNoAction,
        //        "" + DatabaseMetaData.importedKeyNoAction, "FK_1", null,
        //        "" + DatabaseMetaData.importedKeyNotDeferrable}});
        
        trace("getExportedKeys");
        rs = meta.getExportedKeys(null, null, "PARENT");
        testResultSetMeta(rs, 14, new String[] { "PKTABLE_CAT",
                "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME",
                "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME",
                "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE",
                "FK_NAME", "PK_NAME", "DEFERRABILITY"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.VARCHAR,
                Types.VARCHAR, Types.SMALLINT}, null, null);
        /*
         * testResultSetOrdered(rs, new String[][]{ { null,null,"PARENT","ID",
         * null,null,"CHILD","P_ID",
         * "1",""+DatabaseMetaData.importedKeyNoAction,""+DatabaseMetaData.importedKeyNoAction,
         * null,null,""+DatabaseMetaData.importedKeyNotDeferrable } } );
         */
        trace("getCrossReference");
        rs = meta.getCrossReference(null, null, "PARENT", null, null, "CHILD");
        testResultSetMeta(rs, 14, new String[] { "PKTABLE_CAT",
                "PKTABLE_SCHEM", "PKTABLE_NAME", "PKCOLUMN_NAME",
                "FKTABLE_CAT", "FKTABLE_SCHEM", "FKTABLE_NAME",
                "FKCOLUMN_NAME", "KEY_SEQ", "UPDATE_RULE", "DELETE_RULE",
                "FK_NAME", "PK_NAME", "DEFERRABILITY"}, new int[] {
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                Types.SMALLINT, Types.SMALLINT, Types.SMALLINT, Types.VARCHAR,
                Types.VARCHAR, Types.SMALLINT}, null, null);
        /*
         * testResultSetOrdered(rs, new String[][]{ { null,null,"PARENT","ID",
         * null,null,"CHILD","P_ID",
         * "1",""+DatabaseMetaData.importedKeyNoAction,""+DatabaseMetaData.importedKeyNoAction,
         * null,null,""+DatabaseMetaData.importedKeyNotDeferrable } } );
         */
        
        
        
        rs = meta.getSchemas();
        testResultSetMeta(rs, 1, new String[] { "TABLE_SCHEM"}, new int[] { Types.VARCHAR}, null, null);
        check(!rs.next());

        rs = meta.getCatalogs();
        testResultSetMeta(rs, 1, new String[] { "TABLE_CAT"}, new int[] { Types.VARCHAR}, null, null);
        check(!rs.next());

        rs = meta.getTableTypes();
        testResultSetMeta(rs, 1, new String[] { "TABLE_TYPE"}, new int[] { Types.VARCHAR}, null, null);
        testResultSetOrdered(rs, new String[][] { { "TABLE" } });
        
        rs = meta.getTypeInfo();
        testResultSetMeta(rs, 18,  new String[]{
                    "TYPE_NAME","DATA_TYPE","PRECISION","LITERAL_PREFIX",
                    "LITERAL_SUFFIX","CREATE_PARAMS","NULLABLE","CASE_SENSITIVE",
                    "SEARCHABLE","UNSIGNED_ATTRIBUTE","FIXED_PREC_SCALE",
                    "AUTO_INCREMENT","LOCAL_TYPE_NAME","MINIMUM_SCALE",
                    "MAXIMUM_SCALE","SQL_DATA_TYPE","SQL_DATETIME_SUB",
                    "NUM_PREC_RADIX"
                },
                new int[]{
                    Types.VARCHAR,Types.SMALLINT,Types.INTEGER,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,
                    Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,
                    Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,Types.INTEGER,
                    Types.INTEGER,Types.INTEGER
                }   ,null, null
        );
        
        
        check(conn.getWarnings()==null);
        conn.clearWarnings();
        check(conn.getWarnings()==null);
        
    }
}
