/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;
import org.ldbc.jdbc.*;
import java.sql.*;
import java.io.*;

/**
 *
 * Link for docs:
 *
 * Version:
 * IBM DB2 07.02.0000 (DB2/NT) on Windows XP
 * JDBC Version: IBM DB2 JDBC 1.2 Type 3
 *
 * Driver:
 * There is a folder java with the driver db2java.zip.
 * This is a JDK 1.1.x driver, and does not support JDK 1.2 extensions.
 * It is possible to create another file db2java.zip in the folder java12 
 * by running jdbc20.exe in this folder. But using this driver throws the
 * exception: COM.ibm.db2.jdbc.DB2Exception: 
 * [IBM][JDBC Driver] CLI0621E  Unsupported JDBC Server configuration.
 * In the help, there is some information for this error:
 * Explanation: The target JDBC Server configuration is not supported. 
 * If you are running the Control Center, the target JDBC Server must be a 
 * standalone db2jd process (started via db2jstrt) and not a 2-tier native JDBC Server. 
 * User Response: Reconfigure the JDBC Server using db2jstrt on the port targeted 
 * by the Control Center. 
 *
 * Known issues:
 *
 * The name of the primary key index is not consistent. With getPrimaryKeys, the name
 * if for example 
 * SQL021130172846870 and with getIndexInfo it could be 
 * SQL021130172846640.
 *
 * ResultSet.getFetchSize is not implemented (JDK 1.2)
 *
 * Problem with cursor state:
 * COM.ibm.db2.jdbc.DB2Exception: 
 * [IBM][CLI Driver] CLI0115E  Invalid Cursor State. SQLSTATE=24000
 * It seems DB2 does not automatically close resultsets. This test case fails:
 * stat.execute("CREATE TABLE TEST(ID INT)");
 * stat.execute("SELECT * FROM TEST");
 * stat.execute("DROP TABLE TEST"); // fails here
 * however this works:
 * stat.execute("CREATE TABLE TEST(ID INT)");
 * stat.execute("SELECT * FROM TEST");
 * ResultSet rs=stat.getResultSet();
 * stat.execute("DROP TABLE TEST");
 *
 * Binary constant can only be stored to a blob column if the function
 * BLOB is used, for example with the table
 * CREATE TABLE TEST(ID INT PRIMARY KEY,VALUE BLOB)
 * this doesn't work:
 * INSERT INTO TEST VALUES(1,X'01010101')
 * however, this works:
 * INSERT INTO TEST VALUES(1,BLOB(X'01010101'))
 *
 * ResultSet.getCharacterStream is not implemented
 * An java.lang.AbstractMethodError is thrown
 *
 * This query is not allowed:
 * SELECT NULL FROM TEST
 * However, here is a workaround:
 * SELECT NULLIF(1,1) FROM TEST
 *
 * Can not cast integer directly to varchar. This query doesn't work:
 * select cast(1 as varchar(255)) from test
 * In all other database, it works.
 * This workaround is used:
 * select rtrim(cast(cast(1 as char(254)) as varchar(255))) from test
 *
 * DatabaseMetaData resultsets must be explicitly closed before the method
 * setTransactionIsolation can be called. This is not required in all other databases.
 * This code will throw an exception:
 * Connection c1=DriverManager.getConnection("jdbc:db2://localhost/ldbc","ldbc","ldbc");
 * DatabaseMetaData meta=c1.getMetaData();
 * ResultSet rs=meta.getTables(null,null,null,new String[]{"TABLE"});
 * while(rs.next());
 * c1.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
 * COM.ibm.db2.jdbc.DB2Exception: [IBM][CLI Driver] CLI0126E  Operation not valid at this point. SQLSTATE=HY011
 *
 * After calling prep.setNull(parameterIndex,Types.BLOB), the call to
 * prep.executeUpdate();
 * throws this exception:
 * COM.ibm.db2.jdbc.DB2Exception: [IBM][CLI Driver] CLI0122E  Invalid value for this program type. SQLSTATE=HY003
 *
 * If a blob of some bigger size (for example 400000) is used, then after calling
 * prep.setBinaryStream(2,new ByteArrayInputStream(big2),big2.length);
 * the call to
 * prep.executeUpdate();
 * can throw this exception:
 * java.lang.ArrayIndexOutOfBoundsException
 * at COM.ibm.db2.jdbc.net.DB2PreparedStatement.loadParameters(DB2PreparedStatement.java:481)
 * at COM.ibm.db2.jdbc.net.DB2PreparedStatement.execute2(DB2PreparedStatement.java:665)
 * at COM.ibm.db2.jdbc.net.DB2PreparedStatement.executeUpdate(DB2PreparedStatement.java:583)
 * However setBytes with 400000 bytes works.
 *
 * prep.setCharacterStream(parameterIndex,x,length);
 * is not implemented and calling it throws the exception:
 * java.lang.AbstractMethodError
 * But setString works even with a big (400000 character) String
 * 
 * DatabaseMetaData.getKeywords reports.
 * ...ENCODING,END-EXEC1,ERASE...
 * what should the dash mean? And is EXEC1 really a keyword?
 * 
 * Tables can not be renamed if they are referenced.
 */
public class DB2 extends Base implements Adapter {
    // url: jdbc:db2://localhost/ldbc
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "COM.ibm.db2.jdbc.net.DB2Driver";
    }
    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.DATE:
            return "DATE";
        case Types.TIME:
            return "TIME";
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        case Types.CLOB:
            return "CLOB(2000000)";
        case Types.BLOB:
            return "BLOB(2000000)";
        }
        return getDefaultDataTypeString(type);
    }
    public void convertDataType(DataType type) throws SQLException {
         switch(type.getDataType()) {
        case Types.LONGVARBINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }
    public String truncateIndexName(String indexName) {
        if(indexName==null) {
            return null;
        }
        if(indexName.startsWith("SQL") && indexName.length()>14) {
            return "SQL000000000000000";
        }
        return indexName;
    }
    public String getDropIndexSQL(String tableName,String uniqueIndexName) {
        return "DROP INDEX "+quote(uniqueIndexName);
    }
    public String getBinaryConstant(String s) {
        return "BLOB(X'"+s+"')";
    }
    public Reader getCharacterStream(ResultSet rs,int columnIndex) throws SQLException {
        String s=rs.getString(columnIndex);
        if(s==null) {
            return null;
        }
        return new StringReader(s);
    }
    public String getNullConstant() {
        return "NULLIF(1,1)";
    }
    public String getCast(String value,DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.VARCHAR:
            // special case: numbers can only be converted to char

            return "RTRIM(CAST(CAST("+value+" AS CHAR(254)) AS VARCHAR(255)))";
        }
        String s=getDataTypeString(type, false);
        return "CAST("+value+" AS "+s+")";
    }
    public String getNow() throws SQLException {
        return "CURRENT TIMESTAMP";
    }
    public void setNull(jdbcPreparedStatement prep,int parameterIndex, int sqlType) throws SQLException {
        if(sqlType==Types.CLOB) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.VARCHAR);
        } else if(sqlType==Types.BLOB){
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.BINARY);
        } else {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),sqlType);
        }
    }
    synchronized public void setBinaryStream(jdbcPreparedStatement prep,int parameterIndex, InputStream x, int length) throws SQLException {
        if(x==null) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.BINARY);
            return;
        }
        byte[] buffer=new byte[length];
        int offset=0;
        try {
            while(length>0) {
                int i=x.read(buffer,offset,length);
                offset+=i;
                length-=i;
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
        prep.getVendorObject().setBytes(prep.translateParameterIndex(parameterIndex),buffer);
    }
    public void setCharacterStream(jdbcPreparedStatement prep,int parameterIndex,Reader x,int length) throws SQLException {
        if(x==null) {
            prep.getVendorObject().setNull(prep.translateParameterIndex(parameterIndex),Types.VARCHAR);
            return;
        }
        char[] buffer=new char[length];
        int offset=0;
        try {
            while(length>0) {
                int i=x.read(buffer,offset,length);
                offset+=i;
                length-=i;
            }
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
        prep.getVendorObject().setString(prep.translateParameterIndex(parameterIndex),new String(buffer));
    }
    public String getDefaultLikeEscape() {
        // escape '\'
        return "ESCAPE '\\'";
    }
    public String getRenameStatement(String tableName, String newName) throws SQLException {
        return "RENAME TABLE "+quote(tableName)+" TO "+quote(newName);
    }
}
