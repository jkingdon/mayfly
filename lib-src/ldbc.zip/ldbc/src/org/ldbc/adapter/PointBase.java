/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;

import java.sql.*;
import java.io.*;

/**
 * Known issues:
 *
 * The character $ is not supported as part of an identifier (table name and so on).
 *
 * DatabaseMetaData.getColumns, column NUM_PREC_RADIX is of data type DECIMAL, should be INT
 * (workaround implemented in the JDBC driver)
 *
 * ORDER BY is only allowed by columns that are in the select list (this is
 * according to the standard, but other databases don't have this restriction).
 *
 * ResultSet.getString() on a DECIMAL data type should return the value formatted
 * for example for DECIMAL(10,2) the returned value should be 0.00 and not 0
 *
 * ResultSetMetaData problem
 * SELECT CAST(1 AS VARCHAR(255)) FROM TEST
 * This is reported as a CHAR instead of a VARCHAR
 *
 * SIGN is not implemented, it is ANSI standard
 *
 * Should throw a exception if PreparedStatement.setObject(1,null) is called.
 * See also JDBC API Tutorial and Reference, Second Edition,
 * page 544, 24.1.5 Sending JDBC NULL as an IN parameter 
 *
 * NAME is a keyword such as 
 * CREATE TABLE TEST(ID INT) (works)
 * CREATE TABLE NAME(ID INT) (works)
 * SELECT * FROM TEST NAME (throws an exception)
 * There is a lot of such pseudo-keyword, but the words DATA and NAME
 * are problematic as they are used quite often.
 *
 * ResultSet.getRow is not supported for 'regular' ResultSets.
 * According to the specs, this method should work.
 *
 * ResultSet.setFetchSize(100) after Statement.setMaxRows(50) should throw
 * an exception, but doesn't.
 *
 * PreparedStatement.setDate, Time, Timestamp and ResultSet.getDate, Time, Timestamp with calendar
 * are not implemented correctly.
 *
 * BatchUpdates bug:
 * The batch is not cleared after executing it.
 *
 * PreparedStatement.setBytes(2,null); throws a NullPointerException
 *
 * PointBase doesn't support ResultSet.getString on a CLOB.
 * An exception is thrown:
 * java.sql.SQLException: Data Exception -- data is a stream of bytes for parameter 1
 * This conversion is required according to the 
 * JDBC API Tutorial an Reference, Second Edition, page 935,
 * 47.9.6, Conversions by ResultSet.getXXX Methods). 
 *
 * With autocommit switched on, only open open resultset at a time is supported.
 * When trying to open another one (using a different statement), the first one
 * is closed. All other tested databases do not behave in this way.
 * Code example:
 * Statement s1=conn.createStatement();
 * Statement s2=conn.createStatement();
 * ResultSet rs1=s1.executeQuery("SELECT * FROM TEST");
 * ResultSet rs2=s1.executeQuery("SELECT * FROM TEST");
 * rs1.next();
 * rs2.next();
 * java.sql.SQLException: This result set has been invalidated. 
 *
 * DatabaseMetaData.getImportedKeys, getExportedKeys and getCrossReference
 * return the wrong data type for many columns. 
 * 
 * This database automatically shrinks the precision of decimal values if
 * the value ends with 0s: -52005.2400 becomes -52005.24
 */ 
public class PointBase extends Base implements Adapter {

    // url: jdbc:pointbase:sample;create=true

    public String getName() {
        return getClass().getName();
    }

    public String getDriverClass() {
        return "com.pointbase.jdbc.jdbcUniversalDriver";
    }
    
    protected String getExceptionMap() {
    	return "22004="+Messages.INSERT_NULL+" 22028="+Messages.INSERT_NULL+
    	" ZD017="+Messages.COLUMN_ALREADY_EXISTS;
	}

    public String getDataTypeString(DataType type, boolean autoIncrement) throws SQLException {
        int datatype=type.getDataType();
        switch(datatype) {
        case Types.TIMESTAMP:
            return "TIMESTAMP";
        case Types.CLOB:
            return "CLOB("+Integer.MAX_VALUE+")";
        case Types.BLOB:
            return "BLOB("+Integer.MAX_VALUE+")";
        }
        return getDefaultDataTypeString(type);
    }

    public void convertDataType(DataType type) throws SQLException {
        switch(type.getDataType()) {
        case Types.LONGVARBINARY:
            type.update(Types.BLOB,0,0);
            break;
        case Types.LONGVARCHAR:
            type.update(Types.CLOB,0,0);
            break;
        case Types.CHAR:
            type.update(Types.VARCHAR,type.getPrecision(),0);
            break;
        case Types.BIGINT:
        	type.update(Types.INTEGER, 0, 0);
        }
        type.update(type.getDataType(),type.getPrecision(),type.getScale());
    }

    public String getNow() throws SQLException {
        return "CURRENT_TIMESTAMP";
    }

    public String getClobString(ResultSet rs,int columnIndex) throws SQLException {
        Reader reader=rs.getCharacterStream(columnIndex);
        if(reader==null) {
            return null;
        }
        StringBuffer buffer=new StringBuffer();
        try {
            while(true) {
                int c=reader.read();
                if(c==-1) {
                    break;
                }
                buffer.append((char)c);
            }
            return buffer.toString();
        } catch(IOException e) {
            throw convertThrowable(e);
        }
    }

    public boolean isSystemIndex(String tablename, String indexname) {
        if(indexname.equals("PRIMARY_KEY")) {
            return false;
        }
        if(!indexname.startsWith(tablename+"_")) {
            return true;
        }
        if(indexname.indexOf("SYSTEMNAMEDCONSTRAINT")>=0) {
            return true;
        }
        return false;
    }
    
    public String getSelect(boolean distinct, String top, String rest) throws SQLException {
        String select="SELECT ";
        if(distinct) {
            select+="DISTINCT ";
        }
        select+=rest;
        return select;     
    }
    
}
