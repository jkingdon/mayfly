/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.or;

import java.sql.*;
import java.util.*;
import java.lang.reflect.*;

/**
 * This is the main class of the persistency layer / object-relation mapping
 * library. Advantages of this library:
 * <ul>
 * <li>Really easy to use and learn. Only two classes and one exception type.
 * <li>No need to read a lot of documentation.
 * <li>Lean and fast library.
 * <li>Real-world, practical and simple API.
 * <li>Simple application code that is easy to write, understand and maintain.
 * <li>Based on standards: uses SQL as the query language.
 * <li>Significantly simplifies the application code.
 * <li>No need to write boilerplate code.
 * <li>No need to write any exception handling code if you don't want to.
 * <li>Prevents bugs, because most of the code can be checked at compile time.
 * <li>No need to maintain any XML, config files or Javadoc tags.
 * <li>Does not require a special build process.
 * <li>Open Source: free, and no dependency on a company to maintain it.
 * <li>Apache style license: no problems integrating it into any application.
 * <li>Clean, compact, and well documented source code.
 * <li>Can be combined with JDBC / SQL code if required (for example, to use
 * database specific optimizations).
 * </ul>
 */
public class Database {

    private Connection conn;
    private Hashtable tables = new Hashtable();

    /**
     * Connects to a database. The url must be of the form jdbc:xxx:yyy or
     * jdbc:ldbc:xxx:yyy. Only databases that are compatible with LDBC are
     * supported. It is not required to load/register the driver class before
     * calling this method.
     * 
     * @param url the url
     * @param user the user name
     * @param password the password
     */
    public static Database connect(String url, String user, String password) {
        return new Database(url, user, password);
    }

    private Database(String url, String user, String password) {
        if (!url.startsWith("jdbc:ldbc:")) {
            url = "jdbc:ldbc:" + url.substring(5);
        }
        String driver = "org.ldbc.jdbc.jdbcDriver";
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new DatabaseException(
                    "Driver class " + driver + " not found", e);
        }
        try {
            //log(url);
            conn = DriverManager.getConnection(url, user, password);
        } catch (Throwable e) {
            throw new DatabaseException("Error connecting to " + url
                    + " with user " + user, e);
        }
    }
    
    /**
     * Stores an object in the database. If there is a auto-increment primary
     * key, and this field is zero when this method is called, then the field
     * is updated with the actual value stored in the database. The first value
     * used is 1. If the value is not zero, then this value is used to store
     * the row (even if there is no row with this value).
     * 
     * @param obj the object to be saved
     */
    public void save(Object obj) {
        Table table = getTable(obj.getClass());
        table.save(obj);
    }

    /**
     * Loads an object from the database with the specified primary key. If no
     * row with this key is found, null is returned.
     * 
     * @param c the class of the object
     * @param key the key as an integer
     * @return the object or null if no object was found
     */
    public Object load(Class c, int key) {
        Table table = getTable(c);
        return table.loadByKey(new Integer(key));
    }

    /**
     * Loads an object from the database with the specified primary key. If a
     * row with this key is not found, null is returned.
     * 
     * @param c the class of the object
     * @param key the key as an object
     * @return the object or null if no object was found
     */
    public Object load(Class c, Object key) {
        Table table = getTable(c);
        return table.loadByKey(key);
    }
    
    /**
     * Deletes a row in the database.
     * 
     * @param obj the object to be deleted
     * @return true if the row existed and was deleted; false if no such row
     *         was found
     */
    public boolean delete(Object obj) {
        Table table = getTable(obj.getClass());
        return table.delete(obj);
    }
    
    /**
     * Create a new Command object from a given condition or SELECT statement. 
     * In the command, the SQL column names must be used; Java field names are not
     * translated to database column names. This allows to copy and paste the command
     * from a database tool to the application. 
     * Instead of constant values, the parameter ('?') should be used. 
     * The values can then be set by using the setX(...) methods in the command. 
     * <p>
     * Use null or an empty String to retrieve all rows of a table.
     * <p> 
     * The command may contains just the WHERE part of a SELECT statement:<br>
     * NAME=? AND FIRST_NAME=? <br>
     * ID=? OR NAME LIKE ?<br>
     * NAME=? OR NAME IS NULL
     * <p>
     * The command may also contain a sort order, or consist only of the sort order:<br>
     * NAME=? ORDER BY NAME<br>
     * ORDER BY LAST_NAME, FIRST_NAME
     * <p>
     * The command can also be a complete SELECT statement. This allows complex queries.<br>
     * SELECT E.* FROM COMPANY C, EMPLOYEE E WHERE C.NAME=? AND E.C_ID = C.ID<br>
     * Please note that the result set of the command must contain only columns for this object.
     * 
     * @param command the command
     * @return the Query object
     */
    public Command createCommand(Class c, String command) {
        Table table = getTable(c);
        return new Command(table, command);
    }
    
    /**
     * Create a new Command object from a given statement. 
     * In the command, the SQL column names must be used; Java field names are not
     * translated to database column names. This allows to copy and paste the command
     * from a database tool to the application. 
     * Instead of constant values, the parameter ('?') should be used. 
     * The values can then be set by using the setX(...) methods in the command. 
     * <p>
     * The command can be command a SELECT, INSERT, UPDATE or DELETE. 
     * <p>
     * @param command the query
     * @return the Query object
     */
    public Command createCommand(String command) {
        return new Command(this, command);
    }

    /**
     * Maps a class to a table using the manual mapping mode.
     * The table is created if required.
     * <P>
     * When using the manual mapping mode, the mapping has to be specified in
     * the parameter 'map'. The map is a SQL statement (or a list of SQL
     * statements, separated by semicolon) where the mapped Java variable names
     * are in remarks, just before the column names of the table. Other remarks
     * are not allowed. Example: CREATE TABLE TEST( /* id *<b></b>/ T_ID INT, /*
     * name *<b></b>/ T_NAME VARCHAR(200), PRIMARY KEY(T_ID)); CREATE INDEX
     * IDX_NAME ON TEST(T_NAME);
     * <p>
     * If the class has a public constructor with a Database object, then this
     * constructor is used. Otherwise, the class needs to have a public constructor
     * without parameters.
     * <p>
     * This method must be called before accessing the table.
     * 
     * @param c the class to map
     * @param map the mapping between the class and the database table. If this
     *        parameter is null, then a default mapping is used.
     */
    public void map(Class c, String map) {
        // TODO: remove '_' in columns as an option
        // TODO: 1.5 compatibility with tags (metadata) 
        DatabaseException.check(map!=null, "Parameter map may not be null for class "+c.getName());
        Table table = (Table) tables.get(c);
        if (table != null) {
            DatabaseException.check(map.equals(table.map),
                    "Class " + c.getName() + " is already mapped differently; old: "
                            + table.map + " new: " + map);
            return;
        }
        table = mapClassToTable(c, map);
        tables.put(c, table);
    }
    
    /**
     * Maps a class to a table using the automatic mapping mode. 
     * The table is created if required.
     * <P>
     * In this mode, the table name is equal to the class name and the column names 
     * are equal to the public field names (or getter/setter methods if no public
     * fields are defined).
     * <P>
     * Java objects are automatically mapped
     * to the SQL data types. Integer and int are mapped to INTEGER, String to
     * VARCHAR and so on. There are some special cases:
     * <ul>
     * <li>If the field ends with 'key', it is used as the primary key (for
     * example, id_key or NameKey).
     * <li>If the field is an integer, starts with 'auto' and ends with 'key'
     * (for example: autoIdKey), it is used as the autoincrement primary key.
     * <li>CLOB: Character arrays (char[]) are mapped to CLOB. If the field
     * ends with 'Clob' and is a String, it is also mapped to CLOB.
     * </ul>
     * <P>
     * If the class has a public constructor with a Database object, then this
     * constructor is used. Otherwise, the class needs to have a public constructor
     * without parameters.
     * <P>
     * This method must be called before accessing the table.
     * <P>
     * @param c the class to map
     */
    public void map(Class c) {
        Table table = (Table) tables.get(c);
        if (table != null) {
            DatabaseException.check(table.map == null,
                    "Class " + c + " is already mapped manually: "
                            + table.map);
            return;
        }
        table = mapClassToTable(c, null);
        tables.put(c, table);
    }

    /**
     * Runs a statement against the database. The update count of the
     * statement is returned. This method throws an exception for SELECT statements.
     * 
     * @return the update count
     */
    public int run(String sql) {
        try {
            Statement stat = conn.createStatement();
            int count = stat.executeUpdate(sql);
            return count;
        } catch (Throwable e) {
            throw new DatabaseException("Error executing command "
                    + sql, e);
        }
    }

    private Table mapClassToTable(Class c, String map) {
        DatabaseException.check(Modifier.isPublic(c.getModifiers()), "Class "+c.getName()+" is not public");
        if (map == null) {
            String tableName = getTableNameFromClass(c);
            ArrayList fields = getAllFields(c);
            initDefaultMapping(fields);
            return new Table(this, tableName, c, fields, map);
        }
        return getTableFromMap(c, map);
    }
    
    private void initDefaultMapping(ArrayList fields) {
        // copy field names to column names and init default mapping
        for(int i=0; i<fields.size();i++) {
            Column column = (Column) fields.get(i);
            column.columnName = column.fieldName;           
            column.initDefaultMapping();
        }
    }

    private Table getTable(Class c) {
        //log("getTable "+c);
        Table t = (Table) tables.get(c);
        if (t == null) {
            t = mapClassToTable(c, null);
            tables.put(c, t);
        }
        return t;
    }

    private static String getTableNameFromClass(Class c) {
        String tableName = c.getName();
        int lastDot = tableName.lastIndexOf('.');
        if (lastDot > 0) {
            tableName = tableName.substring(lastDot + 1);
        }
        return tableName.toUpperCase();
    }

    private Table getTableFromMap(Class c, String map) {
        ArrayList fields = getAllFields(c);
        String tableName = null;
        Hashtable fieldMap = new Hashtable();
        for (Iterator it = fields.iterator(); it.hasNext();) {
            Column col = (Column) it.next();
            fieldMap.put(col.fieldName.toUpperCase(), col);
        }
        fields.clear();
        StringTokenizer tok = new StringTokenizer(map, ";,.()/* \t\n\r\f", true);
        String last1 = null, last2 = null;
        Column column = null;
        Hashtable columnMap = new Hashtable();
        while (tok.hasMoreElements()) {
            String token = tok.nextToken();
            if (token.equals("(")) {
                // the first tableName '('
                if(tableName == null) {
                    tableName = last1.toUpperCase();
                }
            } else if (token.equals("/") && "*".equals(last1)) {
                // fieldName '*' '/'
                String fieldName = last2;
                column = (Column) fieldMap.get(fieldName.toUpperCase());
                DatabaseException.check(column != null, "Field " + fieldName
                        + " not found in the class " + c.getName());
            } else if (!Character.isWhitespace(token.charAt(0))) {
                if (column != null) {
                    // last word was a field name: then this is a columnName
                    String columnName = token.toUpperCase();
                    column.columnName = columnName; 
                    columnMap.put(columnName, column);
                    fields.add(column);
                    column = null;
                }
                last2 = last1;
                last1 = token;
            }
        }
        if (Table.doesTableExist(conn, tableName)) {
            mapRemainingFields(tableName, fieldMap, columnMap);
            readPrimaryKeyFromTable(tableName, columnMap);
        } else if (map != null) {
            createTableFromScript(tableName, map);
            mapRemainingFields(tableName, fieldMap, columnMap);
            readPrimaryKeyFromTable(tableName, columnMap);
        }
        ArrayList mappedFields = new ArrayList(columnMap.values());
        Table table = new Table(this, tableName, c, mappedFields, map);
        return table;
    }

    private void mapRemainingFields(String table, Hashtable fields,
            Hashtable columns) {
        try {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                String columnName = rs.getString("COLUMN_NAME");
                Column column = (Column) columns.get(columnName);
                if (column == null) {
                    // column not yet mapped
                    // maybe there is a field with this name
                    column = (Column) fields.get(columnName);
                    if (column != null) {
                        column.columnName = columnName;
                        columns.put(columnName, column);
                    }
                }
            }
        } catch (Throwable e) {
            throw new DatabaseException(
                    "Error mapping columns to fields for table " + table, e);
        }
    }

    private void createTableFromScript(String table, String map) {
        try {
            Statement stat = conn.createStatement();
            StringTokenizer tok = new StringTokenizer(map, ";");
            while (tok.hasMoreElements()) {
                String sql = tok.nextToken();
                stat.execute(sql);
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error creating table " + table
                    + " from script " + map, e);
        }
    }

    private void readPrimaryKeyFromTable(String table, Hashtable columns) {
        try {
            DatabaseMetaData meta = conn.getMetaData();
            ResultSet rs = meta.getPrimaryKeys(null, null, table);
            while (rs.next()) {
                String columnName = rs.getString("COLUMN_NAME");
                Column column = (Column) columns.get(columnName);
                DatabaseException.check(column != null,
                        "The class does not contain a mapping for the primary key column "
                                + columnName);
                column.setPrimaryKey();
            }
            rs = meta.getColumns(null, null, table, null);
            while (rs.next()) {
                String columnName = rs.getString("COLUMN_NAME");
                String typeName = rs.getString("TYPE_NAME");
                Column column = (Column) columns.get(columnName);              
                if (typeName.endsWith("AUTOINCREMENT")) {
                    DatabaseException.check(column != null,
                            "The autoincrement column " + columnName
                                    + " not found");
                    column.setAutoIncrement();
                }
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error reading primary key from table "
                    + table, e);
        }
    }

    private void getAllPublicFields(Class c, ArrayList columns) throws SecurityException {
        Field[] allfields = c.getFields();
        for (int i = 0; i < allfields.length; i++) {
            Field f = allfields[i];
            int modifiers = f.getModifiers();
            if (!Modifier.isPublic(modifiers)
                    || Modifier.isStatic(modifiers)) {
                continue;
            } else if(!Column.isKnownType(f.getType())) {
                continue;
            }
            Column column = new Column(f);
            columns.add(column);
        }
    }
    
    private void getAllPublicGetters(Class c, ArrayList columns) throws SecurityException {
        Method[] methods = c.getDeclaredMethods();
        Hashtable getters = new Hashtable();
        Hashtable setters = new Hashtable();
        for (int i = 0; i < methods.length; i++) {
            Method m = methods[i];
            //log("method "+m);
            int modifiers = m.getModifiers();
            if (!Modifier.isPublic(modifiers)
                    || Modifier.isStatic(modifiers)) {
                continue;
            }
            String name = m.getName();
            if (name.length() < 4) {
                // getX or setX are at least 4 characters long
                continue;
            }
            if (!Character.isUpperCase(name.charAt(3))) {
                continue;
            }
            if (name.startsWith("get")) {
                //log("getter: "+name);
                if (m.getParameterTypes().length != 0) {
                    // getter does not have 0 parameters - ignore this
                    // method
                    continue;
                }
                if(!Column.isKnownType(m.getReturnType())) {
                    continue;
                }
                getters.put(name.substring(3), m);
            } else if (name.startsWith("set")) {
                //log("setter: "+name);
                if (m.getParameterTypes().length != 1) {
                    // setter has more or less than 1 parameter - ignore
                    // this method
                    continue;
                }
                if(!Column.isKnownType(m.getParameterTypes()[0])) {
                    continue;
                }
                setters.put(name.substring(3), m);
            }
        }
        for (Iterator iter = getters.keySet().iterator(); iter.hasNext();) {
            String name = (String) iter.next();
            Method g = (Method) getters.get(name);
            Method s = (Method) setters.get(name);
            if (s == null) {
                // only a getter, no setter
                continue;
            }
            Column column = new Column(g, s);
            columns.add(column);
        }
    }
    
    private ArrayList getAllFields(Class c) {
        try {
            DatabaseException.check(c.getName().indexOf('$')<0, "Inner classes are not supported");
            ArrayList columns = new ArrayList();
            getAllPublicFields(c, columns);
            if(columns.size()==0) {
                getAllPublicGetters(c, columns);
            }
            DatabaseException.check(columns.size() > 0,
                    "No public fields or setter/getters in class "+c.getName());
            return columns;
        } catch (SecurityException e) {
            throw new DatabaseException("Error accessing class: " + c, e);
        }
    }

    /**
     * Closes the database. This method ignores all database exceptions.
     */
    public void close() {
        if (conn != null) {
            try {
                conn.close();
            } catch (Throwable e) {
                // ignore
            }
            conn = null;
        }
    }

    /**
     * Gets a connection to the database. This connection should not be closed,
     * instead the method Database.close() should be used.
     * 
     * @return the connection
     */
    public Connection getConnection() {
        return conn;
    }

    void log(String s) {
        // TODO: improve logging mechanism
        System.out.println(s);
    }
}
