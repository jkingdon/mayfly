package org.ldbc.test;
import java.sql.*;
import java.util.*;

public class TestKeywords extends TestBase {
    String[] LEGAL=new String[]{
        "THISMUSTWORK","A","Z","K","M","G","ID","THIS_MUST_WORK","NAME","LAST"
    };
    String[] ILLEGAL=new String[]{
        "SELECT", "INSERT", "UPDATE", "DELETE", "CREATE", "DROP", "FROM",
        "WHERE", "AND", "AS", "ASC", "AVG", "BETWEEN", "BY", "CAST", 
        "COMMIT", "CREATE", "DELETE", "DISTINCT", "DROP", 
        "FALSE", "FROM", "GROUP", "IN", "INDEX", "INNER", "INSERT", "INTO", "IS", 
        "JOIN", "KEY", "LEFT", "LENGTH", "LIKE",
        "MAX", "MOD", "NOT", "NULL", "ON", "OR", "ORDER", 
        "OUTER", "PRIMARY", "REFERENCES", "RIGHT", "ROLLBACK", "SELECT", "SET", 
        "SUM", "TABLE", "TRUE", "UNIQUE", "UPDATE", "VALUES", "WHERE", 
        "COUNT", "MIN", "MAX", "SUM", "CONVERT", 
        "CHAR_LENGTH", "CONCAT", "LOWER", "LCASE", "UPPER", "UCASE",
        "NOW", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP",
        "CURDATE", "CURTIME", "TOP", "LIMIT", "Y","X",
    };
    
    public static void main(String[] argv) {
        new TestKeywords().test(argv);
    }
    Statement stat;
    void test(Connection conn) throws SQLException {
        DatabaseMetaData meta=conn.getMetaData();
        String keywords=meta.getSQLKeywords();
        trace("keywords: "+keywords);
        
        stat=conn.createStatement();
        ArrayList illegal=new ArrayList(Arrays.asList(ILLEGAL));
        // add the keywords from the meta data
        illegal.addAll(convertToList(keywords));
        List legal=new ArrayList(Arrays.asList(LEGAL));
        // maybe this database thinks it doesn't allow some more words
        DatabaseMetaData vmeta=((org.ldbc.jdbc.jdbcDatabaseMetaData)meta).getVendorObject();
        
        trace("keywords(vendor): "+vmeta.getSQLKeywords());
        List vendorlist=convertToList(vmeta.getSQLKeywords());
        
        // remove the elements we know already to be illegal
        vendorlist.removeAll(illegal);
        // they are not in the illegal list, therefore should be legal -
        // add them to the legal list
        legal.addAll(vendorlist);
        // check the legal ones
        boolean bug=false;
        List newfound=new ArrayList();
        Iterator iter=legal.iterator();
        while(iter.hasNext()) {
            String word=(String)iter.next();
            if(word.indexOf('$') != -1) {
                trace("Ignore $: "+word);
                continue;                
            }
            trace(word);
            try {
                // usage as table name
                test("CREATE TABLE "+word+"(I INT PRIMARY KEY,"+word+" INT)");
                test("INSERT INTO "+word+" VALUES(1,1)");
                test("UPDATE "+word+" SET "+word+"="+word+"+1");
                test("DELETE FROM "+word+" WHERE "+word+"=2");
                test("SELECT * FROM "+word);
                test("SELECT I AS "+word+","+word+" FROM "+word);
                test("SELECT "+word+".I AS "+word+","+word+" AS "+word+" FROM "+word+" "+word);
                test("DROP TABLE "+word);
                // usage as column name
                test("CREATE TABLE TEST("+word+" INT PRIMARY KEY)");
                test("SELECT "+word+" FROM TEST");
                test("SELECT "+word+" FROM TEST WHERE "+word+"=1");
                test("SELECT "+word+" AS "+word+" FROM TEST");
                test("SELECT "+word+" FROM TEST "+word+" WHERE "+word+"."+word+"=1");
                test("SELECT "+word+"."+word+" FROM TEST "+word);
                test("DROP TABLE TEST");
            } catch(SQLException e) {
                trace("fail:"+word+" reason:"+e);
                error(e);
                illegal.add(word.toUpperCase());
                newfound.add(word.toUpperCase());
                bug=true;
            }
        }
        if(bug) {
            dumpCorrectedList(illegal);
            StringBuffer buffer=new StringBuffer();
            iter=newfound.iterator();
            int len=0;
            while(iter.hasNext()) {
                if(buffer.length()>0) {
                    len+=2;
                    buffer.append(", ");
                }
                String word=iter.next().toString().toUpperCase();
                len+=2+word.length();
                if(len>50) {
                    buffer.append("\n");
                    len=0;
                }
                buffer.append('\"');
                buffer.append(word);
                buffer.append('\"');
            }
            error("Additional keywords found: \n"+buffer.toString());
        }
        iter=illegal.iterator();
        while(iter.hasNext()) {
            String word=(String)iter.next();
            trace("illegal: "+word);
            try {
                test("CREATE TABLE "+word+"(ID INT PRIMARY KEY)");
                error("not illegal: "+word);
            } catch(SQLException e) {
                // supposed to be illegal
            }
        }
    }
    private void dumpCorrectedList(List list) {
        TreeSet treeset=new TreeSet(list);

        // format the list so the source code can be patched easily 
        // it's not really the task of this driver, but simplifies development
        // of this driver
        Iterator iterator=treeset.iterator();
        StringBuffer key=new StringBuffer("    \"");
        StringBuffer sql=new StringBuffer("    ");
        int keylen=0,sqllen=0;
        for(int i=0;iterator.hasNext();i++) {
            if(i>0) {
                key.append(",");
                keylen++;
                sql.append("| ");
                sqllen+=2;
            }
            String word=iterator.next().toString();
            if(keylen+word.length()>50) {
                key.append("\"+\n    \"");
                keylen=0;
            }
            keylen+=word.length();
            key.append(word);
            if(sqllen+word.length()+3>50) {
                sql.append("\n    ");
                sqllen=0;
            }
            sqllen+=word.length()+3;
            sql.append("\"");
            sql.append(word.toLowerCase());
            sql.append("\" ");
        }
        key.append("\";");
        System.out.println("Translator.KEYWORDS:");
        System.out.println(key.toString());
        System.out.println("sql.g keyword:");
        System.out.println(sql.toString()); 
    }
    private List convertToList(String list) {
        if(list==null) {
            return Collections.EMPTY_LIST;
        }
        ArrayList arraylist=new ArrayList();
        list=list.toUpperCase();
        StringTokenizer tokenizer = new StringTokenizer(list, ",- ");
        while(tokenizer.hasMoreElements()) {
            String token = tokenizer.nextToken();
            arraylist.add(token);
        }
        return arraylist;
    }
    void test(String sql) throws SQLException {
        trace(sql);
        stat.execute(sql);
    }
}
