/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.adapter;

import org.ldbc.core.*;

/**
 * Known issues:
 *
 * DatabaseMetaData.getColumns
 * column ORDINAL_POSITION is -1, should be 1,2,...
 */
public class JDataStore extends Base implements Adapter {
    // url: jdbc:borland:dslocal:C:/test/JDataStore5/data/test.jds
    public String getName() {
        return getClass().getName();
    }
    public String getDriverClass() {
        return "com.borland.datastore.jdbc.DataStoreDriver";
    }
}

