/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;
import java.sql.*;
import org.ldbc.jdbc.*;

public class Result {
    private jdbcResultSet resultset;
    private int updateCount;
    private boolean isResultSet;
    
    Result(jdbcResultSet resultset) {
        isResultSet = true;
        this.resultset = resultset;
    }
    Result(int updateCount) {
        isResultSet = false;
        this.updateCount = updateCount;
    }
    
    public boolean isResultSet() {
        return isResultSet;
    }

    public ResultSet getResultset() {
        return resultset;
    }

    public int getUpdateCount() {
        return updateCount;
    }
    
}
