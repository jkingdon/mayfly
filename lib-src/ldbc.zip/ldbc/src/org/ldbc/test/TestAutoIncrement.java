package org.ldbc.test;

import java.sql.*;

public class TestAutoIncrement extends TestBase {

    public static void main(String[] argv) {
        new TestAutoIncrement().test(argv);
    }

    void test(Connection conn) throws Throwable {
        Statement stat = conn.createStatement();
        ResultSet rs;
        stat.execute("CREATE TABLE AUTOINC("
                + "ID INT AUTOINCREMENT PRIMARY KEY, VALUE VARCHAR(255))");
        DatabaseMetaData meta = conn.getMetaData();
        rs = meta.getColumns(null, null, "AUTOINC", null);
        rs.next();
        String type = rs.getString("TYPE_NAME");
        if (!type.equals("INTEGER AUTOINCREMENT")) {
            error("wrong type name: " + type + " column "
                    + rs.getString("COLUMN_NAME"));
        }
        rs.next();
        type = rs.getString("TYPE_NAME");
        if (!type.equals("VARCHAR")) {
            error("wrong type name: " + type + " column "
                    + rs.getString("COLUMN_NAME"));
        }
        rs.next();
        stat.execute("INSERT INTO AUTOINC VALUES('Hello')");
        checkLastInserted(conn, 1);
        checkLastInserted(stat, 1);
        PreparedStatement prep = conn
                .prepareStatement("INSERT INTO AUTOINC VALUES(?)");
        for (int i = 0; i < 5; i++) {
            prep.setString(1, "World " + (i + 1));
            prep.executeUpdate();
            checkLastInserted(prep, i + 2);
            checkLastInserted(conn, i + 2);
        }
        stat.executeUpdate("INSERT INTO AUTOINC(Id,Value) "
                + "VALUES(10,'How are you')");
        rs = stat.executeQuery("SELECT * FROM AutoInc ORDER BY Id ASC");
        int[] id = new int[] { 1, 2, 3, 4, 5, 6, 10};
        String[] value = new String[] { "Hello", "World 1", "World 2",
                "World 3", "World 4", "World 5", "How are you"};
        for (int i = 0; rs.next(); i++) {
            int xid = rs.getInt(1);
            String xvalue = rs.getString(2);
            if (xid != id[i] || !xvalue.equals(value[i])) {
                error("wrong values, expected:" + id[i] + " " + value[i]
                        + " got:" + xid + " " + xvalue);
            }
        }
        stat.execute("DROP TABLE AUTOINC");
        stat.execute("CREATE TABLE AUTOINC(a VARCHAR(10), "
                + "Id INT AUTOINCREMENT PRIMARY KEY, b VARCHAR(10))");
        stat.executeUpdate("INSERT INTO AUTOINC VALUES('A','B')");
        checkLastInserted(stat, 1);
        checkLastInserted(conn, 1);
        stat.execute("INSERT INTO AUTOINC VALUES('A','B')");
        checkLastInserted(conn, 2);
        checkLastInserted(stat, 2);
        rs = stat.executeQuery("SELECT * FROM AUTOINC ORDER BY ID");
        rs.next();
        if (rs.getInt(2) != 1) {
            error("expected id=1");
        }
        rs.next();
        if (rs.getInt(2) != 2) {
            error("expected id=2");
        }
        stat.execute("DROP TABLE AUTOINC");
        testMultiThread(conn);
    }

    void testMultiThread(Connection conn) throws Throwable {
        Statement stat = conn.createStatement();
        stat.execute("CREATE TABLE AUTOINC("
                + "ID INT AUTOINCREMENT PRIMARY KEY,VALUE INT)");
        int threads = 2;
        int count = 200;
        // insert a few additional records
        // the autoincrement mechanism must not re-use these numbers
        PreparedStatement prep = conn
                .prepareStatement("INSERT INTO AUTOINC(ID, VALUE) VALUES(?,?)");
        for (int i = 0; i < count; i++) {
            int value = 5 + i * threads;
            prep.setInt(1, value);
            prep.setInt(2, value);
            prep.execute();
            trace("inserting value=" + value);
        }
        class Runner extends Thread {
            Connection conn;
            PreparedStatement prep;
            Throwable throwable;
            int id;
            int count;

            Runner(Connection conn, int id, int count) {
                this.conn = conn;
                this.id = id;
                this.count = count;
            }

            public void run() {
                int value = 0;
                try {
                    prep = conn
                            .prepareStatement("INSERT INTO AUTOINC(VALUE) VALUES(?)");
                    for (int i = 0; i < count; i++) {
                        value = id * count + i;
                        prep.setInt(1, value);
                        prep.executeUpdate();
                    }
                } catch (Throwable t) {
                    trace("error at thread=" + id + " value=" + value);
                    throwable = t;
                }
            }

            void cleanUp() throws Throwable {
                conn.close();
                if (throwable != null) {
                    throw throwable;
                }
            }
        }
        Runner[] t = new Runner[threads];
        for (int id = 0; id < threads; id++) {
            t[id] = new Runner(openConnection(), id, count);
        }
        for (int id = 0; id < threads; id++) {
            t[id].start();
        }
        for (int id = 0; id < threads; id++) {
            t[id].join();
            t[id].cleanUp();
        }
        ResultSet rs = stat.executeQuery("SELECT COUNT(*) FROM AUTOINC");
        rs.next();
        int result = rs.getInt(1);
        int expected = threads * count + count;
        if (result != expected) {
            error("Expected count: " + expected + " got: " + result);
        }
        stat.execute("DROP TABLE AUTOINC");
    }

    void checkLastInserted(Connection conn, int expected) throws SQLException {
        Statement stat = conn.createStatement();
        ResultSet rs = stat.executeQuery("GET AUTOINCREMENT KEY");
        rs.next();
        int got = rs.getInt(1);
        if (got != expected) {
            error("a) last autoincrement: expected " + expected + ", got " + got);
        }
        if(rs.next()) {
            error("a) expected one row, got more");
        }
        check(stat.execute("GET AUTOINCREMENT KEY"));
        rs = stat.getResultSet();
        check(rs.next());
        check(rs.getInt(1)==expected);
        check(!rs.next());
        
    }
    
    void checkLastInserted(Statement stat, int expected) throws SQLException {
//#ifdef JDK14
        ResultSet rs = stat.getGeneratedKeys();
        rs.next();
        int got = rs.getInt(1);
        if (got != expected) {
            error("b) last autoincrement: expected " + expected + ", got " + got);
        }
        if(rs.next()) {
            error("b) expected one row, got more");
        }
//#endif
    }
}
