/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.core;

import java.io.*;

public class Trace {
    static {
        try {
            String trace=System.getProperty("ldbc.trace","off").toLowerCase();
            setOption(trace);
        } catch(Throwable e) {
            // ignore
            e.printStackTrace();
        }
    }
    public static void setOption(String value) {
        stream=System.out;
        int comma=value.indexOf(',');
        String file=null;
        if(comma!=-1) {
            file=value.substring(comma+1);
            value=value.substring(0,comma);
        }
        if(value.equals("on")) {
            enabled=true;
            detailed=false;
            sql=true;
            setFile(file);
        } else if(value.equals("off")) {
            enabled=false;
            detailed=false;
            sql=false;
        } else if(value.equals("sqlonly")) {
            enabled=false;
            detailed=false;
            sql=true;
            setFile(file);            
        } else if(value.equals("detailed")) {
            enabled=true;
            detailed=true;
            sql=true;
            setFile(file);
        } else {
            System.out.println("ldbc.trace must be one of {on|off|detailed|sqlonly} but is: <"+value+"> - logging off");
        }
    }
    static void setFile(String fileName) {
        try {
            if(fileName==null) {
                return;
            }
            stream=new PrintStream(new FileOutputStream(fileName,true));
        } catch(Throwable e) {
            e.printStackTrace();
            System.out.println("Can not write to file: "+fileName+" using System.out instead.");
        }
    }
    static boolean enabled;
    static boolean detailed;
    static PrintStream stream;
    static boolean sql;
    final static String CLASSNAME=new Trace().getClass().getName();
    final static String PACKAGE="org.ldbc.jdbc.";
    public static boolean isEnabled() {
        return enabled;
    }
    public static boolean isDetailed() {
        return detailed;
    }
    public static boolean isSQL() {
        return sql;
    }
    public static void trace(String id) {
        traceSub(id,null);
    }
    public static void println(String s) {
        stream.println(s);
    }
    public static void traceQuote(String id,String param) {
        traceSub(id,quote(param));
    }
    public static void trace(String id,int param) {
        traceSub(id,String.valueOf(param));
    }
    public static void trace(String id,String param) {
        traceSub(id,param);
    }
    public static void traceResult(boolean result) {
        if(detailed) {
            stream.println("\treturns "+result);
        }
    }
    public static void traceResult(int result) {
        if(detailed) {
            stream.println("\treturns "+result);
        }
    }
    public static void traceResult(String result) {
        if(detailed) {
            stream.println("\treturns "+result);
        }
    }
    public static void traceResultQuote(String result) {
        if(detailed) {
            stream.println("\treturns "+quote(result));
        }
    }
    public static void traceException(Exception e) {
        stream.println("\tthrows "+e.toString());
    }
    private static void traceSub(String id,String param) {
        String caller=getCaller();
        if(caller==null) {
            return;
        }
        if(param!=null) {
            param="("+param+")";
        } else {
            param="()";
        }
        caller=id+"."+caller+param;
        stream.println(caller);
    }
    /**
     * @param param parameter list - null if none
     * @param result return value - null if none
     */
    private static String getCaller() {
        StringWriter writer=new StringWriter();
        new Exception().printStackTrace(new PrintWriter(writer));
        String trace=writer.getBuffer().toString();
        LineNumberReader reader=new LineNumberReader(new StringReader(trace));
        String caller=null;
        try {
            String line=reader.readLine();
            // the first line is always be 'java.lang.Exception'
            while(true) {
                line=reader.readLine();
                if(line==null) {
                    break;
                }
                line=line.trim();
                // remove the 'at' from the start 
                // could be something else, too - in another language 
                // just skip the first word
                int space=line.indexOf(' ');
                if(space!=-1) {
                    line=line.substring(space).trim();
                }
                if(!line.startsWith(CLASSNAME)) {
                    int open=line.indexOf('(');
                    if(open!=-1) {
                        line=line.substring(0,open);
                    }
                    if(!line.startsWith(PACKAGE)) {
                        break;
                    }
                    caller=line;
                    break;
                }
            }
        } catch(IOException e) {
            caller=null;
        }
        if(caller==null) {
            // in a real application, this can never happen
            return null;
        }
        // remove the class name
        int dot=caller.lastIndexOf('.');
        if(dot!=-1) {
            caller=caller.substring(dot+1);
            // this would remove the package name only
            // dot=caller.lastIndexOf('.',dot-1);
            // if(dot!=-1) {
            //  caller=caller.substring(dot+1);
            //}
        }
        return caller;
    }
    public static String quote(String[] s) {
        if(s==null) {
            return "null";
        }
        StringBuffer buff=new StringBuffer("{");
        for(int i=0;i<s.length;i++) {
            if(i>0) {
                buff.append(',');
            }
            buff.append(quote(s[i]));
        }
        buff.append('}');
        return buff.toString();
    }
    /**
     * Convert a String to parameter as used in Java code.
     * Example: Hello > "Hello"
     * @param s the String
     * @return the Java source code for the String
     */
    public static String quote(String s) {
        if(s==null) {
            return "null";
        }
        StringBuffer buff=new StringBuffer("\"");
        // See also Java Language Specification
        // Escape Sequences for Character and String Literals
        // http://java.sun.com/docs/books/jls/first_edition/html/3.doc.html#101089
        for(int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            switch(c) {
            case '\b':  // 0x8
                buff.append("\\b");
                break;
            case '\t':  // 0x9
                buff.append("\\t");
                break;
            case '\n':  // 0xa
                buff.append("\\n");
                break;
            case '\f':  // 0xc
                buff.append("\\f");
                break;
            case '\r':  // 0xd
                buff.append("\\r");
                break;
            case '\\':  // 0x5c
                buff.append("\\\\");
                break;
            case '"':   // 0x22
                buff.append("\\\"");
                break;
            default:
                if(c>0xff || c<' ') {
                    buff.append("\\u");
                    buff.append(Integer.toHexString(c >> 12));
                    buff.append(Integer.toHexString((c >> 8) & 0xf));
                    buff.append(Integer.toHexString((c >> 4) & 0xf));
                    buff.append(Integer.toHexString(c & 0xf));
                } else {
                    buff.append(c);
                }
            }
        }
        buff.append("\"");
        return buff.toString();
    }
    public static String quote(int[] data) {
        if(data==null) {
            return "null";
        }
        StringBuffer buff=new StringBuffer("{");
        for(int i=0;i<data.length;i++) {
            if(i>0) {
                buff.append(',');
            }
            buff.append(data[i]);
        }
        buff.append('}');
        return buff.toString();
    }
    public static String quoteObject(Object o) {
        if(o==null) {
            return "null";
        }
        return "("+o.getClass().getName()+")[o_"+System.identityHashCode(o)+"]{"+o+"}";
    }
}
