/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.parser;

import org.ldbc.core.*;
import org.ldbc.antlr.*;
import org.ldbc.antlr.collections.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class Translator {
    
    final static int MAX_IDENTIFIER_LENGTH = 30;
    Adapter adapter;
    
    static String KEYWORDS=
        "ABS,ADD,ALL,ALTER,AND,AS,ASC,AVG,BEFORE,BETWEEN,"+
        "BIGINT,BINARY,BIT,BLOB,BOOLEAN,BOTH,BY,CACHED,"+
        "CASCADE,CASE,CAST,CHAR,CHARACTER,CHARACTER_LENGTH,"+
        "CHAR_LENGTH,CLOB,COLUMN,COMMIT,CONCAT,CONSTRAINT,"+
        "CONVERT,COUNT,CREATE,CROSS,CURDATE,CURRENT_DATE,"+
        "CURRENT_TIME,CURRENT_TIMESTAMP,CURTIME,DATABASE,"+
        "DATE,DATETIME,DEC,DECIMAL,DEFAULT,DELETE,DESC,"+
        "DISTINCT,DOUBLE,DROP,EXISTS,EXTRACT,FALSE,FLOAT,"+
        "FOR,FOREIGN,FROM,GRANT,GROUP,HAVING,IF,IMAGE,IN,"+
        "INDEX,INFILE,INNER,INSERT,INT,INTEGER,INTO,IS,JOIN,"+
        "KEY,KILL,LCASE,LEADING,LEFT,LENGTH,LIKE,LIMIT,"+
        "LINENO,LOAD,LOB,LOCAL,LOCATE,LOCK,LONG,"+
        "LONGVARBINARY,LONGVARCHAR,LOWER,MATCH,MAX,"+
        "MEDIUMINT,MIN,MOD,NATURAL,NOT,NOW,NULL,NUMERIC,"+
        "OBJECT,OCTET_LENGTH,ON,OPTION,OR,ORDER,OTHER,OUTER,"+
        "OUTFILE,POSITION,PRECISION,PRIMARY,PRIVILEGES,"+
        "PROCEDURE,READ,REAL,REFERENCES,RENAME,REPLACE,"+
        "RESTRICT,RETURNS,REVOKE,RIGHT,ROLLBACK,SAVEPOINT,"+
        "SELECT,SESSION_USER,SET,SMALLINT,SQRT,SUBSTRING,"+
        "SUM,SYSDATE,TABLE,TEMP,TEXT,TIME,TIMESTAMP,TINYINT,"+
        "TO,TOP,TRAILING,TRIGGER,TRIM,TRUE,UCASE,UNION,"+
        "UNIQUE,UNSIGNED,UPDATE,UPPER,USER,USING,VALUES,"+
        "VARBINARY,VARCHAR,VARCHAR_IGNORECASE,WHEN,WHERE,"+
        "WITH,WRITE,X,Y,ZEROFILL";
    /**
     * Get the list of keywords
     */
    public static String getKeywords() {
        return KEYWORDS;
    }
    /**
     * Check if a SQL statement is valid
     * @throws SQLException if not
     */
    /*
    public static void checkValid(String sql) throws SQLException {
        Translator trans=new Translator(new org.ldbc.adapter.Base());
        trans.translate(sql);
    }
    */

    /**
     * Create a new translator.
     * Only one translator per adapter is required
     *
     * @param adapter the vendor specific adapter
     */
    public Translator(Adapter adapter) {
        this.adapter = adapter;
    }
    /**
     * Translate a SQL statement into a vendor specific statement.
     *
     * @param sql the SQL statement
     */
    public Command translate(String sql) throws SQLException {
        Command command=new Command(adapter);
        command.setOriginalSQL(sql);
        SQLLexer lexer = null;
        try {
            StringReader in=new StringReader(sql);
            lexer=new SQLLexer(in);
            SQLParser parser=new SQLParser(lexer);
            parser.statement();

            if(Trace.isDetailed()) {
                DumpASTVisitor visitor2 = new DumpASTVisitor();
                visitor2.visit(parser.getAST());
            }
            parseCommand(command,parser.getAST());
            if(Trace.isSQL()) {
                Trace.println("\t"+command.getVendorSQL());
            }
            // TODO
            
            //    DumpASTVisitor visitor = new DumpASTVisitor();
            //    visitor.visit(parser.getAST());
            //    System.out.println("###"+sql);
            //    System.out.println(" > "+command.getVendorSQL());
                        
            return command;
        } catch(Throwable e) {
            int col = lexer.getColumn();
            String error = sql;
            if(col>0 && col<sql.length()) {
                error = sql.substring(0,col)+"[*]"+sql.substring(col);   
            } else {
                error = sql;
            }
            if(e.getMessage()!=null) {
                error = error+"; "+e.getMessage();
            }
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,error,e);
        }
    }

    void parseCommand(Command command,AST node) throws SQLException {
        switch(node.getType()) {
        case SQLTokenTypes.CREATE_TABLE:
            command.setType(Command.CREATE_TABLE);
            parseCreateTable(command,node);
            break;
        case SQLTokenTypes.DROP_TABLE:
            command.setType(Command.DROP_TABLE);
            parseDropTable(command,node);
            break;
        case SQLTokenTypes.CREATE_INDEX:
            command.setType(Command.CREATE_INDEX);
            parseCreateIndex(command,node);
            break;
        case SQLTokenTypes.DROP_INDEX:
            command.setType(Command.DROP_INDEX);
            parseDropIndex(command,node);
            break;
        case SQLTokenTypes.UPDATE:
            command.setType(Command.UPDATE);
            parseUpdate(command,node);
            break;
        case SQLTokenTypes.INSERT:
            command.setType(Command.INSERT);
            parseInsert(command,node);
            break;
        case SQLTokenTypes.SELECT:
            command.setType(Command.SELECT);
            parseSelect(command,node);
            break;
        case SQLTokenTypes.DELETE:
            command.setType(Command.DELETE);
            parseDelete(command,node);
            break;
        case SQLTokenTypes.SET_AUTOCOMMIT_TRUE:
            command.setType(Command.AUTOCOMMIT_TRUE);
            break;
        case SQLTokenTypes.SET_AUTOCOMMIT_FALSE:
            command.setType(Command.AUTOCOMMIT_FALSE);
            break;
        case SQLTokenTypes.COMMIT:
            command.setType(Command.COMMIT);
            break;
        case SQLTokenTypes.ROLLBACK:
            command.setType(Command.ROLLBACK);
            break;
        case SQLTokenTypes.GET_AUTOINCREMENT_KEY:
            command.setType(Command.GET_AUTOINCREMENT_KEY);
            break;
        case SQLTokenTypes.ALTER_TABLE_DROP_CONSTRAINT:
            command.setType(Command.ALTER_TABLE_DROP_CONSTRAINT);
            parseAlterTableDropConstraint(command,node);
            break;
        case SQLTokenTypes.ALTER_TABLE_ADD_COLUMN:
            command.setType(Command.ALTER_TABLE_ADD_COLUMN);
            parseAlterTableAddColumn(command,node);
            break;
        case SQLTokenTypes.ALTER_TABLE_RENAME:
            command.setType(Command.ALTER_TABLE_RENAME);
            parseAlterTableRename(command,node);
            break;
        default:
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,"?");
        }
    }
    void parseDelete(Command command,AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        String sql="DELETE FROM "+quote(tableName);
        if(child!=null) {
            int type=child.getType();
            if(type==SQLTokenTypes.CONDITION) {
                sql+=" WHERE "+getCondition(child);
            }
        }
        command.setVendorSQL(sql);
    }
    
    void parseAlterTableDropConstraint(Command command, AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        String constraintName=identifier(child.getText());
        String sql = adapter.getDropForeignKeyStatement(tableName, constraintName);
        command.setVendorSQL(sql);
    }
    
    void parseAlterTableAddColumn(Command command, AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        Column col=getAddColumn(child);
        String sql = adapter.getAddColumnStatement(tableName, col.getCreateSQL(adapter));
        command.setVendorSQL(sql);
    }
    Column getAddColumn(AST child) throws SQLException {
        String columnName=identifier(child.getText());
        child=child.getNextSibling();
        DataType type=getDataType(child);
        child=child.getNextSibling();
        boolean notNull=false;
        String defaultvalue=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.LITERAL_not) {
                notNull=true;
                child=child.getNextSibling();
            } 
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_null) {
                child=child.getNextSibling();
            }
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_default) {
                child=child.getNextSibling();
                defaultvalue = getExpression(child);
                child=child.getNextSibling();
            }
        }
        Column col=new Column(columnName,type,notNull,defaultvalue);
        return col;
    }

    
    void parseAlterTableRename(Command command, AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        String newName=identifier(child.getText());
        String sql = adapter.getRenameStatement(tableName, newName);
        command.setVendorSQL(sql);
    }
    
    String getCondition(AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        return getExpression(child);
    }
    
    String getTableWithAlias(AST parent)  throws SQLException {
        AST table=parent.getFirstChild();
        String tables=quote(identifier(table.getText()));
        table=table.getNextSibling();
        if(table!=null) {
            tables+=" "+quote(identifier(table.getText()));
        }
        return tables;
    }
    
    String getSelect(Command command, AST child, boolean allowTop) throws SQLException {
        String sql="";
        boolean distinct=false;
        String top=null;
        if(child.getType()==SQLTokenTypes.LITERAL_distinct) {
            distinct=true;
            child=child.getNextSibling();
        }
        if(child.getType()==SQLTokenTypes.LITERAL_top) {
            if(!allowTop) {
                throw Factory.getSQLException(
                        Messages.SYNTAX_ERROR,
                        "TOP is not supported in this context");
            }
            child=child.getNextSibling();
            top=child.getText();
            child=child.getNextSibling();
        }
        if(child.getType()==SQLTokenTypes.ASTERISK) {
            sql+="* ";
            child=child.getNextSibling();
        } else if(child.getType()==SQLTokenTypes.SELECT_ITEM || child.getType()==SQLTokenTypes.TABLE_ASTERISK) {
            while(child.getType()==SQLTokenTypes.SELECT_ITEM || child.getType()==SQLTokenTypes.TABLE_ASTERISK) {
                if(child.getType()==SQLTokenTypes.TABLE_ASTERISK) {
                    AST table=child.getFirstChild();
                    sql += quote(identifier(table.getText())) + ".*";
                } else {
                    AST exp=child.getFirstChild();
                    if(exp.getType()==SQLTokenTypes.EXPRESSION) {
                        sql+=getExpression(exp);
                    }
                    exp=exp.getNextSibling();
                    if(exp!=null) {
                        sql+=" AS "+quote(identifier(exp.getText()));
                    }
                }
                sql+=",";
                child=child.getNextSibling();
            }
            sql=sql.substring(0,sql.length()-1);
        }
        // FROM
        String joinConditions="";
        String tables=getTableWithAlias(child);
        child=child.getNextSibling();
        while(child!=null) {
            if(child.getType()==SQLTokenTypes.COMMA) {
                child=child.getNextSibling();
                tables+=",";
                tables+=getTableWithAlias(child);
                child=child.getNextSibling();
            } else if(child.getType()==SQLTokenTypes.LITERAL_inner) {
                child=child.getNextSibling();
                if(adapter.supportsAnsiJoinSyntax()) {
                    tables+=" INNER JOIN ";
                    tables+=getTableWithAlias(child);
                    child=child.getNextSibling();
                    String condition=getCondition(child);
                    child=child.getNextSibling();
                    tables+=" ON "+condition;
                } else {
                    tables+=",";
                    tables+=getTableWithAlias(child);
                    child=child.getNextSibling();
                    String cond=getCondition(child);
                    child=child.getNextSibling();
                    if(joinConditions.length()>0) {
                        joinConditions+=" AND ";
                    }
                    joinConditions+="("+cond+")";
                }
            } else if(child.getType()==SQLTokenTypes.LITERAL_left) {
                if(!adapter.supportsAnsiJoinSyntax()) {
                    throw Factory.getSQLException(
                        Messages.SYNTAX_ERROR,
                        "The ANSI SQL-92 outer join syntax is not support by this database");
                }
                child=child.getNextSibling();
                tables+=" LEFT OUTER JOIN ";
                tables+=getTableWithAlias(child);
                child=child.getNextSibling();
                String condition=getCondition(child);
                child=child.getNextSibling();
                tables+=" ON "+condition;
            /*
            } else if(child.getType()==SQLTokenTypes.LITERAL_right) {
                if(!adapter.supportsAnsiJoinSyntax()) {
                    throw Factory.getSQLException(
                        Messages.SYNTAX_ERROR,
                        "The ANSI SQL-92 outer join syntax is not support by this database");
                }
                child=child.getNextSibling();
                tables+=" RIGHT OUTER JOIN ";
                tables+=getTableWithAlias(child);
                child=child.getNextSibling();
                String condition=getCondition(child);
                child=child.getNextSibling();
                tables+=" ON "+condition;
            */
            } else {
                break;
            }
        }
        String condition=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.CONDITION) {
                condition=getCondition(child);
                child=child.getNextSibling();
            }
        }
        if(joinConditions.length()>0) {
            if(condition==null) {
                condition=joinConditions;
            } else {
                condition=joinConditions+" AND ("+condition+")";
            }
        }
        String group=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.GROUP_BY) {
                group=getGroupBy(child);
                child=child.getNextSibling();
            }
        }
        String having=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.LITERAL_having) {
                child=child.getNextSibling();
                having=getCondition(child);
                child=child.getNextSibling();
            }
        }
        String order=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.ORDER_BY) {
                order=getOrderBy(child);
                child=child.getNextSibling();
            }
        }
        sql = sql+" FROM "+tables;
        if(condition!=null) {
            sql+=" WHERE "+condition;
        }
        if(group!=null) {
            sql+=" GROUP BY "+group;
        }
        if(having!=null) {
            sql+=" HAVING "+having;
        }
        if(order!=null) {
            sql+=" ORDER BY "+order;
        }
        String select = adapter.getSelect(distinct, top, sql);
        if(command != null && top != null) {
            int limit = Integer.parseInt(top);
            if(limit<0) {
                throw Factory.getSQLException(
                        Messages.SYNTAX_ERROR,
                        "TOP with negative value not supported");
            }
            command.setLimit(limit);
        }

        return select;        
    }
    void parseSelect(Command command,AST parent)  throws SQLException {
        String select = getSelect(command, parent.getFirstChild(), true);
        command.setVendorSQL(select);
    }
    void parseInsert(Command command, AST parent)  throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        String sql="INSERT INTO "+quote(identifier(tableName));
        Vector v=new Vector();
        if(child.getType()==SQLTokenTypes.COLUMN_LIST) {
            AST list=child.getFirstChild();
            do {
                v.addElement(identifier(list.getText()));
                list=list.getNextSibling();
            } while(list!=null);
            child=child.getNextSibling();
        }
        String autoIncColumn = adapter.autoIncGetColumn(tableName);
        boolean add = false;
        if(autoIncColumn!=null) {
            command.setAutoIncInsert(true);
            boolean missing=adapter.autoIncAutoColumnMissing(tableName, v);
            if(missing) {
                command.setAutoIncInsertAutoValue(true);
                add =  adapter.autoIncNeedGeneratedValue();
                if(add) {
                    command.setParameterIndexOffset(1);
                }
            } else {
                command.setAutoIncInsertAutoValue(false);
            }
        }
        if(add) {
            if(v.size()==0) {
                adapter.autoIncAddAllColumns(tableName,v);
            }
            v.insertElementAt(autoIncColumn,0);
        }
        if(v.size()>0) {
            String columns="";
            for(int i=0;i<v.size();i++) {
                columns+=quote(v.elementAt(i).toString())+",";
            }
            columns=columns.substring(0,columns.length()-1);
            sql+="("+columns+")";
        }
        String values="";
        if(child.getType()==SQLTokenTypes.LITERAL_values) {
            AST val=child.getFirstChild();
            do {
                String s=getExpression(val);
                values+=s+",";
                val=val.getNextSibling();
            } while(val!=null);
            if(add) {
                values="?,"+values;
            }
            values=values.substring(0,values.length()-1);
            sql+=" VALUES("+values+")";
        } else if(child.getType()==SQLTokenTypes.SELECT) {
            if(add) {
                // TODO: could insert into a temp table, set the id, and insert again
                throw Factory.getSQLException(
                Messages.SYNTAX_ERROR,
                "Automated autoincrement value generation not supported for INSERT INTO ... SELECT");
            }
            String select = getSelect(command, child.getFirstChild(), false);
            sql+=" "+select;
        }
        command.setVendorSQL(sql);
        command.setTableName(tableName);
    }
    void parseUpdate(Command command,AST parent)  throws SQLException {
        AST child=parent.getFirstChild();
        String tableName=identifier(child.getText());
        String sql="";
        child=child.getNextSibling();
        while(child!=null && child.getType()==SQLTokenTypes.UPDATE_SET) {
            AST updateset=child.getFirstChild();
            String columnName=identifier(updateset.getText());
            updateset=updateset.getNextSibling();
            String expression=getExpression(updateset);
            child=child.getNextSibling();
            sql+=quote(columnName)+" = "+expression+",";
        }
        sql=sql.substring(0,sql.length()-1);
        if(child!=null) {
            int type=child.getType();
            if(type==SQLTokenTypes.CONDITION) {
                sql+=" WHERE "+getCondition(child);
            }
        }
        command.setVendorSQL("UPDATE "+quote(tableName)+" SET "+sql);
    }
    String getOrderBy(AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String sql="";
        do {
            // order_item
            AST item=child.getFirstChild();
            sql+=getExpression(item);
            item=item.getNextSibling();
            if(item!=null) {
                // ASC or DESC
                sql+=" "+item.getText();
            }
            sql+=",";
            child=child.getNextSibling();
        } while(child!=null);
        sql=sql.substring(0,sql.length()-1);
        return sql;
    }
    String getGroupBy(AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String sql="";
        do {
            sql+=getExpression(child);
            child=child.getNextSibling();
            sql+=",";
        } while(child!=null);
        sql=sql.substring(0,sql.length()-1);
        return sql;
    }
    String parseDate(String s) {
        s=s.substring(1,s.length()-1);
        // todo: check it's valid - this test is not enough
        java.sql.Date.valueOf(s);
        return s;
    }
    String parseTimestamp(String s) {
        s=s.substring(1,s.length()-1);
        // todo: check it's valid - this test is not enough
        java.sql.Timestamp.valueOf(s);
        return s;
    }
    String parseBinary(String s) {
        s=s.substring(2,s.length()-1);
        // todo: check it's valid
        return s;
    }
    void parseDropIndex(Command command,AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String indexName=identifier(child.getText());
        child=child.getNextSibling();
        String tableName=identifier(child.getText());
        String sql=adapter.getDropIndexSQL(tableName,tableName+"_"+indexName);
        command.setVendorSQL(sql);
    }
    void parseCreateIndex(Command command,AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        boolean unique=false;
        if(child.getType()==SQLTokenTypes.LITERAL_unique) {
            unique=true;
            child=child.getNextSibling();
        }
        String indexName=identifier(child.getText());
        child=child.getNextSibling();
        String tableName=identifier(child.getText());
        child=child.getNextSibling();
        child=child.getFirstChild();
        String sql="";
        do {
            String columnName=identifier(child.getText());
            sql+=quote(columnName)+",";
            child=child.getNextSibling();
        } while(child!=null);
        sql=sql.substring(0,sql.length()-1);
        command.setVendorSQL(
            "CREATE "+(unique?"UNIQUE ":"")+"INDEX "+
            quote(tableName+"_"+indexName)+" ON "+
            quote(tableName)+"("+sql+")"
        );
    }
    void parseDropTable(Command command,AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        boolean ifExists;
        if(child.getType() == SQLTokenTypes.LITERAL_if) {
            ifExists = true;
            child = child.getNextSibling();
        } else {
            ifExists = false;
        }
        String tableName=identifier(child.getText());
        command.setIfExists(ifExists);
        command.setTableName(tableName);        
        command.setVendorSQL("DROP TABLE "+quote(tableName));
    }
    void parseCreateTable(Command command,AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        boolean ifNotExists;
        if(child.getType() == SQLTokenTypes.LITERAL_if) {
            ifNotExists = true;
            child = child.getNextSibling();
        } else {
            ifNotExists = false;
        }
        String tableName=identifier(child.getText());
        Vector columns=new Vector();
        Vector pkcolumns=new Vector();
        Vector foreignKey=new Vector();
        Column autoIncrement=null;
        child=child.getNextSibling();
        String option = null;
        if(child.getType() == SQLTokenTypes.LITERAL_option) {
            child=child.getNextSibling();
            option = child.getText();
            child=child.getNextSibling();
        }
        int fkId = 1;
        while(true) {
            child=child.getNextSibling();
            if(child==null) {
                break;
            }
            int type=child.getType();
            if(type==SQLTokenTypes.COLUMN_DEF) {
                Column col=getColumn(child);
                if(col.isPrimaryKey()) {
                    pkcolumns.addElement(new Integer(columns.size()));
                }
                if(col.isAutoIncrement()) {
                    if(autoIncrement!=null) {
                        throw Factory.getSQLException(
                        Messages.SYNTAX_ERROR,
                        "Only one autoincrement columns allowed per table");
                    }
                    autoIncrement=col;
                }
                columns.addElement(col);
            } else if(type==SQLTokenTypes.PRIMARY_KEY) {
                AST cols=child.getFirstChild();
                do {
                    String pkCol=identifier(cols.getText());
                    for(int i=0;i<columns.size();i++) {
                        Column col=(Column)columns.elementAt(i);
                        if(col.getName().equals(pkCol)) {
                            col.setNotNull();
                            pkcolumns.addElement(new Integer(i));
                        }
                    }
                    cols=cols.getNextSibling();
                } while(cols!=null);
            } else if(type==SQLTokenTypes.FOREIGN_KEY) {
                foreignKey.addElement(getForeignKey(child, "FK_"+fkId));
                fkId++;
            }
        }
        String sql="";
        int len=columns.size();
        for(int i=0;i<len;i++) {
            Column col=(Column)columns.elementAt(i);
            sql+=col.getCreateSQL(adapter);
            sql+=",";
        }
        sql=sql.substring(0,sql.length()-1);
        len=pkcolumns.size();
        if(len>0) {
            sql+=",PRIMARY KEY(";
            for(int i=0;i<len;i++) {
                int colidx=((Integer)pkcolumns.elementAt(i)).intValue();
                Column col=(Column)columns.elementAt(colidx);
                sql+=quote(col.getName())+",";
            }
            sql=sql.substring(0,sql.length()-1)+")";
        }
        for(int i=0;i<foreignKey.size();i++) {
            sql+=","+foreignKey.elementAt(i);
        }
        sql=adapter.getCreateTable(tableName, sql, option);
        String[] cols=new String[columns.size()];
        for(int i=0;i<cols.length;i++) {
            cols[i]=((Column)columns.elementAt(i)).getName();
        }
        if(autoIncrement!=null) {
            command.setAutoIncCreate(autoIncrement.getName(), cols);
        }
        command.setIfNotExists(ifNotExists);
        command.setTableName(tableName);
        command.setVendorSQL(sql);
    }
    // TODO for MySQL:
    // In some cases it is not required to create the additional index (for example, primary key)
    // check if CREATE INDEX is allowed after create table with referential integrity and if not,
    // why not.
    String getForeignKey(AST parent, String name) throws SQLException {
        AST child=parent.getFirstChild();
        AST columns=child.getFirstChild();
        int i=0;
        String columnlist="";
        do {
            String col=identifier(columns.getText());
            if(i>0) {
                columnlist+=",";
            }
            columnlist+=quote(col);
            i++;
            columns=columns.getNextSibling();
        } while(columns!=null);
        String sql="CONSTRAINT "+name+" FOREIGN KEY("+columnlist+") REFERENCES ";
        child=child.getNextSibling();
        String table=identifier(child.getText());
        sql+=quote(table)+"(";
        child=child.getNextSibling();
        columns=child.getFirstChild();
        i=0;
        do {
            String col=identifier(columns.getText());
            if(i>0) {
                sql+=",";
            }
            i++;
            sql+=quote(col);
            columns=columns.getNextSibling();
        } while(columns!=null);
        sql+=")";
        if(adapter.needExplicitIndexOnForeignKey()) {
            sql="INDEX("+columnlist+"),"+sql;
        }
        return sql;
    }
    Column getColumn(AST parent) throws SQLException {
        AST child=parent.getFirstChild();
        String columnName=identifier(child.getText());
        child=child.getNextSibling();
        DataType type=getDataType(child);
        child=child.getNextSibling();
        boolean primarykey=false;
        boolean notNull=false;
        boolean autoIncrement=false;
        String defaultvalue=null;
        if(child!=null) {
            if(child.getType()==SQLTokenTypes.LITERAL_autoincrement) {
                autoIncrement=true;
                child=child.getNextSibling();
            }
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_not) {
                notNull=true;
                child=child.getNextSibling();
            } 
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_null) {
                child=child.getNextSibling();
            }
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_primary) {
                child=child.getNextSibling();
                //the last part is always 'key'
                primarykey=true;
            }
            if(child!=null && child.getType()==SQLTokenTypes.LITERAL_default) {
                child=child.getNextSibling();
                defaultvalue = getExpression(child);
                child=child.getNextSibling();
            }
        }
        Column col=new Column(columnName,type,notNull,defaultvalue);
        if(primarykey) {
            col.setPrimaryKey();
        }
        if(autoIncrement) {
            col.setAutoIncrement();
        }
        return col;
    }
    DataType getDataType(AST child) throws SQLException {
        child=child.getFirstChild();
        int datatype=child.getType();
        int precision=0;
        int scale=0;
        switch(datatype) {
        case SQLTokenTypes.TYPE_INT:
            datatype=Types.INTEGER;
            break;
        case SQLTokenTypes.TYPE_VARCHAR:
            datatype=Types.VARCHAR;
            child=child.getNextSibling();
            precision=Integer.parseInt(child.getText());
            break;
        case SQLTokenTypes.TYPE_DECIMAL:
            datatype=Types.DECIMAL;
            child=child.getNextSibling();
            precision=DataType.getDefaultPrecision(Types.DECIMAL);
            scale=DataType.getDefaultScale(Types.DECIMAL);
            if(child!=null) {
                precision=Integer.parseInt(child.getText());
                child=child.getNextSibling();
                if(child!=null) {
                    scale=Integer.parseInt(child.getText());
                }
            }
            break;
        case SQLTokenTypes.TYPE_DATETIME:
            datatype=Types.TIMESTAMP;
            break;
        case SQLTokenTypes.TYPE_BLOB:
            datatype=Types.BLOB;
            break;
        case SQLTokenTypes.TYPE_CLOB:
            datatype=Types.CLOB;
            break;
        }
        DataType type=new DataType(null,datatype,precision,scale);
        return type;
    }
    String getExpression(AST child) throws SQLException {
        AST v,v1,v2,v3;
        String s1,s2,s3;
        switch(child.getType()) {
        case SQLTokenTypes.EXPRESSION:
            return getExpression(child.getFirstChild());
        case SQLTokenTypes.DECIMAL_VALUE:
            v=child.getFirstChild();
            String s="";
            do {
                s+=v.getText();
                v=v.getNextSibling();
            } while(v!=null);
            return s;
        case SQLTokenTypes.CONDITION:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return s1;
        case SQLTokenTypes.LITERAL_exists:
            v1 = child.getFirstChild().getFirstChild();
            s1 = getSelect(null, v1, false);
            return "EXISTS ("+s1+")";
        case SQLTokenTypes.LITERAL_or:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" OR "+s2;
        case SQLTokenTypes.OPEN_PAREN:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "( "+s1+" )";
        case SQLTokenTypes.LITERAL_and:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" AND "+s2;
        case SQLTokenTypes.IS_NULL:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return s1+" IS NULL";
        case SQLTokenTypes.IS_NOT_NULL:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return s1+" IS NOT NULL";
        case SQLTokenTypes.LIKE:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" LIKE "+s2+" "+adapter.getDefaultLikeEscape();
        case SQLTokenTypes.NOT_LIKE:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" NOT LIKE "+s2+" "+adapter.getDefaultLikeEscape();
        case SQLTokenTypes.NOT_BETWEEN:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            v3=v2.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            s3=getExpression(v3);
            return s1+" NOT BETWEEN "+s2+" AND "+s3;
        case SQLTokenTypes.BETWEEN:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            v3=v2.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            s3=getExpression(v3);
            return s1+" BETWEEN "+s2+" AND "+s3;
        case SQLTokenTypes.NOT:
            return "NOT "+getExpression(child.getFirstChild());
        case SQLTokenTypes.NEGATIVE:
            return "-"+getExpression(child.getFirstChild());
        case SQLTokenTypes.EQUAL:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" = "+s2;
        case SQLTokenTypes.NOT_EQUAL:
        case SQLTokenTypes.NOT_EQUAL_2:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" <> "+s2;
        case SQLTokenTypes.BIGGER:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" > "+s2;
        case SQLTokenTypes.SMALLER:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" < "+s2;
        case SQLTokenTypes.SMALLER_EQUAL:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" <= "+s2;
        case SQLTokenTypes.BIGGER_EQUAL:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" >= "+s2;
        case SQLTokenTypes.VERTBARS:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return adapter.getStringConcatenation(s1,s2);                
        case SQLTokenTypes.ASTERISK:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" * "+s2;                
        case SQLTokenTypes.DIVIDE:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" / "+s2;                
        case SQLTokenTypes.PLUS:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" + "+s2;                
        case SQLTokenTypes.MINUS:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return s1+" - "+s2;                
        case SQLTokenTypes.QUOTED_STRING:
            s=child.getText();
            s=adapter.getStringConstant(s);
            return s;
        case SQLTokenTypes.DATE:
            v=child.getFirstChild();
            s=getExpression(v);
            s=parseDate(s);
            return adapter.getDateConstant(s);
        case SQLTokenTypes.TIMESTAMP:
            v=child.getFirstChild();
            s=getExpression(v);
            s=parseTimestamp(s);
            return adapter.getTimestampConstant(s);
        case SQLTokenTypes.BINARY:
            v=child.getFirstChild();
            s=getExpression(v);
            s=parseBinary(s);
            return adapter.getBinaryConstant(s);
        case SQLTokenTypes.COLUMN:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s=quote(identifier(v1.getText()));
            if(v2!=null) {
                s+="."+quote(identifier(v2.getText()));
            }
            return s;
        case SQLTokenTypes.LITERAL_in:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            v2=v1.getNextSibling();
            s2=getExpression(v2);
            while(v2.getNextSibling()!=null) {
                v2=v2.getNextSibling();
                s2+=", "+getExpression(v2);
            }
            return s1+" IN("+s2+")";
        case SQLTokenTypes.LITERAL_count:
            boolean distinct = false;
            v1=child.getFirstChild();
            if (v1.getType() == SQLTokenTypes.LITERAL_distinct) {
                distinct = true;
                v1=v1.getNextSibling();
            }            
            if(v1.getType()==SQLTokenTypes.ASTERISK) {
                return "COUNT(*)";
            }
            s1=getExpression(v1);
            if (distinct) {
                return "COUNT(DISTINCT "+s1+")";
            }
            return "COUNT("+s1+")";
        case SQLTokenTypes.LITERAL_min:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "MIN("+s1+")";
        case SQLTokenTypes.LITERAL_max:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "MAX("+s1+")";
        case SQLTokenTypes.LITERAL_sum:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "SUM("+s1+")";
        case SQLTokenTypes.LITERAL_avg:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "AVG("+s1+")";
        case SQLTokenTypes.LITERAL_cast:
        case SQLTokenTypes.LITERAL_convert:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            DataType type=getDataType(v2);
            s1=adapter.getCast(s1,type);
            return s1;
        case SQLTokenTypes.LITERAL_length:
        case SQLTokenTypes.LITERAL_character_length:
        case SQLTokenTypes.LITERAL_char_length:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            s1=adapter.getLength(s1);
            return s1;
        case SQLTokenTypes.LITERAL_mod:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return adapter.getMod(s1,s2);
        case SQLTokenTypes.LITERAL_concat:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return adapter.getStringConcatenation(s1,s2);
        case SQLTokenTypes.LITERAL_lcase:
        case SQLTokenTypes.LITERAL_lower:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "LOWER("+s1+")";
        case SQLTokenTypes.LITERAL_ucase:
        case SQLTokenTypes.LITERAL_upper:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "UPPER("+s1+")";
        case SQLTokenTypes.LITERAL_now:
        case SQLTokenTypes.LITERAL_current_date:
        case SQLTokenTypes.LITERAL_current_time:
        case SQLTokenTypes.LITERAL_current_timestamp:
        case SQLTokenTypes.LITERAL_curdate:
        case SQLTokenTypes.LITERAL_curtime:
            return adapter.getNow();
        case SQLTokenTypes.NULL_INSERT:
            return "NULL";
        case SQLTokenTypes.LITERAL_null:
            return adapter.getNullConstant();
        /*
        case SQLTokenTypes.LITERAL_sign:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "SIGN("+s1+")";
        case SQLTokenTypes.LITERAL_left:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return "LEFT("+s1+","+s2+")";
        case SQLTokenTypes.LITERAL_right:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            return "RIGHT("+s1+","+s2+")";
        case SQLTokenTypes.LITERAL_substring:
            v1=child.getFirstChild();
            v2=v1.getNextSibling();
            v3=v2.getNextSibling();
            s1=getExpression(v1);
            s2=getExpression(v2);
            s3=(v3==null) ? null : getExpression(v3);
            return "SUBSTRING("+s1+","+s2+(s3==null ? "" : ","+s3)+")";
        case SQLTokenTypes.LITERAL_ascii:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "ASCII("+s1+")";
        case SQLTokenTypes.LITERAL_char:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "CHAR("+s1+")";
        case SQLTokenTypes.LITERAL_abs:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "ABS("+s1+")";
        case SQLTokenTypes.LITERAL_year:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "YEAR("+s1+")";
        case SQLTokenTypes.LITERAL_month:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "MONTH("+s1+")";
        case SQLTokenTypes.LITERAL_dayofmonth:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "DAYOFMONTH("+s1+")";
        case SQLTokenTypes.LITERAL_dayofweek:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "DAYOFWEEK("+s1+")";
        case SQLTokenTypes.LITERAL_dayofyear:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "DAYOFYEAR("+s1+")";
        case SQLTokenTypes.LITERAL_hour:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "HOUR("+s1+")";
        case SQLTokenTypes.LITERAL_minute:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "MINUTE("+s1+")";
        case SQLTokenTypes.LITERAL_second:
            v1=child.getFirstChild();
            s1=getExpression(v1);
            return "SECOND("+s1+")";
        */
        case SQLTokenTypes.HEX:
        case SQLTokenTypes.PARAMETER:
            return child.getText();
        /*
        case SQLTokenTypes.IDENTIFIER:
            return quote(identifier(child.getText()));
        */
        default:
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,child.getText());
        }
    }
    String identifier(String id) throws SQLException {
        if(id.length() > MAX_IDENTIFIER_LENGTH) {
            // TODO: correct error message
            throw Factory.getSQLException(Messages.SYNTAX_ERROR,id+" (max length: "+MAX_IDENTIFIER_LENGTH+")");
        }
        return id.toUpperCase();
    }
    String quote(String identifier) {
        return adapter.quote(identifier);
    }
}
