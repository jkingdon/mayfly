package org.ldbc.test;
import java.sql.*;

public class TestGrammarMore extends TestBase {
    String[] SQL=new String[]{
    // exists
    "0 ; CREATE TABLE TEST(ID1 INT)",
    "1 ; INSERT INTO TEST VALUES(1)",
    "0 ; DROP TABLE TEST",
    "E ; INSERT INTO TEST VALUES(2)",
    "0 ; CREATE TABLE IF NOT EXISTS TEST(ID2 INT)",
    "0 ; CREATE TABLE IF NOT EXISTS TEST(ID3 INT)",
    "1 ; INSERT INTO TEST VALUES(3)",
    "0 ; DROP TABLE IF EXISTS TEST",
    "E ; INSERT INTO TEST VALUES(4)",
    "0 ; DROP TABLE IF EXISTS TEST",
    "E ; DROP TABLE IF NOT EXISTS TEST",
    "E ; CREATE TABLE IF EXISTS TEST(ID4 INT)",
    
    // top
    "0 ; CREATE TABLE TEST(ID INT PRIMARY KEY, NAME VARCHAR(250))",
    "1 ; INSERT INTO TEST VALUES(1, 'Hello')",
    "1 ; INSERT INTO TEST VALUES(2, 'World')",
    "1 ; INSERT INTO TEST VALUES(3, 'Record')",
    "3 ; SELECT * FROM TEST",
    "0 ; SELECT TOP 0 * FROM TEST ORDER BY ID",
    "1 ; SELECT TOP 1 * FROM TEST ORDER BY ID",
    "2 ; SELECT TOP 2 * FROM TEST ORDER BY ID",
    "3 ; SELECT TOP 3 * FROM TEST ORDER BY ID",
    "3 ; SELECT TOP 4 * FROM TEST ORDER BY ID",
    
    };
    public static void main(String[] argv) {
        new TestGrammarMore().test(argv);
    }
    void test(Connection conn) throws SQLException {
        Statement stat=conn.createStatement();
        for(int i=0;i<SQL.length;i++) {
            String sql=SQL[i];
            int countExpected=-1;
            int idx = sql.indexOf(';');
            boolean exceptionExpected=false;
            if(idx != -1) {
                String s=sql.substring(0, idx).trim().toLowerCase();
                if(s.startsWith("e")) {
                    exceptionExpected=true;
                } else {
                    countExpected = Integer.parseInt(s);
                }
                sql = sql.substring(idx+1).trim();
            }
            trace(sql);
            SQLException exception;
            boolean resultset;
            try {
                resultset=stat.execute(sql);
                exception=null;
            } catch(SQLException e) {
                exception = e;
                resultset=false;
            }
            int count=0;
            if(exception != null) {
                if(!exceptionExpected) {
                    throw exception;
                }
                countExpected = 0;
                count = 0;
            } else if(exceptionExpected) {
                throw new SQLException("Exception expected: "+
                                    "<"+sql+">");
            } else if(resultset) {
                ResultSet rs=stat.getResultSet();
                ResultSetMetaData meta=rs.getMetaData();
                int colcount=meta.getColumnCount();
                while(rs.next()) {
                    count++;
                    for(int j=0;j<colcount;j++) {
                        rs.getString(j+1);
                    }
                }
            } else {
                count=stat.getUpdateCount();
            }
            if(countExpected != count) {
                throw new SQLException("Count missmatch for "+
                    "<"+sql+">"+
                    " expected:"+countExpected+
                    " got:"+count);
            }
        }
    }
}
