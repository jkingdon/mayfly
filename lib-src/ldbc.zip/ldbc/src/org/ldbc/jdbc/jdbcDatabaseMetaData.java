/*
 * Copyright (c) 2003 LDBC Group. For more information, please visit
 * http://ldbc.sourceforge.net
 */

package org.ldbc.jdbc;

import org.ldbc.core.*;
import org.ldbc.parser.*;
import java.sql.*;

/** 
 * Represents the meta data for a database.
 */
public class jdbcDatabaseMetaData implements DatabaseMetaData {
    final static String NOT_A_TABLE="+";
    static int counter;
    int id=counter++;
    jdbcConnection conn;
    Adapter adapter;
    DatabaseMetaData meta;
    /**
     * Returns the major version of this driver.
     * @return the major version number (for example 1)
     */
	public int getDriverMajorVersion() {
        if(Trace.isEnabled()) Trace.trace(getId());
        return jdbcDriver.MAJOR_VERSION;
    }
    /**
     * Returns the minor version of this driver.
     * @return the minor version number (for example 0)
     */
	public int getDriverMinorVersion() {
        if(Trace.isEnabled()) Trace.trace(getId());
        return jdbcDriver.MINOR_VERSION;
    }
    /**
     * Gets the database product name. 
     * Only one line of text will be returned, and never null.
     * @return the product name
     * @throws SQLException if the connection is closed 
     */
	public String getDatabaseProductName() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String name=meta.getDatabaseProductName();
            String line=getFirstLine(name);
            if(Trace.isEnabled()) Trace.traceResultQuote(line);
            return line;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the product version of the database.
     * Only one line of text will be returned, and never null.
     * @return the product version 
     * @throws SQLException if the connection is closed 
     */
	public String getDatabaseProductVersion() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String version=meta.getDatabaseProductVersion();
            String line=getFirstLine(version);
            if(Trace.isEnabled()) Trace.traceResultQuote(line);
            return line;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the name of the JDBC driver.
     * Only one line of text will be returned, and never null.
     * @return the constant LDBC, a space and the name of the underlying driver
     * @throws SQLException if the connection is closed 
     */
	public String getDriverName() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String driver=meta.getDriverName();
            String line="LDBC "+getFirstLine(driver);
            if(Trace.isEnabled()) Trace.traceResultQuote(line);
            return line;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the version number of the driver.
     * The format is [MajorVersion].[MinorVersion]
     * @return the version number
     * @throws SQLException if the connection is closed 
     */
	public String getDriverVersion() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String line=jdbcDriver.MAJOR_VERSION+"."+jdbcDriver.MINOR_VERSION;
            if(Trace.isEnabled()) Trace.traceResultQuote(line);
            return line;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of tables in the database.
     * Only data tables are returned, no system tables.
     * The resultset is sorted by table name.
     * Be careful with tableNamePattern, 
     * there are complex rules with wildcards!
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog (always null)
     * <li>2 TABLE_SCHEM (String) table schema (always null)
     * <li>3 TABLE_NAME (String) table name (all uppercase)
     * <li>4 TABLE_TYPE (String) table type ("TABLE")
     * <li>5 REMARKS (String) comment (always null)
     * </ul>
     *
     * @param catalog  must be null
     * @param schemaPattern must be null
     * @param tableNamePattern null (to get all tables) or a table name.
     *                           All uppercase. Wildcards % and _ are allowed.
     *                           A underline ('_') is a wildcard for any character,
     *                           except if it is quoted with '\'.
     *                           In Java source code the '\' must be quoted with '\'. 
     *                           Example Java code: table="ORDER\\_LINE";
     * @param types null or {"TABLE"}, anything else is not supported
     * @return the list of tables
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String types[]) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                    Trace.quote(catalog)+","+
                    Trace.quote(schemaPattern)+","+
                    Trace.quote(tableNamePattern)+","+
                    Trace.quote(types)
            );
            checkClosed();
            if(catalog!=null || schemaPattern!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schemaPattern:"+schemaPattern);
            }
            checkValidNamePattern(tableNamePattern);
            schemaPattern=getSchema();
            if(types!=null) {
                if(types.length!=1 || !types[0].equals("TABLE")) {
                    throw Factory.getInvalidValueException("types:"+Trace.quote(types));
                }
            } else {
                types=new String[]{"TABLE"};
            }
            ResultSet rs=meta.getTables(catalog,schemaPattern,null,types);
            MemoryResultSet memrs=new MemoryResultSet(rs,
                new String[]{"TABLE_CAT","TABLE_SCHEM","TABLE_NAME","TABLE_TYPE","REMARKS"},
                new int[]{Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR}
            );
            memrs.convertAllToUpperCase(3);
            for(int row=0;memrs.next();row++) {
                String table=memrs.getString(3);
                if(!testPattern(table,tableNamePattern) || !testTable(table)) {
                    memrs.deleteRow(row);
                    row=-1;
                }
            }
            memrs.reset();
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.setAllString(4,"TABLE");
            memrs.setAllNull(5);
            memrs.sort(new int[]{3});
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of columns. 
     * Only data tables are returned, no system tables.
     * The resultset is sorted by table name and ordinal position.
     * Be careful with tableNamePattern and columnNamePattern, 
     * there are complex rules with wildcards!
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog (always null)
     * <li>2 TABLE_SCHEM (String) table schema (always null)
     * <li>3 TABLE_NAME (String) table name (all uppercase)
     * <li>4 COLUMN_NAME (String) column name (all uppercase)
     * <li>5 DATA_TYPE (short) data type (see java.sql.Types)
     * <li>6 TYPE_NAME (String) data type name ("INTEGER", "VARCHAR","INTEGER AUTOINCREMENT")
     * <li>7 COLUMN_SIZE (int) precision (9 for INTEGER, number of characters for VARCHAR)
     * <li>8 BUFFER_LENGTH (int) reserved (always null)
     * <li>9 DECIMAL_DIGITS (int) scale (0 for INTEGER and VARCHAR)
     * <li>10 NUM_PREC_RADIX (int) radix (always 10)
     * <li>11 NULLABLE (int) nullable or not. columnNoNulls or columnNullable
     * <li>12 REMARKS (String) comment (always null)
     * <li>13 COLUMN_DEF (String) default value (always null)
     * <li>14 SQL_DATA_TYPE (int) reserved (always null)
     * <li>15 SQL_DATETIME_SUB (int) reserved (always null)
     * <li>16 CHAR_OCTET_LENGTH (int) reserved (always null)
     * <li>17 ORDINAL_POSITION (int) the column index (1,2,...)
     * <li>18 IS_NULLABLE (String) "NO" for no, "YES" for yes - actually rendundant (see column 11)
     * </ul>
     *
     * @param catalog must be null
     * @param schemaPattern must be null
     * @param tableNamePattern null (to get all tables) or a table name.
     *                           All uppercase. Wildcards % and _ are allowed.
     *                           A underline ('_') is a wildcard for any character,
     *                           except if it is quoted with '\'.
     *                           In Java source code the '\' must be quoted with '\'. 
     *                           Example Java code: table="ORDER\\_LINE";
     * @param columnNamePattern null (to get all columns) or a table name.
     *                           All uppercase. Wildcards % and _ are allowed.
     *                           A underline ('_') is a wildcard for any character,
     *                           except if it is quoted with '\'.
     *                           In Java source code the '\' must be quoted with '\'. 
     *                           Example Java code: table="POS\\_ID";
     * @return the list of columns 
     * @throws SQLException if the connection is closed 
     */
    public ResultSet getColumns(String catalog, String schemaPattern, 
    String tableNamePattern, String columnNamePattern) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                    Trace.quote(catalog)+","+
                    Trace.quote(schemaPattern)+","+
                    Trace.quote(tableNamePattern)+","+
                    Trace.quote(columnNamePattern)
            );
            checkClosed();
            if(catalog!=null || schemaPattern!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schemaPattern:"+schemaPattern);
            }
            checkValidNamePattern(tableNamePattern);
            checkValidNamePattern(columnNamePattern);
            schemaPattern=getSchema();
            ResultSet rs=meta.getColumns(catalog,schemaPattern,null,null);
            MemoryResultSet memrs=new MemoryResultSet(rs,
                new String[]{
                "TABLE_CAT","TABLE_SCHEM","TABLE_NAME","COLUMN_NAME","DATA_TYPE",
                "TYPE_NAME","COLUMN_SIZE","BUFFER_LENGTH","DECIMAL_DIGITS","NUM_PREC_RADIX",
                "NULLABLE","REMARKS","COLUMN_DEF","SQL_DATA_TYPE","SQL_DATETIME_SUB",
                "CHAR_OCTET_LENGTH","ORDINAL_POSITION","IS_NULLABLE"
                },
                new int[]{
                Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.SMALLINT,
                Types.VARCHAR,Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,
                Types.VARCHAR,Types.VARCHAR,Types.INTEGER,Types.INTEGER,Types.INTEGER,Types.INTEGER,
                Types.VARCHAR}
            );
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.convertAllToUpperCase(4);
            for(int row=0;memrs.next();row++) {
                String table=memrs.getString(3);
                String column=memrs.getString(4);
                if(!testPattern(table,tableNamePattern) || !testTable(table)) {
                    memrs.deleteRow(row);
                    row=-1;
                } else if(!testPattern(column,columnNamePattern)) {
                    memrs.deleteRow(row);
                    row=-1;
                }
            }
            memrs.reset();            
            for(int row=0;memrs.next();row++) {
                int datatype=memrs.getInt(5);
                String typename=memrs.getString(6);
                int precision=memrs.getInt(7);
                int scale=memrs.getInt(9);
                DataType type=new DataType(typename,datatype,precision,scale);
                conn.getAdapter().convertDataType(type);
                memrs.setInt(row,5,type.getDataType());
                String typeName=type.getTypeName();
                String tableName=memrs.getString(3);
                String columnName=memrs.getString(4);
                String autoinc=adapter.autoIncGetColumn(tableName);
                if(columnName.equals(autoinc)) {
                    typeName=typeName+" AUTOINCREMENT";
                }
                memrs.setString(row,6,typeName);
                memrs.setInt(row,7,type.getPrecision());
                memrs.setInt(row,9,type.getScale());
                int nullable=memrs.getInt(11);
                if(nullable==DatabaseMetaData.columnNoNulls) {
                    memrs.setString(row,18,"NO");
                } else if(nullable==DatabaseMetaData.columnNullable) {
                    memrs.setString(row,18,"YES");
                } else {
                    throw Factory.getInvalidValueException("nullable:"+nullable);
                }
            }
            memrs.reset();
            memrs.setAllNull(8);
            memrs.setAllInt(10,10);
            memrs.setAllNull(12);
            memrs.setAllNull(13);
            memrs.setAllNull(14);
            memrs.setAllNull(15);
            memrs.setAllNull(16);
            memrs.sort(new int[]{3,17});
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of indexes for this database.
     * Only indexes for data tables are returned, no system tables, no table statistics.
     * The resultset is sorted by NON_UNIQUE ('false' first), TYPE, INDEX_NAME and ORDINAL_POSITION.
     * The primary key index (if there is one) is also listed, with the name "PRIMARY_KEY".
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog (always null)
     * <li>2 TABLE_SCHEM (String) table schema (always null)
     * <li>3 TABLE_NAME (String) table name (all uppercase)
     * <li>4 NON_UNIQUE (boolean) 'false' for a unique index, 'true' for non-unique
     * <li>5 INDEX_QUALIFIER (String) index catalog (always null)
     * <li>6 INDEX_NAME (String) index name (all uppercase)
     * <li>7 TYPE (short) the index type (always tableIndexOther)
     * <li>8 ORDINAL_POSITION (short) the column index (1,2,...)
     * <li>9 COLUMN_NAME (String) the column name (all uppercase)
     * <li>10 ASC_OR_DESC (String) ascending or descending (always 'A')
     * <li>11 CARDINALITY (int) numbers of unique values (always null)
     * <li>12 PAGES (int) number of pages use (always null)
     * <li>13 FILTER_CONDITION (String) filter condition (always null)
     * </ul>
     *
     * @param catalog must be null
     * @param schema must be null
     * @param table table name. May not be not null, no wildcards, all uppercase.
     *                           A underline ('_') must NOT be quoted using '\'.
     *                           Example Java code: table="ORDER_LINE";
     * @param unique only unique indexes
     * @param approximate show only accurate data (the value is ignored)
     * @return the list of indexes and columns
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, 
    boolean approximate) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)+","+
                unique+","+approximate
            );
            checkClosed();
            if(catalog!=null || schema!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schema:"+schema);
            }
            checkValidName(table);
            schema=getSchema();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            String pkname=getPrimaryKeyName(catalog,schema,table);
            ResultSet rs=meta.getIndexInfo(catalog,schema,table,unique,true);
            MemoryResultSet memrs=new MemoryResultSet(rs,
                new String[]{
                "TABLE_CAT","TABLE_SCHEM","TABLE_NAME","NON_UNIQUE","INDEX_QUALIFIER",
                "INDEX_NAME","TYPE","ORDINAL_POSITION","COLUMN_NAME","ASC_OR_DESC",
                "CARDINALITY","PAGES","FILTER_CONDITION"
                },
                new int[]{
                Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.BIT,Types.VARCHAR,
                Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,Types.VARCHAR,Types.VARCHAR,
                Types.INTEGER,Types.INTEGER,Types.VARCHAR
                }
            );
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.setAllNull(5);
            memrs.convertAllToUpperCase(6);
            memrs.setAllShort(7,DatabaseMetaData.tableIndexOther);
            memrs.convertAllToUpperCase(9);
            memrs.setAllString(10,"A");
            memrs.setAllNull(11);
            memrs.setAllNull(12);
            memrs.setAllNull(13);
            for(int row=0;memrs.next();row++) {
                String indexname=memrs.getString(6);
                indexname=adapter.truncateIndexName(indexname);
                if(indexname == null) {
                    indexname = "";
                    memrs.setString(row,6,indexname);
                }
                if(adapter.isPrimaryKey(indexname, pkname)) {
                    memrs.setString(row,6,"PRIMARY_KEY");
                } else if(indexname.length()==0 || adapter.isSystemIndex(table, indexname)) {
                    // its not really an index
                    memrs.deleteRow(row);
                    row=-1;
                    // start from the beginning again
                }
            }
            memrs.reset();
            for(int row=0;memrs.next();row++) {
                String indexname=memrs.getString(6);
                indexname=adapter.truncateIndexName(indexname);
                // TODO: what a table PRIMARY and an index KEY?
                if(indexname.startsWith(table+"_")) {
                    indexname=indexname.substring(table.length()+1);
                    memrs.setString(row,6,indexname);
                }
            }
            memrs.reset();
            memrs.sort(new int[]{4,7,6,8});
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the primary key columns for a table.
     * The resultset is sorted by COLUMN_NAME (and not by KEY_SEQ).
     * The primary key index (if there is one) is also listed, with the name "PRIMARY_KEY".
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog (always null)
     * <li>2 TABLE_SCHEM (String) table schema (always null)
     * <li>3 TABLE_NAME (String) table name (all uppercase)
     * <li>4 COLUMN_NAME (String) column name (all uppercase) 
     * <li>5 KEY_SEQ (short) the column index of this column (1,2,...)
     * <li>6 PK_NAME (String) always "PRIMARY_KEY"
     * </ul>
     *
     * @param catalog must be null
     * @param schema must be null
     * @param table table name (may not be not null, no wildcards, all uppercase).
     *                           A underline ('_') must not be quoted using '\'.
     *                           Example Java code: table="ORDER_LINE";
     * @return the list of primary key columns 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getPrimaryKeys(String catalog, String schema, String table) 
    throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)
            );
            checkClosed();
            if(catalog!=null || schema!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schema:"+schema);
            }
            checkValidName(table);
            schema=getSchema();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            ResultSet rs=meta.getPrimaryKeys(catalog,schema,table);
            MemoryResultSet memrs=new MemoryResultSet(rs,
                new String[]{
                "TABLE_CAT","TABLE_SCHEM","TABLE_NAME","COLUMN_NAME","KEY_SEQ","PK_NAME"
                },
                new int[]{
                Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                Types.SMALLINT,Types.VARCHAR
                }
            );
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.convertAllToUpperCase(4);
            memrs.setAllString(6,"PRIMARY_KEY");
            // fix a bug in Firebird
            for(int row=0;memrs.next();row++) {
                String t=memrs.getString(3);
                if(!table.equals(t)) {
                    memrs.deleteRow(row);
                    row=-1;
                }
            }
            memrs.reset();
            memrs.sort(new int[]{4});
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if all procedures callable.
     * @return true 
     * @throws SQLException if the connection is closed 
     */
	public boolean allProceduresAreCallable() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks if it possible to query all tables returned by getTables.
     * @return true 
     * @throws SQLException if the connection is closed 
     */
	public boolean allTablesAreSelectable() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            return true;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the database URL (jdbc:ldbc:...) for this connection.
     * @return the url 
     * @throws SQLException if the connection is closed 
     */
	public String getURL() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String url=conn.url;
            if(Trace.isEnabled()) Trace.traceResultQuote(url);
            return url;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the user name as passed to DriverManager.getConnection(url,user,password).
     * @return the user name 
     * @throws SQLException if the connection is closed 
     */
	public String getUserName() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            String user=conn.user;
            if(Trace.isEnabled()) Trace.traceResultQuote(user);
            return user; 
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the same as Connection.isReadOnly
     * @return if read only optimization is switched on
     * @throws SQLException if the connection is closed 
     */
	public boolean isReadOnly() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            boolean result=conn.isReadOnly();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks is NULL values are sorted high (bigger than any non-null values).
     * This is database specific.
     * An application should not rely on where null values are sorted in ORDER BY,
     * so that it works with all databases.
     * @return true or false
     * @throws SQLException if the connection is closed 
     */
	public boolean nullsAreSortedHigh() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=meta.nullsAreSortedHigh();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks is NULL values are sorted low (smaller than any non-null values).
     * This is database specific.
     * An application should not rely on where null values are sorted in ORDER BY,
     * so that it works with all databases.
     * @return true or false
     * @throws SQLException if the connection is closed 
     */
	public boolean nullsAreSortedLow() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=meta.nullsAreSortedLow();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks is NULL values are sorted at the beginning (no matter if ASC or DESC is used).
     * This is database specific.
     * An application should not rely on where null values are sorted in ORDER BY,
     * so that it works with all databases.
     * @return true or false
     * @throws SQLException if the connection is closed 
     */
	public boolean nullsAreSortedAtStart() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=meta.nullsAreSortedAtStart();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Checks is NULL values are sorted at the end (no matter if ASC or DESC is used).
     * This is database specific.
     * An application should not rely on where null values are sorted in ORDER BY,
     * so that it works with all databases.
     * @return true or false
     * @throws SQLException if the connection is closed 
     */
	public boolean nullsAreSortedAtEnd() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=meta.nullsAreSortedAtEnd();
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns the connection that created this object.
     * @return the connection 
     */
    public Connection getConnection() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            if(Trace.isEnabled()) Trace.traceResult(conn.getId());
            return conn;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of procedures.
     * As prodecures are very database specific, this call returns an empty resultset.
     *
     * <ul>
     * <li>1 PROCEDURE_CAT (String) catalog
     * <li>2 PROCEDURE_SCHEM (String) schema
     * <li>3 PROCEDURE_NAME (String) name
     * <li>4 NUM_INPUT_PARAMS (int) for future use
     * <li>5 NUM_OUTPUT_PARAMS (int) for future use
     * <li>6 NUM_RESULT_SETS (int) for future use
     * <li>7 REMARKS (String) description
     * <li>8 PROCEDURE_TYPE (short) if this procedure returns a result
     * </ul>
     *
     * @param catalog ignored
     * @param schemaPattern ignored
     * @param procedureNamePattern ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schemaPattern)+","+
                Trace.quote(procedureNamePattern)
            );
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "PROCEDURE_CAT","PROCEDURE_SCHEM","PROCEDURE_NAME",
                    "NUM_INPUT_PARAMS","NUM_OUTPUT_PARAMS","NUM_RESULT_SETS",
                    "REMARKS","PROCEDURE_TYPE"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.INTEGER,Types.INTEGER,Types.INTEGER,
                    Types.VARCHAR,Types.SMALLINT
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of procedure columns.
     * As prodecures are very database specific, this call returns an empty resultset.
     *
     * <ul>
     * <li>1 PROCEDURE_CAT (String) catalog
     * <li>2 PROCEDURE_SCHEM (String) schema
     * <li>3 PROCEDURE_NAME (String) name
     * <li>4 COLUMN_NAME (String) column name
     * <li>5 COLUMN_TYPE (short) column type
     * <li>6 DATA_TYPE (short) sql type
     * <li>7 TYPE_NAME (String) type name
     * <li>8 PRECISION (int) precision
     * <li>9 LENGTH (int) length
     * <li>10 SCALE (short) scale
     * <li>11 RADIX (int) always 10
     * <li>12 NULLABLE (short) nullable
     * <li>13 REMARKS (String) description
     * </ul>
     *
     * @param catalog ignored
     * @param schemaPattern ignored
     * @param procedureNamePattern ignored
     * @param columnNamePattern ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schemaPattern)+","+
                Trace.quote(procedureNamePattern)+","+
                Trace.quote(columnNamePattern)
            );
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "PROCEDURE_CAT","PROCEDURE_SCHEM","PROCEDURE_NAME",
                    "COLUMN_NAME","COLUMN_TYPE","DATA_TYPE",
                    "TYPE_NAME","PRECISION","LENGTH","SCALE","RADIX",
                    "NULLABLE","REMARKS"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,Types.VARCHAR,
                    Types.INTEGER,Types.INTEGER,Types.SMALLINT,Types.INTEGER,
                    Types.SMALLINT,Types.VARCHAR
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of schemas.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TABLE_SCHEM (String) schema name
     * </ul>
     *
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getSchemas() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TABLE_SCHEM"
                },
                new int[]{
                    Types.VARCHAR
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of catalogs.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TABLE_CAT (String) catalog name
     * </ul>
     *
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getCatalogs() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TABLE_CAT"
                },
                new int[]{
                    Types.VARCHAR
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of table types.
     * This call returns a resultset with one record, "TABLE"
     *
     * <ul>
     * <li>1 TABLE_TYPE (String) table type
     * </ul>
     *
     * @return the resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getTableTypes() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TABLE_TYPE"
                },
                new int[]{
                    Types.VARCHAR
                }
            );
            memrs.appendRow(new Object[]{"TABLE"});
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of column privileges.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog
     * <li>2 TABLE_SCHEM (String) table schema
     * <li>3 TABLE_NAME (String) table name
     * <li>4 COLUMN_NAME (String) column name
     * <li>5 GRANTOR (String) the grantor of access (null)
     * <li>6 GRANTEE (String) the grantee of access
     * <li>7 PRIVILEGE (String) SELECT,INSERT,UPDATE,DELETE,REFERENCES
     * <li>8 IS_GRANTABLE (String) YES means the grantee can grant access to others
     * </ul>
     *
     * @param catalog ignored
     * @param schema ignored
     * @param columnNamePattern ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)+","+
                Trace.quote(columnNamePattern)
            );
            checkClosed();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TABLE_CAT","TABLE_SCHEM","TABLE_NAME","COLUMN_NAME",
                    "GRANTOR","GRANTEE","PRIVILEGE","IS_GRANTABLE"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of table privileges.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TABLE_CAT (String) table catalog
     * <li>2 TABLE_SCHEM (String) table schema
     * <li>3 TABLE_NAME (String) table name
     * <li>4 GRANTOR (String) grantor of access
     * <li>5 GRANTEE (String) grantee of access
     * <li>6 PRIVILEGE (String) SELECT, INSERT, UPDATE, DELETE or REFERENCES
     * <li>7 IS_GRANTABLE (String) YES means the grantee can grant access to others
     * </ul>
     *
     * @param catalog ignored
     * @param schemaPattern ignored
     * @param tableNamePattern ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schemaPattern)+","+
                Trace.quote(tableNamePattern)
            );
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TABLE_CAT","TABLE_SCHEM","TABLE_NAME",
                    "GRANTOR","GRANTEE","PRIVILEGE",
                    "IS_GRANTABLE"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of columns that best identifier a row in a table.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 SCOPE (short) scope of result (for example bestRowSession)
     * <li>2 COLUMN_NAME (String) column name
     * <li>3 DATA_TYPE (short) SQL data type, see also java.sql.Types
     * <li>4 TYPE_NAME (String) type name
     * <li>5 COLUMN_SIZE (int) precision
     * <li>6 BUFFER_LENGTH (int) not used
     * <li>7 DECIMAL_DIGITS (short) scale
     * <li>8 PSEUDO_COLUMN (short) for example bestRowNotPseudo
     * </ul>
     *
     * @param catalog ignored
     * @param schema ignored
     * @param table ignored
     * @param scope ignored
     * @param nullable ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)+","+scope+","+nullable
            );
            checkClosed();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "SCOPE","COLUMN_NAME","DATA_TYPE","TYPE_NAME",
                    "COLUMN_SIZE","BUFFER_LENGTH","DECIMAL_DIGITS","PSEUDO_COLUMN"
                },
                new int[]{
                    Types.SMALLINT,Types.VARCHAR,Types.SMALLINT,Types.VARCHAR,
                    Types.INTEGER,Types.INTEGER,Types.SMALLINT,Types.SMALLINT
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Get the list of columns that are update when any value is updated.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 SCOPE (int) not used
     * <li>2 COLUMN_NAME (String) column name
     * <li>3 DATA_TYPE (int) SQL data type - see also java.sql.Types 
     * <li>4 TYPE_NAME (String) data type name
     * <li>5 COLUMN_SIZE (int) precision
     * <li>6 BUFFER_LENGTH (int) length (bytes)
     * <li>7 DECIMAL_DIGITS (int) scale
     * <li>8 PSEUDO_COLUMN (int) is this column a pseudo column
     * </ul>
     *
     * @param catalog ignored
     * @param schema ignored
     * @param table ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getVersionColumns(String catalog, String schema, String table) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)
            );
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "SCOPE","COLUMN_NAME","DATA_TYPE","TYPE_NAME",
                    "COLUMN_SIZE","BUFFER_LENGTH","DECIMAL_DIGITS","PSEUDO_COLUMN"
                },
                new int[]{
                    Types.SMALLINT,Types.VARCHAR,Types.SMALLINT,Types.VARCHAR,
                    Types.INTEGER,Types.INTEGER,Types.SMALLINT,Types.SMALLINT
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of primary key columns that are referenced by a table.
     * The resultset is sorted by PKTABLE_CAT, PKTABLE_SCHEM, PKTABLE_NAME, FK_NAME, KEY_SEQ.
     *
     * <ul>
     * <li>1 PKTABLE_CAT (String) primary catalog
     * <li>2 PKTABLE_SCHEM (String) primary schema
     * <li>3 PKTABLE_NAME (String) primary table
     * <li>4 PKCOLUMN_NAME (String) primary column
     * <li>5 FKTABLE_CAT (String) foreign catalog
     * <li>6 FKTABLE_SCHEM (String) foreign schema
     * <li>7 FKTABLE_NAME (String) foreign table
     * <li>8 FKCOLUMN_NAME (String) foreign column
     * <li>9 KEY_SEQ (short) sequence number (1, 2, ...)
     * <li>10 UPDATE_RULE (short) action on update  
     *        (always DatabaseMetaData.importedKeyNoAction)
     * <li>11 DELETE_RULE (short) action on delete  
     *        (always DatabaseMetaData.importedKeyNoAction)
     * <li>12 FK_NAME (String) foreign key name 
     *        (the first foreign key is FK_1, the second 
     *        FK_2 and so on; however there is no guarantee 
     *        that the first foreign key in the 
     *        CREATE TABLE definition is FK_1 
     *        because of MySQL)
     * <li>13 PK_NAME (String) primary key name 
     *        (always null)
     * <li>14 DEFERRABILITY (short) deferrable or not 
     *        (always DatabaseMetaData.importedKeyNotDeferrable)
     * </ul>
     *
     * @param catalog ignored
     * @param schema ignored
     * @param table the table name
     * @return the resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getImportedKeys(String catalog, String schema, String table) throws SQLException {
        try {
            int[] sortOrder = new int[]{1, 2, 3, 12, 9};
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)
            );
            checkClosed();
            if(catalog!=null || schema!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schema:"+schema);
            }
            checkValidName(table);
            schema=getSchema();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            ResultSet rs=meta.getImportedKeys(catalog,schema,table);
            MemoryResultSet memrs=new MemoryResultSet(rs,
                new String[]{
                    "PKTABLE_CAT","PKTABLE_SCHEM","PKTABLE_NAME","PKCOLUMN_NAME",
                    "FKTABLE_CAT","FKTABLE_SCHEM","FKTABLE_NAME","FKCOLUMN_NAME",
                    "KEY_SEQ","UPDATE_RULE","DELETE_RULE",
                    "FK_NAME","PK_NAME","DEFERRABILITY"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,
                    Types.VARCHAR,Types.VARCHAR,Types.SMALLINT
                }
            );
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.convertAllToUpperCase(4);
            memrs.setAllNull(5);
            memrs.setAllNull(6);
            memrs.convertAllToUpperCase(7);
            memrs.convertAllToUpperCase(8);
            memrs.setAllInt(10,DatabaseMetaData.importedKeyNoAction);
            memrs.setAllInt(11,DatabaseMetaData.importedKeyNoAction);
            memrs.convertAllToUpperCase(12);
            memrs.setAllNull(13);
            memrs.setAllInt(14,DatabaseMetaData.importedKeyNotDeferrable);
            memrs.reset();
            memrs.sort(sortOrder);
            String lastname=null;
            int seq=-1;
            int lastseq=0;
            int fkid=1;
            for(int row=0;memrs.next();row++) {
                String name=memrs.getString(12);
                int s=memrs.getInt(9);
                if(lastname==null || !lastname.equals(name) || s<=lastseq) {
                    seq = 1;
                    lastname = name;
                    fkid++;
                }
                lastseq = s;
                // fix for MySQL: the internal name is returned
                name = adapter.getForeignKeyName(table, name);
                memrs.setString(row, 12, name);
                memrs.setShort(row, 9, (short)seq++);
            }
            memrs.reset();
            // need to re-sort because the foreign key names may have changed
            memrs.sort(sortOrder);
            memrs.reset();
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of foreign key columns that references a table.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 PKTABLE_CAT (String) primary catalog
     * <li>2 PKTABLE_SCHEM (String) primary schema
     * <li>3 PKTABLE_NAME (String) primary table
     * <li>4 PKCOLUMN_NAME (String) primary column
     * <li>5 FKTABLE_CAT (String) foreign catalog
     * <li>6 FKTABLE_SCHEM (String) foreign schema
     * <li>7 FKTABLE_NAME (String) foreign table
     * <li>8 FKCOLUMN_NAME (String) foreign column
     * <li>9 KEY_SEQ (short) sequence number (1,2,...)
     * <li>10 UPDATE_RULE (short) action on update  (always DatabaseMetaData.importedKeyNoAction)
     * <li>11 DELETE_RULE (short) action on delete  (always DatabaseMetaData.importedKeyNoAction)
     * <li>12 FK_NAME (String) foreign key name (always null)
     * <li>13 PK_NAME (String) primary key name (always null)
     * <li>14 DEFERRABILITY (short) deferrable or not (always DatabaseMetaData.importedKeyNotDeferrable)
     * </ul>
     *
     * @param catalog ignored
     * @param schema ignored
     * @param table ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getExportedKeys(String catalog, String schema, String table) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schema)+","+
                Trace.quote(table)
            );
            checkClosed();
            if(catalog!=null || schema!=null) {
                throw Factory.getInvalidValueException("catalog:"+catalog+" schema:"+schema);
            }
            checkValidName(table);
            schema=getSchema();
            if(!testTable(table)) {
                table=NOT_A_TABLE;
            }
            // The resultset is sorted by FKTABLE_CAT, FKTABLE_SCHEM, FKTABLE_NAME, KEY_SEQ.
            /*
            ResultSet rs=mMeta.getExportedKeys(catalog,schema,table);
            MemoryResultSet memrs=new MemoryResultSet(rs,
            */
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "PKTABLE_CAT","PKTABLE_SCHEM","PKTABLE_NAME","PKCOLUMN_NAME",
                    "FKTABLE_CAT","FKTABLE_SCHEM","FKTABLE_NAME","FKCOLUMN_NAME",
                    "KEY_SEQ","UPDATE_RULE","DELETE_RULE",
                    "FK_NAME","PK_NAME","DEFERRABILITY"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,
                    Types.VARCHAR,Types.VARCHAR,Types.SMALLINT
                }
            );
            /*
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.convertAllToUpperCase(4);
            memrs.setAllNull(5);
            memrs.setAllNull(6);
            memrs.convertAllToUpperCase(7);
            memrs.convertAllToUpperCase(8);
            memrs.setAllInt(10,DatabaseMetaData.importedKeyNoAction);
            memrs.setAllInt(11,DatabaseMetaData.importedKeyNoAction);
            memrs.setAllNull(12);
            memrs.setAllNull(13);
            memrs.setAllInt(14,DatabaseMetaData.importedKeyNotDeferrable);
            memrs.reset();
            memrs.sort(new int[]{5,6,7,9});
            String tab=null;
            int seq=0;
            for(int row=0;memrs.next();row++) {
                String t=memrs.getString(7);
                if(tab==null || tab.equals(t)) {
                    seq=1;
                }
                memrs.setInt(row,9,seq++);
            }
            memrs.reset();
            */
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of foreign key columns that references a table, as well as the
     * list of primary key columns that are references by a table.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 PKTABLE_CAT (String) primary catalog
     * <li>2 PKTABLE_SCHEM (String) primary schema
     * <li>3 PKTABLE_NAME (String) primary table
     * <li>4 PKCOLUMN_NAME (String) primary column
     * <li>5 FKTABLE_CAT (String) foreign catalog
     * <li>6 FKTABLE_SCHEM (String) foreign schema
     * <li>7 FKTABLE_NAME (String) foreign table
     * <li>8 FKCOLUMN_NAME (String) foreign column
     * <li>9 KEY_SEQ (short) sequence number (1,2,...)
     * <li>10 UPDATE_RULE (short) action on update  (always DatabaseMetaData.importedKeyNoAction)
     * <li>11 DELETE_RULE (short) action on delete  (always DatabaseMetaData.importedKeyNoAction)
     * <li>12 FK_NAME (String) foreign key name (always null)
     * <li>13 PK_NAME (String) primary key name (always null)
     * <li>14 DEFERRABILITY (short) deferrable or not (always DatabaseMetaData.importedKeyNotDeferrable)
     * </ul>
     *
     * @param primaryCatalog ignored
     * @param primarySchema ignored
     * @param primaryTable ignored
     * @param foreignCatalog ignored
     * @param foreignSchema ignored
     * @param foreignTable ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getCrossReference(
        String primaryCatalog, String primarySchema, String primaryTable, 
        String foreignCatalog, String foreignSchema, String foreignTable) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(primaryCatalog)+","+
                Trace.quote(primarySchema)+","+
                Trace.quote(primaryTable)+","+
                Trace.quote(foreignCatalog)+","+
                Trace.quote(foreignSchema)+","+
                Trace.quote(foreignTable)
            );
            checkClosed();
            if(primaryCatalog!=null || primarySchema!=null) {
                throw Factory.getInvalidValueException("primaryCatalog:"+primaryCatalog+" primarySchema:"+primarySchema);
            }
            checkValidName(primaryTable);
            primarySchema=getSchema();
            if(foreignCatalog!=null || foreignSchema!=null) {
                throw Factory.getInvalidValueException("foreignCatalog:"+foreignCatalog+" foreignSchema:"+foreignSchema);
            }
            checkValidName(foreignTable);
            foreignSchema=getSchema();
            if(!testTable(foreignTable)) {
                foreignTable=NOT_A_TABLE;
            }
            if(!testTable(primaryTable)) {
                primaryTable=NOT_A_TABLE;
            }
            /*
            ResultSet rs=mMeta.getCrossReference(primaryCatalog,primarySchema,primaryTable,foreignCatalog,foreignSchema,foreignTable);
            MemoryResultSet memrs=new MemoryResultSet(rs,
            */
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "PKTABLE_CAT","PKTABLE_SCHEM","PKTABLE_NAME","PKCOLUMN_NAME",
                    "FKTABLE_CAT","FKTABLE_SCHEM","FKTABLE_NAME","FKCOLUMN_NAME",
                    "KEY_SEQ","UPDATE_RULE","DELETE_RULE",
                    "FK_NAME","PK_NAME","DEFERRABILITY"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,
                    Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,
                    Types.VARCHAR,Types.VARCHAR,Types.SMALLINT
                }
            );
            /*
            memrs.setAllNull(1);
            memrs.setAllNull(2);
            memrs.convertAllToUpperCase(3);
            memrs.convertAllToUpperCase(4);
            memrs.setAllNull(5);
            memrs.setAllNull(6);
            memrs.convertAllToUpperCase(7);
            memrs.convertAllToUpperCase(8);
            memrs.setAllInt(10,DatabaseMetaData.importedKeyNoAction);
            memrs.setAllInt(11,DatabaseMetaData.importedKeyNoAction);
            memrs.setAllNull(12);
            memrs.setAllNull(13);
            memrs.setAllInt(14,DatabaseMetaData.importedKeyNotDeferrable);
            memrs.reset();
            memrs.sort(new int[]{1,2,3,9});
            String tab=null;
            for(int row=0,seq=1;memrs.next();row++) {
                memrs.setInt(row,9,seq++);
            }
            memrs.reset();
            */
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of user defined data types.
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TYPE_CAT (String) catalog
     * <li>2 TYPE_SCHEM (String) schema
     * <li>3 TYPE_NAME (String) type name
     * <li>4 CLASS_NAME (String) Java class
     * <li>5 DATA_TYPE (short) SQL Type - see also java.sql.Types
     * <li>6 REMARKS (String) description
     * <li>7 BASE_TYPE (short) base type - see also java.sql.Types
     * </ul>
     *
     * @param catalog ignored
     * @param schemaPattern ignored
     * @param typeNamePattern ignored
     * @param types ignored
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
    public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),
                Trace.quote(catalog)+","+
                Trace.quote(schemaPattern)+","+
                Trace.quote(typeNamePattern)+","+
                Trace.quote(types)
            );
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TYPE_CAT","TYPE_SCHEM","TYPE_NAME","CLASS_NAME","DATA_TYPE","REMARKS","BASE_TYPE"
                },
                new int[]{
                    Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR,Types.SMALLINT,Types.VARCHAR,Types.SMALLINT
                }
            );
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Gets the list of data types.
     * The resultset is ordered by DATA_TYPE and then by how
     * closely the data type maps to the corresponding JDBC SQL type (best match first).
     * This call returns an empty resultset.
     *
     * <ul>
     * <li>1 TYPE_NAME (String) type name
     * <li>2 DATA_TYPE (short) SQL data type - see also java.sql.Types
     * <li>3 PRECISION (int) maximum precision
     * <li>4 LITERAL_PREFIX (String) prefix used to quote a literal (may be null)
     * <li>5 LITERAL_SUFFIX (String) suffix used to quote a literal (may be null)
     * <li>6 CREATE_PARAMS (String) parameters used (may be null) 
     * <li>7 NULLABLE (short) typeNoNulls (NULL not allowed), typeNullable or typeNullableUnknown
     * <li>8 CASE_SENSITIVE (boolean) case sensitive
     * <li>9 SEARCHABLE (short) typePredNone, typePredChar (only in LIKE), typePredBasic (not in LIKE), typeSearchable 
     * <li>10 UNSIGNED_ATTRIBUTE (boolean) unsigned
     * <li>11 FIXED_PREC_SCALE (boolean) fixed precision
     * <li>12 AUTO_INCREMENT (boolean) auto increment
     * <li>13 LOCAL_TYPE_NAME (String) localized version of the data type
     * <li>14 MINIMUM_SCALE (short) minimum scale
     * <li>15 MAXIMUM_SCALE (short) maximum scale
     * <li>16 SQL_DATA_TYPE (int) unused
     * <li>17 SQL_DATETIME_SUB (int) unused
     * <li>18 NUM_PREC_RADIX (int) 2 for binary, 10 for decimal
     * </ul>
     *
     * @return an empty resultset 
     * @throws SQLException if the connection is closed 
     */
	public ResultSet getTypeInfo() throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            MemoryResultSet memrs=new MemoryResultSet(null,
                new String[]{
                    "TYPE_NAME","DATA_TYPE","PRECISION","LITERAL_PREFIX",
                    "LITERAL_SUFFIX","CREATE_PARAMS","NULLABLE","CASE_SENSITIVE",
                    "SEARCHABLE","UNSIGNED_ATTRIBUTE","FIXED_PREC_SCALE",
                    "AUTO_INCREMENT","LOCAL_TYPE_NAME","MINIMUM_SCALE",
                    "MAXIMUM_SCALE","SQL_DATA_TYPE","SQL_DATETIME_SUB",
                    "NUM_PREC_RADIX"
                },
                new int[]{
                    Types.VARCHAR,Types.SMALLINT,Types.INTEGER,Types.VARCHAR,
                    Types.VARCHAR,Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,
                    Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,Types.SMALLINT,
                    Types.VARCHAR,Types.SMALLINT,Types.SMALLINT,Types.INTEGER,
                    Types.INTEGER,Types.INTEGER
                }
            );
            //                   datatype        prefix       suff autoi params            radix
            addDatatypeRow(memrs,Types.DECIMAL  ,null        ,null,false,"precision,scale",10);
            addDatatypeRow(memrs,Types.INTEGER  ,null        ,null,false,null             ,10);
            addDatatypeRow(memrs,Types.INTEGER  ,null        ,null,true ,null             ,10);
            addDatatypeRow(memrs,Types.VARCHAR  ,"'"         ,"'" ,false,"length"         ,10);
            addDatatypeRow(memrs,Types.TIMESTAMP,"DATETIME '","'" ,false,null             ,10);
            addDatatypeRow(memrs,Types.CLOB     ,"'"         ,"'" ,false,null             ,10);
            addDatatypeRow(memrs,Types.BLOB     ,"X'"        ,"'" ,false,null             ,10);
            jdbcResultSet result=new jdbcResultSet(conn,memrs);
            if(Trace.isEnabled()) Trace.traceResult(result.getId());
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    private void addDatatypeRow(MemoryResultSet rs,int dt,String prefix,String suffix,
            boolean autoinc,String params,int radix) throws SQLException {
        Object row[]=new Object[18];
        String datatype=DataType.getDataTypeString(dt);
        if(autoinc) {
            datatype="AUTOINCREMENT "+datatype;
        }
        row[12]=row[0]=datatype;
        row[15]=row[1]=new Integer(dt);
        row[2]=new Integer(DataType.getDefaultPrecision(dt));
        row[3]=prefix;
        row[4]=suffix;
        row[5]=params;
        row[6]=new Integer(DatabaseMetaData.typeNullable);
        row[7]=row[9]=row[10]=row[11]=new Integer(0);
        if(autoinc) {
            row[11]=new Integer(1);
        }
        row[8]=new Integer(DatabaseMetaData.typeSearchable);
        if(radix==10) {
            row[13]=new Integer(0);
            row[14]=new Integer(DataType.getDefaultScale(dt));
            row[17]=new Integer(radix);
        }
        rs.appendRow(row);
    }
    /**
     * Checks if this database store data in local files.
     * @return true 
     * @throws SQLException if the connection is closed 
     */
	public boolean usesLocalFiles() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true; 
    }
    /**
     * Checks if this database use one file per table.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean usesLocalFilePerTable() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns the string used to quote identifiers.
     * @return a double quote
     * @throws SQLException if the connection is closed 
     */
	public String getIdentifierQuoteString() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "\"";
    }
    /**
     * Gets the comma-separated list of all SQL keywords 
     * that are not supported as table/column/index name,
     * in addition to the SQL-92 keywords. That means, 
     * the list should theoretically not contain SQL-92 keywords.
     * <p>
     * However, the JDBC API does not define a way to get the SQL-92 keywords.
     * Also, the list of SQL-92 keywords does not seem to be defined anywhere.
     * Therefore, this method also returns SQL-92 keywords.
     * <p>
     * You should not rely on the fact that the list is 
     * sorted by alphabet, and uppercase, and does not contain spaces. 
     * @return a list with the keywords
     * @throws SQLException if the connection is closed
     */
	public String getSQLKeywords() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        String keywords=Translator.getKeywords();
        return keywords; 
    }
    /**
     * Returns the list of numeric functions supported by this database.
     * @return the list
     * @throws SQLException if the connection is closed 
     */
	public String getNumericFunctions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "";
    }
    /**
     * Returns the list of string functions supported by this database.
     * @return the list
     * @throws SQLException if the connection is closed 
     */
	public String getStringFunctions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "";
    }
    /**
     * Returns the list of system functions supported by this database.
     * @return the list
     * @throws SQLException if the connection is closed 
     */
	public String getSystemFunctions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "CAST";
    }
    /**
     * Returns the list of date and time functions supported by this database.
     * @return the list
     * @throws SQLException if the connection is closed 
     */
	public String getTimeDateFunctions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "";
    }
    /**
     * Returns the default escape character for LIKE.
     * @return the character
     * @throws SQLException if the connection is closed 
     */
	public String getSearchStringEscape() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "\"";
    }
    /**
     * Returns the characters that are allowed for identifiers
     * in addiction to A-Z, a-z, 0-9 and '_'. 
     * @return an empty String ("")
     * @throws SQLException if the connection is closed 
     */
	public String getExtraNameCharacters() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "";
    }
    /**
     * Returns whether alter table with add column is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsAlterTableWithAddColumn() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether alter table with drop column is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsAlterTableWithDropColumn() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether column aliasing is supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsColumnAliasing() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether NULL+1 is NULL or not.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean nullPlusNonNullIsNull() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether CONVERT is supported.
     * @return false (however CAST is supported)
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsConvert() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether CONVERT is supported for one datatype to another.
     * @return false (CONVERT is not supported; however CAST is supported)
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsConvert(int fromType, int toType) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether table correlation names (table alias) are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsTableCorrelationNames() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether table correlation names (table alias) are restricted to be different than table names.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsDifferentTableCorrelationNames() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether expression in ORDER BY are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsExpressionsInOrderBy() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether ORDER BY is supported if the column is not in the SELECT list.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOrderByUnrelated() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether GROUP BY is supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsGroupBy() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether GROUP BY is supported if the column is not in the SELECT list.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsGroupByUnrelated() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * This is a little confusing. The JDBC API Tutorial and Reference, Second Edition, says:
     * 'Checks whether a GROUP BY clause can use columns that are not in the
     * SELECT clause, provided that it specifies all the columns in the SELECT clause.'
     * It probably means, it can use column in addition to the column in the select list,
     * only if all columns in the select list are also specified.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsGroupByBeyondSelect() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether LIKE... ESCAPE is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsLikeEscapeClause() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether multiple resultsets are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsMultipleResultSets() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether multiple transactions (on different connections) are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsMultipleTransactions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether columns with NOT NULL are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsNonNullableColumns() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether ODBC Minimum SQL grammar is supported.
     * All JDBC compliant drivers must return true.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsMinimumSQLGrammar() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether ODBC Core SQL grammar is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCoreSQLGrammar() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether ODBC Extended SQL grammar is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsExtendedSQLGrammar() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether SQL-92 entry level grammar is supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsANSI92EntryLevelSQL() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether SQL-92 intermediate level grammar is supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsANSI92IntermediateSQL() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether SQL-92 full level grammar is supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsANSI92FullSQL() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether refererential integrity is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsIntegrityEnhancementFacility() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether outer joins are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOuterJoins() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether full outer joins are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsFullOuterJoins() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether limited outer joins are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsLimitedOuterJoins() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns the term for "Schema".
     * @return "Schema"
     * @throws SQLException if the connection is closed 
     */
	public String getSchemaTerm() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "Schema";
    }
    /**
     * Returns the term for "Procedure".
     * @return "Procedure"
     * @throws SQLException if the connection is closed 
     */
	public String getProcedureTerm() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "Procedure";
    }
    /**
     * Returns the term for "Catalog".
     * @return "Catalog"
     * @throws SQLException if the connection is closed 
     */
	public String getCatalogTerm() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return "Catalog";
    }
    /**
     * Returns whether the catalog is at the beginning.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean isCatalogAtStart() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns the catalog separator.
     * @return "."
     * @throws SQLException if the connection is closed 
     */
	public String getCatalogSeparator() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return ".";
    }
    /**
     * Returns whether the schema name in INSERT, UPDATE, DELETE is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSchemasInDataManipulation() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the schema name in procedure calls is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSchemasInProcedureCalls() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the schema name in CREATE TABLE is supported
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSchemasInTableDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the schema name in CREATE INDEX is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSchemasInIndexDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the schema name in GRANT is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSchemasInPrivilegeDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the catalog name in INSERT, UPDATE, DELETE is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCatalogsInDataManipulation() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the catalog name in procedure calls is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCatalogsInProcedureCalls() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the catalog name in CREATE TABLE is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCatalogsInTableDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the catalog name in CREATE INDEX is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCatalogsInIndexDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the catalog name in GRANT is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCatalogsInPrivilegeDefinitions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether positioned deletes are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsPositionedDelete() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether positioned updates are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsPositionedUpdate() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether SELECT ... FOR UPDATE is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSelectForUpdate() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether stored procedures are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsStoredProcedures() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether subqueries (SELECT) in comparisons are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSubqueriesInComparisons() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether SELECT in EXISTS is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSubqueriesInExists() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether IN(SELECT...) is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSubqueriesInIns() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether subqueries in quantified expression are supported.
     * JDBC compliant drivers are supposed to return true.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsSubqueriesInQuantifieds() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether correlated subqueries are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsCorrelatedSubqueries() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether UNION SELECT is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsUnion() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether UNION ALL SELECT is supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsUnionAll() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether open resultsets accross commits are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOpenCursorsAcrossCommit() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether open resultsets accross rollback are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOpenCursorsAcrossRollback() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether open statements accross commit are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOpenStatementsAcrossCommit() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether open statements accross rollback are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsOpenStatementsAcrossRollback() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether transactions are supported.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsTransactions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether a specific transaction isolation level is supported.
     * Returns true for Connection.TRANSACTION_READ_COMMITTED and 
     * Connection.TRANSACTION_SERIALIZABLE.
     * @return true if the level is supported
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsTransactionIsolationLevel(int level) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),level);
            checkClosed();
            boolean result;
            if(level==Connection.TRANSACTION_READ_COMMITTED ||
                level==Connection.TRANSACTION_SERIALIZABLE) {
                result=true;
            } else {
                result=false;
            }
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns whether data manipulation and CREATE/DROP is supported in transactions.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsDataDefinitionAndDataManipulationTransactions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether only data manipulations are supported in transactions.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsDataManipulationTransactionsOnly() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether CREATE/DROP commit an open transaction.
     * @return true
     * @throws SQLException if the connection is closed 
     */
    public boolean dataDefinitionCausesTransactionCommit() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Returns whether CREATE/DROP do not affect transactions.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean dataDefinitionIgnoredInTransactions() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether a specific resultset type is supported.
     * Only ResultSet.TYPE_FORWARD_ONLY is supported.
     * @return false for all other types than ResultSet.TYPE_FORWARD_ONLY
     * @throws SQLException if the connection is closed 
     */
    public boolean supportsResultSetType(int type) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId());
            checkClosed();
            boolean result=(type==ResultSet.TYPE_FORWARD_ONLY);
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns whether a specific resultset concurrency is supported.
     * Only type ResultSet.TYPE_FORWARD_ONLY and concurrency 
     * ResultSet.CONCUR_READ_ONLY are supported.
     * @return false if the type is not ResultSet.TYPE_FORWARD_ONLY or
     *               the concurrency is not ResultSet.CONCUR_READ_ONLY
     * @throws SQLException if the connection is closed 
     */
    public boolean supportsResultSetConcurrency(int type, int concurrency) throws SQLException {
        try {
            if(Trace.isEnabled()) Trace.trace(getId(),type+","+concurrency);
            checkClosed();
            boolean result=(
                type==ResultSet.TYPE_FORWARD_ONLY && 
                concurrency==ResultSet.CONCUR_READ_ONLY);
            if(Trace.isEnabled()) Trace.traceResult(result);
            return result;
        } catch(Throwable e) {
            throw convertThrowable(e);
        }
    }
    /**
     * Returns whether own updates are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean ownUpdatesAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether own deletes are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean ownDeletesAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether own inserts are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean ownInsertsAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether other updates are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean othersUpdatesAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether other deletes are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean othersDeletesAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether other inserts are visible.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean othersInsertsAreVisible(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether updates are dectected.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean updatesAreDetected(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether deletes are detected.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean deletesAreDetected(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether inserts are detected.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean insertsAreDetected(int type) throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId(),type);
        checkClosed();
        return false;
    }
    /**
     * Returns whether batch updates are supported.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean supportsBatchUpdates() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns whether the maximum row size includes blobs.
     * @return false
     * @throws SQLException if the connection is closed 
     */
    public boolean doesMaxRowSizeIncludeBlobs() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns the default transaction isolation level.
     * @return Connection.TRANSACTION_READ_COMMITTED
     * @throws SQLException if the connection is closed 
     */
	public int getDefaultTransactionIsolation() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return Connection.TRANSACTION_READ_COMMITTED;
    }
    /**
     * Checks if for CREATE TABLE Test(ID INT), getTables returns Test as the table name.
     * JDBC compliant drivers must return false.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsMixedCaseIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Checks if a table created with CREATE TABLE "Test"(ID INT) 
     * is a different table than a table created with CREATE TABLE TEST(ID INT).
     * JDBC compliant drivers must return true.
     * SQLServer 2000 doesn't support it. 
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean supportsMixedCaseQuotedIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Checks if for CREATE TABLE Test(ID INT), getTables returns TEST as the table name.
     * @return true
     * @throws SQLException if the connection is closed 
     */
	public boolean storesUpperCaseIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Checks if for CREATE TABLE Test(ID INT), getTables returns test as the table name.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean storesLowerCaseIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Checks if for CREATE TABLE Test(ID INT), getTables returns Test as the table name.
     * @return false
     * @throws SQLException if the connection is closed 
     */
	public boolean storesMixedCaseIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Checks if for CREATE TABLE "Test"(ID INT), getTables returns TEST as the table name.
     * @return true (actually, quoted names are not supported)
     * @throws SQLException if the connection is closed 
     */
	public boolean storesUpperCaseQuotedIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return true;
    }
    /**
     * Checks if for CREATE TABLE "Test"(ID INT), getTables returns test as the table name.
     * @return false (actually, quoted names are not supported)
     * @throws SQLException if the connection is closed 
     */
	public boolean storesLowerCaseQuotedIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Checks if for CREATE TABLE "Test"(ID INT), getTables returns Test as the table name.
     * @return false (actually, quoted names are not supported)
     * @throws SQLException if the connection is closed 
     */
	public boolean storesMixedCaseQuotedIdentifiers() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return false;
    }
    /**
     * Returns the maximum length for hex values (characters).
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxBinaryLiteralLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length for literals.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxCharLiteralLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length for column names.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum number of columns in GROUP BY.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnsInGroupBy() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of columns in CREATE INDEX.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnsInIndex() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of columns in ORDER BY.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnsInOrderBy() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of columns in SELECT.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnsInSelect() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of columns in CREATE TABLE.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxColumnsInTable() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of open connection.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxConnections() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length for a cursor name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxCursorNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum length for an index (in bytes).
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxIndexLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum length for a schema name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxSchemaNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum length for a procedure name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxProcedureNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum length for a catalog name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxCatalogNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum size of a row (in bytes).
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxRowSize() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length of a statement.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxStatementLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum number of open statements.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxStatements() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length for a table name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxTableNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    /**
     * Returns the maximum number of tables in a SELECT.
     * @return 0 for limit is unknown
     * @throws SQLException if the connection is closed 
     */
	public int getMaxTablesInSelect() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 0;
    }
    /**
     * Returns the maximum length for a user name.
     * @return 30
     * @throws SQLException if the connection is closed 
     */
	public int getMaxUserNameLength() throws SQLException {
        if(Trace.isEnabled()) Trace.trace(getId());
        checkClosed();
        return 30;
    }
    
    /**
     * Gets the underlying meta data object.
     * This method should only be called if functionality is required
     * that is not yet implemented in LDBC, or for testing.
     *
     * @return the underlying DatabaseMetaData object
     */
    public DatabaseMetaData getVendorObject() {
        return meta;
    }

    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsSavepoints() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsNamedParameters() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsMultipleOpenResults() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsGetGeneratedKeys() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public ResultSet getSuperTypes(String catalog, String schemaPattern, String typeNamePattern) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public ResultSet getSuperTables(String catalog, String schemaPattern, String tableNamePattern) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public ResultSet getAttributes(String catalog, String schemaPattern, String typeNamePattern, String attributeNamePattern) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsResultSetHoldability(int holdability) throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getResultSetHoldability() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getDatabaseMajorVersion() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getDatabaseMinorVersion() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getJDBCMajorVersion() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getJDBCMinorVersion() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public int getSQLStateType() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean locatorsUpdateCopy() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }
    /**
     * THIS FEATURE IS NOT SUPPORTED.
     * @throws SQLException Unsupported Feature (SQL State 0A000) 
     */
    public boolean supportsStatementPooling() throws SQLException {
        throw Factory.getUnsupportedException(); 
    }    

// =============================================================    

    
    jdbcDatabaseMetaData(jdbcConnection conn,DatabaseMetaData meta) {
        this.conn=conn;
        this.adapter=conn.adapter;
        this.meta=meta;
    }
    static String getFirstLine(String s) {
        if(s==null) {
            s="";
        }
        for(int i=0;i<s.length();i++) {
            char c=s.charAt(i);
            if(c<' ') {
                return s.substring(0,i);
            }
        }
        return s;
    }
    String getSchema() throws SQLException {
        return conn.getAdapter().getDefaultSchema();
    }
    void checkValidNamePattern(String s) throws SQLException {
        if(s==null) {
            return;
        }
        if(s.length()==0) {
            throw Factory.getInvalidValueException("length:0");
        }
        char first=s.charAt(0);
        if((first>='0' && first<='9')) {
            throw Factory.getInvalidValueException("s:<"+s+">");
        }
        int len=s.length();        
        for(int i=0;i<len;i++) {
            char c=s.charAt(i);
            // the _ is a valid character, but also a wildcard.
            // may not process wildcards properly (need to test)
            if(c=='\\') {
                if(i>=len) {
                    throw Factory.getInvalidValueException("s:<"+s+">");
                }
                c=s.charAt(++i);
                if(c!='_') {
                    throw Factory.getInvalidValueException("s:<"+s+">");
                }
            } else if(c=='_' || c=='%') {
                // wildcards - ok
            } else if((c<'A' || c>'Z') && (c<'0' || c>'9')) {
                throw Factory.getInvalidValueException("s:<"+s+">");
            }
        }
    }
    void checkValidName(String s) throws SQLException {
        if(s==null || s.length()==0) {
            throw Factory.getInvalidValueException("s:"+s);
        }
        char first=s.charAt(0);
        if(first<'A' || first>'Z') {
            throw Factory.getInvalidValueException("s:"+s);
        }
        int len=s.length();        
        for(int i=1;i<len;i++) {
            char c=s.charAt(i);
            if((c<'A' || c>'Z') && (c<'0' || c>'9') && c!='_') {
                throw Factory.getInvalidValueException("s:"+s);
            }
        }
    }
    boolean testTable(String tableName) {
        if(adapter.isSystemTable(tableName)) {
            return false;
        }
        return true;
    }
    static boolean testPattern(String text,String pattern) {
        if(pattern==null) {
            return true;
        }
        if(text==null) {
            text="";
        }
        return testPatternSub(text.toCharArray(),0,pattern.toCharArray(),0);
    }
    static boolean testPatternSub(char text[], int textIndex, char pattern[], int patternIndex) {
        int textLen = text.length;
        int patternLen = pattern.length;
        for (;patternIndex < patternLen; patternIndex++) {
            char p = pattern[patternIndex];
            if (p == '%') {
                if (++patternIndex >= patternLen) {
                    return true;
                }
                while (textIndex < textLen) {
                    if (testPatternSub(text, textIndex, pattern, patternIndex)) {
                        return true;
                    }
                    textIndex++;
                }
                return false;
            } else if (p == '_') {
                if (textIndex++ >= textLen) {
                    return false;
                }
            } else {
                if (p == '\\') {
                    p = pattern[++patternIndex];
                }
                if (textIndex >= textLen || p != text[textIndex++]) {
                    return false;
                }
            }
        }
        return textIndex == textLen;
    }
    void checkClosed() throws SQLException {
        if(conn.closed) {
            throw Factory.getClosedException();
        }
    }
    String getId() {
        return "dbmeta"+id;
    }
    SQLException convertThrowable(Throwable e) {
        SQLException x=adapter.convertThrowable(e);
        if(Trace.isEnabled()) Trace.traceException(x);
        return x;
    }
    String getPrimaryKeyName(String catalog,String schema,String table) throws SQLException {
        String pkname=null;
        ResultSet rspkname=meta.getPrimaryKeys(catalog,schema,table);
        if(rspkname.next()) {
            pkname=rspkname.getString(6).toUpperCase();
        }
        pkname=adapter.truncateIndexName(pkname);
        return pkname;
    }
}

