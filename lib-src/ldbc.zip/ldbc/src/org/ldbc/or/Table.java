/*
 * Copyright (c) 2003 LDBC Group.  
 * All rights reserved.
 * 
 * For more information on LDBC, please visit
 * http://ldbc.sourceforge.net
 * 
 */
package org.ldbc.or;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.util.*;
import java.lang.reflect.*;

class Table {

    String map;
    private Database database;
    private Connection conn;
    private String tableName;
    private Class classObject;
    private Hashtable fieldMap;
    private Hashtable columnMap;
    private Column[] columnsPk;
    private Column[] columnsData;
    private Column[] columns;
    private Column autoIncrement;
    private PreparedStatement update, insert, select, delete, insertAuto, getAutoKey;
    private String selectHeader;
    private Constructor constrNoParams;
    private Constructor constrWithDatabase;

    Table(Database db, String name, Class c, ArrayList columnList, String map) {
        this.database = db;
        tableName = name;
        classObject = c;
        fieldMap = new Hashtable();
        columnMap = new Hashtable();
        for (int i = 0; i < columnList.size(); i++) {
            Column column = (Column) columnList.get(i);
            fieldMap.put(column.fieldName.toUpperCase(), column);
            columnMap.put(column.columnName.toUpperCase(), column);
        }
        initColumns(columnList);
        initConstructor(c);
        conn = db.getConnection();
        this.map = map;
        createIfRequired();
        initPreparedStatements();
    }

    /*
    private String translateFieldsToColumns(String filter) {
        StringTokenizer tok = new StringTokenizer(filter,
                ":;,.()+=><!'%&/* \t\n\r\f", true);
        StringBuffer buffer = new StringBuffer();
        boolean inString = false;
        while (tok.hasMoreElements()) {
            String token = tok.nextToken();
            if (token.equals("'")) {
                inString = !inString;
            }
            if (inString) {
                buffer.append(token);
            } else {
                Column column = (Column) fieldMap.get(token.toUpperCase());
                if (column != null) {
                    buffer.append(column.columnName);
                } else {
                    buffer.append(token);
                }
            }
        }
        return buffer.toString();
    }
    */

    private void initConstructor(Class c) {
        Constructor[] constructors = c.getConstructors();
        for (int i = 0; i < constructors.length; i++) {
            Constructor constr = constructors[i];
            Class[] params = constr.getParameterTypes();
            if (params.length == 0) {
                constrNoParams = constr;
            } else if (params.length == 1) {
                if (params[0] == Database.class) {
                    constrWithDatabase = constr;
                }
            }
        }
        if (constrWithDatabase != null) {
            // the constructor with the database has priority
            constrNoParams = null;
        } else {
            DatabaseException
                    .check(
                            constrNoParams != null,
                            "The class "
                                    + c.getName()
                                    + " does not have a public constructor without parameters or one with a Database object as parameter");
        }
    }

    void save(Object obj) {
        int count;
        if (autoIncrement != null) {
            Integer id = (Integer) autoIncrement.get(obj);
            try {
                if (id == null || id.intValue() == 0) {
                    // we have a autoincrement column and the value is 0
                    for (int i = 0, j = 0; i < columns.length; i++) {
                        Column c = columns[i];
                        if (c != autoIncrement) {
                            c.bind(insertAuto, ++j, c.get(obj));
                        }
                    }
                    count = insertAuto.executeUpdate();
                    DatabaseException.check(count == 1,
                            "Error inserting one row (" + tableName
                                    + "); update count is " + count);
                    // ResultSet rs = insertAuto.getGeneratedKeys();
                    ResultSet rs = getAutoKey.executeQuery();
                    rs.next();
                    autoIncrement.set(obj, rs, 1);
                    return;
                }
            } catch (Throwable e) {
                throw new DatabaseException("Error saving object " + obj, e);
            }
        }
        int j = 1;
        for (int i = 0; i < columnsData.length; i++) {
            Column c = columnsData[i];
            c.bind(update, j++, c.get(obj));
        }
        for (int i = 0; i < columnsPk.length; i++) {
            Column c = columnsPk[i];
            c.bind(update, j++, c.get(obj));
        }
        try {
            count = update.executeUpdate();
        } catch (Throwable e) {
            throw new DatabaseException("Error saving object " + obj, e);
        }
        if (count == 1) {
            // update one row, so the row already existed
            return;
        }
        DatabaseException.check(count == 0, "Error updating one row ("
                + tableName + "); update count is " + count);
        for (int i = 0; i < columns.length; i++) {
            Column c = columns[i];
            c.bind(insert, i + 1, c.get(obj));
        }
        try {
            count = insert.executeUpdate();
        } catch (Throwable e) {
            throw new DatabaseException("Error saving object " + obj, e);
        }
        DatabaseException.check(count == 1, "Error inserting one row ("
                + tableName + "); update count is " + count);
    }

    Object loadByKey(Object key) {
        try {
            columnsPk[0].bind(select, 1, key);
            ResultSet rs = select.executeQuery();
            if (!rs.next()) {
                return null;
            }
            Object obj = loadObject(rs, columns);
            DatabaseException.check(!rs.next(), "More records found");
            return obj;
        } catch (Throwable e) {
            throw new DatabaseException("Error loading object by key " + key, e);
        }
    }

    Object createNewObject() {
        try {
            Object obj;
            if (constrWithDatabase != null) {
                obj = constrWithDatabase.newInstance(new Object[] { database});
            } else {
                obj = constrNoParams.newInstance(null);
                // obj=classObject.newInstance();
            }
            return obj;
        } catch (Throwable e) {
            throw new DatabaseException("Error creating new object "
                    + classObject, e);
        }
    }

    Object loadObject(ResultSet rs, Column[] columns) {
        Object obj = createNewObject();
        for (int i = 0; i < columns.length; i++) {
            columns[i].set(obj, rs, i + 1);
        }
        return obj;
    }

    ArrayList loadArrayList(Command query) {
        String sql = query.getSQL();
        if(sql==null) {
            sql="";
        } else {
            sql=sql.trim();
        }
        Column[] columns;
        if(sql.length()==0) {
            columns = this.columns;
            sql = selectHeader;
        } else if(sql.startsWith("ORDER BY")) {
            columns = this.columns;
            sql = selectHeader + " " + sql;
        } else if(sql.startsWith("SELECT")) {
            columns = null;
        } else {
            columns = this.columns;
            sql = selectHeader + " WHERE " + sql;
        }
        PreparedStatement prep;
        try {
            prep = conn.prepareStatement(sql);
        } catch (Throwable e) {
            throw new DatabaseException("Error loading objects using query "
                    + sql, e);
        }
        query.bind(prep);
        ArrayList list = new ArrayList();
        try {
            ResultSet rs = prep.executeQuery();
            
            if(rs.next()) {
                if(columns == null) {
                    ResultSetMetaData meta = rs.getMetaData();
                    int len = meta.getColumnCount();
                    columns = new Column[len];
                    for(int i=0; i<len; i++) {
                        String columnName = meta.getColumnLabel(i+1);
                        Column col = (Column)columnMap.get(columnName.toUpperCase());
                        DatabaseException.check(col!=null, "Column "+columnName+" not found in table "+tableName);
                        columns[i] = col;
                    }
                }
                do {
                    Object obj = loadObject(rs, columns);
                    list.add(obj);
                } while (rs.next());
            }
        } catch (Throwable e) {
            throw new DatabaseException("Error loading objects using query "
                    + sql, e);
        }
        return list;
    }

    boolean delete(Object obj) {
        int j = 1;
        for (int i = 0; i < columnsPk.length; i++) {
            Column c = columnsPk[i];
            c.bind(delete, j++, c.get(obj));
        }
        int count;
        try {
            count = delete.executeUpdate();
        } catch (Throwable e) {
            throw new DatabaseException("Error deleting object " + obj, e);
        }
        if (count == 1) {
            // deleted one row, so the row existed
            return true;
        }
        DatabaseException.check(count == 0, "Error deleting one row ("
                + tableName + "); update count is " + count);
        return false;
    }

    private void initColumns(ArrayList columnList) {
        ArrayList pk = new ArrayList();
        ArrayList data = new ArrayList();
        columns = new Column[columnList.size()];
        columnList.toArray(columns);
        for (int i = 0; i < columns.length; i++) {
            Column c = columns[i];
            if (c.isPrimaryKey()) {
                pk.add(c);
            } else {
                data.add(c);
            }
            if (c.isAutoIncrement()) {
                DatabaseException.check(autoIncrement == null, "More than one possible autoincrement column");
                autoIncrement = c;
            }
        }
        DatabaseException.check(pk.size() != 0, "No primary key defined: "
                + tableName);
        columnsPk = new Column[pk.size()];
        pk.toArray(columnsPk);
        columnsData = new Column[data.size()];
        data.toArray(columnsData);
    }

    private void initPreparedStatements() {
        String sql;
        String columnList = "";
        String columnListAuto = "";
        for (int i = 0; i < columns.length; i++) {
            Column c = columns[i];
            if (i > 0) {
                columnList += ",";
            }
            columnList += c.columnName;
            if (autoIncrement != null && !c.isAutoIncrement()) {
                if (columnListAuto.length() > 0) {
                    columnListAuto += ",";
                }
                columnListAuto += c.columnName;
            }
        }
        String params = "";
        String paramsAuto = "";
        for (int i = 0; i < columns.length; i++) {
            if (i > 0) {
                params += ",";
            }
            params += "?";
            if (autoIncrement != null && !columns[i].isAutoIncrement()) {
                if (paramsAuto.length() > 0) {
                    paramsAuto += ",";
                }
                paramsAuto += "?";
            }
        }
        //store.log(sql);
        sql = "INSERT INTO " + tableName + "(" + columnList + ") VALUES("
                + params + ")";
        try {
            insert = conn.prepareStatement(sql);
            if (autoIncrement != null) {
                sql = "INSERT INTO " + tableName + "(" + columnListAuto
                        + ") VALUES(" + paramsAuto + ")";
                insertAuto = conn.prepareStatement(sql);
            }
            sql = "UPDATE " + tableName + " SET ";
            for (int i = 0, j = 0; i < columns.length; i++) {
                Column c = columns[i];
                if (!c.isPrimaryKey()) {
                    if (j++ > 0) {
                        sql += ",";
                    }
                    sql += c.columnName + "=?";
                }
            }
            String wherePk = "WHERE ";
            for (int i = 0, j = 0; i < columns.length; i++) {
                Column c = columns[i];
                if (c.isPrimaryKey()) {
                    if (j++ > 0) {
                        wherePk += " AND ";
                    }
                    wherePk += c.columnName + "=?";
                }
            }
            sql += " " + wherePk;
            //store.log(sql);
            update = conn.prepareStatement(sql);
            sql = "SELECT " + columnList + " FROM " + tableName + " " + wherePk;
            //store.log(sql);
            select = conn.prepareStatement(sql);
            sql = "DELETE FROM " + tableName + " " + wherePk;
            //store.log(sql);
            delete = conn.prepareStatement(sql);
            selectHeader = "SELECT " + columnList + " FROM " + tableName;
            getAutoKey = conn.prepareStatement("GET AUTOINCREMENT KEY");
        } catch (Throwable e) {
            throw new DatabaseException(
                    "Error initializing table " + tableName, e);
        }
    }

    static boolean doesTableExist(Connection conn, String tableName) {
        try {
            DatabaseMetaData meta = conn.getMetaData();
            //store.log("doesTableExist "+tableName);
            ResultSet rs = meta.getTables(null, null, tableName, null);
            // if there is a row, then the table exists
            return rs.next();
        } catch (Throwable e) {
            throw new DatabaseException(
                    "Error checking for table " + tableName, e);
        }
    }

    private void createIfRequired() {
        if (doesTableExist(conn, tableName)) {
            // table already exists
            // TODO: maybe check if the table in the database is compatible
            // with the class
        } else {
            // table does not yet exist
            String sql = "CREATE TABLE " + tableName + "(";
            for (int i = 0; i < columns.length; i++) {
                Column c = columns[i];
                sql += c.getCreateSQL() + ",";
            }
            sql = sql.substring(0, sql.length() - 1);
            sql += ")";
            //store.log(sql);
            try {
                conn.createStatement().execute(sql);
            } catch (Throwable e) {
                throw new DatabaseException("Error creating table " + tableName
                        + " sql=" + sql, e);
            }
        }
    }

}
